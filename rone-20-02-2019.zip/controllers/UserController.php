<?php

namespace controllers;

use models\User;
use appx\core\Request;

class UserController extends \controllers\BaseController{

   
    function userLogin(){
    	// print_r(Request::session());
    	return $this->view('user/login',[
          'subjects'=>\models\Subject::all()
    	]);
    	
    }

    function userLoginAction(User $user){

       $data = Request::all();	
       $check = $user->login($data['email'],$data['password']);
       if (!empty($check)){
         $r = Request::sessionSet('user_session',$check);
         $user->setSuccess('Welcome admin.(:');
       }else{
         $user->setError('Invalid Login!');   
       }
       $this->setResponse($user->getMessage());
       redirect('user-login');
    }

    function userLogOutAction(User $user){
    	Request::sessionUnSet('user_session');
    	$user->setSuccess('You just logged out.):');
    	$this->setResponse($user->getMessage());
    	redirect('user-login');
    }

    function userDashboard(){
    	return $this->view('user/dashboard');
    }



}