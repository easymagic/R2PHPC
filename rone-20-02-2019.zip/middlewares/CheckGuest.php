<?php 

namespace middlewares;

use appx\core\Request;

class CheckGuest{

   
     function handle($next,$guard=[]){
          
         $sess = Request::session(); 
         
         if ( isset($guard[0]) && isset($sess[$guard[0]]) ){
         	
         	if (isset($guard[1])){
              redirect($guard[1]);
         	}else{
              redirect('/');
         	}

         }


     }


}