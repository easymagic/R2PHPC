<?php 
use appx\core\Route;


Route::get('/default','controllers\Home@index');

// Route::get('/test/(test)','controllers\Home@test',['auth:user,admin']);
Route::get('/test/(test)','controllers\Home@test');

// registerRoute('get','/default','controllers\Home:index');

Route::get('/user-login','controllers\UserController@userLogin',['guest:user_session,user-dashboard']);

Route::get('/user-logout','controllers\UserController@userLogOutAction');


Route::get('/user-dashboard','controllers\UserController@userDashboard',['auth:user_session,user-login']);


Route::post('/user-login','controllers\UserController@userLoginAction');

Route::get('/user-create','controllers\UserController@userCreate');

Route::post('/user-create','controllers\UserController@userCreateAction');

Route::get('/user-change-password/(user)','controllers\UserController@userChangePassword');

Route::post('/user-change-password/(user)','controllers\UserController@userChangePasswordAction');

Route::get('/user-edit-profile/(user)','controllers\UserController@userEditProfile');

Route::post('/user-edit-profile/(user)','controllers\UserController@userEditProfileAction');

Route::get('/user-change-password-other/(user)','controllers\UserController@userChangePasswordOther');

Route::post('/user-change-password-other/(user)','controllers\UserController@userChangePasswordOtherAction');

Route::get('/users','controllers\UserController@index');

//oui



Route::post('/student-profile/(student)','controllers\Home@studentLoginAction');

//User
// registerRoute('post','/user/login/action','controllers\UserController:loginAction');
// registerRoute('post','/user/logout/action','controllers\UserController:logoutAction');

// registerRoute('get','/user/login','controllers\UserController:login');
// registerRoute('get','/user','controllers\UserController:index');
// registerRoute('get','/user/(user)/edit','controllers\UserController:edit');
// registerRoute('get','/user/add','controllers\UserController:add');
// registerRoute('get','/user/change/password/(user)','controllers\UserController:changePassword');


// registerRoute('post','/user/change/password/(user)/action','controllers\UserController:changePasswordAction');



// //Subjects
// registerRoute('get','/subject','controllers\SubjectController:index');
// registerRoute('get','/subject/(subject)/edit','controllers\SubjectController:edit');
// registerRoute('get','/subject/add','controllers\SubjectController:add');
// registerRoute('post','/subject','controllers\SubjectController:create');
// registerRoute('post','/subject/(subject)','controllers\SubjectController:update');
// registerRoute('post','/subject/(subject)/delete','controllers\SubjectController:delete');


// //Test
// registerRoute('get','/test','controllers\TestController:index');
// registerRoute('get','/test/add','controllers\TestController:add');
// registerRoute('post','/test','controllers\TestController:create');

// //Assignment
// registerRoute('get','/assignment','controllers\AssignmentController:index');
// registerRoute('get','/assignment/add','controllers\AssignmentController:add');
// registerRoute('post','/assignment','controllers\AssignmentController:create');



// //Student
// registerRoute('get','/student','controllers\StudentController:index');
// registerRoute('get','/student/(student)/edit','controllers\StudentController:edit');
// registerRoute('get','/student/add','controllers\StudentController:add');

// registerRoute('post','/student','controllers\StudentController:store');
// registerRoute('post','/student/(student)','controllers\StudentController:update');
// registerRoute('post','/student/(student)/delete','controllers\StudentController:delete');
// registerRoute('post','/student/change/password/(student)',
// 	          'controllers\StudentController:changePassword');


// //StudentTest
// // registerRoute('post','/create-student-test','controllers\StudentTestController:store');
// registerRoute('get','/student/test','controllers\StudentTestController:index');
// // registerRoute('get','/student/test/(studentTest)/edit',
// // 	          'controllers\AssignmentController:edit');
// // registerRoute('get','/assignment/add','controllers\AssignmentController:add');

// // registerRoute('post','/update-student-test/(studentTest)','controllers\StudentTestController:update');
// registerRoute('post','/student/test/(studentTest)/delete',
// 	          'controllers\StudentController:delete');


// //StudentAssignment
// registerRoute('get','/student/assignment','controllers\StudentAssignmentController:index');
// // registerRoute('get','/assignment/(test)/edit','controllers\AssignmentController:edit');
// // registerRoute('get','/assignment/add','controllers\AssignmentController:add');

// // registerRoute('post','/create-student-test','controllers\StudentTestController:store');
// // registerRoute('post','/update-student-assignment/(studentAssignment)','controllers\StudentAssignmentController:update');
// // registerRoute('post','/delete-student-assignment/(studentAssignment)','controllers\StudentAssignmentController:delete');


// ///student-profile
// registerRoute('get','/student/login',
// 	          'controllers\HomeController:login');
// registerRoute('get','/student/profile/(student)',
// 	          'controllers\HomeController:profile');
// registerRoute('get','/student/test/',
// 	          'controllers\HomeController:test');
// registerRoute('get','/student/assignment/',
// 	          'controllers\HomeController:assignment');
// registerRoute('get','/student/test/(studentTest)/show',
// 	          'controllers\HomeController:testShow');
// registerRoute('get','/student/assignment/(studentAssignment)/show',
// 	          'controllers\HomeController:assignmentSubmit');
// registerRoute('get','/student/change/password/(student)/show',
// 	          'controllers\HomeController:changeStudentPasswordProfile');


// registerRoute('post','/student/login',
// 	          'controllers\HomeController:loginAction');

// registerRoute('post','/student/logout',
// 	         'controllers\HomeController:logout');

// registerRoute('post','/student/update/profile/(student)',
// 	          'controllers\HomeController:profileAction');

// registerRoute('post','/student/change/password/profile/(student)',
// 	          'controllers\HomeController:changeStudentPasswordProfileAction');


// registerRoute('post','/student/submit/test/(studentTest)',
// 	          'controllers\HomeController:submitStudentTest');
// registerRoute('post','/student/submit/assignment/(studentAssignment)',
// 	          'controllers\HomeController:submitStudentAssignment');

// // registerRoute('post','/student-submit-test/(test)','controllers\HomeController:submitStudentTest');

// registerRoute('get','/test2/(test)','controllers\Home:test');

