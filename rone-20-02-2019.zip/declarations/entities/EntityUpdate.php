<?php
namespace declarations\entities;

class EntityUpdate extends \declarations\Db{


   
    function Update($table,$id,$data=array()){
      $this->SetWhere("id=$id");
      $this->DbUpdate($table,$data);
      return array(
        'error'=>false,
        'message'=>'saved'
      );
    }


}