<?php 
namespace declarations\entities;

class EntityAll extends \declarations\Db{


    function All($table){
      return $this->DbGet($table);
    }

}