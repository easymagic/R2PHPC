<?php 
namespace declarations;

class Db{

private static $db_server = DB_SERVER;
private static $db_username = DB_USERNAME;
private static $db_password = DB_PASSWORD;
private static $db_databasename = DB_DATABASENAME;


private $db_table = '';
private $db_cols = '*';
private $db_where = [];
private $db_group = '';
private $db_having = '';
private $db_sort = '';
private $db_limit = '';

private $db_values;
private $db_set;

private $db_records;
private $db_intermediate_record;
private $db_sql;
private static $db_connection = null;
private $db_query;
private $db_query_log;

public $newID = 0;



// $db_server = 'localhost';
// $db_username = 'turboer1_user';
// $db_password = 'Gr;[ntX9sEkf';
// $db_databasename = 'turboer1_db';


// $db_table = '';
// $db_cols = '*';
// $db_where = '';
// $db_group = '';
// $db_having = '';
// $db_sort = '';
// $db_limit = '';

// $db_values = '';
// $db_set = '';

// $db_records = array();
// $db_intermediate_record = array();
// $db_sql = '';
// $db_connection = null;
// $db_query = null;

// $db_query_log = array();

function Silent(){}



private static function dbGetConnection(){
  // private $db_connection;
  // private $db_username;
  // private $db_password;
  // private $db_databasename;
  // private $db_server;

	if (self::$db_connection == null){
	 self::$db_connection = mysqli_connect(self::$db_server,
	                                 self::$db_username,
	                                 self::$db_password,
	                                 self::$db_databasename); // or die('Error in connection.');
	}
   
  return self::$db_connection; 
}


// private $db_table = '';
// private $db_cols = '*';
// private $db_where = '';
// private $db_group = '';
// private $db_having = '';
// private $db_sort = '';
// private $db_limit = '';


function setTable($v){
 $this->db_table = $v;
}

function setCols($v){
 $this->db_cols = $v;
}

function setWhere($v){
 $this->db_where[] = " $v ";
 // $this->db_where = " WHERE $v ";
}

function getWhere(){
  return $this->db_where;
} 

function setGroup($v){
 $this->db_group = $v;
}

function setHaving($v){
 $this->db_having = $v;
}

function setSort($v){
 $this->db_sort = $v;
}

function setLimit($v){
 $this->db_limit = $v;
}

function setSQL($sql){
 $this->db_sql = $sql;
}

function getSQL(){
  return $this->db_sql;
}

function dbResetVars(){
 // private $db_table;
 // private $db_cols;
 // private $db_where;
 // private $db_group;
 // private $db_having;
 // private $db_sort;
 // private $db_limit;
 // private $db_values;
 // private $db_set;

	$this->db_table = '';
	$this->db_cols = '*';
	$this->db_where = [];
	$this->db_group = '';
	$this->db_having = '';
	$this->db_sort = '';
	$this->db_limit = '';

	$this->db_values = '';
	$this->db_set = '';

}


function dbExecQuery(){
 // private $db_sql;
 // private $db_query;
 // private $db_query_log;

 // $db_sql = $sql;
 $this->db_query_log[] = $this->db_sql;

 $this->db_query = mysqli_query(Db::dbGetConnection(),$this->db_sql); 

 $this->dbResetVars(); //reset vars.

 // CallAction('DbResetVars');
 
 return $this->db_query;
}

function dbGet($table){
  return $this->dbRead($table);
}

function resolveWhere(){
 $where = '';
 if (!empty($this->db_where)){
   $where = "WHERE " . implode(' and ', $this->db_where);   
 }
 return $where;  
}


function dbRead($table){
 // private $db_table;
 // private $db_cols;
 // private $db_where;
 // private $db_group;
 // private $db_having;
 // private $db_sort;
 // private $db_limit;

 // private $db_sql;
 // private $db_query;
 // private $db_records;
 // private $db_intermediate_record;

 $this->db_table = $table;
 
 $where = $this->resolveWhere();
 // if (!empty($this->db_where)){
 //   $where = "WHERE " . implode(' and ', $this->db_where);   
 // }

 $this->db_sql = "SELECT $this->db_cols FROM $this->db_table $where $this->db_group $this->db_having $this->db_sort $this->db_limit";

// echo $this->db_sql;

 $this->dbExecQuery();

 

 $this->db_records = array();

 // echo $db_sql;

    
    while ($this->db_intermediate_record = mysqli_fetch_object($this->db_query,get_class($this))){

      // CallAction($table . '_GetIntermediateRecord');	

      $this->db_records[] = $this->db_intermediate_record;

    }

    // print_r($r);
    return $this->db_records;
 
}

function dbGetCreateParams($data){
	// private $db_values;
	// private $db_cols;

	$keys = array_keys($data);
	$values = array_values($data);

	$this->db_cols = implode(',', $keys);

	foreach ($values as $k=>$v){
      $values[$k] = "'$v'";
	}

	$this->db_values = implode(',', $values);

}

function dbGetUpdateParams($data){
  
  // private $db_set;

  $r = array();
  foreach ($data as $k=>$v){
    $r[] = "$k='$v'";
  }

  $this->db_set = implode(',', $r);

}

function dbCreate($table,$data_){
  // private $db_table;
  // private $db_cols;
  // private $db_values;
  // private $db_sql;
  // private $newID;
  // private $data;

  // if (!isset($data['error'])){
  //   $data['error'] = false;
  // }
  
  $this->db_table = $table;
  $this->dbGetCreateParams($data_);

  $this->db_sql = "INSERT INTO $this->db_table ($this->db_cols) VALUES ($this->db_values)";

  // CallAction($db_table . '_BeforeCreate');

  // if (!$data['error']){
    $this->dbExecQuery();
    $this->newID = mysqli_insert_id(Db::dbGetConnection());
  // }
    return $this->newID;


}

function dbUpdate($table,$data){

  // private $db_table;
  // private $db_set;
  // private $db_sql;
  // private $db_where;
  
  $this->db_table = $table;
  $this->dbGetUpdateParams($data);

  $where = $this->resolveWhere();

  $this->db_sql = "UPDATE $this->db_table SET $this->db_set $where";

  $this->dbExecQuery();


}

function dbDelete($table){

  // private $db_table;
  // private $db_sql;
  // private $db_where;

  $this->db_table = $table;

  $where = $this->resolveWhere();

  $this->db_sql = "DELETE FROM $this->db_table $where";

  $this->dbExecQuery();

}


}