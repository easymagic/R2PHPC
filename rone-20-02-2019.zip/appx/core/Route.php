<?php 
namespace appx\core;



class Route{
   
   private static $registered_Routes = [];
   private static $middle_wares = [];
   private static $named_middle_wares = [];

   static function registerMiddleware($middleware){
    self::$middle_wares[] = $middle_wares;
   }

   static function registerNamedMiddleware($name,$middleware){
    self::$named_middle_wares[$name] = $middleware;
   }
   
   static function get($route,$ctrl,$middlewares=array()){
    self::registerRoute('get',$route,$ctrl,$middlewares);
   }

   static function post($route,$ctrl,$middlewares=array()){
     self::registerRoute('post',$route,$ctrl,$middlewares);
   }

   private static function registerRoute($method,$route,$ctrl,$middlewares=array()){
    
    $route = self::cleanRouteString($route);

    $r = explode('/', $route);
    $len = count($r);
    $node = $r[0];
    $salt = $node . ',' . $len . ',' . $method;
    if (!isset(self::$registered_Routes[$salt])){
        self::$registered_Routes[$salt] = array(
          'routes'=>array(),
          'duplicates'=>array(),
          'controller'=>array(),
          'middlewares'=>array()
        );
    }

    if (!in_array($route, self::$registered_Routes[$salt]['duplicates'])){
      self::$registered_Routes[$salt]['duplicates'][] = $route;
      self::$registered_Routes[$salt]['routes'][] = $r;
      self::$registered_Routes[$salt]['controller'][] = $ctrl;
      self::$registered_Routes[$salt]['middlewares'] = $middlewares;
    }    
   }


   static function cleanRouteString($in_Route){
     if (substr($in_Route, 0,1) == '/'){
        $in_Route = substr($in_Route, 1);
     }
     
     if (substr($in_Route, strlen($in_Route) - 1,1) == '/'){
        $in_Route = substr($in_Route, 0,strlen($in_Route) - 1);
     }
     return $in_Route;
   }



     static function routeParamIsArg($v){
       return (substr($v, 0,1) == '(');
     }

     static function routeGetParamVar($v){
      $r = substr($v, 1);
      $r = substr($r, 0,strlen($r) - 1);
      return $r;
     }

     static function runRoute(){

        $__method__ = 'get';
        if (isset($_POST) && !empty($_POST)){
         $__method__ = 'post';
        }

        //__request__
        if (empty($_REQUEST['__request__'])){
          $_REQUEST['__request__'] = 'default';
        }
        
        return self::matchRoute($__method__,$_REQUEST['__request__']); 

     }


     static function matchRoute($method,$in_Route){
       // global $__registered_Routes__;

       $in_Route = self::cleanRouteString($in_Route);
       
       $route_Collection = explode('/', $in_Route);

       $len = count($route_Collection);
       $node = $route_Collection[0];
       $salt = $node . ',' . $len . ',' . $method;
       $track = -1;
       $matched = false;
       $args = array();
       $argsNames = array();

       $r_ = '';

       if (isset(self::$registered_Routes[$salt])){


         foreach (self::$registered_Routes[$salt]['routes'] as $k=>$v){
           
             $checksum_Length = array();
             $checksum_Original_Length = sizeof($v);

           foreach ($v as $kk=>$vv){

             foreach ($route_Collection as $k1=>$v1){
              
               if (self::routeParamIsArg($vv)){ // $vv == '(arg)'
                 $checksum_Length[] = 1;  
                 $args[] = $route_Collection[$kk];
                 $argsNames[] = self::routeGetParamVar($vv);
                 
                 break;
               }else if ($vv == $v1){
                 
                 $checksum_Length[] = 1;
                 
                 break;
               }

             }

             if ($checksum_Original_Length == sizeof($checksum_Length)){
               $track = $k;
               $matched = true;
               break;
             }

           }

         }

         if ($matched){
           $middlewares = self::$registered_Routes[$salt]['middlewares'];
           $r_ = self::evaluateController(self::$registered_Routes[$salt]['controller'][$track],$args,$argsNames,$middlewares);

         }else{
           throw new \Exception("404 Matched Page Not Found!");
         } 
         

       }else{
         throw new \Exception("404 Page Not Found!");
       }

       return $r_;
     }



     static function loadClass($cls){
       return new $cls;
     }

     static function evaluateClass($obj,$method,$args=array()){
        if (is_object($obj) && method_exists($obj, $method)){
          return call_user_func_array(array($obj,$method), $args);
        }else{
          return '';
        }
     }


     static function evaluateStringClass($classString,$args=array(),$argsNames=array()){

      $classString = explode('@', $classString);
      $method = 'index';
      if (count($classString) > 1){
        $method = $classString[1];
        $classString = $classString[0];
      }else{
        $classString = $classString[0];
      }
       

       return \reflect\MethodReflect::autoInjectParams($classString,$method,$argsNames,$args);


     }

     static function evalMiddleware($obj,$potatoe,$options=[]){
        $r = null;
        if (method_exists($obj, 'handle')){
          $r = call_user_func_array(array($obj,'handle'), array($potatoe,$options));
        }else{
          throw new Exception("Invalid middleware signature!");
        }
        return $r;
     }

     static function evaluateController($classString,$args=array(),$argsNames=array(),$middlewares=array()){
        
        //Run middlewares first.
      
        // global $__middle_wares__;
        // global $__named_middle_wares__;
        
        $potatoe = array(
         'request'=>$_REQUEST,
         'post'=>$_POST,
         'files'=>$_FILES,
         'session'=>$_SESSION
        );
        
        foreach (self::$middle_wares as $k=>$v){
          $potatoe = self::evalMiddleware(new $v,$potatoe); // (new $v)->handle($potatoe);
        }


        foreach ($middlewares as $k=>$v){
          $r = explode(':', $v);
          $options = [];
          if (isset($r[1])){
           $options = explode(',', $r[1]);
          }
          $v = $r[0];
          if (isset(self::$named_middle_wares[$v])){
             $cls = self::$named_middle_wares[$v];
             $potatoe = self::evalMiddleware(new $cls,$potatoe,$options);
          }
        }

        return self::evaluateStringClass($classString,$args,$argsNames);

     }



     static function redirect($url,$absolute=false){

        if (!$absolute){
          $url = BASE_URL . $url;
        }

        header('location: ' . $url);
        exit();

     }





}

