<?php 

namespace models;

class BaseModel extends \rone\Model{


	private $modelMessage = [];


	function setError($msg){
     $this->modelMessage['message'] = $msg;
     $this->modelMessage['error'] = true;
	}

	function setSuccess($msg){
     $this->modelMessage['message'] = $msg;
     $this->modelMessage['error'] = false;
	}

	function getMessage(){
		return $this->modelMessage;
	}






}