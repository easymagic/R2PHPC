<?php 

namespace models;

class Test extends \rone\Model{
  
  protected $table = 'test';

  
  function subject(){
    return $this->belongsTo(\models\Subject::class,'subject_id');
  }

  function studentTests(){
    return $this->hasMany(\models\StudentTest::class,'test_id');
  }

  



}