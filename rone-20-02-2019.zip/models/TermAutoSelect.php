<?php

namespace models; 

class TermAutoSelect{
  
  private static $months = array(
   'Jan'=>1,
   'Feb'=>2,
   'Mar'=>3,
   'Apr'=>4,
   'May'=>5,
   'Jun'=>6,
   'Jul'=>7,
   'Aug'=>8,
   'Sep'=>9,
   'Oct'=>10,
   'Nov'=>11,
   'Dec'=>12
  );


  private static $terms = array('first-term','second-term','third-term','Holiday');

  private static $currentTerm = '';  


  static function getTerms(){
    $r = self::$terms;
    unset($r[count($r) - 1]);
    return $r;
  }

  static function getCurrentTerm(){

    $day = +date('d');
    $month = +date('m');
    $year = +date('y');

    if ($month >= self::$months['Sep'] && $month <= self::$months['Dec']){
     self::$currentTerm = self::$terms[0];
    }else if ($month >= self::$months['Jan'] && $month <= self::$months['Apr']){
     self::$currentTerm = self::$terms[1];
    }else if ($month >= self::$months['May'] && $month <= self::$months['Jul']){
     self::$currentTerm = self::$terms[2];
    }else{
     self::$currentTerm = self::$terms[3];  	
    }

    return self::$currentTerm;
  }
  

}