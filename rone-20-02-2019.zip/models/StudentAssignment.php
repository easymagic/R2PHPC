<?php 

namespace models;

class StudentAssignment extends \rone\Model{
  
  protected $table = 'student_assignment';

  
  function assignment(){
   return $this->belongsTo(\models\Assignment::class,'assignment_id');	
  }

  function student(){
   return $this->belongsTo(\models\Student::class,'student_id');		
  }

  



}