<?php 

namespace models;

class StudentTest extends \rone\Model{
  
  protected $table = 'student_test';

  
  function test(){
    return $this->belongsTo(\models\Test::class,'test_id');   
  }

  function student(){
  	return $this->belongsTo(\models\Student::class,'student_id');    
  }

  



}