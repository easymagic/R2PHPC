<?php

namespace models;

class ClassLoad{

  
  static function getClassMap(){

  	$classes = array();

  	$classes['beginners-class'] = 'kindergatten';
  	$classes['kindergatten'] = 'nusery-1';
  	$classes['nursery-1'] = 'nursery-2';
  	$classes['nursery-2'] = 'basic-1';
  	$classes['basic-1'] = 'basic-2';
  	$classes['basic-2'] = 'basic-3';
  	$classes['basic-3'] = 'basic-4';
  	$classes['basic-4'] = 'basic-5';
  	$classes['basic-5'] = 'graduate';
  	$classes['graduate'] = 'graduate';

    return $classes;

  }

  static function getClasses(){
     $r = self::getClassMap();
     $r = array_keys($r);
     unset($r[count($r) - 1]);
     return $r;
  }

  static function getNextClass($cls){
     $data = self::getClassMap();
     if (isset($data[$cls])){
       return $data[$cls];
     }else{
       return null;
     }
  }



}