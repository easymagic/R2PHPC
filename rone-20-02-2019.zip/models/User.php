<?php 

namespace models;

class User extends \models\BaseModel{
  
  protected $table = 'user';


  function login($email,$password){

  	return $this->where('email',$email)->where('password',$password)->getOne();

  }



}