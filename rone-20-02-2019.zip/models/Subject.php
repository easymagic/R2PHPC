<?php 

namespace models;

class Subject extends \rone\Model{
  
  protected $table = 'subject';

  
  function tests(){
   return $this->hasMany(\models\Test::class,'subject_id');		
  }

  function assignments(){
   return $this->hasMany(\models\Assignment::class,'subject_id');		
  }

  function students(){
  	return $this->assignments->students;		
  }

  function testStudents(){
   return $this->tests->students;
  }

  function assignmentStudents(){ 
   return $this->assignments->students;
  }

}