<?php 

namespace models;

class Student extends \models\BaseModel{
  
  protected $table = 'student';

  
  ///relations start
  function assignments(){
   return $this->hasMany(\models\StudentAssignment::class,'student_id');
  }

  function tests(){
   return $this->hasMany(\models\StudentTest::class,'student_id');	
  }
  ///relations stop.


  function login($email,$password){

  }

  function register($data){
    if ($this->checkPassword($data)){
    	unset($data['password_confirm']);
    	$check = $this->accountExists($data['email']);
	    if (!$check){
	      $newID = Student::create($data);
	      $studentData = $this->find($newID);
	      $studentData->uploadPassport();
          $this->setSuccess('Student profile created successfully.'); 
	    }else{
	      $this->setError('An account with this E-mail (' . $check->email . ') already exists!');	

	    }
    }else{
      $this->setError('Invalid Password!');
    }
    return $this->getMessage();
  }

  function accountExists($email){
    return $this->where('email',$email)->getOne();
  }

  function uploadPassport(){
    $obj = \helpers\UploadHelper::factory();
    if ($obj->uploadSucceed('passport','uploads/passport')){
        $this->update([
           'passport'=>$obj->getUploadedFile()
        ]);
    }
  }

  function checkPassword($data){
     return (isset($data['password']) && isset($data['password_confirm']) && !empty($data['password']) && $data['password_confirm'] == $data['password']);
  }

  function changePassword($data){
     if ($this->checkPassword($data)){
       $this->update([
         'password'=>$data['password_confirm']
       ]);
       $this->setSuccess('Password changed successfully.');
     }else{
       $this->setError('Invalid Password!');	
     }
     return $this->getMessage();
  }



  



}