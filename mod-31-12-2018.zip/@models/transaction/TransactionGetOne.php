<?php 
/**

@Inject(@models/entityv2/EntityReadOne);

*/

class TransactionGetOne{
  

  function GetOne($id){
  	$this->EntityReadOne->ReadOne('transaction',$id);
  }
   

}