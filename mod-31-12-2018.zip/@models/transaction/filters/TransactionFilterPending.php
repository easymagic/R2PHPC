<?php 

class TransactionFilterPending{

  


   function FilterPending(){//
    global $db_where;
   	global $transactionFilters;

   	$transactionFilters[] = "pstatus = 'pending'";
     
    $db_where = " where (" . implode(' or ', $transactionFilters) . ") ";

   }



}