<?php 
/**
@Inject(@models/transaction/TransactionGetList);
*/

class TransactionQueryStatus{

  
   function QueryStatus($interpay_reference){
     global $db_where;
     global $data;

     $this->TransactionGetList->GetList();

     if (isset($data['transaction_data']) && count($data['transaction_data']) > 0){
        $data['transaction_data'] = $data['transaction_data'][0];
        $data['message'] = 'Transaction query successful.';
     }else{
     	$data['message'] = 'Invalid interpay-reference!';
     	$data['error'] = true;
     }
   }


}