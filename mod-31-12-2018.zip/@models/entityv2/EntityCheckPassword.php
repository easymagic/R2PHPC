<?php 

class EntityCheckPassword{



   function CheckPassword(){

	   	global $post;
	   	global $data;

	   	// $data['error'] = false;
	   	// $data['message'] = '';	    
	    if ($post['password1'] != $post['password2'] || empty($post['password1'])){
	      $data['message'] = 'Passwords do not match!';
	      $data['error'] = true;
	    }

     
   }




}