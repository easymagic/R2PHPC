<?php

/**

@Inject(@services/Message,@services/DataAdapter,
        @services/DataDict);

*/


  class Db{
     //@services/Db,
     private static $connection = null;
     private $whereString = '';
     private $limit_ = '';
     private $orderString = '';
     private $relationalString = 'And';
     
     function __construct(){
      $this->InitConnection();
     }


     private function ResetFilters(){
      $this->whereString = '';
      $this->limit_ = '';
      $this->orderString = '';
     }

     private function InitConnection(){
       if (self::$connection == null){
         self::$connection = mysqli_connect('localhost',
                                            'root',
                                            '',
                                            'db_interpay'); // or die('Error in connection.');

         // echo self::$connection;
       }
     }

     private function get_criteria_clause($where,$sep=' = ',$comparator=' and '){
       $r = array();

       foreach ($where as $k=>$v){
         $r[] = " $k $sep '$v' ";
       }

       if (!empty($r)){
          return ' where (' . implode($comparator, $r) . ') ';
       }else{
          return '';
       }
     }

     private function get_insert_query($data){
      
      $keys = array_keys($data);
      $values = array_values($data);

      return "(" . implode(',', $keys) . ") values ('" . implode("','", $values) . "')";

     }

     private function get_update_query($data){
      $r = array();
      foreach ($data as $k=>$v){
        // $v = mysqli_escape_string($v,self::$connection);
        $r[] = " $k = '$v' ";
      }
      return ' set ' . implode(' , ', $r) . ' ';
     }

     private function exec_query($sql){
      // echo "$sql";
      $this->ResetFilters();//this avoids conflict with other queries.   
      return  mysqli_query(self::$connection,$sql);
     }

     private function query_result($query){
      $r = array();
    while ($data = mysqli_fetch_assoc($query)){
          $r[] = $data;
    }

    // $r = $this->ReMapFields($r);

     // print_r($r);
    return $r;
     }
   

 private function record_retrieve_query($sql){
  $sql = $sql . ' ' . $this->orderString . ' ' . $this->limit_;
  // echo $sql;
  return $sql;
 }   

 function Get($table,$cols='*'){
   
   $sql = $this->record_retrieve_query("select $cols from $table " . $this->whereString);

    // echo $sql . '<br />';


   return $this->query_result($this->exec_query($sql));

 }

 function SetWhereString($whereString){
  $this->whereString = ' where ' . $whereString;
 }

 private function InterpolateQuotes($sep,$v){
  // $r = explode($sep, $v);
  $v = ltrim($v);
  $v = substr($v, strlen($sep));
  $v = trim($v);
  return " $sep '$v' ";
 }

 private function StartsWith($sep,$v){
   $v = trim($v);
   return (substr($v, 0,strlen($sep)) == $sep);
 }

 private function DecodeCompareValue($v){
   $r = '';
   $v = ltrim($v);
   if ($this->StartsWith('=',$v)){
    $r = $this->InterpolateQuotes('=',$v);
   }else if ($this->StartsWith('<=',$v)){
    $r = $this->InterpolateQuotes('<=',$v);
   }else if ($this->StartsWith('>=',$v)){
    $r = $this->InterpolateQuotes('>=',$v);
   }else if ($this->StartsWith('<',$v)){
    $r = $this->InterpolateQuotes('<',$v);
   }else if ($this->StartsWith('>',$v)){
    $r = $this->InterpolateQuotes('>',$v);
   }else if ($this->StartsWith('like',$v)){
    $r = $this->InterpolateQuotes('like',$v);
   }else{
    // $r = $this->InterpolateQuotes('=',$v);
    $r = ' = ' . "'$v'";
   }
   return $r;
 }
 

 function Where($k,$v){

  // echo $v . "\n";
  // print_r(debug_backtrace());
      
   if (empty($this->whereString)){

     $v = $this->DecodeCompareValue($v);
     $this->whereString = " where $k $v  "; 
     // echo $this->whereString;
     return $this;

   }else{
    
    $join = $this->relationalString;
    return $this->$join($k,$v);

   }

 }

 function And($k,$v){
  $this->relationalString = 'And';
  if (empty($this->whereString)){
    return $this->Where($k,$v);
  }else{
    $v = $this->DecodeCompareValue($v);
    $this->whereString = $this->whereString . " and $k $v "; 
    return $this;
  }
 }

 function Or($k,$v){
  $this->relationalString = 'Or';
  if (empty($this->whereString)){
    return $this->Where($k,$v);
  }else{
    $v = $this->DecodeCompareValue($v);
    $this->whereString = $this->whereString . " or $k $v "; 
    return $this;
  }  
 }


 function Insert($table,$data){
   $sql = "insert into $table " . $this->get_insert_query($data);
   return $this->exec_query($sql);   
 }

 function Update($table,$data){
   $sql = "update $table " . $this->get_update_query($data) . $this->whereString;
   // echo $sql;
   return $this->exec_query($sql);   
 }

 function Delete($table){
   $sql = "delete from $table " . $this->whereString;
   return $this->exec_query($sql);   
 }

 function InsertID(){
    return mysqli_insert_id(self::$connection); 
 }

 function Limit($page=1,$rpp=11){
  // $limit = ($page - 1) * $rpp;
  $this->limit_ = " limit $page , $rpp ";
  return $this;
 }

 function Order($order){
  $this->orderString = " order by $order ";
  return $this;
 }

 function Query($sql){ //for record retrieval only.
   
   $sql = $this->record_retrieve_query($sql);
   return $this->query_result($this->exec_query($sql));

 }

 function DoCount($table,$alias='recordCount'){
   $sql = $this->record_retrieve_query("select count(*) as $alias from $table " . $this->whereString);
   return $this->query_result($this->exec_query($sql));     
 }


 function DoSum($table,$field,$alias='sumTotal'){
   $sql = $this->record_retrieve_query("select sum($field) as $alias from $table " . $this->whereString);
   // echo "$sql";
   return $this->query_result($this->exec_query($sql));     
 }


 function TableExists($table=''){
  $sql = "show tables";
  // echo 'iiii';
  $record = $this->query_result($this->exec_query($sql));
  $r = array();
  foreach ($record as $k=>$v){
     foreach ($v as $k1=>$v1){
       $r[] = $v1;
     }
  }
  
  return in_array($table, $r);
  
 }




  }
 
 

