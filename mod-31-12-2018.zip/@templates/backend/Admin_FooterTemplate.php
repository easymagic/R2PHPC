<!-- content stop -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0 <!-- 2.3.6 -->
    </div>
    <strong>Copyright &copy; 2018.</strong> All rights
    reserved.
</footer>

<div class="control-sidebar-bg"></div>
