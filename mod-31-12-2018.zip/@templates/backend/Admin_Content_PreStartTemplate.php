<div class="content-wrapper">
<?php 
 if (isset($message)){
 	$cls = 'success';
 	if (isset($error) && $error){
     $cls = 'danger';
 	}
?>
<section class="content-header">
	<div class="row">
		<div class="col-md-4">
			<div class="alert alert-<?php echo $cls; ?>"><?php echo $message; ?></div>
		</div>
	</div>
</section>
<?php 
 }
?>	