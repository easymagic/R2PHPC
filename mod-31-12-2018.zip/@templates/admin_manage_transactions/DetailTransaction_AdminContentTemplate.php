<section class="content-header">
      <h1>
        Transaction Detail
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Transaction Detail</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Transaction Detail</h3>

              <a href="<?php echo BASE_URL; ?>Admin_Manage_Transactions/ListTransaction" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Merchant Reference</label>
                  <input disabled="" type="text"  class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['merchant_reference']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Memo</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['memo']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">InterPAY Reference</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['interpay_reference']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Merchant Feedback Page</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['merchant_feedback_page']; ?>" />
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Amount</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['amount']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">E-mail</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['email']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Date Created</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['date_created']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Payment Status</label>
                  <input disabled="" type="text" class="form-control" id="exampleInputEmail1" placeholder="Setting Name" value="<?php echo $transaction_data['pstatus']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Init-Data</label>
                  <textarea class="form-control"><?php echo $transaction_data['paystack_echo_init_data']; ?></textarea>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Response-Data</label>
                  <textarea class="form-control"><?php echo $transaction_data['paystack_echo_response_data']; ?></textarea>
                </div>




              </div>
              <!-- /.box-body -->

              <!-- <div class="box-footer"> -->
                <!-- <button type="submit" class="btn btn-primary">Save</button> -->
              <!-- </div> -->
            </form>
          </div>


</div>

  <!-- /.col -->
</div>
</section>      