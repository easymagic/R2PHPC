<?php 

/**

@Inject(@plugins/AdminBackEndPlugin,
        @plugins/admin/Admin_Manage_TransactionsPlugin);


*/


class Admin_Manage_Transactions{
  
  function Init(){
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->Admin_Manage_TransactionsPlugin);
  }
  
  function ListTransaction_AdminContent(){}
  function DetailTransaction_AdminContent(){}
  



}
 