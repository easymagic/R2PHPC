<?php 

/**

@Inject(@templates/admin-panel/AdminSideBarTemplate,
        @templates/admin-panel/AdminStartTemplate,
        @templates/admin-panel/AdminStopTemplate,
        @templates/admin-panel/AdminToolBarTemplate,
        @templates/admin-panel/AdminTopBarTemplate,
        @services/Db,
        @services/file/FileUpload);

*/


class PlainBackEndPlugin{

  

  function _AdminStart(){
   global $buffer;
   $buffer.= $this->AdminStartTemplate->View();
  } 

  function _AdminTopBar(){
   global $buffer;
   $buffer.= $this->AdminTopBarTemplate->View();
  }

  function _AdminSideBar(){
   global $buffer;
   $buffer.= $this->AdminSideBarTemplate->View();
  }

  // function _AdminToolBar(){
  //  global $buffer;
  //  $buffer.= 'AdminToolBar<br />';
  // }

  function _AdminToolBarStop(){
  	global $buffer;
  	global $data;

  	$buffer.= '</section>
<!-- Main content -->
<section class="content">
  <div class="row"> 
  	';

  	if (isset($data['message'])){
  		$cls = 'success';

  		if (isset($data['error']) && $data['error'] === true){
          $cls = 'danger';
  		}

		  $buffer.='	
		  	  <div class="col-md-8">
		  	  <div class="alert alert-' . $cls . '">
		  	  	' . $data['message'] . '
		  	  </div>	  	  	
		  	  </div>    
		';
  	}


  }

  function _AdminStop(){
   global $buffer;
   $buffer.= $this->AdminStopTemplate->View();
  }



}