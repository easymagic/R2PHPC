<?php 

/**

@Inject(@models/transaction/filters/TransactionFilterFailed,
        @models/transaction/filters/TransactionFilterPending,
        @models/transaction/filters/TransactionFilterSearch,
        @models/transaction/filters/TransactionFilterSettled,
        @models/transaction/filters/TransactionFilterSuccess,
        @models/transaction/filters/TransactionFilterDate,
        @models/transaction/filters/TransactionFilterMerchant,
        @models/transaction/TransactionGetList,
        @models/merchant/MerchantGetList,
        @models/transaction/TransactionGetOne);

*/


class Admin_Manage_TransactionsPlugin{

  
  function Init(){
    global $session;
    global $data;
    global $logged;
    global $session_type;
    global $adminID;
    global $transactionFilters;

    $transactionFilters = array();

    $logged = false;
    $session_type = 'admin';
    
    $data['role'] = '';
    if (isset($session['admin_session'])){
       $data['role'] = $session['admin_session']['role'];
       $logged = true;
       $data['session_type'] = $session_type;
       $adminID = $session['admin_session']['id'];
    }
    $this->CheckFilters();
  }

  private function CheckFilters(){
   global $transactionFilters;
   global $get;

   if (isset($get['pstatus'])){

     if ($get['pstatus'] == 'success'){
      $this->TransactionFilterSuccess->FilterSuccess();
     }else if ($get['pstatus'] == 'pending'){
      $this->TransactionFilterPending->FilterPending();
     }else if ($get['pstatus'] == 'settled'){
      $this->TransactionFilterSettled->FilterSettled();
     }else if ($get['pstatus'] == 'failed'){
      $this->TransactionFilterFailed->FilterFailed();
     }
     
   }

   // if (isset($get['search_text']) && !empty($get['search_text'])){
   //   $this->TransactionFilterSearch->FilterSearch($get['search_text']);
   // }

   if (isset($get['date1']) && isset($get['date2'])){
     $this->TransactionFilterDate->FilterDate($get['date1'],$get['date2']);
   }

   if (isset($get['merchant']) && !empty($get['merchant'])){
     $this->TransactionFilterMerchant->FilterMerchant($get['merchant']);
   }

  }

  
  function ListTransaction_AdminContent(){
     global $db_sql;
     $this->TransactionGetList->GetList();
     $this->MerchantGetList->GetList();
  }

  function DetailTransaction_AdminContent($id){
     $this->TransactionGetOne->GetOne($id);
  }

  function SettleTransaction_Action(){

  }


  function Redirect(){
    global $redirect;
    $redirect = 'ManageSettings/ListSetting';
  }


  function Page_Init(){
    // echo 'Called';
    global $logged;
    global $redirect;

    if (!$logged){
      $redirect = 'Accounts';
    }
  }


    function Page_Destroy(){
      global $session;
      global $data;

      unset($session['data']);
      unset($data['message']);
      unset($data['error']);
    }



}