<?php 
 self::section('inlineLink');
 echo ''; 
 self::endSection();

 self::section('slider');
?>
        <!--HOME SLIDER AREA-->
        <div class="welcome-slider-area">
            <div class="welcome-single-slide slider-bg-one" style="background: url(<?php echo BASE_URL; ?>FE2/events/event1.jpeg) no-repeat scroll center center / cover">
                <!-- bgs/bg3.jpg -->
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1>A Building With Four Walls And Tomorrow Inside.</h1>
                                
<!--                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
 -->                                
<!--                                 <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
 -->                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="welcome-single-slide slider-bg-two" style="background: url(<?php echo BASE_URL; ?>FE2/events/event2.jpeg) no-repeat scroll center center / cover">
                <!-- bgs/bg2.jpg -->
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1>A Great Place For Education.</h1>

<!--                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
 -->                                
<!--                                 <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
 -->                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="welcome-single-slide slider-bg-two" style="background: url(<?php echo BASE_URL; ?>FE2/events/event4.jpeg) no-repeat scroll center center / cover">
                <!-- bgs/bg2.jpg -->
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1>A Great Place For Education.</h1>

<!--                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
 -->                                
<!--                                 <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
 -->                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!--END HOME SLIDER AREA-->
<?php 
 self::endSection();


 self::section('content');
?>


<style type="text/css">
  section{
    padding-top: 0 !important;
    min-height: 512px;
  }
</style>
<style type="text/css">

 .service-content{
   animation-name: fadeIn;font-size: 22px;text-align: justify;    
   line-height: 40px;
 }
    
</style>

    <!--about AREA-->
    <section class="blog-area gray-bg padding-top" id="about">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>About</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">


<img style="width: 240px;border-radius: 50%;float: left;margin-right: 12px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/aboutus.jpg" /> Timberfield was opened to the public on Monday, 13th October, 2014. It was established largely in response to the pressure by members of the host community for a school that will respond to the dynamics of 21st century.
Situated at 45 Bammeke Road Shasha, near Oguntade bus stop.
Timberfield Schools have a history of excellence and distinction in early childhood and Basic education. The Schools runs inclusive education with a Special department that caters for the education of the deaf and hearing child at the levels of Early Childhood / Pre - School and Junior Basic.

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--about AREA END-->

    <!--event AREA-->
    <section class="about-area gray-bg section-padding" id="events">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>Events</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>


<style type="text/css">
  .tg-events img,.tg-events video{
    border-radius: 14px;
  }
</style>

                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="tg-events service-content wow fadeIn">


<div class="col-xs-12 col-md-4">
  <img style="width: 100%;" src="http://timberfieldschoolslagosng.sch.ng/FE2/events/event1.jpeg" />
</div>

<div class="col-xs-12 col-md-4">
  <img style="width: 100%;" src="http://timberfieldschoolslagosng.sch.ng/FE2/events/event2.jpeg" />
</div>


<div class="col-xs-12 col-md-4">
  <video style="max-width: 100%;" controls="1" src="http://timberfieldschoolslagosng.sch.ng/FE2/events/event3.mp4"></video>
</div>


<div class="col-xs-12 col-md-4">
  <img style="width: 100%;" src="http://timberfieldschoolslagosng.sch.ng/FE2/events/event4.jpeg" />
</div>

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--ABOUT AREA END-->










    <!--event AREA-->
    <section class="about-area gray-bg section-padding" id="vision-statement">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>Vision Statement</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">

<img style="width: 240px;border-radius: 50%;float: left;margin-right: 12px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/vision.jpg" />To produce leaders who will excel, compete globally and become contributing members of our community.
                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--ABOUT AREA END-->




    <!--event AREA-->
    <section class="about-area gray-bg section-padding" id="mission-statement">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>Mission Statement</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">

<img style="width: 240px;border-radius: 50%;float: left;margin-right: 12px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/mission.jpg" />In a nurturing and play based environment, our curriculum builds children's self esteem, inspires curiousity, independence, problem solving skill and love for life long learning while fostering respect for themselves and others.

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--ABOUT AREA END-->





    <!--event AREA-->
    <section class="about-area gray-bg section-padding" id="core-values">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>Core Values</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">

<img style="width: 240px;border-radius: 50%;float: left;margin-right: 12px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/corevalues.gif" />
<ul>
  <li>

    <span style="font-size: 60px;float: left;">&bull;&nbsp;</span> Excellence
    <img style="width: 23px;margin-left: 7px;position: relative;top: -2px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/check.png" />

  </li>
  <li>
    <span style="font-size: 60px;float: left;">&bull;&nbsp;</span> Accessibility
    <img style="width: 23px;margin-left: 7px;position: relative;top: -2px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/check.png" />

  </li>

  <li>
    <span style="font-size: 60px;float: left;">&bull;&nbsp;</span> Professionalism
    <img style="width: 23px;margin-left: 7px;position: relative;top: -2px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/check.png" />
  </li>

  <li>
    <span style="font-size: 60px;float: left;">&bull;&nbsp;</span> Integrity
    <img style="width: 23px;margin-left: 7px;position: relative;top: -2px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/check.png" />
  </li>

</ul>

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--ABOUT AREA END-->











    <!--SERVICE AREA-->
    <section class="service-area" id="gallery" style="display: none;">

        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>Gallery</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">


                          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                          consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                          cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                          proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

                        </div>
                    </div>



                </div>
            </div>
        </div>


    </section>
    <!--SERVICE AREA END-->

    <!--PROMO AREA-->
    <section class="promo-area" id="news" style="display: none;">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>News</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">

                          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                          consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                          cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                          proident, sunt in culpa qui officia deserunt mollit anim id est laborum.


                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--PROMO AREA END-->

    <!--TESTMONIAL AREA -->
    <section class="testmonial-area section-padding" id="pta" style="display: none;">
        <div class="service-top-area padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                        <div class="area-title text-center wow fadeIn">
                            <h2>P.T.A</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="service-content wow fadeIn">

                          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                          consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                          cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                          proident, sunt in culpa qui officia deserunt mollit anim id est laborum.



                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--TESTMONIAL AREA END -->








<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

