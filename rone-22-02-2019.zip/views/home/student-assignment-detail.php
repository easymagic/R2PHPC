<?php 
 self::section('headerHeight');

 echo 'height: 17%';

 self::endSection();

 

 self::section('userContent');
?>


<div class="col-xs-12" style="padding: 0;">
   
  
    <div class="form-group" align="right">
      <a href="<?php echo BASE_URL; ?>student-user-assignments/<?php echo $studentAssignment->student->id; ?>" class="btn btn-sm btn-primary">Back</a>
    </div>


      <div class="form-group">
        <u><b>ASSIGNMENT DETAIL (<?php echo $studentAssignment->assignment->subject->name; ?> , 
        	<?php echo $studentAssignment->assignment->subject->term; ?> , 
        	<?php echo $studentAssignment->assignment->subject->class; ?>)</b></u>
      </div>



      <div class="form-group">


<form method="post" action="<?php echo BASE_URL; ?>student-user-assignment/<?php echo $studentAssignment->id ?>/detail">
  

  <div class="form-group" style="margin-bottom: 0;">
     
     <label><u>Question</u> : </label>

  </div>

  <div class="form-group" style="
    border: 1px solid #bbb;background-color: #eee;padding: 9px;font-weight: bold;">
    <p><?php echo $studentAssignment->assignment->content; ?></p>
  </div>
  

   <?php 
     if ($studentAssignment->attended_to){
   ?>

  
  <div class="form-group" style="margin-bottom: 0;">
     
     <label><u>Correction</u> : </label>

  </div>

  <div class="form-group" style="
    border: 1px solid #bbb;background-color: #eee;padding: 9px;font-weight: bold;">
    <p><?php echo $studentAssignment->correction; ?></p>
  </div>

<?php 
   }
?>

  <div class="form-group" style="margin-bottom: 0;">
     
     <label><u>Student Response</u> : </label>

  </div>

    <div class="form-group" style="border: 1px solid #bbb;background-color: #eee;padding: 9px;font-weight: bold;">

    	<textarea placeholder="Your response" name="student_response" class="form-control"><?php echo $studentAssignment->student_response; ?></textarea>
    	
    	

    </div>



   <?php 
     if ($studentAssignment->attended_to){
   ?>
   <div class="form-group">
     <div class="alert alert-warning">
       <b>This test cannot be further edited, it has already been corrected.</b>
     </div>
   </div> 
   <?php 
    }else{
   ?>

   <div class="form-group">
   	<button class="btn btn-success btn-sm">Submit</button>
   </div> 

   <?php 
    }
   ?>
    



</form>










      </div>






</div>


<?php

 self::endSection();


 self::section('content');

  self::extend('frontend/layout.student');

 self::endSection();

 self::extend('frontend/layout.main');
?>

