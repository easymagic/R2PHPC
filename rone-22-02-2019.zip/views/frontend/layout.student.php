<?php 
 use appx\core\Request;
?>
<section class="blog-area gray-bg padding-top" id="about">
        <div class="service-top-area padding-top" style="padding-top: 25px;">
            <div class="container">
                <div class="row">

                    <div class="col-sm-12 col-xs-12 col-md-8 col-md-offset-2">
                      
                      
    <div>
        <?php self::extend('backend/message'); ?>
    </div>  


                                              <div class="area-title text-center wow fadeIn" style="margin-bottom: 0px; visibility: visible; animation-name: fadeIn;">
                            <!-- <h2>Profile</h2> -->
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>


                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-8 col-md-offset-2">
                        <div class="service-content wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                          


<!-- side bar. -->
<div class="col-xs-12 col-md-3">

	 

	 <ul class="list-group">

	 	<li style="padding: 7px;">
	 		<img style="border-radius: 50%;" src="http://timberfieldschoolslagosng.sch.ng/uploads/student/studentpassport/d359733_b-logo.jpg">
	 	</li>

	 	 <li class="list-group-item">
	 	 	 <u><i><b><?php echo $currentTerm; ?></b></i></u>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>student-user-profile/<?php echo Request::sessionGet('student_session')->id; ?>">
	 	 		<b>Profile</b>
	 	 	</a>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>student-user-change-password/<?php echo Request::sessionGet('student_session')->id; ?>">
	 	 		<b>Change Password</b>
	 	 	</a>
	 	 </li>
	 	

	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>student-user-tests/<?php echo Request::sessionGet('student_session')->id; ?>">
	 	 		<b>Tests</b>
	 	 	</a>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>student-user-assignments/<?php echo Request::sessionGet('student_session')->id; ?>">
	 	 		<b>Assignments</b>
	 	 	</a>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a style="color: red;" href="<?php echo BASE_URL; ?>student-user-logout">
	 	 		<b>Log Out</b>
	 	 	</a>
	 	 </li>

	 </ul>


</div>
<div class="col-xs-12 col-md-9">

  <!-- start -->
   

<?php 
 self::yield('userContent','<h3>Welcome User</h3>');
?>


<!-- stop -->
</div>




                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>