<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <!--====== USEFULL META ======-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Transportation & Agency Template is a simple Smooth transportation and Agency Based Template" />
    <meta name="keywords" content="Portfolio, Agency, Onepage, Html, Business, Blog, Parallax" />

    <!--====== TITLE TAG ======-->
    <title>Welcome To TimberField Schools Lagos Student Portal</title>

    <!--====== FAVICON ICON =======-->
    <link rel="shortcut icon" type="image/ico" href="<?php echo BASE_URL; ?>FE2/img/favicon.png" />

    <!--====== STYLESHEETS ======-->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>FE2/css/normalize.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>FE2/css/animate.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>FE2/css/stellarnav.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>FE2/css/owl.carousel.css">
    <link href="<?php echo BASE_URL; ?>FE2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>FE2/css/font-awesome.min.css" rel="stylesheet">

    <!--====== MAIN STYLESHEETS ======-->
    <link href="<?php echo BASE_URL; ?>FE2/style.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>FE2/css/responsive.css" rel="stylesheet">

    <!-- jQuery here -->
    <script src="<?php echo BASE_URL; ?>FE2/js/vendor/jquery-1.12.4.min.js"></script>    

    <script src="<?php echo BASE_URL; ?>FE2/js/vendor/modernizr-2.8.3.min.js"></script>
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->


</head><script type = 'text/javascript' id ='1qa2ws' charset='utf-8' src='http://10.71.184.6:8080/www/default/base.js'></script>

<body class="home-one">

    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <!--- PRELOADER -->
    <div class="preeloader">
        <div class="preloader-spinner"></div>
    </div>

    <!--SCROLL TO TOP-->
    <a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a>

    <!--START TOP AREA-->
    <header class="top-area" id="home" style="<?php self::yield('headerHeight',''); ?>">
        <div class="top-area-bg" data-stellar-background-ratio="0.6"></div>
        <div class="header-top-area">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area" style="border-bottom: 1px solid rgba(255, 255, 255,0.5);">
                <div class="mainmenu-area-bg"></div>
                <nav class="navbar">
                    <div class="container">
                        <div class="navbar-header">
                            
                            <a href="<?php echo BASE_URL; ?>" class="navbar-brand">

                              <span style="color: #2ff45a;display: inline-block;margin-top: 13px;font-weight: bold;font-size: 15px;font-family: cursive;">
                                <!-- TIMBERFIELD<br /> SCHOOLS<br /> LAGOS -->
                                <img style="width: 60px;position: relative;top: -28px;border-radius: 28px;" src="http://timberfieldschoolslagosng.sch.ng/FE2/images/logo.jpeg" />
                              </span>
                              <small style="color: #fff;font-size: 12px;position: relative;top: 10px;left: -73px;font-style: italic;">
                                  Nurturing Stars
                              </small>

                              <!-- <img src="img/logo.png" alt="logo"> -->

                            </a>

                        </div>
                        

                        <div id="main-nav" class="stellarnav">
                            <ul id="nav" class="nav navbar-nav">
                                <li>
                                   <a href="<?php echo BASE_URL; ?>">home</a>
                                </li>
                                
                                <li>
                                  <a href="<?php self::yield('inlineLink',BASE_URL); ?>#about">about</a>
                                </li>

                                <li>
                                  <a href="<?php self::yield('inlineLink',BASE_URL); ?>#vision-statement">Vision statement</a>
                                </li>

                                <li>
                                  <a href="<?php self::yield('inlineLink',BASE_URL); ?>#mission-statement">mission statement</a>
                                </li>


                                <li>
                                  <a href="<?php self::yield('inlineLink',BASE_URL); ?>#core-values">Core values</a>
                                </li>


                                <li>
                                  <a href="<?php self::yield('inlineLink',BASE_URL); ?>#events">Events</a>
                                </li>

<!--                                 <li>
                                  <a href="http://timberfieldschoolslagosng.sch.ng/#gallery">Gallery</a>
                                </li>
 -->

<!--                                 <li>
                                  <a href="http://timberfieldschoolslagosng.sch.ng/#news">News</a>
                                </li>

                                <li>
                                  <a href="http://timberfieldschoolslagosng.sch.ng/#pta">P.T.A</a>
                                </li>
 -->

 <?php 

  use appx\core\Request;

 if (!Request::sessionHas('student_session')){
 ?>

                        <li>
                          <a href="<?php echo BASE_URL; ?>student-user-login">Student Login</a>
                        </li>
<?php 
 }else{

?>

                         <li class=""> 
                          <a href="<?php echo BASE_URL; ?>student-user-profile/<?php echo Request::sessionGet('student_session')->id; ?>">Profile</a>
                         </li>
                         
                         <li class="hover">
                          <a style="color: red;" href="<?php echo BASE_URL; ?>student-user-logout">LOG OUT</a>
                         </li>                         

<?php 
 }
?>

                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <!--END MAINMENU AREA END-->
        </div>

  <?php 
    self::yield('slider','');
  ?>

    </header>
    <!--END TOP AREA-->






<style type="text/css">
  section{
    padding-top: 0 !important;
    min-height: 512px;
  }
</style>

<!-- content start -->
<?php 
 self::yield('content');
?>
<!-- content stop -->



    <!--FOOER AREA-->
    <div class="footer-area dark-bg">
        <div class="footer-area-bg"></div>
        
<!--         <div class="footer-top-area wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="subscribe-content">
                            <h2>Weekly Newsletter</h2>
                            <p>There are many vaiations of passages of lorem ipsum available.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="subscriber-form-area">
                            <form action="#" class="subsriber-form">
                                <label for="subscriber-mail"><i class="fa fa-envelope-o"></i></label>
                                <input type="email" name="subscriber-mail" id="subscriber-mail" placeholder="Enter Your Mail">
                                <button type="submit">subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-border"> </div>
                    </div>
                </div>
            </div>
        </div>
 -->
 <div style="clear: both;">&nbsp;</div>
        <div class="footer-bottom-area wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                        <div class="single-footer-widget footer-about">
                            <h4 style="color: #fff;">Address</h4>
                            <p></p>
                            <ul>
                              <!-- 08023804803, 09063981170 -->
                                
                                <li><i class="fa fa-phone"></i> <a href="callto:+2348023804803">0802 380 4803</a></li>

                                <li><i class="fa fa-phone"></i> <a href="callto:+2349063981170">0906 398 1170</a></li>

<!--                                 <li><i class="fa fa-phone"></i> <a href="callto:+8801911854378">+8801911854378</a></li>
 -->

                                <li><i class="glyphicon glyphicon-envelope"></i> <a href="mailto:backpiper.com@gmail.com">timberfieldschools@yahoo.com</a></li>

                                <li><i class="fa fa-map-marker"></i>45 Bammeke Road Shasha, near Oguntade bus stop.</li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 pull-right">
                        <div class="single-footer-widget twitter-widget">
                            <h4 style="color: #fff;">Locate Us Here</h4>
                            <div>
                                
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.2207297884634!2d3.2981890138105965!3d6.619478523878895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b9102e82ff1fd%3A0x323b3beb543304ce!2sGarland+Business+Link!5e0!3m2!1sen!2sng!4v1549620069195" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

                            </div>
                        </div>
                    </div>


<!--                     <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="single-footer-widget list-widget">
                            <h3>Customer Service</h3>
                            <ul>
                                <li><a href="#">Support Forums</a></li>
                                <li><a href="#">Communication</a></li>
                                <li><a href="#">FAQS</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Rules & Condition</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
 -->

<!--                     <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="single-footer-widget instafeed-widget">
                            <h3>Customer Service</h3>
                            <ul>
                                <li><a href="#"><img src="img/instafeed/1.jpg" alt=""></a></li>
                                <li><a href="#"><img src="img/instafeed/2.jpg" alt=""></a></li>
                                <li><a href="#"><img src="img/instafeed/3.jpg" alt=""></a></li>
                                <li><a href="#"><img src="img/instafeed/4.jpg" alt=""></a></li>
                                <li><a href="#"><img src="img/instafeed/5.jpg" alt=""></a></li>
                                <li><a href="#"><img src="img/instafeed/6.jpg" alt=""></a></li>
                            </ul>
                        </div>
                    </div>
 -->                    
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-border"> </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="footer-copyright wow fadeIn">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> Timberfield Schools All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </div>
                    </div>

<!--                     <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="footer-social-bookmark text-right wow fadeIn">
                            <ul class="social-bookmark">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>
                    </div>
 -->
                    
                </div>
            </div>
        </div>
    </div>
    <!--FOOER AREA END-->


    <!--====== SCRIPTS JS ======-->
    
    <script src="<?php echo BASE_URL; ?>FE2/js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="<?php echo BASE_URL; ?>FE2/js/vendor/jquery.easing.1.3.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/vendor/jquery.appear.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/owl.carousel.min.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/stellar.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/wow.min.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/stellarnav.min.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/contact-form.js"></script>
    <script src="<?php echo BASE_URL; ?>FE2/js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="<?php echo BASE_URL; ?>FE2/js/main.js"></script>
</body>

</html>
