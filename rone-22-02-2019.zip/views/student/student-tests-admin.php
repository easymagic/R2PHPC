<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        <?php echo $student->surname; ?> , <?php echo $student->first_name; ?>'s
         Test History.

        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Test History</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  



              <a href="<?php echo BASE_URL; ?>students" class="btn btn-success btn-sm pull-right">Back</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Subject</th>
                  <th>Question</th>
                  <th>Response</th>
                  <th>Correction</th>
                  <th>Remarks</th>
                  <th>Date Created</th>
                </tr>

                <?php 
                 foreach ($studentTests as $k=>$studentTest){
                ?>
                <tr>

                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $studentTest->test->subject->name; ?></td>
                  <td><?php echo $studentTest->test->content; ?></td>
                  <td><?php echo $studentTest->student_response; ?></td>
                  <td><?php echo $studentTest->correction; ?></td>
                  <td><?php echo $studentTest->remark; ?></td>
                  <td><?php echo $studentTest->date_created; ?></td>

                </tr>
                <?php 
                  }
                ?>
                

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      </div>
<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


