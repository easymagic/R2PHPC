<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Student Tests (<?php echo $test->subject->name; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Student Tests</li>
      </ol>
</section>


<section class="content">
<div class="row">

<div class="col-xs-12">
  <label>
  	Question.
  </label>	
</div>
<div class="col-xs-12">
	<?php echo $test->content; ?>
</div>


<div class="col-md-10">



          <div class="box">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  


              <h3 class="box-title">
                <?php echo ucfirst($test->class); ?>&nbsp;/&nbsp;<?php echo ucfirst($test->term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subject/<?php echo $test->subject->id; ?>/tests" class="btn btn-success btn-sm pull-right">Back</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Surname</th>
                  <th>First Name</th>
                  <th>Other Names</th>
                  <th>Answerred</th>
                  <th>Date Created</th>
                  <th>Operations</th>
                </tr>

                <?php 
                 foreach ($studentTests as $k=>$studentTest){
                ?>
                <tr>
                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $studentTest->student->surname; ?></td>
                  <td><?php echo $studentTest->student->first_name; ?></td>
                  <td><?php echo $studentTest->student->other_names; ?></td>
                  <td><?php echo ($studentTest->attended_to == 1)? 'yes' : 'no'; ?></td>
                  <td><?php echo $studentTest->date_created; ?></td>
                  <td>
                     <a href="<?php echo BASE_URL; ?>subject-test-students/<?php echo $test->id; ?>/<?php echo $studentTest->id; ?>" class="btn btn-primary btn-sm">Submit Your Corrections</a>

                  </td>
                </tr>
                <?php 
                  }
                ?>
                

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      </div>
<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


