<?php 

namespace controllers;

use models\Subject;
use appx\core\Request;

class SubjectController extends \controllers\BaseController{

   
    
    function index($class,$term){
      return $this->view('subject/index',[
        'subjects'=>Subject::allByClassTerm($class,$term),
        'term'=>$term,
        'class'=>$class
      ]);
    }

    function subjectCreate($class,$term){
     return $this->view('subject/create',[
     'term'=>$term,
     'class'=>$class
     ]);
    }

    function subjectCreateAction($class,$term,Subject $subject){
    	$data = Request::all();
    	Subject::create([
           'name'=>$data['name'],
           'class'=>$class,
           'term'=>$term,
           'date_created'=>date('Y-m-d h:i:s'),
           'last_updated'=>date('Y-m-d h:i:s')
    	]);
    	$subject->setSuccess('Subject added.');
    	$this->setResponse($subject->getMessage());
    	return redirect('subjects/' . $class . '/' . $term);
    }

    function subjectEdit(Subject $subject){
    	return $this->view('subject/edit',[
         'subject'=>$subject
    	]);
    }

    function subjectEditAction(Subject $subject){
       $data = Request::all();
       $subject->update([
         'name'=>$data['name'],
         'last_updated'=>date('Y-m-d h:i:s') 
       ]);
       $subject->setSuccess('Subject updated.');
       $this->setResponse($subject->getMessage());
       return redirect('subjects/' . $subject->class . '/' . $subject->term);
    }




}