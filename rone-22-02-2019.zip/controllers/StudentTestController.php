<?php 

namespace controllers;

use models\Subject;
use models\Test;
use models\StudentTest;
// use models\StudentAssignment;
use appx\core\Request;

class StudentTestController extends \controllers\BaseController{

  
    function index(Test $test){
      return $this->view('student-test/index',[
         'test'=>$test,
         'studentTests'=>$test->studentTests
      ]);
    }

    function edit(Test $test,StudentTest $studentTest){
      return $this->view('student-test/edit',[
         'test'=>$test,
         'studentTest'=>$studentTest
      ]);
    }

    function editAction(StudentTest $studentTest){
       $data = Request::all();
       $studentTest->update([
        'correction'=>$data['correction'],
        'passed'=>$data['passed'],
        'failed'=>$data['failed'],
        'result'=>$data['result'],
        'remark'=>$data['remark'],
        'attended_to'=>(isset($data['attended_to']))? $data['attended_to'] : '0'
       ]);

       $studentTest->setSuccess('Teacher\'s response submitted.');
       $this->setResponse($studentTest->getMessage());
 
       redirect('subject-test-students/' . $studentTest->test->id); 

    }


}