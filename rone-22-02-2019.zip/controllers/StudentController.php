<?php 

namespace controllers;

use models\Student;
use appx\core\Request;

class StudentController extends \controllers\BaseController{


   
     function index(Student $student){
      return $this->view('student/index',[
        'students'=>Student::all()
      ]);
     }

     function studentCreate(Student $student){
     	return $this->view('student/create',[
          'student'=>$student
     	]);
     }

     function studentCreateAction(Student $student){
       $data = Request::all();
       $data = [
          'surname'=>$data['surname'],
          'first_name'=>$data['first_name'],
          'other_names'=>$data['other_names'],
          'gender'=>$data['gender'],
          'email'=>$data['email'],
          'guardian_email'=>$data['guardian_email'],
          'password'=>$data['password'],
          'password_confirm'=>$data['password_confirm'],
          'address'=>$data['address'],
          'phone'=>$data['phone'],
          'class'=>$data['class'],
          'term'=>\models\TermAutoSelect::getCurrentTerm()
       ];	
       $this->setResponse($student->studentRegister($data));
       redirect('students');
     }

     function studentEdit(Student $student){
       return $this->view('student/edit',[
        'student'=>$student
       ]);
     }

     function studentEditAction(Student $student){
         // $student->udate();
       $data = Request::all();
       $data = [
          'surname'=>$data['surname'],
          'first_name'=>$data['first_name'],
          'other_names'=>$data['other_names'],
          'gender'=>$data['gender'],
          'guardian_email'=>$data['guardian_email'],
          'address'=>$data['address'],
          'phone'=>$data['phone'],
          'class'=>$data['class'],
          'term'=>\models\TermAutoSelect::getCurrentTerm()
       ];	

        $this->setResponse($student->studentUpdate($data));
     	redirect('students');
     }

     function studentChangePassword(Student $student){
      return $this->view('student/change-password',[
        'student'=>$student
      ]);
     }

     function studentChangePasswordAction(Student $student){
       $data = Request::all();	
       $data = [
          'password'=>$data['password'],
          'password_confirm'=>$data['password_confirm']
       ];
       $this->setResponse($student->changePassword($data));
       return redirect('students');
     }


     function studentTestsAdmin(Student $student){
      return $this->view('student/student-tests-admin',[
         'student'=>$student,
         'studentTests'=>$student->studentTests
      ]);
     }


     function studentAssignmentsAdmin(Student $student){
      return $this->view('student/student-assignments-admin',[
         'student'=>$student,
         'studentAssignments'=>$student->studentAssignments
      ]);
     }









}
