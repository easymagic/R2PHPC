<?php 

namespace controllers;

use models\Student;
use models\StudentTest;
use models\StudentAssignment;

use appx\core\Request;


class HomeController extends BaseController{


     function index(){ //default
       return $this->view('home/index');
     }

     function studentLogin(){ //student-user-login
       return $this->view('home/student-login');
     }

     function studentLoginAction(Student $student){ 
       
       $this->entityLoginAction($entity=$student,
       	                        $sessionName='student_session',
       	                        $welcomeMessage='Welcome user.(:',
       	                        $cb='redirectToProfile',
       	                        $redir='student-user-login');    

     }

     function redirectToProfile(){
     	//student-user-profile/3
     	redirect('student-user-profile/' . Request::sessionGet('student_session')->id);
     }

     function studentLogout(Student $student){ //student-user-logout
        Request::sessionUnSet('student_session');
        $student->setSuccess('You just logged out.');
        $this->setResponse($student->getMessage());
        redirect('student-user-login');
     }

     function studentProfile(Student $student){ //student-user-profile
       return $this->view('home/student-profile',[
        'student'=>$student
       ]);
     }

     function studentProfileAction(Student $student){

          // 'surname'=>$data['surname'],
          // 'first_name'=>$data['first_name'],
          // 'other_names'=>$data['other_names'],
          // 'other_names'=>$data['other_names'],

        $data = Request::all();
        $student->update([
          'address'=>$data['address'],
          'phone'=>$data['phone'],
        ]);
        $student->setSuccess('Profile saved');
        $this->setResponse($student->getMessage());
        redirect('student-user-profile/' . $student->id);
     }

     function studentChangePassword(Student $student){ //student-user-change-password/(student)
       return $this->view('home/student-change-password',[
        'student'=>$student
       ]);
     }

     function studentChangePasswordAction(Student $student){
        $data = Request::all();
        $this->setResponse($student->changePassword([
         'password'=>$data['password'],
         'password_confirm'=>$data['password_confirm']
        ]));

        redirect('student-user-change-password/' . $student->id);
     }

     function studentTests(Student $student){//student-user-tests/(student)
       return $this->view('home/student-tests',[
        'student'=>$student,
        'studentTests'=>$student->studentTests
       ]);
     }

     function studentTestDetail(StudentTest $studentTest){//student-user-test-detail/(studentTest)
       return $this->view('home/student-test-detail',[
        'studentTest'=>$studentTest
       ]);

     }

     function studentTestDetailAction(StudentTest $studentTest){
        $data = Request::all();
        if (!empty($data['student_response'])){
	        $studentTest->update([
	         'student_response'=>$data['student_response']
	        ]); 
	        $studentTest->setSuccess('Your response has been successfully submitted.');
        }else{
        	$studentTest->setError('Your response is required!.');
        }

        $this->setResponse($studentTest->getMessage());
        redirect('student-user-tests/' . $studentTest->student->id);
     }

     function studentAssignments(Student $student){//student-user-assignments/(student)
       return $this->view('home/student-assignments',[
        'student'=>$student,
        'studentAssignments'=>$student->studentAssignments
       ]);
     }

     function studentAssignmentDetail(StudentAssignment $studentAssignment){//student-user-assignment-detail/(studentAssignment)
       return $this->view('home/student-assignment-detail',[
        'studentAssignment'=>$studentAssignment
       ]);
     }

     function studentAssignmentDetailAction(StudentAssignment $studentAssignment){
        $data = Request::all();
        if (!empty($data['student_response'])){
	        $studentAssignment->update([
	         'student_response'=>$data['student_response']
	        ]); 
	        $studentAssignment->setSuccess('Your response has been successfully submitted.');
        }else{
        	$studentAssignment->setError('Your response is required!.');
        }

        $this->setResponse($studentAssignment->getMessage());
        redirect('student-user-assignments/' . $studentAssignment->student->id);
     }


}