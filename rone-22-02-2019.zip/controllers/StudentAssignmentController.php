<?php 

namespace controllers;

use models\Subject;
use models\Assignment;
use models\StudentAssignment;
// use models\StudentAssignment;
use appx\core\Request;

class StudentAssignmentController extends \controllers\BaseController{

  
    function index(Assignment $assignment){
      return $this->view('student-assignment/index',[
         'assignment'=>$assignment,
         'studentAssignments'=>$assignment->studentAssignments
      ]);
    }

    function edit(Assignment $assignment,StudentAssignment $studentAssignment){
      return $this->view('student-assignment/edit',[
         'assignment'=>$assignment,
         'studentAssignment'=>$studentAssignment
      ]);
    }

    function editAction(StudentAssignment $studentAssignment){
       $data = Request::all();
       $studentAssignment->update([
        'correction'=>$data['correction'],
        'passed'=>$data['passed'],
        'failed'=>$data['failed'],
        'result'=>$data['result'],
        'remark'=>$data['remark'],
        'attended_to'=>(isset($data['attended_to']))? $data['attended_to'] : '0'
       ]);

       $studentAssignment->setSuccess('Teacher\'s response submitted.');
       $this->setResponse($studentAssignment->getMessage());
 
       redirect('subject-assignment-students/' . $studentAssignment->assignment->id); 

    }


}