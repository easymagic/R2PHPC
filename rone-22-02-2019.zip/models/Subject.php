<?php 

namespace models;

class Subject extends \models\BaseModel{
  
  protected $table = 'subject';

  
  function tests(){
   return $this->hasMany(\models\Test::class,'subject_id');		
  }

  function assignments(){
   return $this->hasMany(\models\Assignment::class,'subject_id');		
  }

  function students(){
  	return $this->assignments->students;		
  }

  function testStudents(){
   return $this->tests->students;
  }

  function assignmentStudents(){ 
   return $this->assignments->students;
  }

  
  static function allByClassTerm($class,$term){
    $obj = new Subject;
    return $obj->where('class',$class)->where('term',$term)->get();
  } 


}