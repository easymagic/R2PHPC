<?php 

namespace models;

class Student extends \models\BaseModel{
  
  protected $table = 'student';

  
  ///relations start
  function studentAssignments(){
   return $this->hasMany(\models\StudentAssignment::class,'student_id');
  }

  function studentTests(){
   return $this->hasMany(\models\StudentTest::class,'student_id');	
  }
  ///relations stop.
  
  function studentRegister($data){
    return $this->register($data,'uploadPassport','Student profile created successfully.');
  }

  function studentUpdate($data){ 
    $this->uploadPassport();
    unset($data['password']);
    unset($data['email']);
    $this->update($data);
    $this->setSuccess('Student profile updated.');
    return $this->getMessage();
  }



  function uploadPassport(){
    $obj = \helpers\UploadHelper::factory();
    if ($obj->uploadSucceed('passport','uploads/student/passport')){
        $this->update([
           'passport'=>$obj->getUploadedFile()
        ]);
    }
  }

  static function allByClass($class){
    $obj = new Student;
    return $obj->where('class',$class)->get();
  }

  function updateCurrentTerm(){
    $this->update([
     'term'=>\models\TermAutoSelect::getCurrentTerm()
    ]);
  }


  function determinePromotion(){
    
    $classMaps = ClassLoad::getClassMap();
    $currentTerm = \models\TermAutoSelect::getCurrentTerm();
    
    if ($this->term == 'third-term' && $currentTerm == 'first-term'){ //detect promotion
      
      $this->updateCurrentTerm();
      $this->update([
        'class'=>$classMaps[$this->class] ///promotion occurs here
      ]); 

    }else{
      
      $this->updateCurrentTerm();

    }

  }





  



}