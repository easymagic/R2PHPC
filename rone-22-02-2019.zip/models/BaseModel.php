<?php 

namespace models;

class BaseModel extends \rone\Model{


	private $modelMessage = [];


	function setError($msg){
     $this->modelMessage['message'] = $msg;
     $this->modelMessage['error'] = true;
	}

	function setSuccess($msg){
     $this->modelMessage['message'] = $msg;
     $this->modelMessage['error'] = false;
	}

	function getMessage(){
		return $this->modelMessage;
	}




  function checkPassword($data){
     return (isset($data['password']) && isset($data['password_confirm']) && !empty($data['password']) && $data['password_confirm'] == $data['password']);
  }

  function changePassword($data){
     if ($this->checkPassword($data)){
       $this->update([
         'password'=>$data['password_confirm']
       ]);
       $this->setSuccess('Password changed successfully.');
     }else{
       $this->setError('Invalid Password!');	
     }
     return $this->getMessage();
  }



  function login($email,$password){

  	return $this->where('email',$email)->where('password',$password)->getOne();

  }



  function accountExists($email){

  	if (empty($email)){
  	 $this->setError('Invalid e-mail!');	
     return true;
  	}else{
  	 
  	 $check = $this->where('email',$email)->getOne();	
  	 
  	 if ($check){
     
       $this->setError('An account with this E-mail (' . $check->email . ') already exists!');
     
       return true;
  	 
  	 }else{
  	 
  	  return false;	
  	 
  	 }

  	}
    
  }


  function register($data,$cb=null,$successMessage=''){
    if ($this->checkPassword($data)){
    	unset($data['password_confirm']);
    	$check = $this->accountExists($data['email']);
	    if (!$check){
	      $newID = self::create($data);
	      $recordData = $this->find($newID);
	      if (!is_null($cb)){
            $recordData->$cb();
	      }
	      // $recordData->uploadPassport();
          $this->setSuccess($successMessage);  //'Student profile created successfully.'
	    }
    }else{
      $this->setError('Invalid Password!');
    }
    return $this->getMessage();
  }

  function enableAccount(){
  	$this->update([
     'status'=>1
  	]);
    $this->setSuccess('Account enabled.');
    return $this->getMessage();
  }

  function disableAccount(){
  	$this->update([
     'status'=>0
  	]);
    $this->setSuccess('Account disabled.');
    return $this->getMessage();
  }



}