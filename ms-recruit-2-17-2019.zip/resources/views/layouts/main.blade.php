<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="" />
		<!-- Meta Keyword -->
		<meta name="keywords" content="" />
		<!-- meta character set -->
		<meta charset="UTF-8" />
		<!-- Site Title -->
		<title>Job List</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
		<style type="text/css">

    body{
      /*font-weight: bold !important;*/
      color: #000 !important;
      font-size: 16px !important;
    }


    .dropdown-item:hover, .dropdown-item:focus {
        background-color:#8b72fb !important;
        color: #fff !important;
    }


			.bold{
				font-weight: bold;
			}

			.hide{
				display: none;
			}

			.section-gap{
				    padding: 0px 0 !important;
			}

      *{
        font-size: 13px;
      }

		</style>
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="/css/linearicons.css">
			<link rel="stylesheet" href="/css/font-awesome.min.css">
			<link rel="stylesheet" href="/css/bootstrap.css">
			<link rel="stylesheet" href="/css/magnific-popup.css">
			<link rel="stylesheet" href="/css/nice-select.css">					
			<link rel="stylesheet" href="/css/animate.min.css">
			<link rel="stylesheet" href="/css/owl.carousel.css">
			<link rel="stylesheet" href="/css/main.css">

        <link rel="stylesheet" type="text/css" href="/assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css">
  <link href="/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="/assets/plugins/toastr/toastr.min.css" rel="stylesheet">
			<!-- Include SmartWizard CSS -->
<link href="/dist/css/smart_wizard.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="/dist/css/select2.min.css" />

<!-- Optional SmartWizard theme -->
<link href="/dist/css/smart_wizard_theme_circles.css" rel="stylesheet" type="text/css" />
<link href="/dist/css/smart_wizard_theme_arrows.css" rel="stylesheet" type="text/css" />
<link href="/dist/css/smart_wizard_theme_dots.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="/css/sb-admin-2.min.css" />

<link rel="stylesheet" type="text/css" href="/jquery-ui/jquery-ui.theme.min.css" />

<style type="text/css">
 .p1-gradient-bg, .banner-area .overlay-bg, .sidebar .single-slidebar .cat-list li:hover, .callto-action-area, .single-price:hover .price-bottom, .single-service:hover, .submit-right, .submit-left, .contact-btns, .form-area .primary-btn {
    
     /*background-color: #aaa !important;*/
     background-image: none;

 } 
</style>

<script src="/js/vendor/jquery-2.2.4.min.js"></script>

<script type="text/javascript" src="/jquery-ui/jquery-ui.min.js"></script>

<script type="text/javascript" src="/dist/js/select2.full.min.js"></script>

<script type="text/javascript">

    var Ajax = {};

    (function(ajx){


    function callAPI(config){ //data,api,success,error
        config.data._token = '{{csrf_token()}}';
        $.ajax({
           url:config.api,
           type:config.type,
           data:config.data,
           success:function(response){
             config.success(response,function(msg){
              toastr.success(msg);
             });
           },
           error:function(error){
             config.error(response,function(msg){
              toastr.error(msg);
             });                 
           }

        });


    }

       
    
     ajx.post = (function(){
        
        return function(config){
            config.type = 'POST';
            callAPI(config); 
            
        };

     })();


     ajx.delete = (function(){
        
        return function(config){
            config.type = 'POST';
            config.data._method = 'DELETE';
            callAPI(config); 
            
        };

     })();


     ajx.patch = (function(){
        
        return function(config){
            config.type = 'POST';
            config.data._method = 'PATCH';
            callAPI(config); 
            
        };

     })();
   

     ajx.put = (function(){
        
        return function(config){
            config.type = 'POST';
            config.data._method = 'PUT';
            callAPI(config); 
            
        };

     })();





    })(Ajax); 
    

    // function callAPI(config){ //data,api,success,error
    //     config.data._token = '{{csrf_token()}}';
    //     $.ajax({
    //        url:config.api,
    //        type:'post',
    //        data:config.data,
    //        success:function(response){
    //          config.success(response,function(msg){
    //           toastr.success(msg);
    //          });
    //        },
    //        error:function(error){
    //          config.error(response,function(msg){
    //           toastr.error(msg);
    //          });                 
    //        }
    //     });
    // }


    // console.log(123);


  </script>

		</head>
		<body>


<style type="text/css">
  
  @media (min-width: 992px){
    .container {
      max-width: 855px !important;
    }
  }

</style>

			  <header id="header" id="home" style="background-color: #000;">
			    <div class="container">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="/"><img src="/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="/">Home</a></li>
                  <li class="menu-active"><a href="/" style="color: #fe3230;font-weight: bold;">Jobs Listing</a></li>    

<!--                     <li class="nav-item">
                
                    <a class="nav-link" href="">Company Recruit</a>
                
                    </li>
 -->

                   @guest
                    <li class="nav-item">
                      <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                    <li class="nav-item">
                      @if (Route::has('register'))
                       <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                      @endif
                    </li>
                   @else


                    <li class="nav-item">
                
                    <a class="nav-link" href="{{ route('user.dashboard') }}">Dashboard</a>
                
                    </li>

                    @auth

                     @if (Auth::user()->role == 'admin')


                    <li class="nav-item">
                
                    <a class="nav-link" href="{{ route('job.applicants.pool') }}">Talent Pool</a>
                
                    </li>


                     @endif


                    @endauth




                  
<!--                   <li>  
                     <a href="#" data-toggle="modal" data-target="#addjobs">Add Job</a>
                  </li> 
 -->

                  <li><a  href="" onclick="event.preventDefault();document.getElementById('logout-form22').submit();">
                     Logout
                        </a>
                  </li>

              <form id="logout-form22" action="{{ route('logout') }}" method="POST" style="display: none;">
                     @csrf
               </form>


<!--                  <li>
                
                  <a class="ticker-btn"  data-toggle="modal" data-target="#approveReject" href="javascript::void()"  onclick="sessionStorage.setItem('checkid',0)">
                    
                    Approve  Selected

                  </a>

                </li>
 -->

                   @endguest
				           				          	    			          				          
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			  
<!-- Start callto-action Area -->
		 		
			<!-- End calto-action Area -->	

<section style="padding-bottom: 80px;background-color: #202020;background-image: none;" class="banner-area relative" id="home">  
  
  <!-- <div class="overlay overlay-bg"></div> -->
  
<!--   <div class="container">
    <div class="row d-flex align-items-center justify-content-center">
      <div class="about-content col-lg-12" style="padding: 76px 0px !important;">
        <h1 class="text-white">
          Search Your Jobs Here      
        </h1> 
      </div>                      
    </div>
  </div>
 -->
</section>

<section class="post-area section-gap" style="min-height: 373px;">
  <div class="" style="margin:20px;">
    <div class="row justify-content-center d-flex">


      @yield('content')       
        

    </div>
  </div>

  </section>

			<!-- start footer Area -->		
      <br />
			 
       <footer class="footer-area section-gap">
				<div class="container">
					
					<div class="row footer-bottom d-flex justify-content-between">

						<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						
					</div>
				</div>
			</footer>
			<!-- End footer Area -->		

			<script src="/js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="/js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="/js/easing.min.js"></script>			
			<script src="/js/hoverIntent.js"></script>
			<script src="/js/superfish.min.js"></script>	
			<script src="/js/jquery.ajaxchimp.min.js"></script>
			<script src="/js/jquery.magnific-popup.min.js"></script>	
			<script src="/js/owl.carousel.min.js"></script>			
			<script src="/js/jquery.sticky.js"></script>
			<script src="/js/jquery.nice-select.min.js"></script>			
			<script src="/js/parallax.min.js"></script>		
			<script src="/js/mail-script.js"></script>	
			  <script src="/assets/plugins/toastr/toastr.min.js"></script>

        <script type="text/javascript" src="/assets/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
        <script type="text/javascript" src="/assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
			<script src="/js/main.js"></script>

        <script src="/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

        <script type="text/javascript">

/**
          $("#checkAll").change(function () {
                      $("input:checkbox").prop('checked', $(this).prop("checked"));
                    });
**/


(function($){
  $(function(){

    
     $('[data-value]').each(function(){
      var vl = $(this).data('value');
      $(this).val(vl);
     });


     // $('[data-target]=#approveReject').each(function(){
     //  $(this).parent().find('form').on('submit',function(){
     //    return confirm('Do You want to confirm this action?');
     //  });
     // });



  });
})(jQuery);

        </script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">		
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" crossorigin="anonymous"></script>
 
  <script>

/**
   $( function() {
    $("#slider").slider({
    	change: function( event, ui ) {
    		console.log('changed',ui);
    		//percentage-progress
    		$('#percentage-progress').html(ui.value + ' % ');
    	}
    });
    console.log('called.');
   });
**/


  </script>

  </body>
</html>