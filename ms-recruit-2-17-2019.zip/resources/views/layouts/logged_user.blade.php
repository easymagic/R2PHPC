@section('content')
<div class="col-lg-12">
<span onclick="openNav()" style="cursor: pointer;">
  <img src="/burger.png" style="width: 32px;">
</span>	
</div>

<style type="text/css">
  	
@media (min-width: 768px){
.sidebar {
 width: 100% !important;
}  	

}
</style>



 @include('sidebars.admin_sidebar')

<div class="col-lg-3" style="">
  <!-- search filter -->
  @yield('side-bar','')
</div>
<div class="col-lg-9 post-list" style="@yield('main-center-style','margin-left: 11%;')">
 @yield('inner-content')
</div>
@endsection