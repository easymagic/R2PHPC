@extends('layouts.main')

@extends('layouts.logged_user')

@section('side-bar')

 
@endsection

@section('inner-content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12" style="min-height: 450px;">
            
                <!-- <div class="card-header">{{ __('Change Password') }}</div> -->

<div style="
    border-bottom: 3px solid #000000;
    margin-bottom: 17px;
    font-size: 18px;
">
    Users
</div>

@include('notifications.message')


<span id="outlet">
    
</span> 

<script type="text/javascript">
    // user-ajax
    (function($){
        $(function(){

 
            function loadUserPage(api){
               
               $('#outlet').html('Loading ... ');
               
               $.ajax({
                 
                 url:api,
                 type:'get',
                 success:function(response){
                    $('#outlet').html(response);
                    initClientAjaxPagination();
                 }

               });

            }


           function initClientAjaxPagination(){
           
            $('.page-link').on('click',function(){

                var api = $(this).attr('href');
                
                // console.log(api + configToGetRequest());
                // alert(api + configToGetRequest());   
                loadUserPage(api);

                return false;

            });             

          }


            loadUserPage('{{ route("user.ajax") }}');



        });
    })(jQuery);
</script>

                
        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>


<!-- dialog -->
<div class="modal fade modal-3d-slit show" id="profileView" aria-labelledby="exampleModalTitle" role="dialog" style="display: none; padding-right: 17px;">

  <div class="modal-dialog modal-lg">



  <!-- [end] -->
  </div>
</div>
<!-- dialog -->


@endsection
