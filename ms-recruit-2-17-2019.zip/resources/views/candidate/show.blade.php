@extends('layouts.main')

@extends('layouts.logged_user')

@section('inner-content')

<style type="text/css">
    label{
        margin-bottom: 0;
    }
</style>

<div style="
    border-bottom: 3px solid #000000;
    /*margin-bottom: 17px;*/
    font-size: 18px;
">
    Candidate C.V Profile
</div>


<div class="col-xs-12" style="border: 1px solid #bbb;border-top: none;padding: 5px;padding-left: 15px;">

<div>
    <label style="font-weight: bold;text-decoration: underline;font-size: 14px;">
       General Information
    </label>
</div>
      

<div>
    <label style="font-weight: bold;color: #888;">
       Full Name
    </label>
</div>

<div>
    {{$candidate->name}}
</div>



<div>
    <label style="font-weight: bold;color: #888;">
       E-mail
    </label>
</div>

<div>
    {{$candidate->email}}
</div>



<div>
    <label style="font-weight: bold;color: #888;">
       Phone Number
    </label>
</div>

<div>
    {{$candidate->phone_number}}
</div>



<div>
    <label style="font-weight: bold;color: #888;">
       Address
    </label>
</div>

<div>
    {{$candidate->address}}
</div>



<div>
    <label style="font-weight: bold;color: #888;">
       Cover Letter
    </label>
</div>

<div>
    {{$candidate->cover_letter}}
</div>


<div>
    <label style="font-weight: bold;color: #888;">
       Age
    </label>
</div>

<div>
    {{$candidate->age}}
</div>



<div>
    <label style="font-weight: bold;color: #888;">
       Gender
    </label>
</div>

<div>
    {{$candidate->gender}}
</div>


<div>
    <label style="font-weight: bold;color: #888;">
       Marital Status
    </label>
</div>

<div>
    {{$candidate->marital_status}}
</div>






<div>
    <label style="font-weight: bold;text-decoration: underline;font-size: 14px;">
      Educations
    </label>
</div>
<div>
    <ol style="padding: none;list-style: inherit;padding-left: 15px;">
        @foreach ($candidate->candidateEducations as $candidateEducation)
          <li>{{$candidateEducation->education->name}} &nbsp;<span>( {{$candidateEducation->date_from}}  - {{$candidateEducation->date_to}} )</span></li>
        @endforeach
    </ol>
</div>



<div>
    <label style="font-weight: bold;text-decoration: underline;font-size: 14px;">
      Certifications
    </label>
</div>
<div>
    <ol style="padding: none;list-style: inherit;padding-left: 15px;">
        @foreach ($candidate->candidateCertifications as $candidateCertification)
          <li>{{$candidateCertification->certification->name}} &nbsp;<span>( {{$candidateCertification->date_certified}} )</span></li>
        @endforeach
    </ol>
</div>




<div>
    <label style="font-weight: bold;text-decoration: underline;font-size: 14px;">
      Work Experience
    </label>
</div>
<div>
    <ol style="padding: none;list-style: inherit;padding-left: 15px;">
        @foreach ($candidate->candidateWorkExperience as $candidateWorkExperience)
          <li>{{$candidateWorkExperience->company_name}} , {{$candidateWorkExperience->company_role}} &nbsp;<span>( {{$candidateWorkExperience->work_from}} )</span></li>
        @endforeach
    </ol>
</div>








</div>




<div style="clear: both;">&nbsp;</div>

@endsection

