@extends('layouts.main')

@extends('layouts.logged_user')

@section('inner-content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            
                <!-- <div class="card-header">{{ __('Change Password') }}</div> -->

<div style="
    border-bottom: 3px solid #8c76f7;
    margin-bottom: 17px;
    font-size: 18px;
">
    Upload My C.V
</div>


@include('notifications.message')

 
 <style type="text/css">
     .cv label{
        font-weight: bold;
     }
 </style>

<form method="post" action="{{ route('candidate.store') }}" enctype="multipart/form-data">
 
 @csrf
 @method('POST')

<div class="cv" style="
    padding: 10px;
    border: 3px dashed #aaa;
    box-shadow: 2px 2px #999;">




    <!-- jb_recruitment_type_id -->


<!-- jb_competency_id -->


<!-- years_of_experience -->

    
    <div>
        <label style="color: #000;">Full Name</label>
    </div>
    <div>
        <input type="text" name="name" class="form-control" required="" />
    </div>


    <div>
        <label>E-mail</label>
    </div>
    <div>
        <input type="email" name="email" class="form-control" required="" /> 
    </div>


    <div>
        <label>Phone Number</label>
    </div>
    <div>
        <input type="text" name="phone_number" class="form-control" required="" /> 
    </div>


    <div>
        <label>Address</label>
    </div>
    <div>
        <input type="text" name="address" class="form-control" required="" />
    </div>


    <div>
        <label>Cover Letter</label>
    </div>
    <div>
        <textarea class="form-control" name="cover_letter" placeholder="Cover Letter"></textarea>
    </div>

    <div>
        <label>Age</label>
    </div>
    <div>
        <input type="number" name="age" class="form-control" required="" />
    </div>



    <div>
        <label>Gender</label>
    </div>
    <div>
        <select class="form-control" name="gender" required="">
            <option value="">--Select Gender--</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
    </div>



    <div>
        <label>Marital Status</label>
    </div>
    <div>
        <select class="form-control" name="marital_status" required="">
            <option value="">--Select Marital Status--</option>
            <option value="single">Single</option>
            <option value="married">Married</option>
        </select>
    </div>


    <div>
        <label>Upload C.V</label>
    </div>

    <div>
        <input type="file" name="cv_upload" class="form-control" />
    </div>



    <div align="right">
        <button style="margin-top: 17px;" class="btn btn-sm btn-success">Submit</button>
    </div>



</div>
</form>


                
        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>


<!-- dialog -->
<div class="modal fade modal-3d-slit show" id="profileView" aria-labelledby="exampleModalTitle" role="dialog" style="display: none; padding-right: 17px;">

  <div class="modal-dialog modal-lg">



  <!-- [end] -->
  </div>
</div>
<!-- dialog -->


@endsection
