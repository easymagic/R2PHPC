                    <div style="border-bottom: 1px solid #000;" id="candidate-work-experience">
                        <b style="color: #000;">Your Work Experiences</b>
                    </div>

                    <div class="col-lg-12">
                        
                        <table class="table">
                            <tr>
                                <th>Company</th>
                                <th>Role</th>
                                <th>Description</th>
                                <th>From</th>
                                <th>To</th>
                                <th></th>
                            </tr>
                            @foreach ($candidate->candidateWorkExperience as $candidateWorkExperience)
                             <tr>
                                 <td>{{$candidateWorkExperience->company_name}}</td>
                                 <td>{{$candidateWorkExperience->company_role}}</td>
                                 <td>{{$candidateWorkExperience->role_description}}</td>
                                 <td>{{$candidateWorkExperience->work_from}}</td>
                                 <td>{{$candidateWorkExperience->work_to}}</td>
                                 <td>
            <div class="dropdown show">
                <button class="btn btn-success dropdown-toggle btn-sm pull-right" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    Action
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; transform: translate3d(-5px, 38px, 0px); top: 0px; left: 0px; will-change: transform;"> 

                     <form method="post" action="{{ route('candidateworkexperience.destroy',$candidateWorkExperience->id) }}">
                        <!-- /candidate-educations/{candidateEducation}/delete -->
                        
                        @csrf
                        @method('DELETE')

                     <button class="dropdown-item btn btn-danger btn-sm" data-backdrop="false"  data-toggle="modal" data-target="#approveReject" >Remove</button>
                     </form>

                </div>
            </div>                                                  
                                 </td>
                             </tr> 
                            @endforeach
                        </table>



                        <form method="post" action="{{ route('candidateworkexperience.store') }}">
                            <!-- /candidate-educations/add/{candidate}/{user} -->
                            @csrf
                            @method('POST')

                        <table class="table">
                            <tr>
                                
                                <td>
                                     
                                   <input type="text" name="company_name" class="form-control" placeholder="Company Name" />  
                                 
                                </td>

                                <td>
                                	<input type="text" name="company_role" class="form-control" placeholder="Company Role" />
                                </td>

                                <td>
                                	<input type="text" name="role_description" class="form-control" placeholder="Role Description" />
                                </td>

                                <td>
                                	<input type="date" name="work_from" class="form-control" placeholder="Work From" />
                                </td>

                                <td>
                                	<input type="date" name="work_to" class="form-control" placeholder="Work To" />
                                </td>


                                <td align="right">
                                    
                                <button type="submit" class="btn btn-primary btn btn-sm" style="margin-top: 0;">
                                    {{ __(' + ') }}
                                </button>

                                </td>

                            </tr>
                        </table>

                        </form>






</div>
