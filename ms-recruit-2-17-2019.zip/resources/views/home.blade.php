@extends('layouts.main')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

<div style="clear: both;">&nbsp;</div>
<span style="font-weight: bold;">
@include('notifications.message')
</span>
<div style="clear: both;">&nbsp;</div>



            <div class="card-header" style="background-color: #000;color: #fff;">Jobs Listing</div>

 
           
            <div class="col-md-12" style="padding: 0;">
            	

                 @foreach ($jobs as $job)

                 <div class="col-md-12" style="border: 1px solid #ddd;margin: 8px;padding-top: 10px;padding-bottom: 10px;margin-left: 0;margin-top: 0;border-top: 0;">

                   <div class="col-md-12">
                   	   <label style="font-weight: bold;">
                   	   	Role
                   	   </label>

                   	   <div style="float: right;">
                   	   	<small>
                   	   	 Salary Range : &#x20A6; 
                   	   	  {{$job->formatSalaryRange()}}
                   	   	</small>
                   	   </div>

                   </div>
                   <div class="col-md-12">
                   	{{$job->role}}
                   </div>



                   <div class="col-md-12">
                   	   <label style="font-weight: bold;">
                   	   	Description
                   	   </label>
                   </div>
                   <div class="col-md-12">
                   	{{ substr($job->description, 0, 300) }}...
                   </div>


                   <div class="col-md-12">
                   	   <label style="font-weight: bold;margin-top: 21px;color: #aaa;margin-bottom: 0;">
                   	   	 Offer closes in
                   	   </label>
                   </div>
                   <div class="col-md-12">
                   	{{$job->expiry_date}}
                   </div>



                   <div class="col-md-12" align="right" style="padding: 0;">
                   	    
                   	    @auth 
                          @if (Auth::user()->role == 'admin')
                          <!-- nothing -->
                          <a target="_blank" href="{{ route('job.edit',$job->id) }}" class="btn btn-sm btn-info">Edit</a>
                          @endif
                   	    @endauth
                        
                        @auth
                          @if (Auth::user()->candidate()->exists() && !$job->hasCandidate(Auth::user()->candidate->id))
                            <a href="{{ route('job.show',$job->id) }}" class="btn btn-sm btn-primary">
                              View / Apply
                            </a>  
                          @elseif (Auth::user()->candidate()->exists() && $job->hasCandidate(Auth::user()->candidate->id))
                            <a href="{{ route('job.show',$job->id) }}" class="btn btn-sm btn-success">
                              <img src="/pass.png" style="width: 18px;" />  Applied.
                            </a>  
                          @else                          
                            <a href="{{ route('job.show',$job->id) }}" class="btn btn-sm btn-primary">
                              View / Apply
                            </a>  
                          @endif 
                        @else
                          <a href="{{ route('job.show',$job->id) }}" class="btn btn-sm btn-primary">
                            View / Apply
                          </a>  
                        @endauth 
                        </a>

                   </div>




                   </div>

                 @endforeach


            <div class="col-md-12">
              {{$jobs->links()}}
            </div>



            </div>




        </div>
    </div>
</div>
@endsection
