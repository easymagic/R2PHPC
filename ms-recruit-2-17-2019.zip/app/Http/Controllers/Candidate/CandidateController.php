<?php

namespace App\Http\Controllers\Candidate;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Http\Controllers\Base\BaseController;
use App\Models\JbCandidate;
use App\Models\JbRecruitmentType;
use App\Models\JbCompetence;
use App\User;
use App\Models\JbEducation;
use App\Models\JbSkill;
use App\Models\JbCertification;
use Smalot\PdfParser\Parser as SmalotParser;
use Exception;

class CandidateController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    private function getCommonData($config=[]){
        $config['jb_recruitment_type_ids'] = JbRecruitmentType::all();
        $config['jb_competency_ids'] = JbCompetence::all();
        $config['educations'] = JbEducation::all();
        $config['skills'] = JbSkill::all();
        $config['certifications'] = JbCertification::all();
        return $config;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('candidate.create',$this->getCommonData([]));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,SmalotParser $smalotParser)
    {
        //
        
        $data = request()->validate([
        'name'=>'required',
        'email'=>'required',
        'phone_number'=>'required',
        'address'=>'required',
        'age'=>'required',
        'gender'=>'required',
        'marital_status'=>'required',
        'cover_letter'=>'required'
        ]);

        $data['user_id'] = \Auth::user()->id;
        $data['cv_string'] = '....';

        try {

            $id = JbCandidate::create($data)->id;
            $candidateObj = JbCandidate::find($id);
            $candidateObj->grabCvText($smalotParser,$request);
            return $this->logSuccess('candidate.edit',[$id],'Your C.V has been created successfully, Edit below additional information about your C.V ');
        } catch (Exception $e) {

            return $this->logError('candidate.create',[],$e->getMessage());
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(JbCandidate $candidate)
    {
        //
        return view('candidate.show',[
            'candidate'=>$candidate
        ]);

    }

    //jobs related to a candidate scoped to the logged user
    function candidateAppliedJobs(JbCandidate $candidate){
       
       return view('candidate.applied_jobs',[
            'candidateJobs'=>$candidate->candidateJobs()->paginate(7)
       ]);

    }

    // function candidateAppliedJobDetail(){
       
    //    return view('candidate.applied_job_detail',[
    //      'job'=>
    //    ]);

    // }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(JbCandidate $candidate)
    {
        // dd($smalotParser);

        return view('candidate.edit',$this->getCommonData([
          'candidate'=>$candidate
        ]));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JbCandidate $candidate,SmalotParser $smalotParser)
    {
        //
        try {

            // return $this->logSuccess('candidate.edit',[],'Candidate C.V updated.');
            $data = request()->validate([
                'name'=>'required',
                'email'=>'required',
                'phone_number'=>'required',
                'address'=>'required',
                'age'=>'required',
                'gender'=>'required',
                'marital_status'=>'required',
                'cover_letter'=>'required'
            ]); 
            // $data['cv_string'] = '....';

            $candidate->grabCvText($smalotParser,$request);

            $candidate->update($data);


            // dd('Called.');
            // dd($candidate);

            return $this->logSuccess('candidate.edit',[$candidate->id],'Candidate C.V updated.');
        } catch (Exception $e) {
            return $this->logError('candidate.edit',[$candidate->id],$e->getMessage());
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(JbCandidate $candidate)
    {
        //
        try {
            //
            return $this->logSuccess('candidate.index',[],'Candidate Removed');
        } catch (Exception $e) {
            return $this->logError('candidate.index',[],$e->getMessage());
        }

    }

}
