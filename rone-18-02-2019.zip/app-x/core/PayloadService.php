<?php 

/**

@Inject(@services/RequestResponse);

*/

class PayloadService{
  
     private $data = array();
    
     function DecodePayload(){
       $requestBody = file_get_contents('php://input');
       // echo $requestBody;
       if (!empty($requestBody) && is_array(json_decode($requestBody,true)))
        $this->data = json_decode($requestBody,true);
       // print_r($this->data);
     }

     function ExportPayload(){
     	
     	foreach ($this->data as $k=>$v){
          $_REQUEST[$k] = $v;
          $_POST[$k] = $v;
     	}

     	// print_r($_POST);
        
        return $this->data;

     }




  
}