<?php 

RegisterRoute('get','/default','controllers\Home:Index');

RegisterRoute('get','/hello','controllers\Home:Hello');
RegisterRoute('get','/hello/(arg)','controllers\Home:Hellov2');
RegisterRoute('post','/hello','controllers\Home:HelloAction');
RegisterRoute('get','/hello/(arg)/edit','Foo:Edit');
RegisterRoute('post','/hello/(arg)/edit/verb','Foo:EditPost');

RegisterRoute('get','/check-create','controllers\Home:SubjectCreate');

RegisterRoute('post','/apiv1/CreateCheck','models\check\CheckCreate:Create_');

RegisterRoute('post','/SubjectCreate','models\subject\SubjectCreate:Create');

RegisterRoute('get','/cloud-verify/(arg)/(arg)/(arg)','models\cloud\CloudVerify:Verify');



///////GET View End-Points Here /////////
RegisterRoute('get','login','controllers\Home:Login');
RegisterRoute('get','profile','controllers\Home:Profile');

RegisterRoute('get','vision','controllers\Home:Vision');
RegisterRoute('get','mission','controllers\Home:Mission');
RegisterRoute('get','registered-members','controllers\Home:RegisteredMembers');
// RegisterRoute('get','registered-members','controllers\Home:RegisteredMembers',array('auth'));

RegisterRoute('get','registered-members-test/(home)','controllers\Home:test');

RegisterRoute('get','send-voter-mail/(arg)','models\notification\NotificationSendVoterDetail:SendVoterDetail');





///APIs HERE (END-POINTS)
RegisterRoute('post','apiv1/Acredit','models\voter\VoterAcredit:Acredit');
RegisterRoute('post','apiv1/Login','models\voter\VoterLogin:Login_');
RegisterRoute('post','LogOut','models\voter\VoterLogOut:LogOut_');
RegisterRoute('post','apiv1/ChangePassword','models\voter\VoterChangePassword:ChangePassword_');
RegisterRoute('post','apiv1/ChangePhone','models\voter\VoterUpdate:Update_');



