<?php
namespace declarations\entities;

class EntityEnableField extends \declarations\Db{

  

   function EnableField($table,$field){

   	
	    if (!empty($this->GetWhere())){
	       $this->DbUpdate($table,array(
            $field=>1
	       ));
	    }


   }


}