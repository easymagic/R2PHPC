<?php 

class EntityCheckPassword{

   private $post = array();

   function CheckPassword(){
	   	// global $post;
	   	global $data;

	   	// $data['error'] = false;
	   	// $data['message'] = '';	    
	    if ($this->post['password1'] != $this->post['password2'] || empty($this->post['password1'])){
	      $data['message'] = 'Passwords do not match!<br />';
	      $data['error'] = true;
	    }

     
   }

   function SetData($data){
     $this->post = $data;
   }

   function GetData(){
   	return $this->post;
   }




}