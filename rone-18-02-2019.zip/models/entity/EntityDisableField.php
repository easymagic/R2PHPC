<?php 

/**

@Inject(@models/entityv2/EntityUpdate);

*/

class EntityDisableField{



   function DisableField($entity,$field){
     global $data;

     $data['error'] = false;

     $this->EntityUpdate->SetData(array($field=>0));

   	 $this->EntityUpdate->DoUpdate($entity);

   	 $data['message'] = $field . ' disabled.';

   }




}