<?php
namespace models\voter;

class VoterLogin{

  



    function Login_(\declarations\entities\EntityLogin $login){
    	
    	if (!isset($_POST['vin'])){
          $_POST['vin'] = '';
    	}
    	
    	if (!isset($_POST['email'])){
         $_POST['email'] = '';
    	}

        if (empty($_POST['vin'])){
         $_POST['vin'] = $_POST['email'];
        }
    	
    	

    	return $login->Login($table='voter',$usernamefield1='vin',$usernamefield2='email',$passwordfield='password',$_POST);
    }



}