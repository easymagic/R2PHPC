<?php 
namespace models\voter;

class VoterGet extends \declarations\entities\EntityGet{

   

   function Get_($id){
   	return parent::Get('voter',$id);
   }  



}