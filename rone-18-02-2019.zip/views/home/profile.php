<?php
 
 $themeDir = BASE_URL . 'theme1/';

 TemplateSectionStart('mainContent');
?>    


  <section style="margin-top: 93px;background: #28a745;">
    <div class="container" >
      <style type="text/css">
        .ireport img{
          border-radius: 6px;
        }

        @media(min-width: 768px){
          .desktop-centre{
            /*margin-left: 25%;*/
          }
        }

      </style>
       <div class="row ireport">

<div class="col-md-8" style="padding: 0;">

              <?php
               
               if (isset($_SESSION['response']['message'])){
                      $message = $_SESSION['response']['message'];
                      $error = $_SESSION['response']['error'];
                      unset($_SESSION['response']['message']);
               } 

                     if (isset($message)){
                      if (isset($error) && $error){
                         $cls = 'danger';
                      }else{
                       $cls = 'success';  
                      }
                       // global $data;
                       // print_r($data);
                     ?>
                      <div class="alert alert-<?php echo $cls; ?>" style="margin-top: 11px;"><?php echo $message; ?></div>  
                     <?php  
                     }
              ?>


</div>        

  <div class="col-md-5" style="margin-top: 17px;background-color: #fff;padding-top: 14px;padding-bottom: 14px;border: 1px solid #777;border-radius: 8px;margin-bottom: 31px;">
    <div>
      <h4 style="color: #777;font-size: 18px;margin-bottom: 11px;">Profile</h4>
    </div>
    
    <form method="post" action="<?php echo BASE_URL; ?>apiv1/ChangePhone">
      <input type="hidden" name="cbs" value="profile" />
      <input type="hidden" name="cbe" value="profile" />      
    <div>
      <b>Phone</b>
    </div>
    <div>
      <input autocomplete="off" type="text" placeholder="Phone" name="data[phone]" class="form-control" value="<?php echo $profile['phone']; ?>" />
      <hr />
    </div>


    <div>
      <input type="submit" name="" class="btn btn-success" value="Change Phone" />
      <hr />
    </div>
    </form>




    <form method="post" action="<?php echo BASE_URL; ?>apiv1/ChangePassword">
      <input type="hidden" name="cbs" value="profile" />
      <input type="hidden" name="cbe" value="profile" />
    <div>
      <b>Password</b>
    </div>
    <div>
      <input value="<?php echo $profile['password']; ?>" type="password" placeholder="Password" name="password1" class="form-control" />
      <hr />
    </div>


    <div>
      <b>Confirm - Password</b>
    </div>
    <div>
      <input type="password" placeholder="Confirm - Password." name="password2" class="form-control" />
      <hr />
    </div>


    <div>
      <input type="submit" name="" class="btn btn-success" value="Change Password" />
      <hr />
    </div>
    </form>




  </div>



  <div class="col-md-5" style="margin-left: 16px;margin-top: 17px;background-color: #fff;padding-top: 14px;padding-bottom: 14px;border: 1px solid #777;border-radius: 8px;margin-bottom: 31px;">
    <div>
      <h4 style="color: #777;font-size: 18px;margin-bottom: 11px;">Voter Detail</h4>
    </div>
    
    <div>
      <b>First Name</b>
    </div>
    <div>
      <?php echo $profile['first_name'] ?>
      <hr />
    </div>


    <div>
      <b>Last Name</b>
    </div>
    <div>
      <?php echo $profile['last_name'] ?>
      <hr />
    </div>



    <div>
      <b>Polling Unit</b>
    </div>
    <div>
      <?php echo $profile['polling_unit'] ?>
      <hr />
    </div>


    <div>
      <b>VIN - Number</b>
    </div>
    <div>
      <?php echo $profile['vin'] ?>
      <hr />
    </div>



    <div>
      <b>Date Of Birth</b>
    </div>
    <div>
      <?php echo $profile['date_of_birth'] ?>
      <hr />
    </div>


    <div>
      <b>Gender</b>
    </div>
    <div>
      <?php echo $profile['gender'] ?>
      <hr />
    </div>



  </div>
  <!-- [end] -->


</div>
    </div>
</section>



<?php 
 
 EndTemplateSection();

 TemplateExtend('frontend/layout');

?>