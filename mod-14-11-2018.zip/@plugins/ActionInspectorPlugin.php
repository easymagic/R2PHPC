<?php 

/**

@Inject(@services/Db);

*/

class ActionInspectorPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function No_Action(){
    // print_r(func_get_args());
    // echo 'No action called.';
    throw new Exception("Can't use this API without an action!!!.", 1);
  }





}


