<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/View,
        app-x/core/RequestResponse);
*/

class Router{
   

  private function EndsWith($str,$ends){
   $end = substr($str, -1 * strlen($ends));
   $end = strtolower($end);
   if ($end == strtolower($ends)){
    return true;
   }else{
    return false;
   }
  }

  function DispatchAction($plugins,$obj,$name,$method,$args=array()){

     if (isset($_POST) && !empty($_POST)){
      
      $method = $method . '_Action';
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Permission',$args);
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method,$args);
      $this->CallAction($plugins,$obj,$name,$method,$args);        

     }else{

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'No_Action',$args);

     }    
     

  }

  function DispatchRoute($plugins,$obj,$name,$method,$args=array()){
      /////////////////////////////////////
      if ($this->EndsWith($method,'_Action')){
        throw new Exception("<h1>Not Allowed!!!</h1>");
      }
      //////Options - hook /////////////////
      $arg2 = array('sender'=>$obj,'plugins'=>$plugins,'obj'=>$obj,'name'=>$name,'method'=>$method,'args'=>$args,'loader'=>$this->ObjectProxy);      
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Options_Hook',array($arg2) );
      ////universal-hook//////////
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Universal_Hook',$args);
      /////////////////////////////////////
      $this->PayloadService->DecodePayload();
      $payloadData = $this->PayloadService->ExportPayload();
      $args2 = array($payloadData);
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Payload',$args2);
      /////////////////////////////////////
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Permission',$args);
      /////////////////////////////////////
      $this->CallAction($plugins,$obj,$name,'Before_' . $method,$args);        
      /////////////////////////////////////
      $args2 = array_merge($args,array($this->View));
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Inject',$args2);
      /////////////////////////////////////
      $templateString = "@templates/$name/$method" . 'Template';
      $templateObject = DIContainer::GetInstance()->DecodeAnnotationKey($templateString);
      $args2 = array($templateObject);
      if (!method_exists($obj, $method)){
       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Render',$args2);
      }
      /////////////////////////////////////      
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method,$args);
      /////////////////////////////////////
      $this->CallAction($plugins,$obj,$name,$method,$args);        
      /////////////////////////////////////
      $args = array_merge($args,array($this->RequestResponse));
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_JSON',$args);


  }


  function CallAction($plugins,$obj,$name,$method,$args){

      $this->ObjectProxy->CallProxy($obj,$method,$args);

  }




}