<?php 

 // Provide('asset.AssetRead',array(
 //   'search_text'=>$search_text,
 //   'page'=>$page
 // ));
 
 // global $data; 

 foreach ($data as $k=>$v){

   $_SESSION['asset_page_record'][] = $v;

 }
 // $_SESSION['asset_page_record'] = $data;


   foreach ($data as $k=>$v){
 ?><tr>


  <td><?php echo $v['description']; ?></td>
  <td><?php echo $v['asset_category_id']; ?></td>
  <td><?php echo $v['asset_location_id']; ?></td>
  <td><?php echo $v['date_purchased']; ?></td>
  <td><?php echo $v['serial_number']; ?></td>
  <td><?php echo $v['bought_from']; ?></td>

  <td>
    <?php 
     if ($_SESSION['user_account']['role'] == 'admin'){
    ?>
    <a href="<?php echo BASE_URL; ?>asset/edit/<?php echo $v['id']; ?>" class="btn btn-primary btn-sm">
      <i class="fa fa-pencil">Edit</i>
    </a>

    

    <a href="?ccmd=asset/AssetDelete&where[id]=<?php echo $v['id']; ?>" class="btn btn-danger btn-sm confirm"><i class="remove mdi mdi-close-circle-outline"></i></a>

    
    <?php 
     }
    ?>
  </td>
  
  
</tr><?php 
 }
?>