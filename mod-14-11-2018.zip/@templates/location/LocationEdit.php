<?php 



if (count($data) > 0){

  $data = $data[0];

?>
<form method="post">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // LogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Edit Asset Location</h4>
                      <p class="card-description" align="right">
                        <a href="<?php echo $back_link; ?>" class="btn btn-default">Back</a>
                      </p>
                      <form class="forms-sample">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Location Name</label>
                          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Loaction" name="data[name]" value="<?php echo $data['name'] ?>" required="" />
                        </div>
                        <button type="submit" class="btn btn-success mr-2">Save</button>
                        <!-- <button type="reset" class="btn btn-light">Cancel</button> -->
                        <input type="hidden" name="where[id]" value="<?php echo $data['id']; ?>" />
                      </form>
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="assetLocation/AssetLocationUpdate" />

   

</div>

</form>             
<?php 
 }else{
  echo '<h2>Invalid Selection!!!</h2>';
 }
?>