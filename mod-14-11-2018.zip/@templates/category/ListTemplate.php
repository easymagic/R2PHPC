      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="<?php echo BASE_URL; ?>">Home</a></li>
           <li class="active">

             <a href="<?php echo BASE_URL; ?>Category/Add">Add Category</a>

           </li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">




<table class="table table-bordered table-striped">
  
  <tr>
  	<th></th>
  	<th>
  		Name
  	</th>
  </tr>	

  <?php 
   foreach ($category_data as $k=>$v){
  ?>
  <tr>
  	<td>
  		<img src="<?php echo BASE_URL . $v['image']; ?>" style="width: 32px;" />
  	</td>
  	<td>
  		<?php echo $v['name']; ?>
  	</td>
  	<td>
  		<a href="<?php echo BASE_URL; ?>Category/Edit/<?php echo $v['id']; ?>">Edit</a>
  		&nbsp;|&nbsp;
  		<a href="<?php echo BASE_URL; ?>Category/Remove/<?php echo $v['id']; ?>">Remove</a>
  	</td>
  </tr> 
  <?php 
   }
  ?>

</table>





     </div>


