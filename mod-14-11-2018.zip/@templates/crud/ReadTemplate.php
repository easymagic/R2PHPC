<!-- ReadTemplate -->
<div><?php echo $content; ?></div>