<form method="post">
  <input type="text" name="name" placeholder="Input some-foo-thing" />
  <button>Submit-Action.</button>
</form>