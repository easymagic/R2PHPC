    
      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="">Home</a></li>
           <li class="active"><?php echo $title; ?></li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">




<div class="panel panel-default">
          <div class="panel-heading">
            <?php echo $title; ?>
            
            <span class="pull-right">
              <label class="label-checkbox inline">
                <!-- <input type="checkbox" id="toggleLine" checked=""> -->
                <span class="custom-checkbox"></span>
                <!-- Toggle Line -->
              </label>
            </span>

          </div>
          
          <div class="panel-body">

<div data-message></div>            


<div class="row">
              <div class="col-md-4 col-sm-4" data-apply>
                <select data-select class="input-sm form-control inline" style="width:130px;"> 
                  <option value="1">Transform Column</option> 
                </select>
                <a class="btn btn-default btn-sm" data-apply-button>Apply</a>
              </div><!-- /.col -->
</div>


<table class="table table-hover table-striped">
                <thead>
                  <tr>

<th>
<label class="label-checkbox">
                    <input type="checkbox" id="chk-all" data-check-all>
                    <span class="custom-checkbox"></span>
</label>
</th>
   <?php 
    foreach ($fields as $k=>$v){
 ?>
<th><?php echo $Misc->Humanize($v); ?></th>
 <?php 

    }
   ?>


                    
                  </tr>
                </thead>
                <tbody data-tbody>
                  <tr data-tr>

                   <?php 
                     foreach ($fields as $k=>$v){

                      if ($k == 0){

                       ?>


<td>
<label class="label-checkbox">
  <input type="checkbox" id="chk-all" data-col="<?php echo $v; ?>" data-check />
  <span class="custom-checkbox"></span>
</label>  
</td>                    

<td data-col="<?php echo $v; ?>"></td>
                       
                       <?php  

                      }else{
                    ?>

                    <td data-col="<?php echo $v; ?>"></td>

                    <?php 
                      }
                     }
                   ?>
                  </tr>
                </tbody>
              </table>


          </div>
</div>




    
    </div>  









<script type="text/javascript">
  (function($){
    $(function(){

      var $cloneTr = null;
      var $cloneTbody = null;

      function GetCloneTr(){
        $cloneTr = $('[data-tr]').clone();
        $('[data-tr]').hide();
      }
      function GetCloneTBody(){
        $cloneTbody = $('[data-tbody]');
      }

      GetCloneTr();
      GetCloneTBody();

      function AppendRecord(rec){

        $.each(rec,function(k,v){

          var $cloneTrData = $cloneTr.clone();

          $cloneTrData.find('[data-col]').each(function(){
            
            var vl = $(this).data('col');
            if ($(this).is('input')){
             $(this).val(v[vl]);
            }else{
             $(this).html(v[vl]);
            }
            

          });

          $cloneTbody.append($cloneTrData);

        });
        
      }
      window.AppendRecord = AppendRecord;

      AppendRecord(<?php echo $name; ?>Data);


      function ToggleAll(){
        $('[data-check]').each(function(){
          $(this).trigger('click');
        });
        console.log(GetAllChecked());
      }

      $('[data-check-all]').on('click',function(){
         ToggleAll();
      });

      function GetAllChecked(){
        var r = [];
        $('[data-check]').each(function(){
          if ($(this).is(':checked') && $(this).is(':visible')){
            r.push($(this).val());
          }
        });        
        return r;
      }


      var $dataSelect = $('[data-apply]').find('[data-select]');
      var $dataApplyButton = $('[data-apply]').find('[data-apply-button]');

      function GetSelectValue(){
        return $dataSelect.val();
      }

      $dataApplyButton.on('click',function(){

        var vl = GetSelectValue();
        var data = {
          id:GetAllChecked()
        };

        $.ajax({
          url:'<?php echo BASE_URL . $name; ?>/API/?ccmd=' + vl,
          type:'post',
          data:data,
          success:function(response){
            console.log(response);
            location.reload();
          }
        });

      });


      $('[data-message]').html(message);


    });
  })(jQuery);
</script>
