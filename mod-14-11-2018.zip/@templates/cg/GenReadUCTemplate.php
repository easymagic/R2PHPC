

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class <?php echo $name; ?>Read{

 
 function Exec(){
   
   $record = $this->Db->Get('<?php echo strtolower($name); ?>');

   $this->RequestResponse->SetResponse('data',$record);

 }


}