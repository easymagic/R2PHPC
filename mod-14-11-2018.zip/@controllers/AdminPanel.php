<?php
/**

@Inject(@templates/adminpanel/PanelTemplate,
        @services/FolderMigrate,
        @services/DbFields);

*/


class AdminPanel{
  
 
   function Panel($content=''){
      $this->PanelTemplate->content = $content;
      echo $this->PanelTemplate->View();
   }

   function InvalidSelection(){
   	echo 'Invalid Selection!!!';
   }

 
}