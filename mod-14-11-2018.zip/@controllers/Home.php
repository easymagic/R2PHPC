<?php


class Home{
  
   

   function Index(){
    echo 'Home Index ...';
   }  

   function UsePlugins(){
    return array('CRUDPlugin','TestPlugin');
   }

   function Before_Greet(){
    echo 'Checking the time ...<br />';
   }

   function Greet(){
    echo 'Good Morning Nnamdo.';
   }

 
}