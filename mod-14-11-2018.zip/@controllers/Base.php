<?php
/**

@Inject(@templates/entity/EntityToolTemplate,
        @templates/entity/EntityLayoutTemplate,
        @templates/adminpanel/PanelTemplate);

*/


class Base{
  
 
   function Layout($content=''){
    
    $this->PanelTemplate->content = $content;
    echo $this->PanelTemplate->View();  

   }

   function BackEndLayout($content=''){

     $this->PanelTemplate->content = $content;
     echo $this->PanelTemplate->View();

   }


   function Tool($entity){
   	 
   	 $this->EntityToolTemplate->entity = $entity;
     return $this->EntityToolTemplate->View();

   }


 
}