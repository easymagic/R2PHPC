<?php 

/**

@Inject(@services/Db,@templates/cropit/CropitTemplate);

*/


class Category{

  function UsePlugins(){
    return array('CrudPlugin','CrudPermissionPlugin','CrudTemplatePlugin','APIPlugin','UIPlugin','DataPlugin');
    //OEM: (Original Equipment Manufacturer).
  }

  function Greet(){
    return 'Good Evening.';
  }

  function GetEntities(){
    return array('admin1'=>'admin','member'=>'member');
  }

  function GetCountEntities(){
    return array('category'=>'category');
  }

  function GetSumEntities(){
    return array('category1'=>array('category','id'));
  }

  function BeforeDataCount_category(){
    // $this->Db->Where('id','8');
  }

  function BeforeDataSum_category(){
   $this->Db->Where('id','8'); 
  }

  function BeforeDataSeek_admin1(){
    $this->Db->Where('email','admin1');
    // echo 'called before seek admin';
  }

  function BeforeDataSeek_member(){
    // echo 'called before seek member<br />.';
  }

  
  function Init(){
   // $this->Repository->UseResource('category');  
  }

  function Before_Index(){
    // $this->Db->Where('id','8');
  }

  function Before_DropDown(){
   // $this->Db->Where('id','8'); 
  }

  // function DropDown($k,$v,$filterKey,$filterValue){
  // }




}
 