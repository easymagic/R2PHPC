<?php 
/**

@Inject(@templates/Wig/CreateTemplate,
        @framework/controllers/AdminPanel,
        @templates/Wig/ReadTemplate,
        @templates/Wig/EditTemplate,
        @templates/Wig/WigSelectTemplate,
        @usecases/Wig/WigRead,
        @services/DataAdapter,
        @services/CommandSignal,
        @services/MessageLogger,
        @services/Db);

*/

class Wig{

  function Init(){
    $this->CommandSignal->HandleEvents($this);
  }

  function Index(){
   $this->Read();
  }

  function API(){
    
    $response = $this->RequestResponse->GetResponse();

    echo json_encode($response);
    
  }

  
  function Create(){
    $this->CreateTemplate->message = $this->MessageLogger->GetMessageTemplate();
    $this->AdminPanel->Panel($this->CreateTemplate->View());
  }

  function Read(){
   $data = $this->DataAdapter->Resolve($this->WigRead); 
   $this->ReadTemplate->data = $data;
   $this->ReadTemplate->message = $this->MessageLogger->GetMessageTemplate();
   $this->AdminPanel->Panel($this->ReadTemplate->View());
  }

  function Edit($id=''){
   $this->Db->Where('id',$id);
   $this->EditTemplate->message = $this->MessageLogger->GetMessageTemplate();
   $data = $this->DataAdapter->Resolve($this->WigRead); 
   if (count($data) > 0){
     $data = $data[0];
     $this->EditTemplate->data = $data;
     $this->AdminPanel->Panel($this->EditTemplate->View());
   }else{
    $this->AdminPanel->InvalidSelection();
   }
  }

  function Select($k,$label,$v){

   $data = $this->DataAdapter->Resolve($this->WigRead); 
   $this->WigSelectTemplate->data = $data;
   $this->WigSelectTemplate->key = $k;
   $this->WigSelectTemplate->label = $label;
   $this->WigSelectTemplate->value = $v;
   return $this->WigSelectTemplate->View();

  }



}
 