

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class <?php echo $name; ?>Create{

 
 function Exec(){
   
   $data = $this->DataRequirement->Check('data');
   $data = $data['data'];

   $this->Db->Insert('<?php echo strtolower($name); ?>',$data);

   $this->RequestResponse->SetResponse('message','<?php echo $name; ?> added successfully.');
   $this->RequestResponse->SetResponse('newID',$this->Db->InsertID());

 }


}