<?php 

// TemplateStart();

 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $PAGE_TITLE = ''; ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo BASE_URL; ?>LibertyUI/images/favicon.png" />

  <style type="text/css">
    .card-body{
      min-height: 98vh !important;
    }
  </style>
  

  <script src="<?php echo BASE_URL; ?>LibertyUI/vendors/js/vendor.bundle.base.js"></script>
  <script type="text/javascript">
      
      (function($){
        
         $.fn.AjaxPagination = function(config){

             var $el = this;
             var text = $el.html() || $el.val();
             var page_count = 0;
             var locked = false;
             var promise_object = {
                cb:function(response){},
                Append:function(cb){
                 this.cb = cb;
                }

             };

             var $parent = $(config.parent);
             var api = config.api;

             function LoadPage(){
               if (!locked){
                 $el.html('Loading...');
                 locked = true;  
                 ++page_count;
                 $.ajax({
                  url:api,
                  type:'post',
                  data:{
                   page_count:page_count
                  },
                  success:function(response){
                   promise_object.cb(response);
                   locked = false;
                   $el.html(text);
                  }
                 });


               }
             }

             $el.on('click',function(){
              LoadPage();
              return false;
             });


             LoadPage();

             return promise_object;


         };

      })(jQuery);


  </script>  
</head>

<body>



<div class="container-scroller">

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          
<?php 


 echo $content;

?>
          
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018 <a href="http://www.urbanui.com/" target="_blank">Urbanui</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted &amp; made with <i class="mdi mdi-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>



  <!-- plugins:js -->
  
  <script src="<?php echo BASE_URL; ?>LibertyUI/vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo BASE_URL; ?>LibertyUI/js/template.js"></script>
  <!-- endinject -->

<script type="text/javascript">

/***
  (function($){
    $(function(){

      $('[data-value]').each(function(){
        $(this).val($(this).data('value'));
        console.log($(this).data('value'));
      });


          $('.confirm').each(function(){
            $(this).on('click',function(){
              return confirm('Do you want to confirm this action?');
            });
          });


          $('[data-datepicker]').each(function(){

              $(this).datepicker({
                autoclose: true
              });

             var $el = $($(this).data('trigger'));
             console.log($(this).data('trigger'));
             var $this = $(this);

             $el.on('click',function(){
               $this.trigger('click');
               console.log('triggerred');
             });

          });




    });
  })(jQuery);

 ****/
</script>

<?php 
 
 LogvMessage();

?>


</body>

</html>


<?php 

// TemplateStop('footer');