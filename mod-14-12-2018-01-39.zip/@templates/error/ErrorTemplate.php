<!DOCTYPE html>
<html>
<head>
  <title>Error</title>
</head>
<body>
   <h1>Permission - Error</h1>
   <p>
     <?php echo $error_message; ?>
   </p>
</body>
</html>