<?php 
global $routeAction;
global $adminToolBarMenu;

CallAction($obj,'_AdminStart',$args);
CallAction($obj,'_AdminTopBar',$args);
CallAction($obj,'_AdminSideBar',$args);
CallAction($obj,$routeAction . '_AdminToolBar',$args);
CallAction($obj,'_AdminToolBarStop',$args);
CallAction($obj,$routeAction . '_AdminContent',$args);
CallAction($obj,'_AdminStop',$args);
