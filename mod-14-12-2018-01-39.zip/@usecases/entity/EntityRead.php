<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/entity/EntityCommit);


*/

class EntityRead{
  
   

   function Fetch($entity,$id=''){
     
     // $request = $this->RequestResponse->GetRequest();

    // echo $id;



   	 if (!empty($id)){
      // && !is_array($id)
       $this->Db->Where('id',$id);
   	 }else{
   	   // $this->EntityCommit->DoFilter($request);	
   	 }

   	 return $this->Db->Get($entity);     

   }

   function Exec(){

    $record = call_user_func_array(array($this,'Fetch'), func_get_args());
    $this->RequestResponse->SetResponse('data',$record);
   }



}
