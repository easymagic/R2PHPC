<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @usecases/entity/EntityRegister);


*/
class EntityPasswordRecoverChange{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     $this->EntityRegister->CheckPassword($request);

     $request['id'] = base64_decode($request['id']);
     $this->EntityCommit->DoUpdate($request);
     
     $this->RequestResponse->SetResponse('message','Password reset successful.');

  }


}

