<?php 

class admin_status_deactivate implements iusecase{
  
  use entity_single_update_trait;

  
  //abstract implementations

  function get_table_name(){
   return 'admin';
  }

  function get_update_message(){
   return 'Status deactivated!';
  }

  function get_update_input(){
    return array(
     'status'=>0
    );
  }



}