<?php 

/**

@Inject(@templates/User/CreateTemplate,
        @framework/controllers/AdminPanel,
        @templates/User/ReadTemplate,
        @templates/User/EditTemplate,
        @usecases/User/UserRead,
        @services/DataAdapter,
        @services/Db);

*/

class User{

  
  function Create(){
    $this->AdminPanel->Panel($this->CreateTemplate->View());
  }

  function Read(){
   $data = $this->DataAdapter->Resolve($this->UserRead); 
   $this->ReadTemplate->data = $data;
   $this->AdminPanel->Panel($this->ReadTemplate->View());
  }

  function Edit($id=''){
   $this->Db->Where('id',$id);
   $data = $this->DataAdapter->Resolve($this->UserRead); 
   if (count($data) > 0){
     $data = $data[0];
     $this->EditTemplate->data = $data;
     $this->AdminPanel->Panel($this->EditTemplate->View());
   }else{
    $this->AdminPanel->InvalidSelection();
   }
  }



}
 