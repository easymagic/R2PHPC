<?php
/**

@Inject(@templates/entity/EntityToolTemplate,
        @templates/entity/EntityLayoutTemplate,
        @templates/adminpanel/PanelTemplate);

*/


class Base{
  
 
   function Layout($content=''){
    global $data;
    $data['content'] = $content;
    // $this->PanelTemplate->content = $content;
    return $this->PanelTemplate->Render();  

   }

   function BackEndLayout($content=''){
    global $data;
    $data['content'] = $content;
     // $this->PanelTemplate->content = $content;
     return $this->PanelTemplate->Render();

   }


   function Tool($entity){
    global $data;
    $data['content'] = $content;   	 
   	 // $this->EntityToolTemplate->entity = $entity;
     return $this->EntityToolTemplate->Render();

   }


 
}