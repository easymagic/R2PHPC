<?php 

/**

@Inject(@services/Db,
        @services/file/FileUpload,
        api-templates/FooTemplate);

*/


class AcountEntityPlugin{

    
    function GetPluginActions(){
    	return array('Login','Register','ChangePassword','ChangePasswordReset','SendEmail','SendVerification','SendPasswordReset','SendPasswordResetSuccess','GetAuthAccount','VerifyAccount','LogOut','UpdateProfile');
    }


    function Login_Action($entity=''){
      $result = array();
      
       if (!empty($entity) && isset($_POST['data']) && isset($_POST['data']['email']) && isset($_POST['data']['password'])){
         
         $this->Db->Where('email',$_POST['data']['email']); 
         $this->Db->Where('password',$_POST['data']['password']); 
         $record = $this->Db->Get($entity);

         if (!isset($_SESSION['accounts'])){
          $_SESSION['accounts'] = array();
         }
         if (count($record) > 0){
          $record = $record[0];
          $result['data'] = $record;
          $result['message'] = 'Login Successful.' . $this->FooTemplate->View();
          $_SESSION['accounts'][$entity] = $result;
         }else{
          throw new Exception("Invalid login!", 1);
         }
       }else{
        throw new Exception("Invalid params!", 1);
       } 

      return $result;
    }






}