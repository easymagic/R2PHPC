<?php 

/**

@Inject(@services/Db,@services/file/FileUpload);

*/


class APIEntityPlugin{

    
    function GetPluginActions(){
    	return array('Create','All','Find','Update','UpdateBatch','Delete','DeleteBatch','CountRows','Sum','GarbageFieldFile');
    }

    function Hook_Seek($entity){
	    $config = array();
	    include('config/on-seek.php');
	    if (isset($config[$entity])){
	      foreach ($config[$entity] as $k=>$v){
	        $this->Db->And($v[0],$v[1]);  
	      }
	    }    	
    }


	function All_Inject($entity='',$id=''){
		// print_r(func_get_args());
		$record = array();
		if (!empty($entity)){
			$this->Hook_Seek($entity);
			if (!empty($id) && is_numeric($id)){
               $this->Db->Where('id',$id);
               $record = $this->Db->Get($entity);		
               if (count($record) > 0){
                $record = $record[0];
               }
			}else{
		       $record = $this->Db->Get($entity);		
			}
          
		}
		
      return array($entity . '_data'=>$record);
	}

	function Find_Inject($entity='',$key='',$value=''){
		$record = array();
		if (!empty($entity) && !empty($key) && !empty($value) && !is_numeric($key)){
			$this->Hook_Seek($entity);
            $this->Db->Where($key,$value);
            $record = $this->Db->Get($entity);		
		}
        return array($entity . '_data'=>$record);
	}

	function CountRows_Inject($entity=''){

		$record = array();
		$count = 0;
		if (!empty($entity)){

			 $this->Hook_Seek($entity);
			 $record = $this->Db->DoCount($entity,$alias='recordCount');
			 $record = $record[0];
			 $count = $record['recordCount'];
		}
		return array($entity . '_count'=>$count);

	}

	function Sum_Inject($entity='',$field=''){

		$record = array();
		$sum = 0;
		if (!empty($entity) && !empty($field)){

			 $this->Hook_Seek($entity);
			 $record = $this->Db->DoSum($entity,$field,$alias='sumTotal');
			 $record = $record[0];
			 $sum = $record['sumTotal'];
		}
		return array($entity . '_sum'=>$sum);

	}


	function All_Action(){
		// echo "string...";
     return array('msg'=>'Hello World Action!.');
	}

	function Update_Action($entity='',$id=''){
      $result = array();
      $result['message'] = 'Updating...';
      $result['data'] = $_POST;
      if (!empty($entity) && !empty($id) && is_numeric($id)){
        $this->Hook_Seek($entity);
        // echo "string,,,";
        $this->HandleMediaEvents($_POST);
        // print_r($_POST);
        // echo "string";
        $this->Db->Where('id',$id);
        $this->Db->Update($entity,$_POST['data']);
        $result['message'] =  'Updated.';
      }
      return $result;
	}



	function UpdateBatch_Action($entity='',$key='',$value=''){
      $result = array();
      $result['message'] = 'Updating Batch...';
      $result['data'] = $_POST;
      if (!empty($entity) && !empty($key) && !is_numeric($key) && !empty($value)){
        $this->Hook_Seek($entity);
        $this->HandleMediaEvents($_POST);
        $this->Db->Where($key,$value);
        $this->Db->Update($entity,$_POST['data']);
        $result['message'] =  'Updated Batch.';
      }
      return $result;
	}




	function Delete_Inject($entity='',$id=''){
      $result = array();
      $result['message'] = 'Deleting...';
      $result['data'] = $_POST;
      if (!empty($entity) && !empty($id) && is_numeric($id)){
        $this->Hook_Seek($entity);
        $this->Db->Where('id',$id);
        $this->Db->Delete($entity);
        $result['message'] =  'Deleted.';
      }
      return $result;
	}



	function DeleteBatch_Inject($entity='',$key='',$value=''){
      $result = array();
      $result['message'] = 'Deleting Batch...';
      $result['data'] = $_POST;
      if (!empty($entity) && !empty($key) && !is_numeric($key) && !empty($value)){
        $this->Hook_Seek($entity);
        $this->Db->Where($key,$value);
        $this->Db->Delete($entity);
        $result['message'] =  'Deleted Batch.';
      }
      return $result;
	}

	function Create_Action($entity=''){

      $id = 0;
      if (!isset($_REQUEST['data'])){
       throw new Exception("data-param required!", 1);
      }
      if (!empty($entity)){
      	$this->HandleMediaEvents($_POST);
      	$this->CheckDuplicateRecord($entity,$_POST,$message='Duplicate Record!');
	    $this->Db->Insert($entity,$_POST['data']);    
	    $id = $this->Db->InsertID();
      }
      return array('message'=>'New Record Added...','id'=>$id);

	}


  private function CheckFileUpload(&$request){
    if (isset($_FILES)){
      foreach ($_FILES as $k=>$hnd){
      	// echo $k;
       if ($this->FileUpload->DoUpload($hnd,$k)){
         $request['data'][$k] = $this->FileUpload->GetUploadedFile();
       }
      }
      // print_r($request);
    }
  }

  private function HandleMediaEvents(&$request){
  	$this->CheckFileUpload($request);
  }


  private function CheckDuplicateRecord($entity,&$request,$message='Duplicate Record!'){
    
    if (isset($request['check'])){
      
      $key = $request['check'];
      $value = $request['data'][$key];
      $record = $this->Db->Where($key,$value)->Get($entity);
      
      if (count($record) > 0){
        throw new Exception($message, 1);
      }

    }

  }

  private function GetDirContentsForGarbage($field){
    $path = 'uploads/' . $field . '-uploads';
    $dir = scandir($path);
    $dir = array_diff($dir, array('.','..'));
    $lst = array();
    foreach ($dir as $k=>$v){
     $lst[] = $path . '/' . $v;
    }
    return $lst;
  }

  function GarbageFieldFile_Inject($entity='',$field=''){

  	$result = array();
  	$result['message'] = 'Garbaged field.';
    
    if (!empty($entity) && !empty($field)){
       
       $this->Hook_Seek($entity);
       $record = $this->Db->Get($entity,$field);
       $recs = array();
       foreach ($record as $k=>$v){
         $recs[] = $v[$field];
       }

       $result['totalFiles'] = $recs;
       $result['totalGarbageFiles'] = array_diff($this->GetDirContentsForGarbage($field),$recs);

       //garbage the excess files
       $lst = array();
       foreach ($result['totalGarbageFiles'] as $k=>$v){
         $lst[] = $v;
         @unlink($v);
       }
       $result['totalGarbageFiles'] = $lst;
       $result['Garbaged'] = count($result['totalGarbageFiles']);
       $result['TotalLeft'] = count($result['totalFiles']);

    }

  	return $result;

  }



}