<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/View,
        app-x/core/RequestResponse);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;
   

  private function EndsWith($str,$ends){
   $end = substr($str, -1 * strlen($ends));
   $end = strtolower($end);
   if ($end == strtolower($ends)){
    return true;
   }else{
    return false;
   }
  }

  function SetParams($plugins,$obj,$name,$method,$args){
   $this->plugins = $plugins;
   $this->obj = $obj;
   $this->name = $name;
   $this->method = $method;
   $this->args = $args;
  }

  private function UpdateViewData($dt){
    if (is_array($dt)){
     foreach ($dt as $k=>$v){
       $this->View->$k = $v;
     }
    }
  }

  function DispatchAction($plugins,$obj,$name,$method,$args=array()){

     // $plugins = $this->plugins;
     // $obj = $this->obj;
     // $name = $this->name;


     // $this->PluginLoader->SetParams($plugins,$obj,$name,$method,$args);

     
      
      try {

      /////////////////////////////////////
      $this->PayloadService->DecodePayload();
      $payloadData = $this->PayloadService->ExportPayload();
      $args2 = array($payloadData);
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Payload',$args2);

       if (isset($_POST) && !empty($_POST)){

        // print_r($_POST);
        // print_r($_REQUEST);

      
        $method = $method . '_Action';
        $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Permission',$args);
        $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Global_Permission',array($name,$method,$args));
        $vars = $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method,$args);
        $this->UpdateViewData($vars);
        $vars = $this->CallAction($method,$args);        
        $this->UpdateViewData($vars);

        $_POST = array();

       }else{

        $vars = $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'_No_Action',$args);
        $this->UpdateViewData($vars);

       }    

        
      } catch (Exception $e) {

        $this->UpdateViewData(array('error'=>true,'message'=>$e->getMessage()));

      }


     

  }

  function DispatchRoute($plugins,$obj,$name,$method,$args=array()){

     // $plugins = $this->plugins;
     // $obj = $this->obj;
     // $name = $this->name;

     // $this->PluginLoader->SetParams($plugins,$obj,$name,$method,$args);
      
      /////////////////////////////////////
      if ($this->EndsWith($method,'_Action')){
        throw new Exception("<h1>Not Allowed!!!</h1>");
      }
      //////Options - hook /////////////////
      $arg2 = array('sender'=>$obj,'plugins'=>$plugins,'obj'=>$obj,'name'=>$name,'method'=>$method,'args'=>$args,'loader'=>$this->ObjectProxy,'pluginLoader'=>$this->PluginLoader);      
      
      try {

          $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Options_Hook',array($arg2) );
          ////universal-hook//////////
          $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Universal_Hook',$args);
          /////////////////////////////////////
          $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Permission',$args);
          $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Global_Permission',array($name,$method,$args));
          /////////////////////////////////////
          $this->CallAction('Before_' . $method,$args);        
          /////////////////////////////////////
          // $args2 = array_merge($args,array($this->View));
          $vars = $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Inject',$args);
          // print_r($vars);
          $this->UpdateViewData($vars);

        
      } catch (Exception $e) {
         
         $this->UpdateViewData(array('error'=>true,'message'=>$e->getMessage())); 

      }



      /////////////////////////////////////
      $templateString = "@templates/$name/$method" . 'Template';
      // echo $templateString;
      $templateObject = DIContainer::GetInstance()->DecodeAnnotationKey($templateString);
      $args2 = array($templateObject);

      $buffer = '';

      // echo "[" . get_class($obj) . "," . $method . "]<br />";
      if (!method_exists($obj, $method)){
        // echo $method . '<br />';
       $buffer = $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Render',$args2);
       // echo $buffer;
      }
      /////////////////////////////////////      
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method,$args);
      /////////////////////////////////////
      $buffer.=$this->CallAction($method,$args);        
      /////////////////////////////////////
      // $args = array_merge(array(InjectViewClass::GetBuffer()));
      $view_buffer = InjectViewClass::GetBuffer();
      $args = array();
      $data = array();
      foreach ($view_buffer as $k=>$v){
        if (!is_object($v)){
         $data[$k] = $v;
        }
      }
      $args[] = $data;

      $buffer.=$this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_JSON',$args);
      
      return $buffer;
  }


  function CallAction($method,$args){

      return $this->ObjectProxy->CallProxy($this->obj,$method,$args);

  }




}