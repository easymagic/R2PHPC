<?php 

class DIContainer{
  
  private static $dep = array(); 
  private static $instance = null;

  private $depString = array(); 
  private $clsObject = null;



   static function GetInstance(){
    return new DIContainer();
   }

   static function GetRepository(){
    return self::$dep;
   }

   function InjectClass($cls){

    if (!$this->HasDep($cls)){
     $this->clsObject = new $cls(); 
     $this->Set($cls,$this->clsObject);
     $this->GetInjectAnnotation();
     $this->DecodeAnnotations();
     $this->Set($cls,$this->clsObject);
     if (method_exists($this->clsObject, 'Init')){

      $this->clsObject->Init();
       
     }
    }

    return $this->Get($cls);

   }

   private function Get($k){
     
     if (isset(self::$dep[$k])){
       return self::$dep[$k];
     }else{
       return null;
     }

   }

   private function Set($k,$v){
     self::$dep[$k] = $v;
   }

   private function HasDep($k){
     return isset(self::$dep[$k]);
   }

   static function ConvertAnnotation($doc){

    $rr = array();

    if (!empty(trim($doc))){

      $r = explode('@Inject(', $doc);
      $r = explode(')', $r[1]);
      $r = $r[0];
      $r = explode(',', $r);
      $r = array_map('trim', $r);

      foreach ($r as $k=>$v){

         $rr[] = $v;

      }

    } 

    return $rr; 

   }


   private function GetInjectAnnotation(){

    $reflect = new ReflectionClass($this->clsObject);
    $doc = $reflect->getDocComment();
    // $this->depString = array();
      $r = self::ConvertAnnotation($doc);

      foreach ($r as $k=>$v){
         $this->depString[] = $v;
      }
     
   }


  private function AutoInjectDependencies(){
    // $this->depString[] = 'app-x/core/SideEffect';
    // print_r($this->depString);
  } 

   private function DecodeAnnotations(){
     
     foreach ($this->depString as $k=>$v){
        // $r = explode('/', $v);
        $this->DecodeAnnotationKey($v);
     }

     $this->UpdateDependencies();

   }

   private function UpdateDependencies(){
     foreach (self::$dep as $k=>$v){
      $this->clsObject->$k = $v;
     }
   }

   function DecodeAnnotationKey($depStr){
      
      $file = $depStr . '.php';
      // echo $file;
      $obj  = null;

      if (file_exists($file)){
        

        $r = explode('/', $depStr);

        $package = array_shift($r);

        $cls = end($r);

        if (!$this->HasDep($cls)){

            if ($package == '@templates' || substr($cls, -8) == 'Template'){ 

               $this->Set($cls,new InjectViewClass($depStr));
               $obj = $this->Get($cls);
     
            }else if ($package == '@loopers'){

              $this->Set($cls,new InjectViewClass($depStr));
              $obj = $this->Get($cls);

            }else{   

              require_once($file);                         
              
              $this->Set($cls,DIContainer::GetInstance()->InjectClass($cls));
              $obj = $this->Get($cls);

            }



        }else{
          $obj = $this->Get($cls);
        }


      }

      // print_r($obj);


      return $obj;

   }







}



class InjectViewClass{
  
  private $view_ = null;
  private static $vars = array();

   function __construct($view){
     $this->view_ = $view;
     // self::$vars = DIContainer::GetRepository();
     $arr = DIContainer::GetRepository();
     foreach ($arr as $k=>$v){
       self::SetKey($k,$v);
     }
   }

   function __set($k,$v){
     self::$vars[$k] = $v;
   }

   public static function SetKey($k,$v){
    self::$vars[$k] = $v; 
   }

   public static function GetKey($k){
    if (isset(self::$vars[$k])){
     return self::$vars[$k];
    }else{
     return '';  
    }
   }

   public static function GetBuffer(){
    return self::$vars;
   }

   function View(){
    
      $file = $this->view_ . '.php';

      if (file_exists($file)){
        extract(self::$vars);
        StartBuffer();
        include($file);
        return GetBuffer();
      }

   }


   function LoopView($varName='data'){
    
      $file = $this->view_ . '.php';
      $__r__ = array();

      if (file_exists($file)){
        extract(self::$vars);
        if (isset($$varName)){

           foreach ($$varName as $k=>$v){

             $row = $v; //alias v to row.

              StartBuffer();
              include($file);
              $__r__[] = GetBuffer();

           }

        }
      }

      return implode('', $__r__);

   }



}


