<?php 

$config['admin1'] = array(
 array('id',4)
);

$config['category1'] = array(
 array('id',58)
);