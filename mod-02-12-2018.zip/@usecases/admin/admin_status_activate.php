<?php 

class admin_status_activate implements iusecase{
  
  use entity_single_update_trait;

  
  //abstract implementations

  function get_table_name(){
   return 'admin';
  }

  function get_update_message(){
   return 'Status activated!';
  }

  function get_update_input(){
    return array(
     'status'=>1
    );
  }



}