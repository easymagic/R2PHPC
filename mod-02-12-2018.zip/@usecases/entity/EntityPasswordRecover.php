<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/EmailQueue,
        @usecases/entity/EntityRegister);


*/
class EntityPasswordRecover{
  
  private $entity = '';

  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     $entity = $this->EntityCommit->GetEntity();
     
     if (!isset($request['email']))throw new Exception("email-param required!", 1);
     
     $email = $request['email'];

     $this->SendPassResetEmail('email',$email);
     
  }

  private function GetResetLink($id){
    return '<a href="' . BASE_URL . $this->entity . '/RecoverPasswordChange/' . base64_encode($id) . '">link</a>';
  }  


  function SendPassResetEmail($k,$v){
     
     $data = $this->EntityRegister->GetData($k,$v);
     $msg = '<b>Dear user,</b><br /> 
             Your password reset request was successful,<br />
             Click on the ' . $this->GetResetLink($data['id']) . ' to reset your password.
             <br /><br />
             <b>Regards.</b>';

     $this->EmailQueue->SetSubject('PASSWORD RESET FROM SITE.COM');             
     $this->EmailQueue->SetMessage($msg);
     $this->EmailQueue->SetTo($data['email']);
     $this->EmailQueue->SetFrom('info@site.com');
     $this->EmailQueue->Send();

  }



}

