<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService,
        @services/AuthorizationService);

*/

class APIPluginv2{

  private $entity;
  private $plugins = array();
  // private $pluginsObj = array();

  function GetScope(){
    return 'private';
  }

  function LoadAPIPlugins(){
    $dir = scandir('api-plugins');
    $dir = array_diff($dir, array('.','..'));
    foreach ($dir as $k=>$v){
      $r = explode('.php', $v);
      require_once('api-plugins/' . $r[0] . '.php');
      $cls = $r[0];
      $this->plugins[$r[0]] = DIContainer::GetInstance()->DecodeAnnotationKey('api-plugins/' . $r[0]);
      // $this->plugins[$r[0]] = new $cls(); // $r[0];
    }
  }

  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function Collection_Payload($requestData){
    foreach ($requestData as $k=>$v){

      $_REQUEST[$k] = $v;

    }
    $this->RequestResponse->SetRequest($requestData);
    $this->LoadAPIPlugins();
  }

  function CallPlugins($hook,$args){
     $r = array();
     // $argsold = $args;
     $entity = array_shift($args);
     $action = array_shift($args);
     foreach ($this->plugins as $k=>$v){
       
       if (method_exists($v, 'GetPluginActions') && in_array($action, $v->GetPluginActions())){
          if (method_exists($v, $action . $hook)){
            array_unshift($args,$entity);
            $r = call_user_func_array(array($v,$action . $hook), $args);
            break;
          }
       }

     }
   return $r;
  }

  function Collection_Action(){
     return $this->CallPlugins('_Action',func_get_args());
  }

  function Collection_Inject(){
     return $this->CallPlugins('_Inject',func_get_args()); 
  }


  function Collection_JSON($json){
    return json_encode($json);
  }




}


