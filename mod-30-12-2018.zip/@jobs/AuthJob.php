<?php 


$auth = '';
$authFailRedirect = '';

class AuthJob{

   
   function PostJob(){

   	 global $redirect;
   	 global $auth;
   	 global $authFailRedirect;
   	 global $accounts;
   	 global $RedirectJob;

   	 if (!empty($auth)){
       if (!isset($accounts[$auth])){
         $redirect = $authFailRedirect;
         $RedirectJob->PostJob();
        // echo "redrrr";
       }
   	 }



   }


}