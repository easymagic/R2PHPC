<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/RequestResponse,
        app-x/core/EmailQueue,
        @services/PluginAdapter);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;

  private function ExecJobs(){
   global $serverJobs;
    foreach ($serverJobs as $serverJob){
       if (method_exists($serverJob, 'PostJob')){
         $serverJob->PostJob(); //execute each job
       }
    }   
  }
   


  function Dispatch(){

    global $data;
    global $json;
    global $actionPermission;
    global $permission;
    // global $accounts;
    global $contentType;
    global $routeName;
    global $routeAction;
    global $routeArgs;
    global $buffer;
    // global $redirect;

    
    $method = $routeAction;
    $args = $routeArgs;

    // echo $routeAction;
    // echo $routeName;
    
    CallAction('Page_Init');

    if (ActionTrigerred()){

      CallAction($method . '_ActionPermission');

       if ($actionPermission){

         // CallAction($method . '_PreAction');        
         // $this->ExecJobs();
         CallAction($method . '_Action');        
       }else{
         throw new Exception("You do not have the permission to call this action!");
       }

    }else{

       CallAction($method . '_NoAction');

    }

    

    CallAction($method . '_Permission');

    if ($permission){


       CallAction($method);
       ///users can develop their own framework theme loading pattern.
       RunThemes();

       

    }else{
      
      throw new Exception("You do not have the permission to view this page!");

    }

    //PersistData(); //persist data for another page.

    //call server-jobs handlers
    $this->ExecJobs();

    CallAction('Page_Destroy');


    //check content-type
    if ($contentType == 'json'){
      foreach ($data as $k=>$v){
         if (!is_object($v)){
           $json[$k] = $v;
         }
      }
      $buffer = json_encode($json);
    }

  }





}