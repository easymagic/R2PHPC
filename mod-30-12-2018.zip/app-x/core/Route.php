<?php 

/**

@Inject(@services/RequestResponse,
        app-x/core/SideEffect,
        @services/View,
        @services/PayloadService);

*/

class Route{
   

  function FormSubmitted(){
    $this->RequestResponse->SetRequest($_REQUEST);
    return !empty($_POST);
  }


  private function EndsWith($str,$ends){
   //Action
   $end = substr($str, -7);
   $end = strtolower($end);
   if ($end == $ends){
    return true;
   }else{
    return false;
   }
  }


   function ProxyCallMethod($obj,$mtd,$args){
    $r = null; 
     if (method_exists($obj, $mtd)){
       $r = call_user_func_array(array($obj,$mtd), $args);  
     }
    return $r; 
   }
  


  function HandleDispatch($obj,$method,$args=array()){
    try {
      $this->HandleDispatchInner($obj,$method,$args);
    } catch (Exception $e) {
      // $this->RequestResponse->SetResponse('message',$e->getMessage());
      // $this->RequestResponse->SetResponse('error',true);
      echo "<h1>{$e->getMessage()}</h1>";
    }
  }


  function HandlePlugins($obj,$method,$args=array()){
       if (method_exists($obj, 'UsePlugins')){

         $this->PayloadService->DecodePayload();

         $this->SideEffect->RegisterSideEffects($obj->UsePlugins(),$obj,$method . '_Payload',array($this->PayloadService->ExportPayload()));
         
         $this->SideEffect->RegisterSideEffects($obj->UsePlugins(),$obj,$method . '_Permission',$args);
         $this->SideEffect->RegisterSideEffects($obj->UsePlugins(),$obj,$method . '_InjectView',array_merge($args,array($this->View)));
          $template = '@templates/' . strtolower(get_class($obj)) . '/' . $method . 'Template';
          // echo $template;
          $_view = DIContainer::GetInstance()->DecodeAnnotationKey($template);
          $args2 = array($_view);

         if (!method_exists($obj, $method)){
            $this->SideEffect->RegisterSideEffects($obj->UsePlugins(),$obj,$method . '_RenderView',$args2);
         }
         


         $this->SideEffect->RegisterSideEffects($obj->UsePlugins(),$obj,$method,$args);

         $this->SideEffect->RegisterSideEffects($obj->UsePlugins(),$obj,$method . '_JSON',$args);


       }
  }


  function HandleDispatchInner($obj,$method,$args=array()){

      $methodAction = $method . '_Action';

      if ($this->FormSubmitted()){
       // $this->ProxyCallMethod($obj,$methodAction . 'Permission',$args);

       $this->HandlePlugins($obj,$methodAction,$args); 
       $this->ProxyCallMethod($obj,$methodAction,$args);

       
      }

      if (!$this->EndsWith($method,'_action')){

       $this->ProxyCallMethod($obj,'Before_'.$method,$args);
       $this->HandlePlugins($obj,$method,$args);
       $this->ProxyCallMethod($obj,$method,$args);
       $this->ProxyCallMethod($obj,'After_'.$method,$args);

      }else{
        echo '<h1>Not Allowed!!:(</h1>';
      }

  }


}