<?php 

class TransactionFilterFailed{

  


   function FilterFailed(){//
    global $db_where;
     
    $db_where = " where (pstatus = 'failed') "; 

   }



}