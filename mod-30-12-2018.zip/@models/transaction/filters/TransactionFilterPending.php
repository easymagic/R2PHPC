<?php 

class TransactionFilterPending{

  


   function FilterPending(){//
    global $db_where;
     
    $db_where = " where (pstatus = 'pending') "; 

   }



}