<?php 

class TransactionFilterSuccess{

  


   function FilterSuccess(){//
   	global $db_where;
     
    $db_where = " where (pstatus = 'success') "; 

   }



}