<?php 

class TransactionFilterSettled{

  


   function FilterSettled(){//
    global $db_where;
     
    $db_where = " where (pstatus = 'settled') "; 

   }



}