<?php 
/**

@Inject(@models/entityv2/EntityRead);

*/

class TransactionGetList{
  

  function GetList(){
  	$this->EntityRead->Read('transaction');
  }
   

}