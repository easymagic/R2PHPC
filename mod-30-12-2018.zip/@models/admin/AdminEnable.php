<?php 

/**

@Inject(@models/entityv2/EntityEnableField);

*/

class AdminEnable{

  

   function Enable($id){
     $this->EntityEnableField->EnableField('admin','status',"id=$id");
   }


}