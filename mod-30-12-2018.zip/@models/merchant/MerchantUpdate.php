<?php 

/**

@Inject(@models/entityv2/EntityUpdate,
        @models/entityv2/EntityGenerateUID);

*/
class MerchantUpdate{

  


  function Update($id){
    global $postData;
    global $data;

    if (isset($postData['email'])){ //security measures
      unset($postData['email']);
    }
    if (isset($postData['password'])){ //security measures
     unset($postData['password']);
    }

  	$this->EntityUpdate->DoUpdate('merchant',$postData,"id=$id");
	$this->EntityGenerateUID->GenerateUID('merchant','merch_secret',$id,"id=$id",11); //keep consistent.

  	$data['error'] = false;
  	$data['message'] = 'Account saved.';

  }



}