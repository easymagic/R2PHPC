    <header class="main-header">
        <a href="http://localhost/admin/" class="logo">
            <span class="logo-mini"><img src="http://localhost/admin//images/Fordepro_favicon.png" style="height: 45px"></span>
            <span class="logo-lg"><img src="http://localhost/admin/../assets/main/images/Fordepro_logo_white.png" style="height: 45px"></span>
        </a>

        <nav class="navbar navbar-static-top">
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">

                    <!-- Notifications: style can be found in dropdown.less -->


                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs">Admin</span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- Menu Footer-->
                            <li class="user-footer">
                                <?php 
                                 $ctrl = 'Merchant/';
                                 if ($session_type == 'admin'){
                                   $ctrl = 'ManageAccounts/';
                                 }
                                ?>
                                <div class="pull-left">
                                    <a href="<?php echo BASE_URL . $ctrl; ?>ChangePassword"
                                       class="btn btn-default btn-flat">Change Password</a>
                                </div>

                                <div class="pull-right">
                                    <a href="<?php echo BASE_URL . $ctrl; ?>LogOut" class="btn btn-default btn-flat">Sign
                                        out</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>

        </nav>
    </header>
