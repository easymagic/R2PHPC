<?php 


class CheckMerchantSessionPlugin{


 function MerchantLogin_AdminContent(){
   global $session;
   global $redirect;


   if (isset($session['merchant_session'])){
     $redirect = 'Merchant/Dashboard';
   }


 }  

 

}