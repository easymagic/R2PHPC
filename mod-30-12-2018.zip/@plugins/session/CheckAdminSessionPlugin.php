<?php 


class CheckAdminSessionPlugin{


 function Index_AdminContent(){
  $this->AdminLogin_AdminContent();
 }

 function AdminLogin_AdminContent(){
   global $session;
   global $redirect;
  
   // echo 'Called...';

   if (isset($session['admin_session'])){
     $redirect = 'ManageAccounts/Dashboard';
   }


 }  

 

}