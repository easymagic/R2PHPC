<?php 

class WebPayment{

  
  
 function GateWay($uid){

 }



}