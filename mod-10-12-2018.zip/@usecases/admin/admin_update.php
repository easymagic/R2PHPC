<?php 

class admin_update implements iusecase{
  
  use entity_update_trait;

  
  //abstract implementations

  function get_logout_message(){
    return 'Just logged out!';
  }

  function get_session_name(){
    return 'admin_account';
  }

  function get_table_name(){
  	return 'admin';
  }

  function get_update_message(){
  	return 'Admin account updated.';
  }



}