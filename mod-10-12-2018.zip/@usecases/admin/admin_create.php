<?php 

class admin_create implements iusecase{
  
  use entity_create_trait,entity_record_exists_trait{
     

     entity_create_trait::exec as trait_create;

  }

 
  function exec(){
    
    if ($this->input['password1'] == $this->input['password2'] && strlen($this->input['password1'])){

       $this->input['data']['password'] = $this->input['password1'];
       $this->input['data']['date_created'] = date('Y-m-d h:i:s');

       if ($this->record_exists('admin',array('email'=>$this->input['data']['email']))){
          throw new Exception("An account with this E-mail already exists!");
       }

       $this->trait_create();

    }else{
      throw new Exception("Passwords do not match!");
    }

  }

  
  //abstract implementations
  function get_table_name(){
    return 'admin';
  }

  function get_create_message(){
    return 'Admin account created successfully.';
  }

}