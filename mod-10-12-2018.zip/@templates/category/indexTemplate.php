<?php 
 // print_r($admin1_data);
 // print_r($member_data);
 if (isset($category_count)){
  // echo "Count: $category_count.<br />";
 }

 if (isset($category1_sum)){
  // echo "Count: $category1_sum.";
 }


 if (isset($message)){
   // echo $message;
 }
?>
      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="<?php echo BASE_URL; ?>">Home</a></li>
           <li class="active">

             <a href="<?php echo BASE_URL; ?>Category/Add">Add Category</a>

           </li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">




<table class="table table-bordered table-striped">
  
  <tr>
    <th></th>
    <th>
      Name
    </th>
  </tr> 

  <?php 
   foreach ($category_data as $k=>$v){
  ?>
  <tr>
    <td>
      <img src="<?php echo BASE_URL . $v['image']; ?>" style="width: 32px;" />
    </td>
    <td>
      <?php echo $v['name']; ?>
    </td>
    <td>
      <a href="<?php echo BASE_URL; ?>Category/Edit/<?php echo $v['id']; ?>">Edit</a>
      &nbsp;|&nbsp;
      <form style="display: inline-block;" method="post" action="<?php echo BASE_URL; ?>category/Index/<?php echo $v['id']; ?>">
       <input type="submit" name="anyname" value="Remove"  class="btn btn-danger" />
      </form>
      
    </td>
  </tr> 
  <?php 
   }
  ?>

</table>









  
    


<?php 
 if (!isset($label))$label='Submit';

?>
<form method="post" enctype="multipart/form-data" action="<?php echo BASE_URL; ?>category">
  <input type="text" name="data[name]"  />
  <button>Add Cat.</button>
  <input type="file" name="image" />
  <div style="clear: both;">&nbsp;</div>
<!-- cropit here -->
<?php 
 // $CropitTemplate->id = uniqid();
 // $CropitTemplate->width = 256;
 // $CropitTemplate->name = 'image';
 // // $CropitTemplate->url = BASE_URL . $image;
 // $CropitTemplate->height = 256;
 // echo $CropitTemplate->View();
?> 

<div style="clear: both;">&nbsp;</div>

  <input type="hidden" name="check" value="name" />
</form>






     



     </div>


