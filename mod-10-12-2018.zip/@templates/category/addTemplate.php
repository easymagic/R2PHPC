<?php 
 if (isset($category_data)){
   // print_r($category_data);
 }
?>

      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="<?php echo BASE_URL; ?>">Home</a></li>
           <li class="active">

             <a href="<?php echo BASE_URL; ?>Category">Back</a>

           </li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">



<?php 
 if (isset($message))echo $message;
 if (!isset($label))$label='Submit';
 if (isset($data) && empty($data)){
  echo 'No-record';
 } 
?>
<form method="post" enctype="multipart/form-data">
  <input type="text" name="data[name]" value="<?php echo $Input->Val('name','category_data'); ?>" />
  <button>Add Cat.</button>
  <input type="file" name="image" />
  <?php 
    $image = $Input->Val('image','category_data');

    if (!empty($image)){

      ?>

      <div style="">
        <img src="<?php echo BASE_URL; ?><?php echo $image; ?>" style="width: 256px;" />
      </div>

      <?php 

    }
  ?>

<div style="clear: both;">&nbsp;</div>

<!-- cropit here -->
<?php 

 // $CropitTemplate->id = uniqid();
 // $CropitTemplate->width = 256;
 // $CropitTemplate->name = 'image';
 // // $CropitTemplate->url = BASE_URL . $image;
 // $CropitTemplate->height = 256;
 // echo $CropitTemplate->View();

?> 

<div style="clear: both;">&nbsp;</div>

  <input type="hidden" name="check" value="name" />
</form>





     </div>

