<?php //echo $entity; ?>
<div class="clearfix">&nbsp;</div>
<div class="col-xs-12" align="right">
    
    

    <a href=""> List</a>&nbsp;|&nbsp;
    <a href=""> &plus; Add</a>&nbsp;|&nbsp;
    <a href="">Export</a>&nbsp;|&nbsp;
    <input type="text" name="" placeholder="Search ..." />



<div class="clearfix">&nbsp;</div>
  
</div>