<?php 

class DIContainer{
  
  private static $dep = array(); 
  private static $instance = null;

  private $depString = array(); 
  private $clsObject = null;



   static function GetInstance(){
    return new DIContainer();
   }

   // static function GetRepository(){
   //  return self::$dep;
   // }

   function InjectClass($cls){
    global $dependencyData;

    if (!isset($dependencyData[$cls])){
     $this->clsObject = new $cls(); 
     // $this->Set($cls,$this->clsObject);
     $dependencyData[$cls] = $this->clsObject;
     $this->GetInjectAnnotation();
     $this->DecodeAnnotations();
     // $this->Set($cls,$this->clsObject);
     $dependencyData[$cls] = $this->clsObject;

     if (method_exists($dependencyData[$cls], 'Init')){

      $dependencyData[$cls]->Init();
       
     }
    }

    return  $this->clsObject; //$this->Get($cls);

   }

   private function Get($k){
     
     if (isset(self::$dep[$k])){
       return self::$dep[$k];
     }else{
       return null;
     }

   }

   private function Set($k,$v){
     self::$dep[$k] = $v;
   }

   private function HasDep($k){
     return isset(self::$dep[$k]);
   }

   static function ConvertAnnotation($doc){

    $rr = array();

    if (!empty(trim($doc))){

      $r = explode('@Inject(', $doc);
      $r = explode(')', $r[1]);
      $r = $r[0];
      $r = explode(',', $r);
      $r = array_map('trim', $r);

      foreach ($r as $k=>$v){

         $rr[] = $v;

      }

    } 

    return $rr; 

   }


   private function GetInjectAnnotation(){

    $reflect = new ReflectionClass($this->clsObject);
    $doc = $reflect->getDocComment();

      $r = self::ConvertAnnotation($doc);

      foreach ($r as $k=>$v){
         $this->depString[] = $v;
      }
     
   }



   private function DecodeAnnotations(){
     
     foreach ($this->depString as $k=>$v){
        InjectKey($v);
     }

     $this->UpdateDependencies();

   }

   private function UpdateDependencies(){
     global $dependencyData;
     global $data;
     foreach ($dependencyData as $k=>$v){
      $data[$k] = $v;
      $this->clsObject->$k = $v;
     }
   }



}


