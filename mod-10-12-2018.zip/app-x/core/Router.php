<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/RequestResponse,
        app-x/core/EmailQueue);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;
   

  private function HandleRedirects(){
    global $redirect;
    if (!empty($redirect)){
      header("Location: " . BASE_URL . $redirect);
      $redirect = '';
      exit();
    }    
  }

  private function HandleEmailQueue(){
    global $emailQueue;
    //subject,message,to,from
    foreach ($emailQueue as $k=>$v){
       if (isset($v['subject']) && isset($v['message']) && isset($v['to']) && isset($v['from'])){
         $this->EmailQueue->SetSubject($v['subject']); 
         $this->EmailQueue->SetMessage($v['message']);
         $this->EmailQueue->SetTo($v['to']);
         $this->EmailQueue->SetFrom($v['from']);
         $this->EmailQueue->Send();
       }
    }
    $emailQueue = array(); //clear the queue.
  }

  private function HandleCartOperations(){
    
    global $cart;
    global $addCart;
    global $removeCart;
    global $session;
    global $data;
    global $cartTotalQty;
    global $cartTotalPrice;


    if (!isset($session['cart_list'])){
      $session['cart_list'] = array();
    }

    $cart = $session['cart_list'];

    if (!empty($addCart) && isset($addCart['id'])){

       if (isset($cart[$addCart['id']])){
         ++$cart[$addCart['id']]['qty'];
         $data['message'] = 'Cart Updated.';
       }else{
         $addCart['qty'] = 1;
         $cart[$addCart['id']] = $addCart; 
         $data['message'] = 'New Item Added To Cart.';
       }

       $addCart = ''; //reset
         
    }

    if (!empty($removeCart) && is_numeric($removeCart) && $removeCart*1 > 0){
       $removeCart = $removeCart * 1;
       if (isset($cart[$removeCart])){
         unset($cart[$removeCart]);
         $data['message'] = 'Item Removed From Cart.';
       }else{
         $data['message'] = 'Item Not Found In Cart!';
       }

       $removeCart = ''; //reset
    }

    $session['cart_list'] = $cart; //update session.

    //total price & qty
    foreach ($cart as $ct){

      if (isset($ct['price'])){
        $cartTotalPrice+=$ct['price']*$ct['qty'];
      }
      if (isset($ct['qty'])){
        $cartTotalQty+=$ct['qty'];
      }
      
    }

  }

  private function HandleHashing(){
    global $hashID;
    global $hashedID;

    if (!empty($hashID)){
       $hashedID = substr(md5($hashID),-7);
       $hashID = 0;
    }

  }

  function Dispatch($plugins,$obj,$name,$method,$args){

    global $data;
    global $dataJSON;
    global $actionPermission;
    global $permission;
    global $accounts;
    // global $redirect;

    $buffer = '';

    if (ActionTrigerred()){

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_ActionPermission',$args);
       if ($actionPermission){
         $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Action',$args);
         $this->CallAction($obj,$method . '_Action',$args);
       }else{
        throw new Exception("You do not have the permission to call this action!");
       }

    }else{

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_NoAction',$args);

    }
    
    //handle email queue
    $this->HandleEmailQueue();
    
    //handle $redirects
    $this->HandleRedirects();

    //handle $accounts
    if (isset($accounts['accounts']))
    foreach ($accounts['accounts'] as $k=>$accountSessionName){
      $accountSessionName = ucfirst($accountSessionName);
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Logged_' . $accountSessionName,$args);
    }

    //handle cart-operations
    $this->HandleCartOperations();

    //handle hashing
    $this->HandleHashing();


    $this->HandleRedirects();


    

    if ($permission){

       $test = $this->CallAction($obj,$method,$args);
       if (!empty($test)){
        $buffer.=$test;
       }
       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Data',$args);

       $this->HandleCartOperations();

       $this->HandleRedirects();

       foreach ($data as $k=>$v){
         if (!is_object($v)){
           $dataJSON[$k] = $v;
         }
       }

       $buffer.= $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Render',$args);

    }else{
      
      throw new Exception("You do not have the permission to view this page!");

    }

    
    return $buffer;

  }



  function CallAction($obj,$method,$args){

      return $this->ObjectProxy->CallProxy($obj,$method,$args);

  }




}