<?php 

class admin_all implements iusecase{
  
  use entity_read_trait;

  
  //abstract implementations
  function get_table_name(){
  	return 'admin';
  }



}