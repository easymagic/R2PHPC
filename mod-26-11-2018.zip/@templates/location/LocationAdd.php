<!-- asset-create -->
<form method="post">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // LogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Add Asset Location</h4>
                      <p class="card-description" align="right">
            <a href="<?php echo $back_link; ?>" class="btn btn-default">Back</a>
                      </p>
                      <form class="forms-sample">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Location Name</label>
                          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Loaction" name="data[name]"  required="" />
                        </div>
                        <button type="submit" class="btn btn-success mr-2">Submit</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                      </form>
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="assetLocation/AssetLocationCreate" />

   

</div>

</form>             