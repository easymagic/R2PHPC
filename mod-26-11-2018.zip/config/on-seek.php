<?php 

$config['admin1'] = array(
 array('id',4)
);