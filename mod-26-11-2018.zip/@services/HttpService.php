<?php 


class HttpService{

  
   function Dispatch($route){
     // $PageObject = DIContainer::GetInstance()->InjectClass('FrontController'); 
     $dt = $this->FrontController->GetDispatch($route);
     return json_decode($dt,true);
   }  



}