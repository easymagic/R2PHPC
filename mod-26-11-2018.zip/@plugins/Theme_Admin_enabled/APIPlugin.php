<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService);

*/

class APIPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function Collection_Payload($requestData){
    $this->RequestResponse->SetRequest($requestData);
    print_r($this->RequestResponse->GetRequest());
    // echo 'called.';
  }

  function Collection_Action($entity='',$id='',$verb=''){
    return $this->CrudService->HandleCrudAction($entity,$id,$verb);
  }

  function Collection_Inject($entity='',$id=''){
    return $this->CrudService->HandleCrud($entity,$id);
    
  }


  function Collection_JSON($json){
    return json_encode($json);
  }




}


