<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService);

*/

class APIPermissionPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function GetScope(){
    return 'private';
  }


  function Collection_Action_Permission($entity='',$id='',$verb=''){
    // print_r(func_get_args());

   if (empty($verb)){

    if ($this->CrudService->IsAddAction($entity,$id)){
      // echo $entity . '_Add'; 
    }else if ($this->CrudService->IsUpdateAction($entity,$id)){
      // echo $entity . '_Update'; 
    }else{
      
    }


   }else if ($this->CrudService->IsDeleteAction($verb)){
      
      // echo $entity . '_Delete';

   }

  }

  function Collection_Permission($entity='',$id=''){
   // print_r(func_get_args());
    if ($this->CrudService->IsReadAction($entity,$id)){
       // echo $entity . '_Read';
    }else if ($this->CrudService->IsReadOneAction($entity,$id)){
       // echo $entity . '_ReadOne';
    }else{
      
    }

  }



}


