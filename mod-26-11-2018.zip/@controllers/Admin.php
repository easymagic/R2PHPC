<?php 

/**

@Inject(@templates/Admin/CreateTemplate,
        @controllers/Base,
        @templates/Admin/IndexTemplate,
        @templates/Admin/EditTemplate,
        @usecases/Admin/AdminRead,
        @services/DataAdapter,
        @services/Db,
        @templates/foo,
        @templates/admin/login);

*/

class Admin{

  private $stamp = '';

   
  function Login(){
    echo $this->login->View();
  }

  function Create(){
    $this->AdminPanel->Panel($this->CreateTemplate->View());
  }

  function Index(){
   $this->Base->BackEndLayout($this->IndexTemplate->View());
  }

  function FooPermission(){
    // echo 'called permission.';
    // throw new Exception("You do not have the permission to access this page!!!",1);
  }


  
  function BeforeFoo(){
    // echo 'Called before Foo...';
  }

  function AfterFoo(){
    echo 'Called after Foo...' . $this->stamp;
  }

  
  function Foo(){
    $this->stamp = 'set.';
    echo $this->foo->View();
  }

  function FooActionPermission(){
    // echo 'Action permission called...';
    throw new Exception("You do not have the permission to call this action!!!",1);
  }

  function Foo_Action(){
    echo 'Action called.';
  }

  function Edit($id=''){
   $this->Db->Where('id',$id);
   $data = $this->DataAdapter->Resolve($this->AdminRead); 
   if (count($data) > 0){
     $data = $data[0];
     $this->EditTemplate->data = $data;
     $this->AdminPanel->Panel($this->EditTemplate->View());
   }else{
    $this->AdminPanel->InvalidSelection();
   }
  }



}
 