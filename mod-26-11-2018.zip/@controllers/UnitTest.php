<?php
/**

@Inject(@framework/controllers/Home,
        @components/category/CategoryListTemplate,
        @usecases/admin/AdminFetch,
        @framework/controllers/CRUDHelper,
        @services/CommandSignal,
        @services/CommandDecorator,
        @services/MessageLogger,
        @services/Permmision,
        @services/DataAdapter,
        @services/RequestResponse,
        @usecases/category/CategoryRead)

*/


class UnitTest{


  function Init(){

  	$this->CommandSignal->HandleEvents($this);

  }

  ///Category
  function ListCategory(){
    $this->RequestResponse->SetRequest(array(
       'filters'=>array(
         'id'=>'24',
         'name'=>'test-category'
       )
    ));
    $record = $this->DataAdapter->Resolve($this->CategoryRead);
    print_r($record);
  }

  function CreateCategory(){
    
    $message = $this->MessageLogger->GetMessageTemplate();
    
    echo $message;
    
    if (isset($this->newID)){
      echo '<br />NewID:' . $this->newID . '<br />';
    }

    $this->CommandDecorator->TriggerCmd('category/CategoryCreate','Create Category','data[name]=test-category');

  }

  function UpdateCategory(){

  }

  ///Member
  function ListMember(){

  }

  function CreateMember(){

  }

  function LoginMember(){

  }

  function VerifyMember(){

  }

  function BlockMember(){

  }

  function UpdateMember(){

  }

  ///wig
  function ListWig(){

  }

  function CreateWig(){

  }

  function UpdateWig(){

  }

  ///wig_order & wig_order_items
  function ListWigOrder(){

  }

  function CreateWigOrder(){

  }

  function CreateWigOrderItems(){

  }

  function UpdateWigOrderItems(){

  }





}