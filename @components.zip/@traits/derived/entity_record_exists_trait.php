<?php 

trait entity_record_exists_trait{
  
   
   function record_exists($table_name,$criteria=array()){
     $record = $this->db->get_where($table_name,$criteria);
     return (count($record) > 0);
   }


}