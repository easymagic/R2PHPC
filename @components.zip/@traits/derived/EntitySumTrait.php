<?php 

/**

@Inject(Db,Message)

*/

trait EntitySumTrait{
  

  use EntityTrait;

  // protected $db = null;


  function Exec(){
    
   //where 
   if (isset($this->input['where']))
    $this->Db->where($this->input['where']);

   //like
   if (isset($this->input['like']))
    $this->Db->like($this->input['like']);

   //limit
   if (isset($this->input['limit']))
    $this->Db->limit($this->input['limit']);

   //order
   // if (isset($this->input['order']))
   //  $this->db->order($this->input['order']);
  
   // echo $this->GetTableName();

  	$record = $this->Db->DoSum($this->GetTableName(),$this->GetFieldName());

  	// $this->output['data'] = $record;
    $this->Message->Set('data',$record);
    
  }

  function InjectServices($Db){
     $this->db = $Db;
  }  

  abstract function GetTableName();
  abstract function GetFieldName();



}