<?php 

trait EntityLogoutTrait{
  
  use EntityTrait;
  // protected $db = null;

  function Exec(){

  	 unset($_SESSION[$this->GetSessionName()]);
     $this->output['message'] = $this->GetLogoutMessage();

  }


  abstract function GetLogoutMessage();
  abstract function GetSessionName();




}