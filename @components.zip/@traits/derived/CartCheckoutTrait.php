<?php 

trait CartCheckoutTrait{
  
  
  use EntityTrait;
  protected $db = null;  


  function Exec(){


     if (!isset($this->input['data']))
      throw new Exception("data-param expected!");

     if (!isset($_SESSION[$this->GetCartName()]))
       throw new Exception("Cart session not set!");

     $cart_data = $_SESSION[$this->GetCartName()];

     $this->db->insert($this->GetOrderTableName(),$this->input['data']);
     $insert_order_id = $this->db->insert_id();     

     $total_qty = 0;
     $total_price = 0;

     foreach ($cart_data as $k=>$v){

        $total_qty+=$v['qty'];
        $total_price+=$v[$this->GetCartPriceName()];
       
        $post_order_items = array();

        $post_order_items[$this->GetOrderChildId()] = $insert_order_id;

        foreach ($this->GetOrderItemsFields() as $k2=>$v2){

           $post_order_items[$k2] = $v[$v2];

        }

        $this->db->insert($this->GetOrderItemsTableName(),$post_order_items);

     }

     $this->db->where(array('id'=>$insert_order_id));
     $response_data = array(

      $this->GetOrderTotalQtyName()=>$total_qty,
      $this->GetOrderTotalPriceName()=>$total_price,
      $this->GetOrderTransactionIdName()=>$this->MakeSalt($insert_order_id)

     );

     $this->db->update($this->GetOrderTableName(),$response_data);

     $this->output['message'] = $this->GetCheckoutMessage();
     $this->output['data'] = $response_data;

     $this->ClearTheCart();


  }

  private function ClearTheCart(){
    if (isset($_SESSION[$this->GetCartName()])){
      unset($_SESSION[$this->GetCartName()]);
    }
  }


  function InjectServices($Db){
     $this->db = $Db;
  }


  private function MakeSalt($id){
    $r = md5($id);
    $r = substr($r, -11);
    return $r;
  }



 abstract function GetOrderTableName();
 abstract function GetOrderTotalQtyName();
 abstract function GetOrderTotalPriceName();
 abstract function GetOrderTransactionIdName();
 abstract function GetOrderItemsTableName();
 abstract function GetOrderItemsFields(); //associative array with data-dictionaries
 abstract function GetOrderChildId();
 abstract function GetCartName();
 abstract function GetCheckoutMessage();
 abstract function GetCartPriceName();



}