<?php 

trait entity_single_update_trait{
  
  use EntityTrait;
  protected $db = null;

  function Exec(){

  	 if (!isset($this->input['where']))
  	 	throw new Exception("The where parameter is required!");

  	 $this->db->where($this->input['where']);

     if (count($this->get_update_input()) > 1)
      throw new Exception("Only one field is allowed!");

  	 $this->db->update($this->get_table_name(),$this->get_update_input());
  	 $this->output['message'] = $this->get_update_message();
  	 $this->output['data'] = $this->get_update_input();

  }

  function GetService($service_locator){
    $this->db = $service_locator->get('db');
  }

  abstract function get_table_name();
  abstract function get_update_message();
  abstract function get_update_input();





}