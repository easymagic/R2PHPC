<?php 

trait JSONPayloadTrait{

  private $raw_json = '';
  private $out = '';
   
 
  private function GetRequestJSONBody(){
    $this->raw_json = file_get_contents('php://input');
    $this->AdaptJSONToRequestPair();   
  }

  private function AdaptJSONToRequestPair(){
    $r = $this->raw_json;
    $r = json_decode($r,true);
    if ($r){
      foreach ($r as $k=>$v){

         $_REQUEST[$k] = $v;

      }
    }
  }




}