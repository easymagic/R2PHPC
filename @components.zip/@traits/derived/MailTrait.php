<?php 

trait MailTrait{
   
   abstract function GetMailTo();
   abstract function GetMailFrom();
   abstract function GetMailSubject();
   abstract function GetMailMessage();

   
   function SendMail(){

   	 $result = '';
     
     $to = $this->GetMailTo();
     $from = $this->GetMailFrom();;
     $subject = $this->GetMailSubject();
     $message = $this->GetMailMessage();

	$headers = "From: " . strip_tags($from) . "\r\n";
	$headers .= "Reply-To: ". strip_tags($from) . "\r\n";
	// $headers .= "CC: susan@example.com\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";     

	if (mail($to, $subject, $message,$headers)){
      $result = 'Mail sent';
	}else{
      $result = 'Mail not sent';
	}
       

     return $result;

   }




}