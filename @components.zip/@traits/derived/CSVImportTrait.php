<?php 

trait CSVImportTrait{
  
  
  private $csv_data = array('header'=>array(),'content'=>array());


  private function GetTempFile($name){
   return $_FILES[$name]['tmp_name'];
  }

  function DoImport($input_name){
     
     $hnd = fopen($this->GetTempFile($input_name), 'r+');
     $this->csv_data['header'] = fgetcsv($hnd);  
     while (!feof($hnd)){
      $this->csv_data['content'][] = fgetcsv($hnd);  
     }

  	 fclose($hnd);
     
     return $this->csv_data;

  }




}