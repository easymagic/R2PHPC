<?php 

trait file_io_trait{
  
  private $hnd = null;

  private function init_file_in($file){
    $this->hnd = fopen($file, 'r+');
  }

  private function init_file_out($file){
   $this->hnd = fopen($file, 'w+'); 
  }

  private function close_file($hnd){

  }


  function read_file_raw($index){

     $this->init_file_in($this->get_file_name_in($index));
     
     $data = fread($this->hnd, filesize($this->get_file_name_in($index)));
     // ob_start();
     // include($this->get_file_name($index));
     // $data = ob_get_contents();
     // ob_end_clean();
    
     $this->close_file($this->hnd);

     return ($data);


  } 


  
  function read_file($index){

     // $this->init_file_in($this->get_file_name($index));
     
     // $data = fread($this->hnd, filesize($this->get_file_name($index)));
     ob_start();
     include($this->get_file_name_in($index));
     $data = ob_get_contents();
     ob_end_clean();
    
     // $this->close_file($this->hnd);

     return ($data);


  } 

  function write_file($index,$data){
     
     $this->init_file_out($this->get_file_name_out($index));
 
     fwrite($this->hnd, $data);
 
     $this->close_file($this->hnd);

  }  

  abstract function get_file_name_in($index); //this includes the relative path.
  abstract function get_file_name_out($index); //this includes the relative path.




}