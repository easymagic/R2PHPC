<?php 

trait EntityVerifyTrait{
 
 use EntityTrait;

 // private $db = null;


 function Exec(){
   
   $code = $this->GenerateVerificationCode($this->input['id']);
   $this->output['code'] = $code;
   $this->input['where'] = array(
    'id'=>$this->input['id']
   );
   // $this->input['data'] = array();
   $this->input['data'][$this->GetVerificationField()] = $code;

   $this->GetUpdateAction();

 }

 // function GetService($service_locator){
 //  // $this->db = $service_locator->get('db');
 // }

 function GenerateVerificationCode($id){
  $r = md5($id);
  $r = substr($r, -5);
  return $r;
 }
  

 abstract function GetUpdateAction(); 
 abstract function GetVerificationField();




}