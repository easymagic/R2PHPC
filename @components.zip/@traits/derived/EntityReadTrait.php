<?php 

/**
 
 @Inject(Db,Message);

*/

trait EntityReadTrait{
  

  use EntityTrait;



  function Exec(){
    
   //where 
   if (isset($this->input['where']))
    $this->Db->where($this->input['where']);

   //like
   if (isset($this->input['like']))
    $this->Db->like($this->input['like']);

   //limit
   if (isset($this->input['limit']))
    $this->Db->limit($this->input['limit']);

   //order
   if (isset($this->input['order']))
    $this->Db->order($this->input['order']);
  
   // echo $this->GetTableName();

  	$record = $this->Db->get($this->GetTableName());

  	$this->output['data'] = $record;
    $this->Message->Set('data',$record);

    
  }


  abstract function GetTableName();



}