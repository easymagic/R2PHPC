<?php 

trait EntityUploadTrait{
  
   
  function DoUpload(){

    $file_data = $_FILES[$this->GetUploadName()];

    $tmp = $file_data['tmp_name'];
    $file_name = uniqid() . $file_data['name'];

    if (move_uploaded_file($tmp, $this->GetUploadPath() . $file_name)){
     $this->SetUploadedFile($file_name);
    }else{
      // throw new Exception("File upload failed!");
    }



  } 

  abstract function SetUploadedFile($uploaded_file);
  abstract function GetUploadName();
  abstract function GetUploadPath();




}