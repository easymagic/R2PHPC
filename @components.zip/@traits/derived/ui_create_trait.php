<?php 

trait ui_create_trait{
  
  private $data = array(); 
  


  function index(){
   $this->init_vars(); 


    //echo '....ui start....';

    $this->load->view('traits/create_trait',$this->data);


  }

  private function init_vars(){
   $this->data = array(
     'get_form_data'=>array($this,'get_form_data'),
     'before_form'=>array($this,'before_form'),
     'after_form'=>array($this,'after_form'),
     'get_form_title'=>array($this,'get_form_title'),
     'get_usecase'=>array($this,'get_usecase'),
     'get_navigation'=>array($this,'get_navigation'),
     'get_submit_button'=>array($this,'get_submit_button')
   );
  }

  abstract function get_form_data();
  abstract function get_submit_button();
  abstract function before_form();
  abstract function after_form();
  abstract function get_form_title();
  abstract function get_usecase();
  abstract function get_navigation();




}


///mathew 25 (Transfer of earthly wealth to spiritual wealth.)

///malachi 3:8-10
//nehemiah 10:38
