<?php 

trait cms_all_page_trait{
 
 

 private $data = array();
 
 function index(){

   $this->load_header();
   // $this->load_vars();
   $this->load_content();
   $this->load_footer();

 }

 private function load_header(){
  $this->data['page_title'] = $this->get_page_title();
  // $this->data['social_links'] = $this->get_social_links();
  // $this->data['nav_menu'] = $this->get_nav_menu();
  $this->load_view('traits_ui/header',$this->data);
 }

 private function load_content(){
   
   $this->load_view('traits_ui/cms/content',$this->data);
 }

 private function load_footer(){
  $this->load_view('traits_ui/footer',$this->data);
 }


 private function load_vars(){
  // $this->data['use_gallery'] = $this->use_gallery();
  // $this->data['galleries'] = $this->get_gallery();
 }






 //abstract definitions 
 abstract function load_view($view,$data);
  abstract function get_page_by_name($page_name);
 



}