<?php 
  
  // namespace core\services;

  class Db implements irepo{
     
     private $test = 'Hello.';
     private static $connection = null;
     private $where = '';
     private $limit_ = '';
     private $order = '';
     
     function __construct(){
     	$this->init_connection();
     }

     private function reset_filters(){
     	$this->where = '';
     	$this->limit_ = '';
     	$this->order = '';
     }

     private function init_connection(){
       if (self::$connection == null){
         self::$connection = mysqli_connect('localhost:3306',
                                            'ydetbkzc_easymagic',
                                            'september92014',
                                            'ydetbkzc_wkf_db'); //or die('Error in connection.');

         // echo self::$connection;
       }
     }

     private function get_criteria_clause($where,$sep=' = ',$comparator=' and '){
       $r = array();

       foreach ($where as $k=>$v){
         $r[] = " $k $sep '$v' ";
       }

       if (!empty($r)){
          return ' where (' . implode($comparator, $r) . ') ';
       }else{
       	  return '';
       }
     }

     private function get_insert_query($data){
      
      $keys = array_keys($data);
      $values = array_values($data);

      return "(" . implode(',', $keys) . ") values ('" . implode("','", $values) . "')";

     }

     private function get_update_query($data){
      $r = array();
      foreach ($data as $k=>$v){
      	// $v = mysqli_escape_string($v,self::$connection);
        $r[] = " $k = '$v' ";
      }
      return ' set ' . implode(' , ', $r) . ' ';
     }

     private function exec_query($sql){
      $this->reset_filters();//this avoids conflict with other queries. 	
      return  mysqli_query(self::$connection,$sql);
     }

     private function query_result($query){
     	$r = array();
	 	while ($data = mysqli_fetch_assoc($query)){
          $r[] = $data;
	 	}

    // print_r($r);
	 	return $r;
     }
   

 private function record_retrieve_query($sql){
  $sql = $sql . ' ' . $this->order . ' ' . $this->limit_;
  return $sql;
 }	 

 function get($table){
   
   $sql = $this->record_retrieve_query("select * from $table " . $this->where);

    //echo $sql;

   return $this->query_result($this->exec_query($sql));

 }

 function get_where($table,$criteria){

   $sql = $this->record_retrieve_query("select * from $table " . $this->get_criteria_clause($criteria,'=','and'));

   return $this->query_result($this->exec_query($sql));
    
 }

 function like($criteria){

 	$this->where = $this->get_criteria_clause($criteria,' like ','and');

 }

 function get_like($table,$criteria){

   $sql = $this->record_retrieve_query("select * from $table " . $this->get_criteria_clause($criteria,' like ','and'));

   return $this->query_result($this->exec_query($sql));

 }

 function where($criteria){
   
   $this->where = $this->get_criteria_clause($criteria,' = ','and');

 }

 function insert($table,$data){
   $sql = "insert into $table " . $this->get_insert_query($data);
   // echo $sql;
   return $this->exec_query($sql);   
 }

 function update($table,$data){
   $sql = "update $table " . $this->get_update_query($data) . $this->where;
   return $this->exec_query($sql);   
 }

 function delete($table){
   $sql = "delete from $table " . $this->where;
   return $this->exec_query($sql);   
 }

 function insert_id(){
    return mysqli_insert_id(self::$connection); 
 }

 function limit($limit){
  $this->limit_ = " limit $limit ";
 }

 function order($order){
  $this->order = " order by $order ";
 }

 function query($sql){ //for record retrieval only.
   
   $sql = $this->record_retrieve_query($sql);
   return $this->query_result($this->exec_query($sql));

 }

 function count_where($table,$criteria=array(),$sep=' = ',$comparator=' and '){
   $sql = $this->record_retrieve_query("select count(*) as record_count from $table " . $this->get_criteria_clause($criteria,$sep,$comparator));
   return $this->query_result($this->exec_query($sql));   
 }

 function DoCount($table){
   $sql = $this->record_retrieve_query("select count(*) as record_count from $table " . $this->where);
   return $this->query_result($this->exec_query($sql));     
 }


 function DoSum($table,$field){
   $sql = $this->record_retrieve_query("select sum($field) as sum_total from $table " . $this->where);
   return $this->query_result($this->exec_query($sql));     
 }




  }
 
 

