<?php 
/**

@Inject();

*/
class DataAdapter{

   

   function Resolve($useCase,$input=array()){
   	$output = array();
    $useCase->Exec($input,$output); 
   	// echo 'Resolving ... ' . $this->Home->GreetAdminHome();
   	if (isset($output['data'])){
      return $output['data'];
   	}else{
      return $output;
   	}
   	
   }



}