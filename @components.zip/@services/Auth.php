<?php 

class Auth{
  
  private $id = 'user.account';

  function IsLogged(){
    return isset($_SESSION[$this->id]);
  }

  function IsNotLogged(){
   return !$this->IsLogged($this->id);
  }

  function ClearAuth(){
   unset($_SESSION[$this->id]);
  }

  function GetData(){
  	return $_SESSION[$this->id];
  }



}