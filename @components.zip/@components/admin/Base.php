<?php
  $URL = BASE_URL . 'BackEndUI/';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Perfect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $URL; ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Font Awesome -->
  <link href="<?php echo $URL; ?>css/font-awesome.min.css" rel="stylesheet">
  
  <!-- Pace -->
  <link href="<?php echo $URL; ?>css/pace.css" rel="stylesheet">
  
  <!-- Color box -->
  <link href="<?php echo $URL; ?>css/colorbox/colorbox.css" rel="stylesheet">
  
  <!-- Morris -->
  <link href="<?php echo $URL; ?>css/morris.css" rel="stylesheet"/>  
  
  <!-- Perfect -->
  <link href="<?php echo $URL; ?>css/app.min.css" rel="stylesheet">
  <link href="<?php echo $URL; ?>css/app-skin.css" rel="stylesheet">
  
  </head>

  <body class="overflow-hidden">

    <?php echo $content; ?>


  
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

  <?php 
   
    if (isset($View_js_include)){
      echo $View_js_include->View();
    }
 
  ?>  
  
  </body>
</html>
