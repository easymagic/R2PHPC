<?php
  $URL = BASE_URL . 'BackEndUI/';
?>  
<!-- default -->
<!-- Jquery -->
	<script src="<?php echo $URL; ?>js/jquery-1.10.2.min.js"></script>
	
	<!-- Bootstrap -->
    <script src="<?php echo $URL; ?>bootstrap/js/bootstrap.min.js"></script>
   
	<!-- Modernizr -->
	<script src='<?php echo $URL; ?>js/modernizr.min.js'></script>
   
    <!-- Pace -->
	<script src='<?php echo $URL; ?>js/pace.min.js'></script>
    
	<!-- Popup Overlay -->
	<script src='<?php echo $URL; ?>js/jquery.popupoverlay.min.js'></script>
	
    <!-- Slimscroll -->
	<script src='<?php echo $URL; ?>js/jquery.slimscroll.min.js'></script>
   
	<!-- Cookie -->
	<script src='<?php echo $URL; ?>js/jquery.cookie.min.js'></script>

	<!-- Perfect -->
	<script src="<?php echo $URL; ?>js/app/app.js"></script>
	
	<script>
		$(function()	{

			// $('#invoicePrint').click(function()	{
			// 	window.print();
			// });

		});
	</script>