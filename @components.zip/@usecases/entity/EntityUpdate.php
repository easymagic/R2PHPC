<?php 

class EntityUpdate implements iUseCase{

 use EntityUpdateTrait{
 	EntityUpdateTrait::Exec as DoUpdate;
 }

 private $table_name = '';


 function Exec(){
 	$args = $this->input['args'];
 	$this->table_name = array_shift($args);

 	$this->DoUpdate();
 }

 function GetUpdateMessage(){
 	return 'Saved.';
 }

 function GetTableName(){
 	return $this->table_name;
 }


}