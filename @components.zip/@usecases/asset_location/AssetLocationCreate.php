<?php 

class AssetLocationCreate implements IUseCase{
	
	use EntityCreateTrait;


  function GetTableName(){
    return 'asset_location';
  }

  function GetCreateMessage(){
  	return 'Asset location created successfully.';
  }



}