<?php 

class upload_remove implements iusecase{
  
  private $path = '';
  private $file_name = '';

  private $input = array();
  private $output = array();

  
  function get_input($input){
     
     //path,name,output_name
  	 $this->input = $input;

  	 $this->path = $input['path'];
  	 
  	 $this->file_name = $input['file_name'];

  }


  function get_output(){
    return $this->output;
  }

  function get_service($obj){

  }

  function exec(){

    $del_file = $this->path . $this->file_name;

    if (file_exists($del_file)){
      @unlink($del_file);
      $this->output['message'] = 'File deleted.';
      $this->output['data'] = array(
        'deleted_file'=>$this->file_name
      );
    }else{

      $this->output['message'] = 'File not found (' . $this->file_name . ')';

    }

  }



}