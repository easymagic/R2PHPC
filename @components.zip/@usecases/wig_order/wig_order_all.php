<?php 

class wig_order_all implements iusecase{
  
  use entity_read_trait;

  
  //abstract implementations
  function get_table_name(){
  	return 'wig_order';
  }



}