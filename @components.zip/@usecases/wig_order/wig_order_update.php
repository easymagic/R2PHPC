<?php 

class wig_order_update implements iusecase{
  
  use entity_update_trait;

  
  //abstract implementations

  function get_table_name(){
  	return 'wig_order';
  }

  function get_update_message(){
  	return 'Updated.';
  }



}