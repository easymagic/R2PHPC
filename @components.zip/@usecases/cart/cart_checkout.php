<?php 

class cart_checkout implements iusecase{
 
 use cart_checkout_trait;


   //abstract definitions
 function get_order_table_name(){
  return 'wig_order';
 }

 function get_order_total_qty_name(){
  return 'total_qty';
 }

 function get_order_total_price_name(){
  return 'total_price';
 }

 function get_order_transaction_id_name(){
  return 'transaction_id';
 }

 function get_order_items_table_name(){
   return 'wig_order_items';
 }

 function get_order_items_fields(){
   return array(
     
     'wig_id'=>'id',
     'total_price'=>'total_price',
     'qty'=>'qty',
     'date_created'=>'date_created'

   );
 } //associative array with data-dictionaries


 function get_order_child_id(){
  return 'order_id';
 }

 function get_cart_name(){
  return 'cart-wig';
 }

 function get_checkout_message(){
  return 'Your order has been checked out successfully.';
 }

 function get_cart_price_name(){
  return 'price';
 }


}