<?php 

class cart_manage implements iusecase{
 
 use cart_trait;


   //abstract definitions
   function get_cart_name(){
    return 'cart-wig';
   }

   function get_table_name(){
    return 'wig';
   }


   function get_cart_id_name(){
    return 'id';
   }


   function get_cart_price_name(){
    return 'price';
   }


}