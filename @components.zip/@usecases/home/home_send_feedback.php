<?php 

class home_send_feedback implements iusecase{
 
 private $email = null;
 private $input = array();
 private $output = array();


 function get_input($in){

  $this->input = $in;

 }

 function get_output(){
  return $this->output;
 }

private function humanize($str){

	$r = explode('_', $str);

	$r = array_map('ucfirst', $r);

	return implode(' ', $r);

}


 function exec(){

      $frm = array();

      // $bucket = array_diff_assoc($_REQUEST, array(
      // 	'__q'=>$_REQUEST['__q'],
      // 	'send_feedback'=>'Send Feedback'));
      $bucket = $_REQUEST;

    	foreach ($bucket as $k=>$v){


    		$frm[] = "<b>" . $this->humanize($k)  . "</b>:&nbsp;" . $v;


    	}

    	$msg = '<b>Dear Site Admin</b> <br /> 
    	Someone has just sent a feedback from your Site
         with the below information<br />
    	' . implode('<br />', $frm);


 	$this->email->set_from('info@olavalue.com');
 	$this->email->set_to('info@olavalue.com');
 	// $this->email->set_to('nnamware@yahoo.com');
 	$this->email->set_subject('FEEDBACK FROM OLAVALUE COM');
 	$this->email->set_message($msg);
 	$this->email->send();

 	$this->output['message'] = 'Feedback successfully sent, we will get back to you with respect to your comment. <br /><b>Thank You</b>';

 }

 function get_service($service_locator){
  $this->email = $service_locator->get('email');
 }


}