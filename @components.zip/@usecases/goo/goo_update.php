<?php 

class goo_update implements iusecase{
  
  use entity_update_trait;

  
  //abstract implementations

  function get_table_name(){
  	return 'goo';
  }

  function get_update_message(){
  	return 'goo updated.';
  }



}