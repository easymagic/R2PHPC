<?php 

class wig_order_items_create implements iusecase{
  
  use entity_create_trait;
 
  //abstract implementations
  function get_table_name(){
    return 'wig_order_items';
  }

  function get_create_message(){
    return 'Wig order item created successfully.';
  }

}