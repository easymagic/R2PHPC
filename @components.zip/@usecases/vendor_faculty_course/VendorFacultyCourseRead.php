<?php 

class VendorFacultyCourseRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'vendor_faculty_course';
 }


}