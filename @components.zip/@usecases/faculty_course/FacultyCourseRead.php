<?php 

class FacultyCourseRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'faculty_course';
 }


}