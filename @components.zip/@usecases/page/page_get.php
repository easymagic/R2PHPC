<?php 

class page_get implements iusecase{
  
  private $db = null;
  private $input = array();
  private $output = array();
  private $where = array();



  function get_input($in){
    $this->input = $in;
    if (isset($this->input['name'])){

    	$this->where['name'] = $this->input['name'];

    }
  }

  function get_output(){
    return $this->output;
  }

  function exec(){
   if (!empty($this->where)){
      $this->db->where($this->where);
   }
   $this->output['pages'] = $this->db->get('page');
  }

  function get_service($service_locator){
    $this->db = $service_locator->get('db');
  }



 


}