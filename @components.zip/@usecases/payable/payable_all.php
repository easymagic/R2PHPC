<?php 

class payable_all implements iusecase{

 
 use entity_read_trait;

 function get_table_name(){
  return  'payable';
 }


}