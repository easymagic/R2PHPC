<?php 

class MicroCMSRead implements iUseCase{

 use EntityReadTrait;
  
 
 function GetTableName(){
 	// echo 'Called.';
 	return 'microcms';
 }



}