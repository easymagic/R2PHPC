<?php 

class record_duplicate_check implements iusecase{
  
  // private $field_name = '';
  // private $field_value = '';

  private $input = array();
  private $output = array();

  private $table_name = '';

  private $db = null;

  
  function get_input($input){

    // throw new Exception("Error Processing Request", 1);
     
     //path,name,output_name
  	 $this->input = $input;

     if (!isset($this->input['data']))
      throw new Exception("data array-param required!");

     if (!isset($this->input['duplicate']))
      throw new Exception("duplicate array-param required!");

     foreach ($this->input['duplicate']['filter'] as $field=>$value)
      $this->input['duplicate']['filter'][$field] = $this->input['data'][$field];
     


     if (!isset($this->input['duplicate']['table_name']))
        throw new Exception("duplicate.table_name param required!");

     if (!isset($this->input['duplicate']['error_message']))
        throw new Exception("duplicate.error_message param required!");

     $this->table_name = $this->input['duplicate']['table_name'];


  }

  function get_output(){
    return $this->output;
  }

  function get_service($obj){
    $this->db = $obj->get('db');
  }

  function exec(){
    
    $record = $this->db->get_where($this->table_name,$this->input['duplicate']['filter']);

    if (count($record) > 0){
      throw new Exception($this->input['duplicate']['error_message']);
    }else{
      $this->output['data'] = array(
        'go_ahead1'=>1
      );
    }

  }



}