<?php 

class FacultyCreate implements IUseCase{
	
  use EntityCreateTrait,EntityUploadTrait{
  	EntityCreateTrait::Exec as DoExec;
  }


  function GetTableName(){
    return 'faculty';
  }

  function GetCreateMessage(){
  	return 'Faculty created successfully.';
  }

  function Exec(){
  	$this->DoUpload();
  	$this->DoExec();
  }

  function SetUploadedFile($uploaded_file){
    $this->input['data']['logo'] = $uploaded_file;
  }

  function GetUploadName(){
    return 'image';
  }

  function GetUploadPath(){
   return 'uploads/faculty/';
  }




}