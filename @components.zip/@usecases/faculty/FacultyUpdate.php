<?php 

class FacultyUpdate implements IUseCase{
	
	use EntityUpdateTrait,EntityUploadTrait{
		EntityUpdateTrait::Exec as DoExec;
	}


  function GetTableName(){
    return 'faculty';
  }

  function GetUpdateMessage(){
  	return 'Faculty updated.';
  }

  function Exec(){
  	$this->DoUpload();
  	$this->DoExec();
  }

  function SetUploadedFile($uploaded_file){
    $this->input['data']['logo'] = $uploaded_file;
  }

  function GetUploadName(){
    return 'image';
  }

  function GetUploadPath(){
   return 'uploads/faculty/';
  }


}