<?php 

class MemberVendorFacultyCourseTestCreate implements IUseCase{
  
  use EntityCreateTrait;


  function GetTableName(){
    return 'member_vendor_faculty_course_test';
  }

  function GetCreateMessage(){
    return 'Test Created.';
  }



}