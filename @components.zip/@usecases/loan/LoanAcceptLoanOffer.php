<?php 

class LoanAcceptLoanOffer implements iUseCase{

 
   use EntityTrait;

   private $db = null;
   private $loan_request_id = '';
   private $credit_grant_id = '';
   private $sender_id = '';
   private $loan_request_data = array();

   function Exec(){ //loan_request_id
      
      $this->loan_request_id = $this->input['data']['loan_request_id'];
      $this->sender_id = $this->input['data']['sender_id'];

      $this->CheckDuplicate();
      $this->GetLoanRequestData();
      $this->CreateCreditCorrespondingRequest();
      $this->UpdateCorrespondingLoanRequest(); 
      

      $this->output['message'] = 'Loan Offer Accepted.';
   }

   private function GetLoanRequestData(){
     $this->db->where(array(
       'id'=>$this->loan_request_id
     ));
     $this->loan_request_data = $this->db->get('loan_request');
   }

   private function CreateCreditCorrespondingRequest(){
     
     $this->input['data'] = array();
     $this->input['data']['sender_id'] = $this->sender_id;
     $this->input['data']['interest'] = $this->loan_request_data[0]['interest'];
     $this->input['data']['amount'] = $this->loan_request_data[0]['amount'];
     $this->input['data']['loan_request_id'] = $this->loan_request_id;
     $this->input['data']['credit_status'] = 'pending';
     $this->input['data']['date_created'] = date('Y-m-d h:i:s');

     $this->db->insert('credit_grant',$this->input['data']);

     $this->credit_grant_id = $this->db->insert_id();

   }

   private function UpdateCorrespondingLoanRequest(){
     
     $this->input['data'] = array();
     $this->input['data']['debt_status'] = 'pending';
     $this->input['data']['credit_grant_id'] = $this->credit_grant_id;
     $this->db->where(array(
       'id'=>$this->loan_request_id
     ));
     $this->db->update('loan_request',$this->input['data']);

   }


   private function CheckDuplicate(){

     $this->db->where(array(
       'id'=>$this->loan_request_id
     ));

     $data = $this->db->get('loan_request');

     if (!empty($data) && !empty($data[0]['credit_grant_id'])){
       throw new Exception("Offer already accepted!");
     }

   }


   function GetService($service_locator){
   
     $this->db = $service_locator->get('db');

   }



}