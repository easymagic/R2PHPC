<?php 
/**

@Inject(Db,Message)

*/

class AdminFetch{
 

 use EntityReadTrait;


 function GetTableName(){
   return 'admin';
 }


}