<?php 

class MemberVendorFacultyCourseCreate implements IUseCase{
  
  use EntityCreateTrait;


  function GetTableName(){
    return 'member_vendor_faculty_course';
  }

  function GetCreateMessage(){
    return 'Applied successfully.';
  }



}