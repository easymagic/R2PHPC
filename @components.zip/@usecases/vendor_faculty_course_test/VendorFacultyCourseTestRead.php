<?php 

class VendorFacultyCourseTestRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'vendor_faculty_course_test';
 }


}