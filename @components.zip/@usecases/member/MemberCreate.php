<?php 

class MemberCreate implements IUseCase{
  
  use EntityCreateTrait;


  function GetTableName(){
    return 'member';
  }

  function GetCreateMessage(){
    return 'Account created successfully ,activate your account from the link sent to your e-mail.';
  }



}