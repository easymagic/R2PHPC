<?php 

class UserLogin implements IUseCase{
  
  use EntityLoginTrait;

  function GetTableName(){
    return 'user';
  }

  function GetLoginSuccessMessage(){
    return 'Login successful.';
  }

  function GetLoginFailureMessage(){
    return 'Invalid login!';
  }

  function GetAuthFields(){
    return array(
      'username'=>'email',
      'password'=>'password'
    );
  }

  function GetSessionName(){
    return 'user_account';
  }



  // abstract function GetTableName();
  // abstract function GetSessionName();
  // abstract function GetAuthFields();
  // abstract function GetLoginSuccessMessage();
  // abstract function GetLoginFailureMessage();
  function GetLoginStatusFailureMessage(){
    return  'Account deactivated.';
  }
  
  function GetStatusField(){
    return 'active';
  }



}