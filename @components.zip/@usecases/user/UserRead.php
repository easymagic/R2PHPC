<?php 

class UserRead implements IUseCase{
 
 use EntityReadTrait;


 function GetTableName(){
 	return 'user';
 }


}