<?php 

class AssetCategoryRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'asset_category';
 }


}