<?php 

class VendorFacultyCourseMaterialCreate implements iUseCase{
  
  use EntityCreateTrait,EntityUploadTrait{
  	EntityCreateTrait::Exec as DoExec;
  }

 function Exec(){
 	$this->DoUpload();
 	$this->DoExec();
 }

  function GetTableName(){
    return 'vendor_faculty_course_material';
  }

  function GetCreateMessage(){
    return 'Course Material Added.';
  }

  function SetUploadedFile($uploaded_file){
    $this->input['data']['content'] = $uploaded_file;
  }

  function GetUploadName(){
    return 'file';
  }

  function GetUploadPath(){
   return 'uploads/vendor_faculty_course_material/';
  }




}