<?php 

class category_update implements iusecase{
  
  use entity_update_trait;

  
  //abstract implementations

  function get_table_name(){
  	return 'category';
  }

  function get_update_message(){
  	return 'Category updated.';
  }



}