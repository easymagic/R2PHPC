<?php 

class wig_create implements iusecase{
  
  private $uploaded_file = '';

  use entity_create_trait;

  // ,entity_upload_trait{
   
  //    entity_create_trait::exec as create_entity;

  // }
 
  //abstract implementations

  // function exec(){
    
  //   // $this->do_upload();

  //   $this->input['data']['image'] = $this->uploaded_file;

  //   $this->create_entity();

  // }


  function get_table_name(){
    return 'wig';
  }

  function get_create_message(){
    return 'Wig added successfully.';
  }


  // function set_uploaded_file($uploaded_file){
  //   $this->uploaded_file = $uploaded_file;
  // }

  // function get_upload_name(){
  //  return 'image';
  // }

  // function get_upload_path(){
  //  return 'wig_images/';
  // }


}