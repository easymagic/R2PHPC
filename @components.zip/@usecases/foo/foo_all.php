<?php 

class foo_all implements iusecase{
  
  use entity_read_trait;

  
  //abstract implementations
  function get_table_name(){
  	return 'foo';
  }



}