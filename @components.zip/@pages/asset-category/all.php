<?php 
 
 $this->LoadComponent('asset-location-list',array(
   'title'=>'Asset Locations.',
   'edit_url'=>BASE_URL . 'asset-location/edit/'
 ));

?>