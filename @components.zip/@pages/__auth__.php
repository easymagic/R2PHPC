<?php 
 

 
 $CAN_ACCESS = (!isset($_SESSION['user_account']));
 $RESTRICT = 'account/dashboard';
 // echo $RESTRICT;