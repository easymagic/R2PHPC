<?php 

TemplateStart();

 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $PAGE_TITLE; ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>LibertyUI/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo BASE_URL; ?>LibertyUI/images/favicon.png" />
</head>

<body>



<?php 
 if (isset($_SESSION['user_account'])){
?>
<div class="container-scroller">
    <!-- partial:partials/_horizontal-navbar.html -->
    <nav class="navbar horizontal-layout col-lg-12 col-12 p-0">
      <div class="container d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-top">
      
      <h4 style="margin-top: 19px;">
       Assets - Backend     
      </h4>
          
<!--           <a class="navbar-brand brand-logo" href="index.html"><img src="<?php echo BASE_URL; ?>LibertyUI/images/logo-inverse.svg" alt="logo"></a>
          <a class="navbar-brand brand-logo-mini" href="index.html"><img src="<?php echo BASE_URL; ?>LibertyUI/images/logo-mini.svg" alt="logo"></a>
 -->

        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center">
          <form class="search-field ml-auto" action="#">
            <div class="form-group mb-0">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                </div>
                <input type="text" class="form-control">
              </div>
            </div>
          </form>
          <ul class="navbar-nav navbar-nav-right mr-0">

            <li class="nav-item dropdown d-none d-xl-inline-block">
              <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <img class="img-xs rounded-circle" src="https://placehold.it/100x100" alt="Profile image">
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                
                <a class="dropdown-item mt-2">
                  Manage Accounts
                </a>
                <a class="dropdown-item">
                  Change Password
                </a>
                <a class="dropdown-item">
                  Check Inbox
                </a>
                <a class="dropdown-item" href="?ccmd=user/UserLogOut">
                  Sign Out
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </div>
      <div class="nav-bottom">
        <div class="container">
          <ul class="nav page-navigation">
            <li class="nav-item active">
              <a href="index.html" class="nav-link"><i class="link-icon mdi mdi-television"></i><span class="menu-title">DASHBOARD</span></a>
            </li>
            
            
            
            
            <li class="nav-item">
              <a href="#" class="nav-link"><i class="link-icon mdi mdi-asterisk"></i><span class="menu-title">ASSETS</span><i class="menu-arrow"></i></a>
              <div class="submenu">
                <ul class="submenu-item">
                  
                  <li class="nav-item"><a class="nav-link" href="pages/apps/email.html">All</a></li>
                
                <li class="nav-item"><a class="nav-link" href="pages/apps/calendar.html">Add</a></li>


                </ul>
              </div>
            </li>
          


            <li class="nav-item">
              <a href="#" class="nav-link"><i class="link-icon mdi mdi-asterisk"></i><span class="menu-title">CATEGORY</span><i class="menu-arrow"></i></a>
              <div class="submenu">
                <ul class="submenu-item">
                  
                  <li class="nav-item"><a class="nav-link" href="pages/apps/email.html">All</a></li>
                
                <li class="nav-item"><a class="nav-link" href="pages/apps/calendar.html">Add</a></li>
                                

                </ul>
              </div>
            </li>



            <li class="nav-item">
              <a href="#" class="nav-link"><i class="link-icon mdi mdi-asterisk"></i><span class="menu-title">LOCATION</span><i class="menu-arrow"></i></a>
              <div class="submenu">
                <ul class="submenu-item">
                  
                  <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>asset-location/all">All</a></li>
                
                <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>asset-location/create">Add</a></li>
                                

                </ul>
              </div>
            </li>




          </ul>


        </div>
      </div>
    </nav>


    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          
<?php 
 }

TemplateStop('header');



TemplateStart();

 if (isset($_SESSION['user_account'])){
?>
          
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018 <a href="http://www.urbanui.com/" target="_blank">Urbanui</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted &amp; made with <i class="mdi mdi-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>

<?php 
 }
?>  



  <!-- plugins:js -->
  <script src="<?php echo BASE_URL; ?>LibertyUI/vendors/js/vendor.bundle.base.js"></script>
  <script src="<?php echo BASE_URL; ?>LibertyUI/vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo BASE_URL; ?>LibertyUI/js/template.js"></script>
  <!-- endinject -->
</body>

</html>


<?php 

TemplateStop('footer');