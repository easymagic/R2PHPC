<?php 
if (is_array($ID)){
  print_r($ID);
}else{
 echo $ID;	
}
