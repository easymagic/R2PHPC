<?php 

$CAN_ACCESS = true;
$AUTH_MESSAGE = '<b>Please login first before going to app</b>';