<?php 

class Home{



  function GreetAdminHome(){
    return 'Welcome Administrator Home.';
  }


}