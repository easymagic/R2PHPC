<?php 

class FrontController{
  
  private $route = '';
  private $check = '';
  private $ext = '';
  private $ID = '';
  private $immediateDirectory = '';
  private $page_path = '@pages/';

  function __construct(){
  	$this->HandleRequest();
  }
  


  
  function HandleRequest(){

	 if (empty($_REQUEST['__request__'])){
	  $this->route = 'index';
	 }else{
	  $this->route =  $_REQUEST['__request__']; 	
	 }

	 $this->route = $this->RemoveExtension($this->route);
	 // echo $this->route;
	 $this->ID = $this->GetID($this->route);

	 
	 if (is_numeric($this->ID) || is_array($this->ID) || !$this->DirectoryExists($this->route)){
      $this->RestoreRouteToDefault(); //remove the number and append index to it.
	 }

	 $this->immediateDirectory = $this->GetImmediateDirectory($this->route);


   $this->FetchPagePartial();

	 $this->ComputeAutoIncludes();


  }

  private function DirectoryExists($file){
    return (file_exists($this->page_path . $file . '.php') || file_exists($this->page_path . $file));
  }

  private function RestoreRouteToDefault(){
    
    $r = $this->route;
    
    $r = explode('/', $r);
    $id = end($r);

    while (is_numeric($id) || !$this->DirectoryExists(implode('/', $r))){
      array_pop($r);
      $id = end($r);
    }

    $r = implode('/', $r);
    if (file_exists($this->page_path . $r . '.php')){
     $this->route = $r;
    }else{
     $this->route = $r . '/index';  
    }
    
  }

  private function RemoveExtension($file){
    $r = explode('.', $file);
    if (count($r) > 1){
      array_pop($r);
      $r = implode('', $r);
    }else{
      $r = implode('', $r);
    }
    return $r;

  }

  private function GetID($file){

    $r = explode('/', $file);
    $id = end($r);

    $acc = array();
    $acc[] = $id;
    // array_pop($r);
    
    while (is_numeric($id) || !$this->DirectoryExists(implode('/', $r))){
      
      array_pop($r);
      $id = end($r);
      if (is_numeric($id) || !$this->DirectoryExists(implode('/', $r)))$acc[] = $id;
      
    }

    if (count($acc) == 1){
     return $acc[0];
    }else{
     return array_reverse($acc); 	
    }

    // return $id;
  }

  private function GetImmediateDirectory($file){
  	// echo $file;
   $r = explode('/', $file);
   array_pop($r);
   $r = implode('/', $r);
   if (!empty($r)){
    $r.= '/';
   }
   return $r;
  }

  private function ComputeAutoIncludes(){
  	
  	$file_template = $this->page_path . $this->immediateDirectory . '__template__.php';
  	$file_auth = $this->page_path . $this->immediateDirectory . '__auth__.php';
  	$file_restore = $this->page_path . $this->immediateDirectory . '__restore__.php';

  	// echo $file_template . '<br />';
  	// echo $file_auth . '<br />';
  	// echo $file_restore . '<br />';

  	if (file_exists($file_template)){
  	  if (!isset($PAGE_TITLE))$PAGE_TITLE = 'Title New ......';	
      include($file_template);
  	}

  	if (file_exists($file_auth)){
  	  $CAN_ACCESS = false;	
  	  $RESTRICT = '';

      include($file_auth);

      if (!$CAN_ACCESS){
      	 // echo $file_auth;
        $this->Redirect($RESTRICT);
      }
  	}


  	if (file_exists($file_restore)){
       
       $AUTH_PAGE = '';
       $CAN_ACCESS = false;
       $AUTH_MESSAGE = 'Do something before comming here (' . BASE_URL . $this->route . ')';
       $GRANT_URI = BASE_URL . $this->route;

       include($file_restore);

       if (!$CAN_ACCESS){

       	  $_SESSION['AUTH_MESSAGE'] = $AUTH_MESSAGE;
       	  $_SESSION['GRANT_URI'] = $GRANT_URI;
       	  $this->Redirect($AUTH_PAGE);

       }

  	}

  }


  function Redirect($page){
   header("location: " . BASE_URL . $page);
   exit();
  }


  private function FetchPagePartial(){

	 $ID = $this->ID;

	 TemplateStart();
	 if (file_exists($this->page_path . $this->route . '.php')){



	  include($this->page_path . $this->route . '.php');

	 }else{

	 	// echo $this->page_path . $this->route . '.php';
	     
	    include('pages/index.php');

	 }
	 TemplateStop('main-content');

  }


  function LoadComponent($component,$vars=array()){

     extract($vars);
     // $file_data = '@components/' . $component . '/data.php';
     $file_view = '@components/' . $component . '/view.php';
     
     // if (file_exists($file_data))include($file_data); 
     if (file_exists($file_view))include($file_view); 

  }

  function Provide($package,$params = array()){

     $input = array();
     $package = explode('.', $package);
     $package = implode('/', $package);

     foreach ($params as $k=>$v){

       $input[$k] = $v;

     }

     $output = array();

     CallUseCase($package,$input,$output);

     foreach ($output as $k=>$v){

       $GLOBALS[$k] = $v;

     }

     // print_r($GLOBALS);

  }



  function LoadPage(){

  	 

	 echo Template('header');
	 echo Template('main-content');
	 echo Template('footer');


  }








}



