<?php 
 
 require_once('core/core.php');
 
 // $out = array();
 // $in = array(
 //  'id'=>8
 // );

 // core\call_usecase('user/user_login',$in,$out);

 // print_r($out);

