<?php 

/**

@Inject(@plugins/BackEndPlugin,
        @plugins/BackEndLoginPlugin,
        @templates/admin/indexTemplate,
        @templates/admin/loginTemplate);

@InjectFolder(@models/entityv2);

*/


class Admin{
  

  function Init(){
    InstallPlugin($this->BackEndPlugin);
  }

  function Index_AdminContent(){
    // global $buffer;

    $this->EntityRead->Read('merchant');

    // $buffer.=$this->indexTemplate->View();
  }




}
 