<?php 

class Test{

  
  
 function GateWay(){
   global $data;

   // $data['gway'] = 'InterPAY.ABC.AKL';
 }

 function Gway(){

 }



}