<?php 

/**

@Inject(@plugins/BackEndPlugin,
        @plugins/BackEndLoginPlugin,
        @templates/admin/indexTemplate,
        @templates/admin/loginTemplate);

*/


class AdminLogin{
  

  function Init(){    
    InstallPlugin($this->BackEndLoginPlugin);
  }

  function Index_AdminContent(){
    global $buffer;

    $buffer.=$this->loginTemplate->View();
  }




}
 