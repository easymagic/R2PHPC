<?php 

/**

@Inject(@models/transaction/TransactionInitPayment);

*/

class Api{

  
  

  function InitTransaction(){ //post-params: $merchant_secret, post-data-params: amount,email,merchant_feedback_page
    global $contentType;
    $contentType = 'json';

    $this->TransactionInitPayment->InitPayment();
    
  }

  function QueryTransaction(){

  }



}