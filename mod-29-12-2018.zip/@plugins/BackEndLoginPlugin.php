<?php 

/**

@Inject(@templates/backend/Admin_LoginHeaderTemplate,
        @templates/backend/Admin_LoginFooterTemplate);

*/


class BackEndLoginPlugin{


 function Admin_LoginHeader(){
  global $buffer;
  $buffer.=$this->Admin_LoginHeaderTemplate->View();
 }  


 function Admin_LoginFooter(){
  global $buffer;
  $buffer.=$this->Admin_LoginFooterTemplate->View();
 }

 

}