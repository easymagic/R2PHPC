<?php 



$config['category'] = array('date_created'=>date('Y-m-d h:i:s'),
	                        'authorization_key'=>'secret_key101');

