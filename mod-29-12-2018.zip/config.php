<?php 

define('DEFAULT_CONTROLLER', 'Admin');
define('BASE_URL', 'http://localhost/interpay/');
