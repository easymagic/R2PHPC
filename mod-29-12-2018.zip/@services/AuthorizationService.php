<?php 

/**

@Inject(@services/Db);

*/


class AuthorizationService{
  
   private $secret_key = '';
   private $authorization_key = '';
   private $permissions = '';
   private $date_created = '';


   function IsAuthorized($secret_key=''){
    global $headers;
    extract($headers);
    // extract($this->FrontController->GetHeaders());
    // extract(getallheaders());
    if (empty($secret_key)){
       if (isset($Authorization)){
         $secret_key = $Authorization;
       }
    }
     
     $dt = $this->Db->Where('secret_key',$secret_key)->Get('authorization');
     if (count($dt) > 0){
       $dt = $dt[0];
       $this->secret_key = $dt['secret_key'];
       $this->authorization_key = $dt['authorization_key'];
       $this->permissions = $dt['permissions'];
       $this->date_created = $dt['date_created'];
       return true;
     }else{
       return false;
     }

   }


  
}