<?php
/**

@Inject(@services/FolderMigrate,
        @controllers/Category,
        @services/UIComponent,
        @templates/console/TerminalTemplate,
        @services/DbFields,
        @services/CommandSignal);

*/

//HMT

class Api{
  
  

  
  function Foo(){
  	return 'Getting foo data';
  }
  

 
}