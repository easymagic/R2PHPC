<?php 

/**

@Inject(@services/file/FileUpload,
        @services/Db);

*/

class CrudService{

  

  private function CheckFileUpload(&$request){
    if (isset($_FILES)){
      foreach ($_FILES as $k=>$hnd){
       if ($this->FileUpload->DoUpload($hnd,$k)){
         $request['data'][$k] = $this->FileUpload->GetUploadedFile();
       }
      }
    }
  }


  private function CheckDuplicateRecord(&$request,$message='Duplicate Record!'){
    
    if (isset($request['check'])){
      
      $key = $request['check'];
      $value = $request['data'][$key];
      $record = $this->Db->Where($key,$value)->Get($this->entity);
      
      if (count($record) > 0){
        throw new Exception($message, 1);
      }

    }

  }

  function DoAdd($entity,$data){
    $this->CheckDuplicateRecord($data);
    $this->CheckFileUpload($data);
    $this->Db->Insert($entity,$data['data']);    
    return array('message'=>'New Record Added...','id'=>$this->Db->InsertID());

  }

  function DoUpdate($entity,$id,$data){
    $this->CheckFileUpload($data);
    $this->Db->Where('id',$id);
    $this->Db->Update($entity,$data['data']);
    return array('message'=>'Record Saved....');
  }

  function DoDelete($entity,$id){
    // if (!isset($request['id']))throw new Exception("id-seek-param required!", 1);
    // $id = $request['id'];
    $this->Db->Where('id',$id);
    $this->Db->Delete($entity);
    // $this->RequestResponse->SetResponse('message','Record Removed.');
    return array('message'=>'Record Removed....');    
  }

  function GetRecords($entity){
    return $this->Db->Get($entity);
  }

  function GetRecord($entity,$id){
   
   $dt = $this->Db->Where('id',$id)->Get($entity);
   if (count($dt) > 0){
    return $dt[0];
   }else{
    return $dt; 
   }
   
  }


  function HandleCrud($entity,$id=''){

    if (empty($id) && !empty($entity)){
       return array('data'=>$this->GetRecords($entity));
    }else if (!empty($entity) && !empty($id)){
       return array('data'=>$this->GetRecord($entity,$id));
    }else{
      return array();
    }
    
  }

  function HandleCrudAction($entity,$id='',$verb=''){
   
   if (empty($verb)){

    if (empty($id) && !empty($entity)){
       return $this->DoAdd($entity,$_REQUEST);
    }else if (!empty($entity) && !empty($id)){
       return $this->DoUpdate($entity,$id,$_REQUEST);
    }else{
      return array();
    }


   }else if ($verb == 'delete'){

     return $this->DoDelete($entity,$id);

   }



  }


}