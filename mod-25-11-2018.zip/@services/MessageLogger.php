<?php 

class MessageLogger{
  
  private $message = '';
  private $error = '';


  function ResolveMessages($obj){
    if (isset($obj->error)){
      $this->error = $obj->error;
    }
    if (isset($obj->message)){
      $this->message = $obj->message;
    }
  }  


  function GetMessageTemplate(){
  	
  	if (!empty($this->message)){
	  	if ($this->error){
          $style = 'color:red;';
	  	}else{
          $style = 'color:green;';
	  	}

	  	return '<p style="' . $style . '">' . $this->message . '</p>';

  	}else{

  		return '';

  	}

  }

  
}