<!-- This wraps the whole cropper -->
<div id="image-cropper<?php echo $id; ?>">
  <!-- This is where the preview image is displayed -->
  <div class="cropit-preview"></div>
  
  <!-- This range input controls zoom -->
  <!-- You can add additional elements here, e.g. the image icons -->
  <input type="range" class="cropit-image-zoom-input" />
  
  <!-- This is where user selects new image -->
  <input type="file" class="cropit-image-input" />

  <input type="hidden" name="ImageData[<?php echo $name; ?>]" id="save<?php echo $id; ?>" />

<div align="right">
  <button type="button" id="apply-crop-btn<?php echo $id ?>" class="btn btn-success">
   Apply Crop
  </button>
</div>  
  <!-- The cropit- classes above are needed
       so cropit can identify these elements -->
</div>

<style type="text/css">
.cropit-preview{
  /* You can specify preview size in CSS */
  width: <?php echo $width; ?>px;
  height: <?php echo $height; ?>px;
  background-color: #ddd;
}  

#image-cropper<?php echo $id; ?>{
  /* You can specify preview size in CSS */
  width: <?php echo $width + 13; ?>px;  
  padding: 5px;
  border: 1px solid #888;
  margin-top: 12px;
  overflow-y: scroll;
  overflow-x: hidden;
}  


</style>

<script type="text/javascript">
  (function($){
    $(function(){

$('#image-cropper<?php echo $id; ?>').cropit();

// In the demos I'm passing in an imageState option
// so it renders an image by default:
// $('#image-cropper').cropit({ imageState: { src: { imageSrc } } });

// Exporting cropped image
$('#apply-crop-btn<?php echo $id ?>').click(function() {
  var imageData = $('#image-cropper<?php echo $id; ?>').cropit('export');
  $('#save<?php echo $id; ?>').val(imageData);
  // window.open(imageData);
});



    });
  })(jQuery);
</script>
