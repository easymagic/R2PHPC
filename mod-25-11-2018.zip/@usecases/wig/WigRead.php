<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class WigRead{

 
 function Exec(){
   
   $record = $this->Db->Get('wig');

   $this->RequestResponse->SetResponse('data',$record);

 }


} 