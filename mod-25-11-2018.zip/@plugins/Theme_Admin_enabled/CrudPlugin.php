<?php 

/**

@Inject(@usecases/entity/EntityCreate,
        @usecases/entity/EntityRead,
        @usecases/entity/EntityUpdate,
        @usecases/entity/EntityDelete,
        @services/RequestResponse,
        @services/Input,
        @services/FormTrigger,
        @services/entity/EntityCommit,
        @services/View);

*/


class CrudPlugin{

 private $entity = null;
  
  function SetEntity($entity=''){
    $this->entity = $entity;
  }


  function Index_Action($id=''){
    
    if (empty($id)){
      return $this->Add_Action();
    }else{
     return $this->Remove_Action($id);  
    }
    
  }


  function Index_Inject($id=''){  
    $this->RequestResponse->SetRequest($_REQUEST);
    $record = $this->EntityRead->Fetch($this->entity);
    return array($this->entity . '_data'=>$record);
    // $data = $this->entity . '_data';
    // $this->View->$data = $record;    
  }


  function Edit_Action($id=''){
    $this->RequestResponse->AddRequest('entity',$this->entity);
    return $this->EntityCommit->CallUCAction($this->EntityUpdate,$id); 
  }


  function Edit_Inject($id=''){
    $record = $this->EntityRead->Fetch($this->entity,$id);
    if (count($record) == 1 && !empty($id)){
     $record = $record[0];
    }
    return array($this->entity . '_data'=>$record);
    // $data = $this->entity . '_data';
    // $this->View->$data = $record;
  }


  function Add_Action(){
      $this->RequestResponse->AddRequest('entity',$this->entity);
      return $this->EntityCommit->CallUCAction($this->EntityCreate); 
  }

  //keep my vow


  function Remove_Action($id=''){
      $this->RequestResponse->AddRequest('id',$id);
      $this->RequestResponse->AddRequest('entity',$this->entity);
      return $this->EntityCommit->CallUCAction($this->EntityDelete); 
  }

  // function Remove_Inject($id=''){
  //   $record = $this->EntityRead->Fetch($this->entity,$id);
  //   if (count($record) == 1 && !empty($id)){
  //    $record = $record[0];
  //   }
  //   $data = $this->entity . '_data';
  //   $this->View->$data = $record;
  // }




}


