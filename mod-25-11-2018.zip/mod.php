<?php
require_once('config.php');
require_once('app-x/core/core.php');
$PageObject = DIContainer::GetInstance()->InjectClass('FrontController'); 
echo $PageObject->DispatchRequest();
// $PageObject->DecodePluginUse();
// $PageObject->DispatchRequest();