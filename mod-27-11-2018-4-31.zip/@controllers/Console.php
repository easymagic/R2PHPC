<?php
/**

@Inject(@templates/console/TerminalTemplate,
        @services/FolderMigrate,
        @services/DbFields,
        @services/CommandSignal);

*/


class Console{
  
  

  function Init(){
    $this->CommandSignal->HandleEvents($this);
  }

  
  function Index(){
    // echo 'Calling Console.';
    $response = $this->RequestResponse->GetResponse();
    // print_r($response);
    // print_r($_REQUEST);
    $message = $this->MessageLogger->GetMessageTemplate();
    echo $message;
    echo $this->TerminalTemplate->View();
    // $this->Db->Where('id',1);
    // $r = $this->Db->Get('member');
    // $r = $r[0];
    // $this->Db->Where('id',1);
    // $this->Db->Update('member',array(
    //  'ccount'=>(1 + $r['ccount'])
    // ));
    // $r = $this->Db->Get('member');
    // print_r($r);
    // print_r($this->DbFields->GetFields('wig_order'));

    // $this->FolderMigrate->Migrate('@templates','@templatesNew');
  }


 
}