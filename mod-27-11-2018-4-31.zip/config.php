<?php 

define('DEFAULT_CONTROLLER', 'Home');
define('BASE_URL', 'http://localhost/forde/');
