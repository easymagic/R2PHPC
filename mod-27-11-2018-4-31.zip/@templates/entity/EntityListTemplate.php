<?php 
 echo $Base->Tool($entity);
?>
<div class="col-xs-12">
 
 <table class="table table-striped">
   <tr>
     <th colspan="2" align="center">Options</th>
     <?php echo $TableHeaderTemplate->View(); ?>
   </tr>
   <?php 
     foreach ($data as $k=>$v){

      ?>
      <tr>
       <td>
         <a href="">Edit</a>
       </td>   
       <td>
         <a href=""> &cross; Remove</a>
       </td>          
      <?php
       $TableRowTemplate->data = $v;
       echo $TableRowTemplate->View();
      ?>
      </tr>

      <?php 

     }
   ?>



 </table>  
<?php 
// print_r($data);
?>

</div>