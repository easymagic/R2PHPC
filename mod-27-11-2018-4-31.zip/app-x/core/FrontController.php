<?php 

/**
@Inject(app-x/core/PluginLoader,
        app-x/core/Router,
        app-x/core/RequestResponse);
*/


class FrontController{
  

  private $obj = null;
  private $name = '';
  private $method = 'Index';
  private $args = array();
  private $plugins = array();
  private $request = array();
  private $parentLookOut = array('dba'=>'DbaV2');
  private $headers = array();




  function __construct(){}

  // private function CheckParentLookOut($name){
  //   if (in_array($name, array_keys($this->parentLookOut))){
  //     // array_unshift($this->args,$this->name);
  //     array_unshift($this->args,$this->method);
  //     $this->name  = $this->parentLookOut[$name];
  //     $this->method = 'Map'; //http://localhost/forde/Dba/category/[ShowList,Add,Edit]
  //     $controllerPath = '@controllers/' . $this->name;
  //     $this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

  //   }
  // }

  function GetDispatch($route,$headers=array()){
    $this->headers = $headers;
    $this->request = $route; // $_REQUEST['__request__'];
    $this->RequestResponse->SetRequest($_REQUEST);
    $r = explode('/', $this->request);

    if (count($r) >= 1){
     $name = array_shift($r);
     $method = array_shift($r);
     $args = $r;
    }else{
     $name = DEFAULT_CONTROLLER;
    }

    if (empty($method) || is_numeric($method)){
     $method = 'Index';
    }

    $controllerPath = '@controllers/' . $name;

    $name = strtolower($name);

    $obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

    $plugins = $this->DecodePluginUse($obj);
    
    return $this->DispatchRequest_($plugins,$obj,$name,$method,$args);

  }

  function GetHeaders(){
    return $this->headers;
  }

  function DispatchRequest(){
     return $this->GetDispatch($_REQUEST['__request__']);
  }


  function DecodePluginUse($obj){
      
      $plugins = array();
      
      if (method_exists($obj, 'UsePlugins')){
       $plugins = $obj->UsePlugins();
      }

      return $plugins;

     // print_r($this->plugins);
  }

 
  function DispatchRequest_($plugins,$obj,$name,$method,$args){

    $buffer = ''; 
   
   try {

    // $this->CheckParentLookOut($this->name);

    // array('plugins'=>$this->plugins,
    //       'sender'=>$this->obj,
    //       'name'=>$this->name,
    //       'method'=>$this->method,
    //       'args'=>$this->args)
    if (method_exists($obj, 'GetEntity_Hook')){
       $name = $obj->GetEntity_Hook();
    }

     // $this->Router->SetParams($plugins,$obj,$name,$method,$args);

     $this->Router->DispatchAction($plugins,$obj,$name,$method,$args);

     $buffer = $this->Router->DispatchRoute($plugins,$obj,$name,$method,$args);
     
   } catch (Exception $e) {
     
     $buffer = $e->getMessage();

   }

   return $buffer;


  }






}