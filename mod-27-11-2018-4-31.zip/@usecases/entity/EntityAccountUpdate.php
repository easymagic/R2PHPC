<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);


*/
class EntityAccountUpdate{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     $entity = $this->EntityCommit->GetEntity();

     $id = $_SESSION['accounts'][$this->entity]['id'];

     $this->EntityCommit->CheckFileUpload($request);
     $this->EntityCommit->CheckDataFileUpload($request);
     $this->EntityCommit->DoUpdate($id,$request);

  }


}

