<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @usecases/entity/EntityRegister);


*/
class EntityChangePassword{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityRegister->CheckPassword($request);
     $this->EntityCommit->RequireEntity($request);

     $entity = $this->EntityCommit->GetEntity();
     $account = $_SESSION['accounts'][$entity];
     
     $request['id'] = $account['id'];
     
     $this->EntityCommit->DoUpdate($request);
     $this->RequestResponse->SetResponse('message','Password changed successfully.');

  }


}

