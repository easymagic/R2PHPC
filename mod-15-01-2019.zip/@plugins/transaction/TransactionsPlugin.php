<?php 

/**

@Inject(@models/transaction/filters/TransactionFilterFailed,
        @models/transaction/filters/TransactionFilterPending,
        @models/transaction/filters/TransactionFilterSearch,
        @models/transaction/filters/TransactionFilterSettled,
        @models/transaction/filters/TransactionFilterSuccess,
        @models/transaction/filters/TransactionFilterDate,
        @models/transaction/filters/TransactionFilterMerchant,
        @models/transaction/TransactionGetList,
        @models/merchant/MerchantGetList,
        @models/transaction/TransactionGetOne);

*/


class TransactionsPlugin{

  
  function Init(){
    global $transactionFilters;
    $transactionFilters = array();
    
  }


  private function CheckFilters(){
   global $transactionFilters;
   global $get;

   if (isset($get['pstatus'])){

     if ($get['pstatus'] == 'success'){
      $this->TransactionFilterSuccess->FilterSuccess();
     }else if ($get['pstatus'] == 'pending'){
      $this->TransactionFilterPending->FilterPending();
     }else if ($get['pstatus'] == 'settled'){
      $this->TransactionFilterSettled->FilterSettled();
     }else if ($get['pstatus'] == 'failed'){
      $this->TransactionFilterFailed->FilterFailed();
     }
     
   }

   // if (isset($get['search_text']) && !empty($get['search_text'])){
   //   $this->TransactionFilterSearch->FilterSearch($get['search_text']);
   // }

   if (isset($get['date1']) && isset($get['date2'])){
     $this->TransactionFilterDate->FilterDate($get['date1'],$get['date2']);
   }

   if (isset($get['merchant']) && !empty($get['merchant'])){
     $this->TransactionFilterMerchant->FilterMerchant($get['merchant']);
   }

  }

  
  function ListTransaction_AdminContent(){
     global $db_sql;
     $this->CheckFilters();
     CallAction('Init_Transaction');
     $this->TransactionGetList->GetList(); 
     // echo $db_sql;   
     CallAction('Init_Merchant'); 
     $this->MerchantGetList->GetList();
  }

  function DetailTransaction_AdminContent($id){
     $this->TransactionGetOne->GetOne($id);
  }

  function SettleTransaction_Action(){

  }


  function Redirect(){
    global $redirect;
    $redirect = 'ManageSettings/ListSetting';
  }


}