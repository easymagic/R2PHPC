<?php 

/**

@Inject(@templates/backend/Admin_HTML_StartTemplate,
        @templates/backend/Admin_HeaderTemplate,
        @templates/backend/admin/Admin_SideBarTemplate,
        @templates/backend/Admin_Content_PreStartTemplate,
        @templates/backend/Admin_Content_PreStopTemplate,
        @templates/backend/Admin_FooterTemplate,
        @templates/backend/Admin_HTML_StopTemplate);

*/


class AdminBackEndPlugin{


  function Page_Init(){
    global $session;
    global $data;
    global $logged;
    global $session_type;
    global $adminID;

    $logged = false;
    $session_type = 'admin';

    // echo $session_type;
    
    // $data['role'] = '';
    if (isset($session['admin_session'])){
      // echo 'called.';
       $data['role'] = $session['admin_session']['role'];
       $logged = true;
       $data['session_type'] = $session_type;
       // echo $data['session_type'];
       $adminID = $session['admin_session']['id'];
    }
  }



 function Admin_HTML_Start(){
  global $buffer;
  $buffer.=$this->Admin_HTML_StartTemplate->View();
 }  

 function Admin_Header(){
  global $buffer;
  $buffer.=$this->Admin_HeaderTemplate->View();
 }

 function Admin_SideBar(){
  global $buffer;
  $buffer.=$this->Admin_SideBarTemplate->View();
 }

 function Admin_Content_PreStart(){
  global $buffer;
  $buffer.=$this->Admin_Content_PreStartTemplate->View();
 }

 function Admin_Content_PreStop(){
  global $buffer;
  $buffer.=$this->Admin_Content_PreStopTemplate->View();
 }

 function Admin_Footer(){
  global $buffer;
  $buffer.=$this->Admin_FooterTemplate->View();
 }

 function Admin_HTML_Stop(){
  global $buffer;
  $buffer.=$this->Admin_HTML_StopTemplate->View();
 }

 

}