<?php 

/**

@Inject(@plugins/BackEndPlugin,
        @plugins/AdminBackEndPlugin,
        @plugins/MerchantBackEndPlugin,
        @templates/admin/indexTemplate,
        @templates/admin/loginTemplate);

@InjectFolder(@models/entityv2);

*/


class Admin{
  

  function Init(){
    InstallPlugin($this->AdminBackEndPlugin);
    // InstallPlugin($this->MerchantBackEndPlugin);
  }

  function Index_AdminContent(){
    // global $buffer;

    $this->EntityRead->Read('merchant');

    // $buffer.=$this->indexTemplate->View();
  }




}
 