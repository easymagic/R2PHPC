<?php 
/**

@Inject(@plugins/webpayment/WebPaymentPlugin);

*/

class WebPayment{

  
  
 function GateWay($uid=''){}
 function Feedback(){}



}