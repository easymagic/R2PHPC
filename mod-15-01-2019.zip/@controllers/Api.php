<?php 

/**

@Inject(@models/transaction/TransactionInitPayment,
        @models/transaction/TransactionQueryStatus);

*/

class Api{

  
  

  function InitTransaction(){ //post-params: $merchant_secret, post-data-params: amount,email,merchant_feedback_page
    global $contentType;
    $contentType = 'json';

    $this->TransactionInitPayment->InitPayment();
    
  }

  function QueryTransaction($interpay_reference){
    
    global $contentType;
    $contentType = 'json';  	

  	$this->TransactionQueryStatus->QueryStatus($interpay_reference);
   
  }



}