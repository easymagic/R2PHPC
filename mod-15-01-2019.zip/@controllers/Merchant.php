<?php 

/**

@Inject(@plugins/MerchantBackEndPlugin,
        @plugins/transaction/TransactionsPlugin,
        @plugins/session/CheckMerchantSessionLoggedPlugin,
        @plugins/dashboard/DashboardPlugin,
        @plugins/merchant/MerchantPlugin);

*/


class Merchant{


  function Init(){
    InstallPlugin($this->MerchantBackEndPlugin);
    InstallPlugin($this->TransactionsPlugin);
    InstallPlugin($this->CheckMerchantSessionLoggedPlugin);
    InstallPlugin($this->DashboardPlugin);
    InstallPlugin($this->MerchantPlugin);

    InstallTheme('@themes/AdminBackEndFramework');
    
  }



  function ListTransaction_AdminContent(){}
  function DetailTransaction_AdminContent(){}
  function Dashboard_AdminContent(){}

  ////MerchantPlugin
  function ChangePassword_AdminContent(){}
  function EditProfile_AdminContent(){}







}