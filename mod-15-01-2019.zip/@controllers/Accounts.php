<?php 

/**

@Inject(@plugins/BackEndPlugin,
        @plugins/BackEndLoginPlugin,
        @templates/accounts/AdminLogin_AdminContentTemplate,
        @templates/accounts/MerchantLogin_AdminContentTemplate,
        @plugins/AccountsPlugin,
        @plugins/session/CheckAdminSessionPlugin,
        @plugins/session/CheckMerchantSessionPlugin);

*/


class Accounts{
  

  function Init(){    
    
    InstallTheme('@themes/AdminBackEndFramework');

    InstallPlugin($this->BackEndLoginPlugin);
    InstallPlugin($this->AccountsPlugin);
    InstallPlugin($this->CheckMerchantSessionPlugin);
    InstallPlugin($this->CheckAdminSessionPlugin);

    

  }

  function Index_AdminContent(){
    global $buffer;
    $buffer.=$this->AdminLogin_AdminContentTemplate->View();
  }


  function AdminLogin_AdminContent(){
    // global $buffer;
    // $buffer.=$this->AdminLogin_AdminContentTemplate->View();
  }

  function MerchantLogin_AdminContent(){
    // global $buffer;
    // $buffer.=$this->MerchantLogin_AdminContentTemplate->View();
  }




}
 