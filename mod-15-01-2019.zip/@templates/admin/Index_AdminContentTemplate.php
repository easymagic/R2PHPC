<section class="content-header">
  <h1> Add Movie </h1>
  <div class="row col-lg-1" style="float:right; margin-bottom:20px; margin-top:10px;">
    <input type="button" class="btn btn-block btn-info" value="Back" onclick="window.history.back()" />
  </div>
  <ol class="breadcrumb">
    <li><a href="admin/home"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="movie">Movie</a></li>
    <li class="active">Add Movie</li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <div class="row"> 
    <!-- form start -->
    
      
      <!-- left column -->
      <div class="col-md-8"> 
        <?php 
          print_r($merchant_data);
        ?>
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Add Movie Form</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body"> 
            <!-- text input -->
            <div class="form-group">
              <label>Title:</label>
              <input type="text" class="form-control" placeholder="Enter Title" id="title" name="title" data-error="Enter title!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Year:</label>
              <input type="text" class="form-control" placeholder="Enter Year" id="year" name="year" data-error="Enter year!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Budget:</label>
              <input type="text" class="form-control" placeholder="Enter Budget" id="budget" name="budget" data-error="Enter budget!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Stage:</label>
              <input type="text" class="form-control" placeholder="Enter Stage" id="stage" name="stage" data-error="Enter stage!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Synopsis:</label>
              <input type="text" class="form-control" placeholder="Enter Synopsis" id="story" name="story" data-error="Enter story!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Rating:</label>
              <input type="text" class="form-control" placeholder="Enter Rating" id="rating" name="rating" data-error="Enter rating!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Category:</label>
              <select class="form-control" name="moviecategory" id="moviecategory" required >
              </select>
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Release Date:</label>
              <input type="text" class="form-control" placeholder="Enter Release Date" id="release_date" name="release_date" data-error="Enter release date!" required />
              <div class="help-block with-errors"></div>
            </div>
            </div>
          </div>
          <!-- /.box-body -->
          
          <div class="box-footer">
            <!-- formaction="add" -->
            <button type="submit" class="btn btn-primary">Add Movie</button>
            <button type="reset" class="form-reset btn btn-primary">Reset</button>
          </div>
        </div>
        <!-- /.box --> 
      </div>
  

</section>
