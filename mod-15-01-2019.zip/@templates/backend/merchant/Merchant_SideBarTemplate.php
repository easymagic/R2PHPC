    <aside class="main-sidebar">
        <section class="sidebar">
            <ul class="sidebar-menu">
                <li class="header">MAIN NAVIGATION (MERCHANT)</li>
                <li class="active">
                    <a href="<?php echo BASE_URL; ?>Merchant/Dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>

                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Transactions</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo BASE_URL; ?>Merchant/ListTransaction"><i class="fa fa-building-o"></i>Manage Transactions</a></li>
                    </ul>
                </li>



                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Account</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo BASE_URL; ?>Merchant/EditProfile"><i class="fa fa-building-o"></i>Edit Profile</a></li>
                      <li><a href="<?php echo BASE_URL; ?>Merchant/ChangePassword"><i class="fa fa-building-o"></i>Change Password</a></li>
                    </ul>
                </li>

            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>
<!-- content start -->
