<?php 

$data = array();
$dataJSON = array();
$dependencyData = array();

// $args = array();
// $name = '';
// $action = '';
$headers = array();
$headers = getallheaders();
extract($headers);

/////Decode Payload (As a side Effect)////////
$requestBody = file_get_contents('php://input');
$requestBodyData = array();

if (!empty($requestBody) && is_array(json_decode($requestBody,true))){
 $requestBodyData = json_decode($requestBody,true);	
 foreach ($requestBodyData as $k=>$v){
    $_REQUEST[$k] = $v;
    $_POST[$k] = $v;
 }
}

$request = &$_REQUEST;
$response = array();
$post = &$_POST;

$postData = array();
if (isset($post['data'])){
 $postData = &$post['data'];
}

$requestData = array();
if (isset($request['data'])){
 $requestData = &$request['data'];
}

$get = &$_GET;
$session = &$_SESSION;
// $accounts = array('accounts'=>array('admin'));
$accounts = array();
if (isset($session['accounts'])){
  $accounts = $session['accounts'];
}
$newID = 0;



// class GlobalBucket{


  
//   function PostJob(){

//   }



// }
