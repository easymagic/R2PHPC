<?php
error_reporting(E_ALL);
session_start();

require_once('app-x/core/FrontController.php');
require_once('app-x/core/DIContainer.php');
require_once('config.php');
require_once('app-x/core/core.php');

//Payment variables here
$payStackSecret = 'sk_test_533ac4229f9c0a279ca6fda625b9660ba86bc178';
$payStackPaymentStatus = false;

//Special variables here
$contentType = 'html';
$routeObject = null;
$routeName = '';
$routeAction = '';
$routeArgs = array();
$buffer = '';
$json = array();

$threads = array();
$plugins = array();
$libs = array();
$themes = array();


$PageObject = InjectClass('FrontController'); 
$PageObject->DispatchRequest();

echo $buffer;