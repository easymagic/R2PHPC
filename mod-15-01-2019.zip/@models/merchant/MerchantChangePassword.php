<?php 
/**

@Inject(@models/entityv2/EntityChangePassword);

*/

class MerchantChangePassword{

  
   function ChangePassword($id){
    global $post;

     $this->EntityCheckPassword->SetData($post);   	
   	 $this->EntityRead->SetWhere("id=$id");
     $this->EntityChangePassword->ChangePassword('merchant');
   }

}