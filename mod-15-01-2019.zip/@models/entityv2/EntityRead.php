<?php 

class EntityRead{

   

   function Read($entity){     
     global $db_records;
     global $data;
     // echo "$entity";
     DbRead($entity);

     $data[$entity . '_data'] = $db_records;
 
     return $db_records;
   }

   function SetWhere($criteria){
     global $db_where;
     $db_where = " where ($criteria) ";
     // echo $db_where;
     // die($db_where);
   }


}