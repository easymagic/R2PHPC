<?php 

/**

@Inject(@models/entityv2/EntityUpdate);

*/

class GWSettingsUpdate{


  function Update($id){
    global $postData;
    global $data;

    // $name = $postData['name'];
    $this->EntityRead->SetWhere("id=$id");
    $this->EntityUpdate->SetData($postData);
    $this->EntityUpdate->DoUpdate('gw_settings',$postData);
    
    $data['message'] = 'Option Updated.';
  }

}