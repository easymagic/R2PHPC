<?php 

/**

@Inject(@models/entityv2/EntityDelete);

*/

class GWSettingsRemove{


  function Remove($id){
    // global $postData;
    global $data;

    // $name = $postData['name'];
    $this->EntityRead->SetWhere("id=$id");
    $this->EntityDelete->DoDelete('gw_settings');
    // $this->EntityRemoveOption->RemoveOption('gw_settings',$name);
    $data['message'] = 'Option Removed.';
  }

}