<?php 

/**

@Inject(@models/entityv2/EntityRead);

*/

class GWSettingsGetList{

  function GetList(){
    $this->EntityRead->Read('gw_settings');
  }

}