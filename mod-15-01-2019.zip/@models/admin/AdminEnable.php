<?php 

/**

@Inject(@models/entityv2/EntityEnableField);

*/

class AdminEnable{

  

   function Enable($id){
   	 $this->EntityRead->SetWhere("id=$id");
     $this->EntityEnableField->EnableField('admin','status');
   }


}