<?php 

/**

@Inject(@models/entityv2/EntityLogin);

*/

class AdminLogin{

  

  function Login(){
  	global $post;
  	// print_r($post);
  	// echo '....';
    $this->EntityLogin->SetData($post);
  	$this->EntityLogin->SetLoginFields('email','password');
    $this->EntityLogin->Login('admin');
    
  }



}