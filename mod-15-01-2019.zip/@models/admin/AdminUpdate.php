<?php 

/**

@Inject(@models/entityv2/EntityUpdate);

*/

class AdminUpdate{
  



  function Update($id){
    global $postData;
    global $data;

    if (isset($postData['email'])){ //security measures
      unset($postData['email']);
    }
    if (isset($postData['password'])){ //security measures
     unset($postData['password']);
    }

    $this->EntityRead->SetWhere("id=$id");
    $this->EntityUpdate->SetData($postData);    

    $this->EntityUpdate->DoUpdate('admin');

    $data['message'] = 'Account saved.';
    $data['error'] = false;

  }


}