<?php 
/**
@Inject(@models/transaction/TransactionGetList);
*/

class TransactionQueryStatus{

  
   function QueryStatus($interpay_reference){
     global $db_where;
     global $data;

     $this->EntityRead->SetWhere("interpay_reference='$interpay_reference'");
     $this->TransactionGetList->GetList(); //interpay_reference

     if (isset($data['transaction_data']) && count($data['transaction_data']) > 0){
        $data['transaction_data'] = $data['transaction_data'][0];
        $data['message'] = 'Transaction query successful.';
     }else{
     	$data['message'] = 'Invalid interpay-reference!';
     	$data['error'] = true;
     }
   }


}