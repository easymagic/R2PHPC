<?php 
/**

@Inject(@models/entityv2/EntityUpdate);

*/


class TransactionUpdateSuccess{
  


  function UpdateSuccess($criteria){
     $this->EntityUpdate->Update('transaction',array('pstatus'=>'success'),$criteria);
  }



}