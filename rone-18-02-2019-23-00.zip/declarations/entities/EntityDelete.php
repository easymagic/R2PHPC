<?php
namespace declarations\entities;

class EntityDelete extends \declarations\Db{

   // function SetWhere(){

   // } 

   function Delete($table){
    
    if (!empty($this->GetWhere())){
       $this->DbDelete($table);
    }

   }


}