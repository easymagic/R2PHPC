<?php 

/*** Url Config***/
// define('DEFAULT_CONTROLLER', 'Admin');
// define('BASE_URL', 'http://timberfieldschoolslagosng.sch.ng/sandbox/');
define('BASE_URL', 'http://door2doorconnect.com.ng.r2soft.com.ng/');
define('CALLBACK_URL', '');
// define('API_URL', '/d2dc/rone/');


/****Database config*****/
// private static $db_server;
// private static $db_username;
// private static $db_password;
// private static $db_databasename;
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASENAME', 'country_state_db');


                                            // 'ydetbkzc_door2door_user',
                                            // '$5zIjy[DMHcf',
                                            // 'ydetbkzc_door2door_connect_db'); // or 



/*** Middle-ware declaration ***/
//$__middle_wares__ = array(); 
//$__named_middle_wares__ = array();
$__named_middle_wares__['auth'] = middlewares\CheckAuth::class;