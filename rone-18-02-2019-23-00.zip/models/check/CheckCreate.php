<?php 

class CheckCreate extends EntityCreate{


  

    function Create_(){
     $r = parent::Create('tbl_check',$_POST['data']);	
     $r['message'] = 'Check created.';
     $r['error'] = false;
     return $r;;
    }


}