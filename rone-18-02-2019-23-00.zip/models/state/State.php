<?php 

namespace models\state;


class State extends \rone\Model{


	protected $table = 'states';

    
    function country(){
    	return $this->belongsTo(\models\country\Country::class,'country_id');
    }



}