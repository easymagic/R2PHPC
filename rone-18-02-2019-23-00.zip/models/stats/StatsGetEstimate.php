<?php 
namespace models\stats;

class StatsGetEstimate{



	function GetEstimate(){

      $r = array();


$r[] = array("state"=>'ABIA', //53,117, 42,648, 13,231
             "districts"=>array(
               "a"=>"42124",
               "b"=>"36125",
               "c"=>"53111"
             ));

$r[] = array("state"=>'ADAMAWA',
             "districts"=>array(
               "a"=>"43101",
               "b"=>"62991",
               "c"=>"44231"
             ));


$r[] = array("state"=>'AKWA IBOM',
             "districts"=>array(
               "a"=>"72021",
               "b"=>"41846",
               "c"=>"35425"
             ));

$r[] = array("state"=>'ANAMBRA',
             "districts"=>array(
               "a"=>"65342",
               "b"=>"75123",
               "c"=>"40114"
             ));

$r[] = array("state"=>'BAUCHI',
             "districts"=>array(
               "a"=>"47249",
               "b"=>"38117",
               "c"=>"59724"
             ));

$r[] = array("state"=>'BAYELSA',
             "districts"=>array(
               "a"=>"24824",
               "b"=>"15110",
               "c"=>"18291"
             ));

$r[] = array("state"=>'BENUE',
             "districts"=>array(
               "a"=>"58115",
               "b"=>"165665",
               "c"=>"32193"
             ));

$r[] = array("state"=>'BORNO',
             "districts"=>array(
               "a"=>"91291",
               "b"=>"87216",
               "c"=>"92987"
             ));

$r[] = array("state"=>'CROSS RIVER',
             "districts"=>array(
               "a"=>"78189",
               "b"=>"43237",
               "c"=>"65112"
             ));

$r[] = array("state"=>'DELTA',
             "districts"=>array(
               "a"=>"78109",
               "b"=>"63125",
               "c"=>"69542"
             ));

$r[] = array("state"=>'EBONYI',
             "districts"=>array(
               "a"=>"27452",
               "b"=>"41348",
               "c"=>"28981"
             ));

$r[] = array("state"=>'EDO',
             "districts"=>array(
               "a"=>"102146",
               "b"=>"73753",
               "c"=>"34192"
             ));

$r[] = array("state"=>'EKITI',
             "districts"=>array(
               "a"=>"27216",
               "b"=>"32181",
               "c"=>"34103"
             ));

$r[] = array("state"=>'ENUGU',
             "districts"=>array(
               "a"=>"67783",
               "b"=>"71128",
               "c"=>"60110"
             ));

$r[] = array("state"=>'FCT',
             "districts"=>array(
               "a"=>"",
               "b"=>"",
               "c"=>""
             ));

$r[] = array("state"=>'GOMBE',
             "districts"=>array(
               "a"=>"32127",
               "b"=>"66753",
               "c"=>"61524"
             ));

$r[] = array("state"=>'IMO',
             "districts"=>array(
               "a"=>"81843",
               "b"=>"75327",
               "c"=>"98010"
             ));

$r[] = array("state"=>'JIGAWA',
             "districts"=>array(
               "a"=>"118290",
               "b"=>"55030",
               "c"=>"63401"
             ));

$r[] = array("state"=>'KADUNA',
             "districts"=>array(
               "a"=>"63129",
               "b"=>"44310",
               "c"=>"69401"
             ));

$r[] = array("state"=>'KANO',
             "districts"=>array(
               "a"=>"96304",
               "b"=>"70590",
               "c"=>"69205"
             ));

$r[] = array("state"=>'KATSINA',
             "districts"=>array(
               "a"=>"78203",
               "b"=>"68405",
               "c"=>"28010"
             ));

$r[] = array("state"=>'KEBBI',
             "districts"=>array(
               "a"=>"32871",
               "b"=>"46240",
               "c"=>"44007"
             ));

$r[] = array("state"=>'KOGI',
             "districts"=>array(
               "a"=>"55030",
               "b"=>"38104",
               "c"=>"44003"
             ));

$r[] = array("state"=>'KWARA',
             "districts"=>array(
               "a"=>"87678", 
               "b"=>"182240",
               "c"=>"304856"
             ));


// $r[] = array("state"=>'KWARA',
//              "districts"=>array(
//                "a"=>"87678", 
//                "b"=>"182000",
//                "c"=>"304000"
//              ));


$r[] = array("state"=>'LAGOS',
             "districts"=>array(
               "a"=>"339128",
               "b"=>"155972",
               "c"=>"240214"
             ));

$r[] = array("state"=>'NASARAWA',
             "districts"=>array(
               "a"=>"54235",
               "b"=>"43120",
               "c"=>"72202"
             ));

$r[] = array("state"=>'NIGER',
             "districts"=>array(
               "a"=>"18021",
               "b"=>"17080",
               "c"=>"33130"
             ));

$r[] = array("state"=>'OGUN',
             "districts"=>array(
               "a"=>"331764",
               "b"=>"41021",
               "c"=>"20217"
             ));

$r[] = array("state"=>'ONDO',
             "districts"=>array(
               "a"=>"87124",
               "b"=>"67231",
               "c"=>"52020"
             ));

$r[] = array("state"=>'OSUN',
             "districts"=>array(
               "a"=>"55210",
               "b"=>"42021",
               "c"=>"35093"
             ));

$r[] = array("state"=>'OYO',
             "districts"=>array(
               "a"=>"112231",
               "b"=>"59020",
               "c"=>"70170"
             ));

$r[] = array("state"=>'PLATEAU',
             "districts"=>array(
               "a"=>"76240",
               "b"=>"67112",
               "c"=>"70015"
             ));

$r[] = array("state"=>'RIVERS',
             "districts"=>array(
               "a"=>"78217",
               "b"=>"105219",
               "c"=>"92023"
             ));

$r[] = array("state"=>'SOKOTO',
             "districts"=>array(
               "a"=>"74029",
               "b"=>"81028",
               "c"=>"45215"
             ));

$r[] = array("state"=>'TARABA',
             "districts"=>array(
               "a"=>"46239",
               "b"=>"74017",
               "c"=>"41640"
             ));

$r[] = array("state"=>'YOBE',
             "districts"=>array(
               "a"=>"28160",
               "b"=>"42058",
               "c"=>"46030"
             ));



$r[] = array("state"=>'ZAMFARA',
             "districts"=>array(
               "a"=>"32019",
               "b"=>"56220",
               "c"=>"71184"
             ));




/**


<option value="34"></option>
<option value="35"></option>
<option value="36">ZAMFARA</option>
**/



      return $r;


	}



}