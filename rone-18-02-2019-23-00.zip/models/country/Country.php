<?php 

namespace models\country;


class Country extends \rone\Model{


	protected $table = 'countries';

    
    function states(){
    	return $this->hasMany(\models\state\State::class,'country_id');
    }



}