<?php 

class SubjectCreate{

  

   function Create(){

   	// print_r($_POST);
   	// echo 'called...';

   	LoadClass($this,'@models/Db');
    $this->Db->DbCreate('subject',$_POST['data']);

    return array('message'=>'Subject Created','error'=>false,'newID'=>$this->Db->newID);

   }


}