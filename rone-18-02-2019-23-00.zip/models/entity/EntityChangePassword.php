<?php 
/**

@Inject(@models/entityv2/EntityUpdate,
        @models/entityv2/EntityCheckPassword);

*/

class EntityChangePassword{



   function ChangePassword($entity){

	   	global $post;
	   	global $data;

	   	$data['error'] = false;
	   	$data['message'] = '';

	   	$this->EntityCheckPassword->SetData($post);
	   	$this->EntityCheckPassword->CheckPassword();
	   	if (!$data['error']){
	   	  $result = $this->EntityCheckPassword->GetData();	
	      $data['message'] = 'Passwords changed successfully.';
	      $this->EntityUpdate->SetData(array('password'=>$result['password1']));
	      $this->EntityUpdate->DoUpdate($entity);
	   	}
	    

     
   }




}