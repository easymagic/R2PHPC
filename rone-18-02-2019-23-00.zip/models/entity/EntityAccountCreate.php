<?php 
/**

@Inject(@models/entityv2/EntityCreate,
        @models/entityv2/EntityRead,
        @models/entityv2/EntityCheckPassword);

*/

class EntityAccountCreate{
   

  private $postData = array(); 
  private $duplicateField = 'email';
  

  function AccountCreate($entity){
    global $data;
    global $newID;
    global $postData;

    $data['error'] = false;
    $data['message'] = '';

    $this->EntityCheckPassword->CheckPassword();
    $this->CheckDuplicate($entity);    
    
    if (!$data['error']){
      
      $result = $this->EntityCheckPassword->GetData();
      $this->postData['password'] = $result['password1'];
      $this->EntityCreate->SetData($this->postData);
    	$this->EntityCreate->DoCreate($entity); 
    	$data['message'] = ucfirst($entity) . ' account created successfully.';

    } 	

  }

  function SetData($data){
   $this->postData = $data;
  }

  function SetDuplicateField($field){
   $this->duplicateField = $field;
  }

  private function CheckDuplicate($entity){
   global $data;
   // global $db_where;
   global $postData;
   
   // $db_where = " where (" . $this->duplicateField . " = '" . $postData['email'] . "') ";
   $this->EntityRead->SetWhere($this->duplicateField . " = '" . $postData['email'] . "'");
   $this->EntityRead->Read($entity);
   
   if (count($data[$entity . '_data']) > 0){
      $data['error'] = true;
      $data['message'].= 'An account with this <b>E-mail</b> already exist!';
   }

  }

  // private function CheckPassword(){
  //  global $data;
  //  global $post;
  //  global $postData;
  
  //  if ($post['password1'] != $post['password2'] || empty($post['password1'])){
  //   $data['error'] = true;
  //   $data['message'].= 'Passwords do not match!<br />';
  //  }else{
  //  	$postData['password'] = $post['password1'];
  //  }

  // }




}