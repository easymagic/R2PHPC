<?php 

namespace middlewares;

class CheckAuth{


  
    function handle($options){
      echo 'Checking auth....';	
      return $options;
    }


}