<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
  // global $post;
?>

<div>
	<h1 style="color: green;"><?php echo strtoupper('Verification Successful.'); ?></h1>
</div>

<div>
	<div>
		<b>First Name</b>
	</div>
	<div>
		<?php echo $first_name; ?>
	</div>

	<hr />
</div>



<div>
	<div>
		<b>Last Name</b>
	</div>
	<div>
		<?php echo $last_name; ?>
	</div>
	<hr />
</div>




<div>
	<div>
		<b>Polling Unit</b>
	</div>
	<div>
		<?php echo $polling_unit; ?>
	</div>
	<hr />
</div>


<div>
	<div>
		<b>VIN</b>
	</div>
	<div>
		<?php echo $vin; ?>
	</div>
	<hr />
</div>


<div>
	<div>
		<b>Date Of Birth</b>
	</div>
	<div>
		<?php echo $date_of_birth; ?>
	</div>
	<hr />
</div>


<div>
	<div>
		<b>Gender</b>
	</div>
	<div>
		<?php echo $gender; ?>
	</div>
</div>

<div>
	<br />
	<br />
	Kind Regards<br />
	<b>Door2Door Connect Team</b>
	<br />
</div>

</body>
</html>