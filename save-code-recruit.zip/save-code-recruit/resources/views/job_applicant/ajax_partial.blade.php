


 <table class="table table-striped">
     <tr>
         <th>
             Full Name
         </th>
         <th>
             E-mail
         </th>
         <th>
             Phone Number
         </th>
         <th></th>
     </tr>
     @foreach ($applicants as $applicant)
     
     <tr>
         
         <td>
             {{$applicant->candidate->name}}
         </td>
         <td>
             {{$applicant->candidate->email}}
         </td>
         <td>
             {{$applicant->candidate->phone_number}}
         </td>
         <td>
            <div class="dropdown show">
                <button class="btn btn-success dropdown-toggle btn-sm pull-right" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    Action
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; transform: translate3d(-5px, 38px, 0px); top: 0px; left: 0px; will-change: transform;"> 
                     
                     <a class="dropdown-item" data-backdrop="false" href="">Detail</a> 


                     <form method="post" action="/view-applicants/{{$applicant->id}}/approve">
                        
                        @csrf 
                        
                     <button type="button" class="dropdown-item btn btn-danger btn-sm" data-backdrop="false"  data-toggle="modal" data-target="#approveReject" >Approve</button> 

                     </form>




                     <form method="post" action="/view-applicants/{{$applicant->id}}/unapprove">
                        
                        @csrf 
                        
                     <button type="button" class="dropdown-item btn btn-danger btn-sm" data-backdrop="false"  data-toggle="modal" data-target="#approveReject" >Unapprove</button> 

                     </form>

                </div>
            </div>             
         </td>
     </tr>

     @endforeach
 </table>           
