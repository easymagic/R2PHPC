@extends('layouts.main')

@extends('layouts.logged_user')

@section('inner-content')

<div style="
    border-bottom: 3px solid #8c76f7;
    margin-bottom: 17px;
    font-size: 18px;
">
    Update My C.V
</div>



 <style type="text/css">
     .cv label{
        font-weight: bold;
     }
 </style>

<form method="post" action="{{ route('candidate.update',$candidate->id) }}">
 @csrf
 @method('PATCH')
<div class="cv" style="
    padding: 10px;
    border: 1px solid #ddd;">

    <!-- jb_recruitment_type_id -->


<!-- jb_competency_id -->


<!-- years_of_experience -->
@include('notifications.message')

    
    <div>
        <label style="color: #000;">Full Name</label>
    </div>
    <div>
        <input type="text" name="name" class="form-control" value="{{$candidate->name}}" />
    </div>


    <div>
        <label>E-mail</label>
    </div>
    <div>
        <input type="email" name="email" class="form-control" value="{{$candidate->email}}" /> 
    </div>


    <div>
        <label>Phone Number</label>
    </div>
    <div>
        <input type="text" name="phone_number" class="form-control" value="{{$candidate->phone_number}}" /> 
    </div>


    <div>
        <label>Address</label>
    </div>
    <div>
        <input type="text" name="address" class="form-control" value="{{$candidate->address}}" />
    </div>



    <div>
        <label>Cover Letter</label>
    </div>
    <div>
    	<textarea class="form-control" name="cover_letter">{{$candidate->cover_letter}}</textarea>
    </div>



    <div>
        <label>Age</label>
    </div>
    <div>
        <input type="number" name="age" class="form-control" value="{{$candidate->age}}" />
    </div>



    <div>
        <label>Gender</label>
    </div>
    <div>
        <select class="form-control" name="gender" data-value="{{$candidate->gender}}">
            <option value="">--Select Gender--</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
    </div>



    <div>
        <label>Marital Status</label>
    </div>
    <div>
        <select class="form-control" name="marital_status" data-value="{{$candidate->marital_status}}">
            <option value="">--Select Marital Status--</option>
            <option value="single">Single</option>
            <option value="married">Married</option>
        </select>
    </div>



    <div align="right">
        <button style="margin-top: 17px;" class="btn btn-sm btn-success">Save</button>
    </div>



</div>
</form>


<div style="clear: both;">&nbsp;</div>

<!-- candidate education -->
@include('candidate_education.index')

<!-- candidate skill -->
@include('candidate_skill.index')

<!-- candidate certification -->
@include('candidate_certification.index')


<!-- candidate workexperience -->
@include('candidate_work_experience.index')


@endsection

