                    <div style="border-bottom: 1px solid #000;" id="candidate-education">
                        <b style="color: #000;">Your Educations</b>
                    </div>

                    <div class="col-lg-12">
                        
                        <table class="table">
                            <tr>
                                <th>Institution</th>
                                <th>Qualification</th>
                                <th>From</th>
                                <th>To</th>
                            </tr>
                            @foreach ($candidate->candidateEducations as $candidateEducation)
                             <tr>
                                 <td>{{$candidateEducation->education->name}}</td>
                                 <td>{{$candidateEducation->qualifications}}</td> 
                                 <td>{{$candidateEducation->date_from}}</td>
                                 <td>{{$candidateEducation->date_to}}</td>
                                 <td>
            <div class="dropdown show">
                <button class="btn btn-success dropdown-toggle btn-sm pull-right" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    Action
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; transform: translate3d(-5px, 38px, 0px); top: 0px; left: 0px; will-change: transform;"> 
                     

                     <form method="post" action="{{ route('candidateeducation.destroy',$candidateEducation->id) }}">
                        <!-- /candidate-educations/{candidateEducation}/delete -->
                        
                        @csrf
                        @method('DELETE') 
                        
                     <button class="dropdown-item btn btn-danger btn-sm" data-backdrop="false"  data-toggle="modal" data-target="#approveReject" >Remove</button> 

                     </form>

                </div>
            </div>                                                  
                                 </td>
                             </tr> 
                            @endforeach
                        </table>


                        <!-- qualifications -->

                        <form method="post" action="{{ route('candidateeducation.store') }}">
                            <!-- /candidate-educations/add/{candidate}/{user} -->
                            @csrf
                            @method('POST')



                        <table class="table">
                            <tr>
                              <td>
                                <select class="form-control" name="jb_education_id" style="display: inline-block;">
                                    <option value="">--Select Education--</option>
                                    @foreach ($educations as $education)
                                    <option value="{{$education->id}}">{{$education->name}}</option>
                                    @endforeach
                                </select>                                  
                              </td>
                              <td>
                                <input type="text" name="qualifications" class="form-control" placeholder="Qualifications" required="" />
                              </td>
                              <td>
                                <input type="date" name="date_from" class="form-control" required="" />
                              </td>                                
                              <td>
                                <input type="date" name="date_to" class="form-control" style="width: 90%;display: inline-block;" required="" />                                  
                              </td>
                              <td align="right">
                                <button type="submit" class="btn btn-primary btn btn-sm" style="margin-top: 0;">
                                    {{ __(' + ') }}
                                </button>                                  
                              </td>
                            </tr>
                        </table>

                        </form>


<!--                             <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Institution') }}</label>

                            <div class="col-md-6">

                            </div>                                
                            </div>





                            <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Date From') }}</label>

                            <div class="col-md-6">



                            </div>                                
                            </div>



                            <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Date To') }}</label>

                            <div class="col-md-6">





                            </div>                                
                            </div>
 -->




                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-2" align="right">

                            </div>
                        </div>




</div>
