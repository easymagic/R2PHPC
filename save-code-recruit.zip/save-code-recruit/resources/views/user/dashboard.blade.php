@extends('layouts.main')

@extends('layouts.logged_user')

@section('inner-content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            @if (Auth::user()->role == 'admin')
            <a href="{{ route('job.index') }}">
            <div class="col-xs-12 col-md-3" style="display: inline-block;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($jobCount)}} - Jobs
                    <!-- [end] -->
                    </div>
                </div>                
            </div>
            </a>


            <div class="col-xs-12 col-md-3" style="display: inline-block;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($applicantCount)}} - Applicants
                    <!-- [end] -->
                    </div>
                </div>                
            </div>
            @else 

            <div class="col-xs-12 col-md-3" style="display: inline-block;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($jobAppliedCount)}} - Applied Jobs
                    <!-- [end] -->
                    </div>
                </div>                
            </div>

            @endif




        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>

@endsection
