<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

     <a href="/user-profile/{{Auth::user()->id}}">Profile</a>
     <a href="/change-password/{{Auth::user()->id}}">Change Password</a>

    @if (Auth::user()->hasUploadedCv())
     <a href="{{ route('candidate.edit',Auth::user()->candidate()->id) }}">Update Your C.V</a>
    @else
     <a href="{{ route('candidate.create') }}">Upload Your C.V</a>
    @endif 
     <a href="/">Job Apply</a>

  @guest
   <!-- nothing here at the moment -->
  @else
    @if (Auth::user()->role == 'admin')
     <a href="{{ route('job.index') }}">Jobs</a>
     <a href="{{ route('education.index') }}">Educations</a>
     <a href="{{ route('recruitmenttype.index') }}">Recruitment Types</a>
     <a href="{{ route('certification.index') }}">Certifications</a>
     <a href="{{ route('competence.index') }}">Competencies</a>
     <a href="{{ route('skill.index') }}">Skills</a>
    @elseif (Auth::user()->role == 'client')
     <a href="">Job Apply</a>
    @endif
  @endguest

</div>

<!-- Use any element to open the sidenav -->



<style type="text/css">
  
/* The side navigation menu */
.sidenav {
  height: 100%; /* 100% Full-height */
  width: 0; /* 0 width - change this with JavaScript */
  position: fixed; /* Stay in place */
  z-index: 90000; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 0;
  background-color: #000; /* Black*/
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 60px; /* Place content 60px from the top */
  transition: 0.5s; /* 0.5 second transition effect to slide in the sidenav */
}

/* The navigation menu links */
.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 14px;
  color: #fff;
  display: block;
  transition: 0.3s;
}

/* When you mouse over the navigation links, change their color */
.sidenav a:hover {
  color: #f1f1f1;
}

/* Position and style the close button (top right corner) */
.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

/* Style page content - use this if you want to push the page content to the right when you open the side navigation */
#main {
  transition: margin-left .5s;
  padding: 20px;
}

/* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

</style>

<script type="text/javascript">
/* Set the width of the side navigation to 250px */
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}  
</script>


<!-- search filter -->
@yield('side-bar','')
