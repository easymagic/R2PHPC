<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Models\JbCandidate;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','dob','sex','phone_num','marital_status','address'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    function candidates(){
        return $this->hasMany(JbCandidate::class,'user_id');
    }


    function candidate(){
        return $this->candidates->first();
    }


    function hasUploadedCv(){
        // dd($this->candidate);
       return $this->candidates()->exists(); 
    }






}
