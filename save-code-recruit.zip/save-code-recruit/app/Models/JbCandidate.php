<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\User;


class JbCandidate extends Model{
    //
    protected $table = 'jb_candidates';

    protected $fillable = ['user_id','name','email','phone_number','address','age','gender','marital_status','cover_letter','cv_string'];
    //cv_upload

                // 'name'=>'required',
                // 'email'=>'required',
                // 'phone_number'=>'required',
                // 'address'=>'required',
                // 'date_of_birth'=>'required',
                // 'gender'=>'required',
                // 'marital_status'=>'required',
                // 'cover_letter'=>'required'


    // const UPDATED_AT = null;
    // const CREATED_AT = null;


    function candidateEducations(){
    	return $this->hasMany(JbCandidateEducation::class,'jb_candidate_id');
    }

    function candidateJobs(){
        return $this->hasMany(JbCandidateJob::class,'jb_candidate_id');
    }

    function candidateCertifications(){
       return $this->hasMany(JbCandidateCertification::class,'jb_candidate_id');
    }


    function candidateSkills(){
       return $this->hasMany(JbCandidateSkill::class,'jb_candidate_id');
    }

    function candidateWorkExperience(){
       return $this->hasMany(JbCandidateWorkExperience::class,'jb_candidate_id'); 
    }


    function user(){
        return $this->belongsTo(User::class,'user_id');
    }

    function competencies(){
    	return $this->hasMany(JbCandidateCompetency::class,'jb_candidate_id');
    }


    static function myCv($userID){
      return JbCandidate::where('user_id',$userID)->first();
    }


}
