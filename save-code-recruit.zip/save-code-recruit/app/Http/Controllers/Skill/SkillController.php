<?php

namespace App\Http\Controllers\Skill;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Http\Controllers\Base\BaseController;
use App\Models\JbSkill;

class SkillController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('skill.index',[
             'skills'=>JbSkill::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('skill.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = request()->validate([
              'name'=>'required'
        ]);
        $data['created_by'] = \Auth::user()->id;
        try {

            JbSkill::create($data);
            return $this->logSuccess('skill.index',[],'Skill Added');
        } catch (Exception $e) {
            return $this->logError('skill.create',[],$e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(JbSkill $skill)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(JbSkill $skill)
    {
        //
        return view('skill.edit',[
          'skill'=>$skill
        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JbSkill $skill)
    {
        //
        try {
            $skill->update(request()->validate([
              'name'=>'required' 
            ]));
            return $this->logSuccess('skill.index',[],'Skill updated.');
        } catch (Exception $e) {
            return $this->logError('skill.edit',[],$e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(JbSkill $skill)
    {
        //
        try {
            $skill->delete();
            return $this->logSuccess('skill.index',[],'Skill Removed.');
        } catch (Exception $e) {
            return $this->logError('skill.index',[],$e->getMessage());
        }
    }

}
