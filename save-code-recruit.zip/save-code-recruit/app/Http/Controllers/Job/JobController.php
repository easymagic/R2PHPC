<?php

namespace App\Http\Controllers\Job;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\JbJob;
use App\Models\JbCertification;
use App\Models\JbRecruitmentType;
use App\Models\JbSkill;
use App\Models\JbCompetence;

use App\Http\Controllers\Base\BaseController;
use App\Models\JbJobRecruitementType;
use App\Models\JbJobTag;

// use App\Models\JbJobSkill;
// use App\Models\JbJobCertification;





class JobController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('job.index', ['jobs'=>JbJob::all()]);

    }

    private function getCommonData($config=[]){
    
      $config['jb_recruitment_type_ids'] = JbRecruitmentType::all();
      $config['certifications'] = JbCertification::all();
      $config['skills'] = JbSkill::all();
      $config['competencies'] = JbCompetence::all();
      $config['recruitmentTypes'] = JbJobRecruitementType::all();
      $config['tags'] = JbJobTag::all();
      return $config;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('job.create',$this->getCommonData());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

      try {
        
        // $data = $request->all();
        $data = request()->validate(['role'=>'required',
                                    'description'=>'required',
                                    'jb_recruitment_type_id'=>'required',
                                    'salary_start'=>'required',
                                    'salary_stop'=>'required',
                                    'address'=>'required',
                                    'expiry_date'=>'required',
                                    'years_of_experience'=>'required']);
       
       $data['created_by'] = \Auth::user()->id;

// dd($data);

        JbJob::create($data);          
        
        return $this->logSuccess('job.index',[],'Job added.');
        

        //return redirect()->route('job.index')->with(['message'=>'Job added.']);

      } catch (Exception $e) {

        return $this->logError('job.index',[],$e->getMessage());
        
        //return redirect()->route('job.index')->with(['message'=>$e->getMessage(),'error'=>true]);  

      }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(JbJob $job)
    {
        //
        return view('job.show',['job'=>$job]);

    }

    function showApplicants(JbJob $job){
       return view('job.applicants',[
           'job'=>$job,
           'jobSkills'=>$job->jobSkills,
           'jobCertifications'=>$job->jobCertifications,
           'jobCompetencies'=>$job->jobCompetencies,
           'jobRecruitmentTypes'=>$job->jobRecruitmentTypes,
           'applicants'=>$job->runFilter([]),
           'json'=>request()->all(),
           'tags'=>JbJobTag::all()
       ]);
    }

    function showApplicantsAjax(JbJob $job){
        // dd($job->runFilter([]));
     return view('job_applicant.ajax_partial',[
      'applicants'=>$job->runFilter(request()->all())
     ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(JbJob $job)
    {
        //
        return view('job.edit',$this->getCommonData(['job'=>$job]));
        // [
        //     'job'=>$job,
        //     'jb_recruitment_type_ids'=>\App\Models\JbRecruitmentType::all(),
        //     'certifications'=>JbCertification::all()
        // ]);        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,JbJob $job)
    {
        //
        try {


     $data = request()->validate(['role'=>'required',
                                    'description'=>'required',
                                    'jb_recruitment_type_id'=>'required',
                                    'salary_start'=>'required',
                                    'salary_stop'=>'required',
                                    'address'=>'required',
                                    'expiry_date'=>'required',
                                    'years_of_experience'=>'required']);

            // $data = $request->validate('role','description','jb_recruitment_type_id','salary_start','salary_stop','address','expiry_date','years_of_experience');
            $job->update($data);
            
            return redirect()->route('job.index')->with(['message'=>'Job updated.','error'=>false]);

        } catch (Exception $e) {

            return redirect()->route('job.index')->with(['message'=>$e->getMessage(),'error'=>true]);

            
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(JbJob $job)
    {
        //
        try {
         
          $job->delete();

          return $this->logSuccess('job.index',[],'Job removed');
          
          // return redirect()->route('job.index')->with(['message'=>'Job removed.','error'=>false]);

        } catch (Exception $e) {

           return $this->logError('job.index',[],$e->getMessage()); 
           
           // return redirect()->route('job.index')->with(['message'=>$e->getMessage(),'error'=>true]);
            
        }
        
    }

}
