<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\JbCandidateJob;
use App\Models\JbJob;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(Request $request){
        return view('home',[
          'jobs'=>JbJob::getActiveJobs()
        ]);
    }



    function indexTest(){
      return view('layouts.main');
    }


    function userDashboard(){
       $applicantCount = 0;
       if (Auth::user()->candidate()){
         $applicantCount = Auth::user()->candidate()->candidateJobs->count();
       }
        return view('user.dashboard',[
          'jobCount'=>JbJob::count(),
          'applicantCount'=>JbCandidateJob::count(),
          'jobAppliedCount'=>$applicantCount
        ]);
    }


    function jobDetail(JbJob $job){
      return view('job.detail',[
        'job'=>$job
      ]); 
    }

    function jobApply(JbJob $job,JbCandidateJob $candidateJob,Request $request){
       JbCandidateJob::create([
           'jb_job_id'=>$job->id,
           'jb_candidate_id'=>Auth::user()->candidate()->id,
           'approved'=>0
       ]);
       return redirect('/')->with(['message'=>'You have successfully applied for the role of a ' . $job->role]);
    }


}
