<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DocumentType extends Model
{
	protected $table='document_types';
	protected $fillable=['docname'];

	     //
}
