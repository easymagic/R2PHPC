<?php 
namespace controllers;

use models\phonebook\phone_book;

class Home{

   public $newName = 'Old name...';

   
   function index(\rone\Model $model){
   	// return array('welcomeMessage'=>'Hello RONE.');
    // return '000000';
    // return View('home/index');
    // print_r($model->all('phone_books'));

    // phone_book::create([
    //   'phone_number'=>'new number' . uniqid(),
    //   'owner_id'=>'me' . uniqid(),
    //   'created_at'=>date('Y-m-d h:i:s'),
    //   'updated_at'=>date('Y-m-d h:i:s')
    // ]);

    print_r(phone_book::all('phone_books'));
    return 'Default.';

   }

   function getPhoneBook(phone_book $phone){
     
     print_r($phone);

     // $phone->update([
     //   'phone_number'=>'updated phone new ' . uniqid()
     // ]);

     // $phone->delete();

   }

   function Login(){
    if (isset($_SESSION['voter_session'])){
      Redirect('profile');
    }
    return View('home/login');
   }

   function Profile(){
    if (!isset($_SESSION['voter_session'])){
      Redirect('login');
    }
    $id = $_SESSION['voter_session']['id'];
    // LoadClass($this,'@models/voter/VoterGet');
    
    $obj = new \models\voter\VoterGet;

    return View('home/profile',array(
       'profile'=>$obj->Get_($id)
    ));
   }

   function Mission(){
    return View('home/mission');
   }

   function Vision(){
    return View('home/vision');
   }

   function RegisteredMembers(\models\stats\StatsGetEstimate $stats){
    // LoadClass($this,'@models/stats/StatsGetEstimate');
    // $stats  = new \models\stats\StatsGetEstimate;

    // print_r($stats);
    // print_r($stats->GetEstimate());

    return View('home/registered-members',array(
       'states'=>$stats->GetEstimate()
    ));
   }

   function test(\controllers\Home $home,\controllers\Home $hm,\models\stats\StatsGetEstimate $stats){
    // print_r($stats);
    // echo json_encode($stats);
    echo count($stats->GetEstimate()) . '--||--' . $home->newName . $hm->newName;
   }

   function resolveRouteBinding($value=''){
      $this->newName = 'Value resolved to ' . $value;
   }



}