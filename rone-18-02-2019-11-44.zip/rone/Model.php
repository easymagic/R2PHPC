<?php

namespace rone;

class Model extends \declarations\Db{   

   protected $table = '';

   function __construct(){
    if (empty($this->table)){
	   	$r = get_called_class();
	   	$r = explode('\\', $r);
	   	$this->table = end($r) . 's';
	   	$this->table = strtolower($this->table);
    }
   }

   function getTableName(){
   	return $this->table;
   }

   static function getClassConstructor(){
   	 $cls = get_called_class();
   	 $obj = new $cls;
     return $obj;   	
   }

   
   static function all(){
   	 $obj = self::getClassConstructor();
   	 return $obj->get();
   }

   static function create($data=array()){
     $obj = self::getClassConstructor();
     return $obj->dbCreate($obj->getTableName(),$this->purifyData($data));
   }

   function where($k,$v,$eq='='){
   	 if (!is_numeric($v)){
       $v = "'$v'";
   	 }
     $this->setWhere(" ($k $eq $v) ");
     return $this;
   }

   function whereRaw($str){
    $this->setWhere($str);
    return $this;
   }

   function get(){
   	return $this->dbGet($this->getTableName());
   }

   private function purifyData($data){
     $filteredData = array();
     foreach ($data as $k=>$v){
       if (!is_numeric($k) && isset($this->$k)){
         $filteredData[$k] = $v;
       }
     }
     return $filteredData;
   }

   function update($data=array()){
    $this->where('id',$this->id);
    $this->dbUpdate($this->getTableName(),$this->purifyData($data));
   }

   function delete(){
    $this->where('id',$this->id);
    $this->dbDelete($this->getTableName());
   }

   function resolveRouteBinding($id){

   	 $this->where('id',$id);
   	 $result = $this->get();

   	 if (isset($result[0])){
       return $result[0];
   	 }else{
       return self::getClassConstructor();
   	 }

   }




}
