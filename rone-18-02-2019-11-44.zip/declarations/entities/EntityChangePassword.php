<?php 
namespace declarations\entities;

class EntityChangePassword extends \declarations\entities\EntityUpdate{

   
    function ChangePassword($table,$id,$data=array()){
         // LoadClass($this,'@declarations/entities/EntityCheckPassword');
       
       $obj = new \declarations\entities\EntityCheckPassword;
         
    	 $check = $obj->CheckPassword($data);
       
    	 if (!$check['error']){
           $this->Update($table,$id,array(
            'password'=>$check['data']['password']
           ));
           $check['message'] = 'Password successfully changed.';
    	 }
    	 return $check;

    }

}