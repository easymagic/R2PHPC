<?php 
namespace models\phonebook;

class phone_book extends \rone\Model{


	
}