<?php 
use appx\core\Route;

$guest = ['guest:customer_session,'];
$auth = ['auth:customer_session,customer-login'];

Route::get('/default','controllers\DispatchController@requestDispatch'); //make request dispatch the default index page.

Route::get('/services','controllers\HomeController@services');
Route::get('/faq','controllers\HomeController@faq');
Route::get('/contact-us','controllers\HomeController@contactUs');
Route::post('/contact-us','controllers\HomeController@contactUsAction');

Route::get('/terms-and-conditions','controllers\HomeController@termsAndConditions');

Route::get('/customer-logout','controllers\CustomerController@customerLogout',$auth);
Route::get('/customer-login','controllers\CustomerController@customerLogin',$guest);
Route::post('/customer-login','controllers\CustomerController@customerLoginAction',$guest);

Route::get('/customer-register','controllers\CustomerController@customerRegister',$guest);
Route::post('/customer-register','controllers\CustomerController@customerRegisterAction',$guest);


Route::get('/customer-profile/(customer)','controllers\CustomerController@customerProfile',$auth);
Route::post('/customer-profile/(customer)','controllers\CustomerController@customerProfileAction',$auth);

Route::get('/customer-change-password/(customer)','controllers\CustomerController@customerChangePassword',$auth);
Route::post('/customer-change-password/(customer)','controllers\CustomerController@customerChangePasswordAction',$auth);


Route::get('/customer-transactions/(customer)','controllers\CustomerController@customerTransactions',$auth);

Route::get('/customer-transaction-detail/(customer)/(transaction)','controllers\CustomerController@customerTransactionDetail',$auth);


Route::get('/customer-forgot-password','controllers\CustomerController@customerForgotPassword');
Route::post('/customer-forgot-password','controllers\CustomerController@customerForgotPasswordAction');




/////dispatch playground start
Route::get('/request-dispatch','controllers\DispatchController@requestDispatch');
Route::post('/request-dispatch','controllers\DispatchController@saveDispatchSettings');
Route::get('/request-dispatch/get-dispatchers/(latlng1)/(latlng2)','controllers\DispatchController@getDispatchers');
Route::post('/request-dispatch/get-dispatchers/(latlng1)/(latlng2)','controllers\DispatchController@createDispatchRequest',$auth);
Route::get('/request-dispatch/additional-info/(customer)/(transaction)','controllers\DispatchController@additionalInfo',$auth);
Route::post('/request-dispatch/additional-info/(customer)/(transaction)','controllers\DispatchController@additionalInfoAction',$auth);
Route::get('/request-dispatch/cash-payment-page/(customer)/(transaction)','controllers\DispatchController@cashPaymentPage',$auth);
Route::get('/request-dispatch/card-payment-page/(customer)/(transaction)','controllers\DispatchController@cardPaymentPage',$auth);
Route::get('/request-dispatch/card-payment-feedback-page/(transaction)','controllers\DispatchController@cardPaymentFeedbackQuery',$auth);

//cardPaymentFeedbackQuery
//////dispatch playground stop


//CustomerController

// Route::get('/test/(test)','controllers\Home@test',['auth:user,admin']);
Route::get('/test/(test)','controllers\Home@test');



$guest = ['guest:user_session,user-dashboard'];
$auth = ['auth:user_session,user-login'];

// registerRoute('get','/default','controllers\Home:index');

Route::get('/user-login','controllers\UserController@userLogin',$guest);

Route::get('/user-logout','controllers\UserController@userLogOutAction',$auth);

Route::get('/user-dashboard','controllers\UserController@userDashboard(type=admin)',$auth);

Route::post('/user-login','controllers\UserController@userLoginAction',$guest);

// Route::get('/user-create','controllers\UserController@userCreate',$auth);

// Route::post('/user-create','controllers\UserController@userCreateAction',$auth);

Route::get('/user-change-password/(user)','controllers\UserController@userChangePassword',$auth);

Route::post('/user-change-password/(user)','controllers\UserController@userChangePasswordAction',$auth);

// user/(user)/users
// user/(user)/user/add
// user/(user)/user/(user)/edit
// user/(user)/user/(user)/enable
// user/(user)/user/(user)/disable

Route::get('/user/(admin)/staffs','controllers\StaffController@users');
Route::get('/user/(admin)/staff/add','controllers\StaffController@userAdd');
Route::post('/user/(admin)/staff/add','controllers\StaffController@userAddAction');
Route::get('/user/(admin)/staff/(user)/edit','controllers\StaffController@userEdit');
Route::post('/user/(admin)/staff/(user)/edit','controllers\StaffController@userEditAction');
Route::get('/user/(admin)/staff/(user)/enable','controllers\StaffController@userEnable');
Route::get('/user/(admin)/staff/(user)/disable','controllers\StaffController@userDisable');
Route::get('/user/(admin)/staff/(user)/change-password','controllers\StaffController@userChangePassword');
Route::post('/user/(admin)/staff/(user)/change-password','controllers\StaffController@userChangePasswordAction');


// CompanyStaffController
Route::get('/user/(admin)/companystaffs','controllers\CompanyStaffController@users');
Route::get('/user/(admin)/companystaff/add','controllers\CompanyStaffController@userAdd');
Route::post('/user/(admin)/companystaff/add','controllers\CompanyStaffController@userAddAction');

Route::get('/user/(admin)/companystaff/(user)/edit','controllers\CompanyStaffController@userEdit');

Route::post('/user/(admin)/companystaff/(user)/edit','controllers\CompanyStaffController@userEditAction');

Route::get('/user/(admin)/companystaff/(user)/enable','controllers\CompanyStaffController@userEnable');

Route::get('/user/(admin)/companystaff/(user)/disable','controllers\CompanyStaffController@userDisable');

Route::get('/user/(admin)/companystaff/(user)/change-password','controllers\CompanyStaffController@userChangePassword');

Route::post('/user/(admin)/companystaff/(user)/change-password','controllers\CompanyStaffController@userChangePasswordAction');





Route::get('/user/(admin)/companies','controllers\CompanyController@users');
Route::get('/user/(admin)/company/add','controllers\CompanyController@userAdd');
Route::post('/user/(admin)/company/add','controllers\CompanyController@userAddAction');
Route::get('/user/(admin)/company/(user)/edit','controllers\CompanyController@userEdit');
Route::post('/user/(admin)/company/(user)/edit','controllers\CompanyController@userEditAction');
Route::get('/user/(admin)/company/(user)/enable','controllers\CompanyController@userEnable');
Route::get('/user/(admin)/company/(user)/disable','controllers\CompanyController@userDisable');
Route::get('/user/(admin)/company/(user)/change-password','controllers\CompanyController@userChangePassword');
Route::post('/user/(admin)/company/(user)/change-password','controllers\CompanyController@userChangePasswordAction');







Route::get('/user/(admin)/dispatchers','controllers\DispatcherController@users');

Route::get('/user/(admin)/dispatcher/add','controllers\DispatcherController@userAdd');

Route::post('/user/(admin)/dispatcher/add','controllers\DispatcherController@userAddAction');

Route::get('/user/(admin)/dispatcher/(user)/edit','controllers\DispatcherController@userEdit');

Route::post('/user/(admin)/dispatcher/(user)/edit','controllers\DispatcherController@userEditAction');

Route::get('/user/(admin)/dispatcher/(user)/enable','controllers\DispatcherController@userEnable');

Route::get('/user/(admin)/dispatcher/(user)/disable','controllers\DispatcherController@userDisable');

Route::get('/user/(admin)/dispatcher/(user)/change-password','controllers\DispatcherController@userChangePassword');

Route::post('/user/(admin)/dispatcher/(user)/change-password','controllers\DispatcherController@userChangePasswordAction');

///places/////PlacesController@getPlaces
Route::get('/places/(place)','controllers\PlacesController@getPlaces');



///Transactions/////////////////
Route::get('/user/(admin)/transactions','controllers\TransactionController@index');
Route::get('/user/(admin)/transaction/(transaction)/detail','controllers\TransactionController@detail');
Route::get('/user/(admin)/transaction/(transaction)/update-dispatch-status/(status)','controllers\TransactionController@updateDispatchStatus');

Route::get('/user/(admin)/transaction/(transaction)/update-payment-status/(status)','controllers\TransactionController@updatePaymentStatus');

//users,userAdd,userEdit,userEnable,userDisable,changePassword


// Route::get('/user-edit-profile/(user)','controllers\UserController@userEditProfile',$auth);

// Route::post('/user-edit-profile/(user)','controllers\UserController@userEditProfileAction',$auth);

// Route::get('/user-change-password-other/(user)','controllers\UserController@userChangePasswordOther');

// Route::post('/user-change-password-other/(user)','controllers\UserController@userChangePasswordOtherAction');

// Route::get('/user-enable-account/(user)','controllers\UserController@enableAccountAction');
// Route::get('/user-disable-account/(user)','controllers\UserController@disableAccountAction');


// //enableAccountAction
// Route::get('/users','controllers\UserController@index');

// //oui
// Route::get('/students','controllers\StudentController@index',$auth);
// Route::get('/student-create','controllers\StudentController@studentCreate',$auth);
// Route::post('/student-create','controllers\StudentController@studentCreateAction',$auth);
// Route::get('/student-edit/(student)','controllers\StudentController@studentEdit',$auth);
// Route::post('/student-edit/(student)','controllers\StudentController@studentEditAction',$auth);
// Route::get('/student-test/(student)','controllers\StudentController@studentTestsAdmin',$auth);

// Route::get('/student-assignment/(student)','controllers\StudentController@studentAssignmentsAdmin',$auth);

// //studentAssignmentsAdmin
// //studentTestsAdmin(Student $student)

// Route::get('/student-change-password/(student)','controllers\StudentController@studentChangePassword',$auth);

// Route::post('/student-change-password/(student)','controllers\StudentController@studentChangePasswordAction',$auth);



// Route::get('/subjects/(class)/(term)','controllers\SubjectController@index');
// Route::get('/subject-create/(class)/(term)','controllers\SubjectController@subjectCreate');
// Route::post('/subject-create/(class)/(term)','controllers\SubjectController@subjectCreateAction');
// Route::get('/subject-edit/(subject)','controllers\SubjectController@subjectEdit');
// Route::post('/subject-edit/(subject)','controllers\SubjectController@subjectEditAction');


// ///subject test.
// Route::get('/subject/(subject)/tests','controllers\TestController@index');
// Route::get('/subject/(subject)/test/create','controllers\TestController@create');
// Route::post('/subject/(subject)/test/create','controllers\TestController@createAction');
// Route::get('/subject-test/(test)','controllers\TestController@detail');
// Route::post('/subject-test/(test)','controllers\TestController@editAction');

// Route::get('/subject-test-students/(test)','controllers\StudentTestController@index');
// Route::get('/subject-test-students/(test)/(studentTest)','controllers\StudentTestController@edit');
// Route::post('/subject-test-students/(test)/(studentTest)','controllers\StudentTestController@editAction');


// ///subject assignment.
// Route::get('/subject/(subject)/assignments','controllers\AssignmentController@index');
// Route::get('/subject/(subject)/assignment/create','controllers\AssignmentController@create');
// Route::post('/subject/(subject)/assignment/create','controllers\AssignmentController@createAction');
// Route::get('/subject-assignment/(assignment)','controllers\AssignmentController@detail');
// Route::post('/subject-assignment/(assignment)','controllers\AssignmentController@editAction');

// Route::get('/subject-assignment-students/(assignment)','controllers\StudentAssignmentController@index');
// Route::get('/subject-assignment-students/(assignment)/(studentAssignment)','controllers\StudentAssignmentController@edit');
// Route::post('/subject-assignment-students/(assignment)/(studentAssignment)','controllers\StudentAssignmentController@editAction');




// /////Front-End Section.
// $guest = ['guest:student_session,'];
// $auth = ['auth:student_session,student-user-login'];

// Route::get('/student-user-login','controllers\HomeController@studentLogin',$guest);
// Route::get('/student-user-logout','controllers\HomeController@studentLogout',$auth);
// Route::post('/student-user-login','controllers\HomeController@studentLoginAction',$guest);

// Route::get('/student-user-profile/(student)','controllers\HomeController@studentProfile',$auth);


// Route::post('/student-user-profile/(student)','controllers\HomeController@studentProfileAction',$auth);


// Route::get('/student-user-change-password/(student)','controllers\HomeController@studentChangePassword',$auth);

// Route::post('/student-user-change-password/(student)','controllers\HomeController@studentChangePasswordAction',$auth);


/////test////////
Route::get('/student-user-tests/(student)','controllers\HomeController@studentTests',$auth);

Route::get('/student-user-test/(studentTest)/detail','controllers\HomeController@studentTestDetail',$auth);

Route::post('/student-user-test/(studentTest)/detail','controllers\HomeController@studentTestDetailAction',$auth);


/////assignment////////
Route::get('/student-user-assignments/(student)','controllers\HomeController@studentAssignments',$auth);

Route::get('/student-user-assignment/(studentAssignment)/detail','controllers\HomeController@studentAssignmentDetail',$auth);

Route::post('/student-user-assignment/(studentAssignment)/detail','controllers\HomeController@studentAssignmentDetailAction',$auth);



// studentTests

// Route::post('/student-profile/(student)','controllers\Home@studentLoginAction');

//User
// registerRoute('post','/user/login/action','controllers\UserController:loginAction');
// registerRoute('post','/user/logout/action','controllers\UserController:logoutAction');

// registerRoute('get','/user/login','controllers\UserController:login');
// registerRoute('get','/user','controllers\UserController:index');
// registerRoute('get','/user/(user)/edit','controllers\UserController:edit');
// registerRoute('get','/user/add','controllers\UserController:add');
// registerRoute('get','/user/change/password/(user)','controllers\UserController:changePassword');


// registerRoute('post','/user/change/password/(user)/action','controllers\UserController:changePasswordAction');



// //Subjects
// registerRoute('get','/subject','controllers\SubjectController:index');
// registerRoute('get','/subject/(subject)/edit','controllers\SubjectController:edit');
// registerRoute('get','/subject/add','controllers\SubjectController:add');
// registerRoute('post','/subject','controllers\SubjectController:create');
// registerRoute('post','/subject/(subject)','controllers\SubjectController:update');
// registerRoute('post','/subject/(subject)/delete','controllers\SubjectController:delete');


// //Test
// registerRoute('get','/test','controllers\TestController:index');
// registerRoute('get','/test/add','controllers\TestController:add');
// registerRoute('post','/test','controllers\TestController:create');

// //Assignment
// registerRoute('get','/assignment','controllers\AssignmentController:index');
// registerRoute('get','/assignment/add','controllers\AssignmentController:add');
// registerRoute('post','/assignment','controllers\AssignmentController:create');



// //Student
// registerRoute('get','/student','controllers\StudentController:index');
// registerRoute('get','/student/(student)/edit','controllers\StudentController:edit');
// registerRoute('get','/student/add','controllers\StudentController:add');

// registerRoute('post','/student','controllers\StudentController:store');
// registerRoute('post','/student/(student)','controllers\StudentController:update');
// registerRoute('post','/student/(student)/delete','controllers\StudentController:delete');
// registerRoute('post','/student/change/password/(student)',
// 	          'controllers\StudentController:changePassword');


// //StudentTest
// // registerRoute('post','/create-student-test','controllers\StudentTestController:store');
// registerRoute('get','/student/test','controllers\StudentTestController:index');
// // registerRoute('get','/student/test/(studentTest)/edit',
// // 	          'controllers\AssignmentController:edit');
// // registerRoute('get','/assignment/add','controllers\AssignmentController:add');

// // registerRoute('post','/update-student-test/(studentTest)','controllers\StudentTestController:update');
// registerRoute('post','/student/test/(studentTest)/delete',
// 	          'controllers\StudentController:delete');


// //StudentAssignment
// registerRoute('get','/student/assignment','controllers\StudentAssignmentController:index');
// // registerRoute('get','/assignment/(test)/edit','controllers\AssignmentController:edit');
// // registerRoute('get','/assignment/add','controllers\AssignmentController:add');

// // registerRoute('post','/create-student-test','controllers\StudentTestController:store');
// // registerRoute('post','/update-student-assignment/(studentAssignment)','controllers\StudentAssignmentController:update');
// // registerRoute('post','/delete-student-assignment/(studentAssignment)','controllers\StudentAssignmentController:delete');


// ///student-profile
// registerRoute('get','/student/login',
// 	          'controllers\HomeController:login');
// registerRoute('get','/student/profile/(student)',
// 	          'controllers\HomeController:profile');
// registerRoute('get','/student/test/',
// 	          'controllers\HomeController:test');
// registerRoute('get','/student/assignment/',
// 	          'controllers\HomeController:assignment');
// registerRoute('get','/student/test/(studentTest)/show',
// 	          'controllers\HomeController:testShow');
// registerRoute('get','/student/assignment/(studentAssignment)/show',
// 	          'controllers\HomeController:assignmentSubmit');
// registerRoute('get','/student/change/password/(student)/show',
// 	          'controllers\HomeController:changeStudentPasswordProfile');


// registerRoute('post','/student/login',
// 	          'controllers\HomeController:loginAction');

// registerRoute('post','/student/logout',
// 	         'controllers\HomeController:logout');

// registerRoute('post','/student/update/profile/(student)',
// 	          'controllers\HomeController:profileAction');

// registerRoute('post','/student/change/password/profile/(student)',
// 	          'controllers\HomeController:changeStudentPasswordProfileAction');


// registerRoute('post','/student/submit/test/(studentTest)',
// 	          'controllers\HomeController:submitStudentTest');
// registerRoute('post','/student/submit/assignment/(studentAssignment)',
// 	          'controllers\HomeController:submitStudentAssignment');

// // registerRoute('post','/student-submit-test/(test)','controllers\HomeController:submitStudentTest');

// registerRoute('get','/test2/(test)','controllers\Home:test');

