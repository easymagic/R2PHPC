<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Assignments (<?php echo $subject->name; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Assignments</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-10">
          <div class="box">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  


              <h3 class="box-title">
                <?php echo ucfirst($subject->class); ?>&nbsp;/&nbsp;<?php echo ucfirst($subject->term); ?>
              </h3>

<!-- subjects/nursery-1/second-term               -->

              <a href="<?php echo BASE_URL; ?>subject/<?php echo $subject->id; ?>/assignment/create" class="btn btn-success btn-sm pull-right"> + Add Assignment</a>


              <a style="margin-right: 5px;" href="<?php echo BASE_URL; ?>subjects/<?php echo $subject->class; ?>/<?php echo $subject->term; ?>" class="btn btn-primary btn-sm pull-right">Back</a>


            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Content</th>
                  <th>Date Created</th>
                  <th>Operations</th>
                </tr>

                <?php 
                 foreach ($assignments as $k=>$assignment){
                ?>
                <tr>
                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $assignment->content; ?></td>
                  <td><?php echo $assignment->date_created; ?></td>
                  <td>

                     <a href="<?php echo BASE_URL; ?>subject-assignment/<?php echo $assignment->id; ?>" class="btn btn-primary btn-sm">Detail</a>


                     <a href="<?php echo BASE_URL; ?>subject-assignment-students/<?php echo $assignment->id; ?>" class="btn btn-success btn-sm">Student Assignment Result</a>



                  </td>
                </tr>
                <?php 
                  }
                ?>

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      </div>
<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
