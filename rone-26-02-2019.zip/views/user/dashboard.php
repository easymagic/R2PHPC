<?php 
self::section('content');
?>
<div class="content-wrapper">
  <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
</section>


<section class="content">
<div class="row">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  

<!-- authUserObj     -->
<?php 
 
 $seeStaffs = false;
 $seeCompanies = false;
 $seeCustomers = false;
 $seeDispatchers = false;
 $seeTotalRequests = false;
 $seePendingRequests = false;
 $seeBookedRequests = false;
 $seePickupRequests = false;
 $seeDropOffRequests = false;

 
 if ($authUserObj->role == 'admin'){

   $seeStaffs = true;
   $seeCompanies = true;
   $seeCustomers = true;
   $seeDispatchers = true;
   $seeTotalRequests = true;
   $seePendingRequests = true;
   $seeBookedRequests = true;
   $seePickupRequests = true;
   $seeDropOffRequests = true;

 }else if ($authUserObj->role == 'staff'){

   $seeStaffs = true;
   $seeCompanies = true;
   $seeCustomers = true;
   $seeDispatchers = true;
   $seeTotalRequests = true;
   $seePendingRequests = true;
   $seeBookedRequests = true;
   $seePickupRequests = true;
   $seeDropOffRequests = true;


 }else if ($authUserObj->role == 'company'){

   $seeStaffs = true;
   $seeCustomers = true;
   $seeDispatchers = true;
   $seeTotalRequests = true;
   $seePendingRequests = true;
   $seeBookedRequests = true;
   $seePickupRequests = true;
   $seeDropOffRequests = true;

 }else if ($authUserObj->role == 'company-staff'){

   $seeStaffs = true;
   $seeCustomers = true;
   $seeDispatchers = true;
   $seeTotalRequests = true;
   $seePendingRequests = true;
   $seeBookedRequests = true;
   $seePickupRequests = true;
   $seeDropOffRequests = true;

 }else if ($authUserObj->role == 'dispatcher'){

   $seeStaffs = true;
   $seeCustomers = true;
   $seeDispatchers = true;
   $seeTotalRequests = true;
   $seePendingRequests = true;
   $seeBookedRequests = true;
   $seePickupRequests = true;
   $seeDropOffRequests = true;

 }

?>


        <?php 
         if ($seeStaffs){
        ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Staffs</span>
              <span class="info-box-number"><?php echo number_format($userCount); ?><small></small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <?php 
         }

        if ($seeCompanies){
        ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Companies</span>
              <span class="info-box-number"><?php echo number_format($companyCount); ?><small></small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <?php 
         }


         if ($seeCustomers){
        ?>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Customers</span>
              <span class="info-box-number"><?php echo number_format($customerCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <?php 
         }

         if ($seeDispatchers){
        ?>
         
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Dispatchers</span>
              <span class="info-box-number"><?php echo number_format($dispatcherCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <?php 
         }

         if ($seeTotalRequests){
        ?>

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

<!-- dispatchCount         -->


        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Requests</span>
              <span class="info-box-number"><?php echo number_format($dispatchCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <?php 
         }

         if ($seePendingRequests){

        ?>



        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Pending Requests</span>
              <span class="info-box-number"><?php echo number_format($dispatchPendingCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <?php 
         }

         if ($seeBookedRequests){
        ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Booked Requests</span>
              <span class="info-box-number"><?php echo number_format($dispatchBookedCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <?php 
         }

         if ($seePickupRequests){
        ?>


        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Pickedup Requests</span>
              <span class="info-box-number"><?php echo number_format($dispatchPickedUpCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <?php 
         }

         if ($seeDropOffRequests){
        ?>

        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Droppedoff Requests</span>
              <span class="info-box-number"><?php echo number_format($dispatchDroppedOffCount); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <?php 
         } 
        ?>

      </div>
</section>      
</div>

<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


