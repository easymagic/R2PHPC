<?php 
 self::section('content');
?>

<div class="content-wrapper" style="min-height: 477px;">
	<section class="content-header">
      <h1>
        Transaction Detail
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Transaction Detail</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Transaction Detail</h3>

              <a href="<?php echo $routeBack; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="exampleInputEmail1">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->

                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Transaction - ID : </label>
                  <label>
                    <?php echo $transaction->transaction_id; ?>
                  </label>
                </div>

                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatcher : </label>
                  <label>
                    <?php echo $transaction->user->username; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Company : </label>
                  <label>
                    <?php echo $transaction->company->company_name; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Payment Type : </label>
                  <label>
                    <?php echo $transaction->payment_type; ?>
                  </label>
                </div>



                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Payment Status : </label>
                  <label>
                    <?php echo $transaction->payment_status; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Amount : </label>
                  <label>
                    <?php echo number_format($transaction->dispatch_amount); ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Status : </label>
                  <label>
                    <?php echo $transaction->dispatch_status; ?>
                  </label>
                </div>



                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Requester Address : </label>
                  <label>
                    <?php echo $transaction->requester_address; ?>
                  </label>
                </div>

                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Requester E-mail : </label>
                  <label>
                    <?php echo $transaction->requester_email; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Requester Phone : </label>
                  <label>
                    <?php echo $transaction->requester_phone; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Pickup Address : </label>
                  <label>
                    <?php echo $transaction->pickup_address; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dropoff Address : </label>
                  <label>
                    <?php echo $transaction->dropoff_address; ?>
                  </label>
                </div>

                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Description : </label>
                  <label>
                    <?php echo $transaction->dispatch_description; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Distance : </label>
                  <label>
                    <?php echo $transaction->dispatch_distance; ?>KM
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Period : </label>
                  <label>
                    <?php echo $transaction->dispatch_period; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Dispatch Landmark : </label>
                  <label>
                    <?php echo $transaction->dispatch_landmark; ?>
                  </label>
                </div>


                <div class="form-group">
                  <label style="text-decoration: underline;" for="exampleInputEmail1">Date Created : </label>
                  <label>
                    <?php echo $transaction->date_created; ?>
                  </label>
                </div>





              </div>
              <!-- /.box-body -->

              <div class="box-footer">

                <!-- <button type="submit" class="btn btn-primary">Change Username</button> -->

              </div>
            
          </div>
          <!-- [end] -->

          

</div>

  <!-- /.col -->
</div>
</section>      </div>


<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
