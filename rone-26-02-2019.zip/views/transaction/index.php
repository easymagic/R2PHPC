<?php 
 self::section('content');
?>

<div class="content-wrapper" style="min-height: 477px;">
	<section class="content-header">
      <h1>
        Transactions
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Transactions</li>
      </ol>
</section>

<style type="text/css">
  th{
    text-transform: uppercase;
    background-color: #5d5757;
    color: #fff;
  }


  .pickedup{
    background-color: #e8e82c;
  }

  .droppedoff{
    background-color: #6dea6d;
  }

  .booked{
    background-color: #e4b764;
  }


</style>

<section class="content">
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">List Transactions</h3>

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  
              
              <div>
                
                <div align="right" style="font-size: 22px;">
                 <b>Total :   ₦<?php echo number_format($transactionsSum); ?></b>
                </div>
                
                <div align="right">
                 <b>Count:   <?php echo number_format($transactionsCount); ?></b>
                </div>
                
                
              </div>


              <div>
                <form method="get">
                  <input type="" id="date_start" autocomplete="off" name="filter_date_start" placeholder="Date From">
                  <input type="" id="date_stop" autocomplete="off" name="filter_date_stop" placeholder="Date To">
                  
                  <select style="padding: 2px;" name="filter_payment_type">
                    <option value="">Type</option>
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="pos">POS</option>
                  </select>

                  <select style="padding: 2px;" name="filter_payment_status">
                    <option value="">Payment</option>
                    <option value="success">Success</option>
                    <option value="pending">Pending</option>
                  </select>

                  <select style="padding: 2px;" name="filter_dispatch_status">
                    <option value="">Dispatch</option>
                    <option value="booked">Booked</option>
                    <option value="droppedoff">Dropped Off</option>
                    <option value="pickedup">Picked Up</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                  <button type="submit" style="border: 1px solid orange;background-color: #674848;color: #fff;">FILTER</button>


                </form>
              </div>

            </div>
            <!-- /.box-header -->
            <!-- table-striped -->
            <div class="box-body">
              <table class="table" style="font-size: 12px;">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Tran-ID</th>
                  <th>Amount</th>
                  <th>Logistics</th>
                  <th>Period</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Operations</th>

                </tr>

                <?php 
                  foreach ($transactions as $k=>$transaction){
                ?>
                <tr class="<?php echo $transaction->dispatch_status; ?>">
                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $transaction->transaction_id ?></td>
                  <td>₦<?php echo number_format($transaction->dispatch_amount); ?></td>

                  <!-- logistics start -->
                  <td>
                    <div>
                      <b><u>Pickup: </u></b><?php echo $transaction->pickup_address; ?></div>
                    <div>
                      <b><u>Dropoff: </u></b><?php echo $transaction->dropoff_address; ?></div>                    
                    <div>
                      <b><u>Company: </u></b><?php echo $transaction->company->company_name; ?></div>                    

                  </td>
                  <!-- logistics stop -->
                  
                  <td><?php echo $transaction->dispatch_period; ?></td>
                  
                  <!-- status start -->
                  <td style="text-transform: uppercase;">
                  	<b><?php echo $transaction->dispatch_status; ?>/<?php echo $transaction->payment_type; ?>/<?php echo $transaction->payment_status; ?></b>
                   <!-- <b>booked/cash/pending</b> -->
                  </td>
                  <!-- status stop -->

                  
                  <td><?php echo $transaction->date_created; ?></td>
                  <td>
                  	<?php 
                     if ($transaction->dispatch_status == 'droppedoff'){ //show
                       ?>
                   <div class="alert alert-success">
                   	Package Ddeliverred
                   </div>
                       <?php  
                     }else{
                  	?>
                    <select data-actions="actions" class="form-control">
                      <option value="">Apply Actions</option>
                      <?php 
                        if ($transaction->payment_type == 'cash' || $transaction->payment_type == 'pos'){

                        if ($transaction->payment_status == 'pending'){

                        	if ($transaction->dispatch_status == 'booked'){ //show-pickup

                        		?>
                  <option value="user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/update-dispatch-status/pickedup">Pick Up</option>
                        		<?php 

                        	}else if ($transaction->dispatch_status == 'pickedup'){ //show-manual-payment
                        		?>

                  <option value="user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/update-payment-status/pos">Pay with POS</option>
                  <option value="user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/update-payment-status/cash">Collect Cash</option>
                        		<?php 
                        	}

                         }else if ($transaction->payment_status == 'success'){

                        	  ?>
                  <option value="user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/update-dispatch-status/droppedoff">Drop Off</option>
                        	  <?php 	

                         }	

                        }else if ($transaction->payment_type == 'card'){

                        	 if ($transaction->payment_status == 'success'){

                        	 	if ($transaction->dispatch_status == 'booked'){ //show-pickup
                        	    ?>
                  <option value="user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/update-dispatch-status/pickedup">Pick Up</option>                        	    
                        	    <?php 		

                        	 	}else if ($transaction->dispatch_status == 'pickedup'){//show-droppoff
                        	 	  ?>
                  <option value="user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/update-dispatch-status/droppedoff">Drop Off</option>
                        	 	  <?php 	

                        	 	}

                        	 }

                        }

                      ?>
                      
                     </select>
                     <?php
                      }
                     ?>
                     <div align="center">
                      <a target="_blank" href="<?php echo BASE_URL; ?>user/<?php echo $user->id; ?>/transaction/<?php echo $transaction->id; ?>/detail" style="font-weight: bold;font-size: 17px;">Detail</a>
                     </div>
                  </td>
                </tr>
                <?php 
                  }
                ?>



                
                


                






                
                </tr>


                

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      
<script type="text/javascript">
  (function($){
    $(function(){

      $('[data-actions]').each(function(){
        $(this).on('change',function(){
          // var vl = $(this).data('actions');
          if (confirm('Do you want to confirm "' + $(this).val() + '"')){
           //commit action
           location.href = '<?php echo BASE_URL; ?>' + $(this).val();
           //
          }
        });
      });



      $('[data-slide-toggle]').each(function(){
        var toggle = false; 
        var $btn = $(this).find('button');
        var $description = $(this).find('[data-description]');

        $btn.on('click',function(){
          if (!toggle){
            $description.slideDown();
          }else{
            $description.slideUp();
          }
          toggle = !toggle;
        });


      });



    });
  })(jQuery);
</script></div>


<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
