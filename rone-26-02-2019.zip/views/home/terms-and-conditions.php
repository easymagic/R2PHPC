<?php 
 self::section('content');
?>

<style type="text/css">
  .dc_toggle,.style1{
    margin-bottom: 21px;
  }
</style>
<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__titlefaq blog text-center">
    <div class="container">
      <h2></h2>
      <span class="sep"></span>
      <p></p>
    </div>
  </div>
  <div class="container">
    <div class="row no_padding nothing no-margin">

<!-- new start -->
 <!-- DC [2 Columns] Start -->
<div align="justify">

<h1>General Terms and Conditions</h1>
<h2>Welcome to Turbo Errands!</h2>
<p>This document spells out certain terms and conditions as provided by Turbo Errands, hereafter to be referred to as Turbo Errands. These terms and conditions outline the rules and regulations for the use of Turbo Errands&rsquo;s website/mobile application.</p>
<p>By accessing this website/mobile application, we assume you accept these terms and conditions in full. Do not continue to use Turbo Errands&rsquo;s website/mobile application if you do not accept all of the terms and conditions stated on this page.</p>
<p>The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and any or all Agreements: "Client", &ldquo;You&rdquo; and &ldquo;Your&rdquo; refers to you, the person accessing this website and accepting the Company&rsquo;s terms and conditions. "The Company", &ldquo;Ourselves&rdquo;, &ldquo;We&rdquo;, &ldquo;Our&rdquo; and "Us", refers to our Company. &ldquo;Party&rdquo;, &ldquo;Parties&rdquo;, or &ldquo;Us&rdquo;, refers to both the Client and ourselves, or either the Client or ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner, whether by formal meetings of a fixed duration, or any other means, for the express purpose of meeting the Client&rsquo;s needs in respect of provision of the Company&rsquo;s stated services/products, in accordance with and subject to, prevailing law of the Federal Republic of Nigeria. Any use of the above terminology or other words in the singular, plural, capitalisation and/or he/she or they, are taken as interchangeable and therefore as referring to same.</p>
<h2>Cookies</h2>
<p>We employ the use of cookies. By using Turbo Errands&rsquo;s website/mobile application, you consent to the use of cookies in accordance with Turbo Errands&rsquo;s privacy policy.&nbsp;<br /> <br /> Most of the modern day interactive web sites use cookies to enable us to retrieve user details for each visit. Cookies are used in some areas of our site to enable the functionality of this area and ease of use for those people visiting. Some of our affiliate / advertising partners may also use cookies.</p>
<h2>License</h2>
<p>Unless otherwise stated, Turbo Errands and/or it&rsquo;s licensors own the intellectual property rights for all material on Turbo Errands All intellectual property rights are reserved. You may view and/or print pages from http://www.example.com for your own personal use subject to restrictions set in these terms and conditions.</p>
<p>You must not:</p>
<ul>
<li>Republish material from https://www.turboerrands.com</li>
<li>Sell, rent or sub-license material from https://www.turboerrands.com</li>
<li>Reproduce, duplicate or copy material from https://www.turboerrands.com</li>
<li>Do not redistribute content from https://www.turboerrands.com (unless content is specifically made for redistribution).</li>
</ul>
<h2>User Comments</h2>
<ol>
<li>This Agreement shall begin on the date hereof.</li>
<li>Certain parts of this website offer the opportunity for users to post and exchange opinions, information, material and data ('Comments') in areas of the website. Turbo Errands does not screen, edit, publish or review Comments prior to their appearance on the website and Comments do not reflect the views or opinions of Turbo Errands, its agents or affiliates. Comments reflect the view and opinion of the person who posts such view or opinion. To the extent permitted by applicable laws Turbo Errands shall not be responsible or liable for the Comments or for any loss cost, liability, damages or expenses caused and or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website.</li>
<li>Turbo Errands reserves the right to monitor all Comments and to remove any Comments which it considers in its absolute discretion to be inappropriate, offensive or otherwise in breach of these Terms and Conditions.</li>
<li>You warrant and represent that:</li>
<ol>
<li>You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;</li>
<li>The Comments do not infringe any intellectual property right, including without limitation copyright, patent or trademark, or other proprietary right of any third party;</li>
<li>The Comments do not contain any defamatory, libelous, offensive, indecent or otherwise unlawful material or material which is an invasion of privacy</li>
<li>The Comments will not be used to solicit or promote business or custom or present commercial activities or unlawful activity.</li>
</ol>
<li>You hereby grant to Turbo Errands a non-exclusive royalty-free license to use, reproduce, edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats or media.</li>
</ol>
<h2>Reservation of Rights</h2>
<p>We reserve the right at any time and in its sole discretion to request that you remove all links or any particular link to our Web site. You agree to immediately remove all links to our Web site upon such request. We also reserve the right to amend these terms and conditions and its linking policy at any time. By continuing to link to our Web site, you agree to be bound to and abide by these linking terms and conditions.</p>
<h2>Removal of links from our website</h2>
<p>If you find any link on our website or any linked website objectionable for any reason, you may contact us about this. We will consider requests to remove links but will have no obligation to do so or to respond directly to you. Whilst we endeavor to ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we commit to ensuring that the website remains available or that the material on the website is kept up to date.</p>






<!-- sep   -->



<p><strong>Visiting our Website</strong></p>
<p>TURBO ERRANDS is committed to preserving the privacy of users of our websites. When you visit our web pages, our web servers always temporarily save for connection and set up and security purposes the connection data of the computer connecting to our site, a list of the web pages that you visit within our site, the date and duration of your visit, the IP address of your device, the identification data of the type of browser and operation system used as well as the website through which you linked to our site. Additional personal information such as your name, address, telephone number or e-mail address is not collected unless you provide this data voluntarily, e.g. while completing an online contact form, as part of a registration, survey, competition, fulfillment of contract or an information request.</p>
<p>The web tracking data will be stored for a<strong>&nbsp;</strong>period of 36 months<strong>&nbsp;</strong>and then automatically deleted. Furthermore we are using cookies, tracking-tools and targeting measures. You will find more details hereto below "Use of Web Tracking", "Use of Cookies" and "Use of Google Adwords".</p>
<p>As far as you have enabled geo localization functions in your browser, respectively in your operating system we will use this data to offer you location-based services (e.&nbsp;g. location of the nearest bikers, bike delivery company representatives, warehouses etc.). We will not use this data for any other purpose. If you disable this function your data will be deleted in due time.</p>
<p>For contractual reasons, we also need personal data to provide our services and comply with the obligations arising from contractual agreements concluded with you. This data is used e.&nbsp;g. for performing a (shipment) contract, managing customer data, handling payments and, as the case may be, assessing creditworthiness. Certain shipment data will also be provided to the authorities of the country of transit or destination for customs and tax clearance or for security screening, as required by the laws of such country. The information provided would usually include: shipper name and address, receiver name and address, description of the goods, number of pieces, weight and value of shipment.</p>
<p><strong><a href="https://www.logistics.dhl/global-en/home/footer/global-privacy-notice.html">Online Presence and Website Optimization</a></strong></p>
<p>We use tracking software to determine how many users visit our website and how often. We do not use this software to collect individual personal data or individual IP addresses. The data are used solely in anonymous and summarized form for statistical purposes and for developing the website.</p>
<p><strong><a href="https://www.logistics.dhl/global-en/home/footer/global-privacy-notice.html">Use of Google Adwords Conversion Tracking</a></strong></p>
<p>We use the online advertising program "Google AdWords" and the conversion tracking function of Google AdWords. Google conversion tracking is an analytics service provided by Google Inc.</p>
<p>When you click on an ad delivered by Google, a conversion tracking cookie is placed on your computer. These cookies expire after 30 days, do not contain any personal data and therefore cannot be used to identify you personally. If you visit certain pages on our website and the cookie has not yet expired, we and Google can tell that you clicked on the ad and were directed to that page. Each Google AdWords customer has a different cookie, so it is not possible to track cookies via websites of other AdWords customers. The information collected by means of the conversion cookie is used to compile conversion statistics for AdWords customers who have opted for conversion tracking. Customers can see the total number of users who clicked on their ad and were directed to a page containing a conversion tracking tag. However, they do not receive information that enables them to identify users personally. If you do not want to participate in conversion tracking, you can opt out of this use and prevent cookies from being installed by selecting the appropriate settings on your browser software (deactivation option). You will then not be included in the conversion tracking statistics. Further information and Google's Privacy Policy are available at: <strong><a href="https://policies.google.com/privacy">https://policies.google.com/privacy</a></strong></p>
<p><strong><a href="https://www.logistics.dhl/global-en/home/footer/global-privacy-notice.html">Social-Media-Plug-ins</a></strong></p>
<p>On our website we use social-media-plug-ins (like facebook, google+, twitter etc.) in order to promote our brand, products and services and to get in touch with our customers. Therefore these advertising purposes are regarded as carried out for a legitimate interest. It is the responsibility of the respective social-media provider to be in line with all applicable laws and regulations.</p>
<p>&nbsp;</p>
<p>Privacy Policy</p>
<p>Turbo Errands ("TE", the "Company", "we" or "us") a company registered under the laws of the Federal Republic of Nigeria and having its registered office in Lagos State, is committed to protecting the privacy and security of any identifiable business information you provide us. Business Information includes information that can be linked to a specific individual or entity, such as a postal address, phone number or email address.</p>
<p>This Privacy Policy is in accordance with commonly accepted privacy principles and best practices among global regulatory bodies. This Privacy Policy should be read in conjunction with TE's&nbsp;<u><a href="https://turboerrands.com/terms.php">Terms and Conditions of Use</a></u>.</p>
<p>TE reserves the right to modify or amend this Privacy Policy at any time and for any reason, and such modifications will be effective immediately upon posting the modified Privacy Policy to the TE website. Any material changes to this Privacy Policy will be posted prior to implementation. Questions regarding this policy should be emailed to&nbsp;<u><a href="mailto:privacy@husslenet.com">info@turboerrands.com</a></u>.</p>
<p>Additional terms and conditions relating to all business listings and advertising on the TE Services can be found here.</p>
<p>Please read this Privacy Policy carefully before accessing or using any of the information and services available through TE which include, but are not limited to, the Turboerrands.com, Turboerrands.com website (the "Site"), the TE mobile website, the TE mobile application, the TE SMS service and the TE telephone service (together the "Services" or " TE Services"). The Services may be accessed in several ways, such as via the internet, mobile phones, fixed line phones, Personal Data Assistants (PDAs) and other methods.</p>
<ol>
<li>What Information We Collect</li>
<li>Information we may hold or collect from you includes: your name, telephone numbers, email addresses, business name, addresses, website address, fax number, business description, financial information, various other information you may wish to disclose relating to your business registration, passwords to log into your TE account, reviews from users and financial information. Please note that if you wish to publish your business details on TE, you may experience difficulty or delays with your listing or submission if you chose not to provide us with certain information.</li>
<li>Any information posted in public areas of TE such as online notice boards or business listing information that you have elected to disclose is by its very nature public and not considered to be Personal Information.</li>
<li>Generally, we collect Business Information from you directly and any personal information you may want to share with us. However, in some cases we may obtain your Business Information through our partners, service providers or associates where you have given them permission to do so or from publicly available sources.</li>
</ol>
<p><br /> </p>
<p><strong>Disclaimer</strong></p>
<p>TE shall not be responsible or liable for any personal information contained in information given to us through our sources. If you find any information you consider personal or private which you do not wish to share with the public, kindly notify us immediately or within 30 days of publication of such information on our website. The information shall be withdrawn within two (2) working days from the time of confirmed receipt of report.</p>
<p><br /> </p>
<ol>
<li><strong> Other information we may collect:&nbsp;</strong>When you use the Services, we record and log general information about your visit for statistical purposes including but not limited to web browser details, internet protocol address, telephone numbers, duration of visit and numerous other facts.</li>
</ol>
<p>We may, from time to time, use "cookies" (explained below) to store your preferences, record session information and collect information on how you visit and access our web pages. We collect information on the web pages visited by our customers to help us continue to improve our services.</p>
<ol>
<li><strong> PLEASE NOTE</strong></li>
</ol>
<p>THAT TE CANNOT TAKE RESPONSIBILITY IN ANY WAY FOR THE USE OR MISUSE OF ANY INFORMATION YOU PROVIDE DIRECTLY TO BUSINESSES OR ANY THIRD PARTIES, PERSONAL OR OTHERWISE, OR ANY INFORMATION YOU FIND THROUGH TE. WE ARE ALSO NOT RESPONSIBLE FOR ANY OF THE CONTENT OR PRACTICES OF THESE BUSINESSES OR THIRD PARTIES AND PLEASE CHECK THEIR RELEVANT TERMS AND CONDITIONS AND PRIVACY POLICIES.</p>
<p><br /> </p>
<ol start="2">
<li>How We Use Your Information</li>
<li>TE uses Business Information mainly for the purpose of responding to and fulfilling your requests for the products and services listed by us. Information collected on TE may be used to</li>
</ol>
<p><br /> </p>
<ol>
<li>Respond directly to email or SMS requests by you through the use of the email address or telephone number you provide.</li>
<li>Send newsletters or other emails only where you have opted to receive them.</li>
</ol>
<p><strong>III.&nbsp;</strong>Respond to your questions or suggestions. We will use your Email address and/or telephone number to contact you when you submit a question or suggestion.</p>
<ol>
<li>Help us research and improve our products and services and,</li>
<li>As such we may, from time to time, contact you to let you know about service improvements, products or promotions that may be of interest to you or to ask you for feedback in the event you wish to provide it.</li>
</ol>
<p><br /> </p>
<ol>
<li>We may also use Business Information in an aggregate form for various purposes such as marketing and statistical analysis but will only ever disclose compiled or completely anonymous results.</li>
</ol>
<p><br /> </p>
<ol start="3">
<li>Who We Share Your Information With</li>
<li>As a rule, we do not share with third parties any Information that is not publicly available on TE except in the following circumstances:</li>
</ol>
<p><br /> </p>
<ol>
<li>With other companies who have an agency, partnering or co-branding relationship with TE but agree to protect Information to the same standard as maintained by TE;</li>
<li>From time to time, there may be third parties who provide competitions or other benefits to you through TE and request to collect Information. In the event this happens, we will require those third parties to protect the Information to the same standard as maintained by TE;</li>
</ol>
<p><strong>III.&nbsp;</strong>Where we may be required by law to do so;</p>
<ol>
<li>Where you have a representative such as an auditor or lawyer who is authorized by you to receive such Information; or</li>
<li>Where, in our reasonable opinion, there is threat to our interests (such as customer fraud) or where there is a possibility of harm to others.</li>
</ol>
<p><br /> </p>
<ol>
<li>Where your information appears in a publicly available portion of an advertisement or business listing published with TE or is otherwise publicly available, we may also use that information for publication in other media or with other third parties such as our partners, associates and affiliates but we will take reasonable steps to make sure any such party uses the information for prudent and legitimate purposes.</li>
</ol>
<p><br /> </p>
<ol start="4">
<li>How You Can Control or Access Your Information</li>
<li>We believe that users and customers should have control over the collection and use of their Information. So if you would like to access or inquire about your Information, please contact us at&nbsp;<u><a href="mailto:privacy@husslenet.com">info@turboerrands.com</a></u>. Note that you may be required to provide proof of identity or make statements for security reasons. We also reserve the right to charge a fee for repetitive requests for providing you with access or answering inquiries about your Information.</li>
</ol>
<p><br /> </p>
<ol>
<li>If for some reason we cannot disclose the information then we will let you know (for example, if the information has been deleted from our system).</li>
<li>Please note that certain publicly available information we receive and provide may be from external data sources. Where such publicly available information pertains to you, we will not be able to disclose or edit such information nor will we have access to or be able to provide you with any underlying information that you used in originally supplying information to any external data source.</li>
</ol>
<p><br /> </p>
<ol start="5">
<li>Cookies</li>
<li>Cookies are pieces of information that our web page transfers to your computer's hard disk for record-keeping purposes. Cookies can make the web more useful by storing information about your preferences on a particular site. The use of cookies is an industry standard and many websites use them to provide useful features for you. Cookies do not personally identify you, only your computer.</li>
<li>We may use these cookies to store information, such as user preferences when you visit our website.</li>
<li>Certain third parties who advertise with or supply services to us may also use technology, such as cookies, that collect anonymous information.</li>
<li>You can delete or disable cookies from your computer at any time (see your internet browser's help menu for more information). Please note that if you choose to delete or disable cookies, you may not be able to fully interact with our website or other websites. Also note that deleting a cookie is different from disabling a cookie and, among other things, just because a cookie is deleted does not mean that new cookies will not be created and stored in the future.</li>
</ol>
<p><br /> </p>
<ol start="6">
<li>Advertisers, Business Owners and Users of TE</li>
<li>In addition to this Privacy Policy, Advertisers on TE should read the Privacy section contained in the Terms and Conditions of Use for All Business Listings and Advertisers.</li>
</ol>
<p>&nbsp;</p>



<!-- sep -->




</div>



            <!-- END one_half --> 
      <!-- DC [2 Columns] End -->
      <div class="dc_clear"></div>
      <!-- line break/clear line --> 
      <br />

<!-- new stop -->


      
      
      
    </div>
  </div>
</section>
<div id="snackbar"></div>

<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

