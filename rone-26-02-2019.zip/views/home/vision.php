<?php
 
 $themeDir = BASE_URL . 'theme1/';

 TemplateSectionStart('mainContent');
?>    

	<section style="margin-top: 93px;background: #28a745;">
		<div class="container" >
			<style type="text/css">
				.ireport img{
					border-radius: 6px;
				}

        @media(min-width: 768px){
          .desktop-centre{
            /*margin-left: 25%;*/
          }
        }

			</style>
			 <div class="row ireport">


  <div class="col-md-12" style="margin-top: 17px;background-color: #fff;padding-top: 14px;padding-bottom: 14px;border: 1px solid #777;border-radius: 8px;margin-bottom: 31px;">
    <div>
      <h4 style="color: #777;font-size: 18px;margin-bottom: 11px;text-decoration: underline;">OUR - VISION</h4>
    </div>
    
    <div>
      To Bridge the gap between the Government and the Grassroots.
    </div>





  </div>



  <!-- [end] -->


</div>
		</div>
</section>


<?php 
 
 EndTemplateSection();

 TemplateExtend('frontend/layout');

?>