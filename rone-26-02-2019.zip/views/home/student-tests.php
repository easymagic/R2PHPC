<?php 
 self::section('headerHeight');

 echo 'height: 17%';

 self::endSection();

 

 self::section('userContent');
?>

<div class="col-xs-12" style="padding: 0;">
   

      <div class="form-group">
        <u><b>TESTS</b></u>
      </div>


      <div class="form-group">
        <table class="table">
          <tbody><tr>
              <th>
                #
              </th>
              <th>
                Subject
              </th>
              <th>
                Term
              </th>
              <th>
                Class
              </th>

              <th>
                Date
              </th>

              <th>
                Operations
              </th>
            
          </tr>

          <?php 
            foreach ($studentTests as $k=>$studentTest){
          ?>
          
           <tr>
             <td><?php echo ($k + 1); ?></td>
             <td><?php echo $studentTest->test->subject->name; ?></td>
             <td><?php echo $studentTest->test->subject->term; ?></td>
             <td><?php echo $studentTest->test->subject->class; ?></td>
             <td><?php echo $studentTest->date_created; ?></td>
             <td>
               <a href="<?php echo BASE_URL; ?>student-user-test/<?php echo $studentTest->id; ?>/detail" class="btn btn-sm btn-info">Detail</a>
             </td>
           </tr>
           <?php

            }

           ?>


                  </tbody></table>
      </div>






</div>
<?php

 self::endSection();


 self::section('content');

  self::extend('frontend/layout.student');

 self::endSection();

 self::extend('frontend/layout.main');
?>

