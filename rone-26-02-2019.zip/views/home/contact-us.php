<?php 
 self::section('content');
?>


<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__titlecontact blog text-center">
    <div class="container">
      <h2><font color="#FFFFFF">Contact Us</font></h2>
      <span class="sep"></span>
      <p>We love to hear from you.</p>
    </div>
  </div>
  <section class="recent-posts">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <h3>Send us a message</h3>
          <hr>
          <p>Our friendly customer service representatives are committed to answering all your questions and meeting any need you may have. We would love to hear from you! Please fill out the form below so we may assist you.</p>
          <br />
          <p id="feedback"></p>
          <form role="form" id="contact-form" name="contact-form" method="post" action="" class="contact-form">
            <div class="form-group col-md-6">
              <label class="sr-only" for="exampleInputEmail1">Your Name: *</label>
              <input required type="text" class="form-control" id="name" name="data[name]" placeholder="Your Name: *" required="">
            </div>
            <div class="form-group col-md-6">
              <label class="sr-only" for="exampleInputEmail1">Email: *</label>
              <input required type="email" class="form-control" id="email" name="data[email]" placeholder="Email: *" required="">
            </div>
            <div class="clearfix"></div>
            <div class="form-group">
              <label class="sr-only" for="exampleInputEmail1">Subject:</label>
              <input type="text" class="form-control" id="subject" name="data[subject]" placeholder="Subject:" required="">
            </div>
            <div class="form-group">
              <textarea required class="form-control" id="message" name="data[message]" rows="5" placeholder="Message: *" required=""></textarea>
            </div>
            <input id="submit-button" type="submit" class="btn btn-lg btn-info" value="Submit">
          </form>
        </div>
        <div class="col-md-4">
          <h3>Get in touch</h3>
          <hr>
          <p class="black-text"><span class="orange">Email:</span> info@turboerrands.com</p>
          <p class="black-text"><span class="orange">Telephone:</span>+234 906 000 6408 </p>
           </div>
      </div>
    </div>
  </section>
</section>

<!-- +234 803 655 6778 --><div id="snackbar"></div>


<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

