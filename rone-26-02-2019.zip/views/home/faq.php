<?php 
 self::section('content');
?>

<style type="text/css">
  .dc_toggle,.style1{
    margin-bottom: 21px;
  }
</style>
<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__titlefaq blog text-center">
    <div class="container">
      <h2></h2>
      <span class="sep"></span>
      <p></p>
    </div>
  </div>
  <div class="container">
    <div class="row no_padding nothing no-margin">
      <h2>Questions we're asked all the time</h2>



<!-- new start -->
 <!-- DC [2 Columns] Start -->
      <div class="one_half"> 
        <!-- DC Toggle 1 Start -->
        <div class="dc_toggle_container" style="width:98%;"> + <a href="#" class="toggleCollapse" rel="style1" onClick="return false;">expand all</a><br />
          <br />
          <div class="dc_toggle style1 dc_hide">
            <div><a href="" class="dc_toggle_link">What is your return policy?</a></div>
            <div class="dc_toggle_box">We offer a 30-day money-back guarantee on all our products. If for any reason you are not entirely satisfied with the product, you may return it for a product refund.
              The guarantee is valid from the day the order is made on our website and covers all customers.</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">What payment methods do you accept?</a></div>
            <div class="dc_toggle_box">We accept Credit Card, Paypal, Check, Money Orders, and Bank Wire. We accept credit cards in the form of Mastercard, Visa, American Express and Diners.</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">Do you offer an affiliate program?</a></div>
            <div class="dc_toggle_box">Yes! You can signup to our affiliate program <a href="#">here</a>.</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">When will my order ship?</a></div>
            <div class="dc_toggle_box">Your order will ship within one business day from the date you placed the order. Transit time will vary depending on the shipping method and destination, but generally, your products will arrive in five to seven business days (statewide).</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">What are your hours of operation?</a></div>
            <div class="dc_toggle_box"> General hours are:<br />
              9:00am to 5:30pm, Monday to Friday. </div>
          </div>
        </div>
        <!-- DC Toggle 1 End --> 
        
      </div>
      <!-- END one_half -->
      
      <div class="one_half column-last"> <br />
        <br />
        <!-- DC Toggle 1 Start -->
        <div class="dc_toggle_container" style="width:98%;">
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">Do you ship internationally?</a></div>
            <div class="dc_toggle_box">At this time we only ship within state.</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">What type of security do you use to safeguard personal information?</a></div>
            <div class="dc_toggle_box">We use high-grade 256 bit encryption to secure all transactions.</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">How do I track my package? </a></div>
            <div class="dc_toggle_box">You will receive your tracking number via email as soon as it becomes available. Your tracking number will also be listed in your account. Tracking results should start to appear after the shipping carrier picks up the package from our warehouse.</div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">Where can I find your Terms and Conditions?</a></div>
            <div class="dc_toggle_box">You can view our Terms and Conditions <a href="#">here</a>. </div>
          </div>
          <div class="dc_toggle style1">
            <div><a href="" class="dc_toggle_link">How can I contact you?</a></div>
            <div class="dc_toggle_box"> You can reach us via phone or email. Click <a href="#">here</a> for more information. </div>
          </div>
        </div>
        <!-- DC Toggle 1 End --> 
        
      </div>
      <!-- END one_half --> 
      <!-- DC [2 Columns] End -->
      <div class="dc_clear"></div>
      <!-- line break/clear line --> 
      <br />

<!-- new stop -->


      
      
      
    </div>
  </div>
</section>
<div id="snackbar"></div>

<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

