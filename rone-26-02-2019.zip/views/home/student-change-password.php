<?php 
 self::section('headerHeight');

 echo 'height: 17%';

 self::endSection();

 

 self::section('userContent');
?>

<div class="col-xs-12">
   

      <div class="form-group">
        <u><b>CHANGE PASSWORD</b></u>
      </div>

      <form method="post" action="<?php echo BASE_URL; ?>student-user-change-password/<?php echo $student->id; ?>">


        <div class="form-group">
          <input type="password" name="password" class="form-control" placeholder="Password">
        </div>

        <div class="form-group">
          <input type="password" name="password_confirm" class="form-control" placeholder="Confirm Password">
        </div>


        <div class="form-group">
          <input type="submit" class="form-control btn btn-info" value="CHANGE PASSWORD">
        </div>


        
      </form>



</div>

<?php

 self::endSection();


 self::section('content');

  self::extend('frontend/layout.student');

 self::endSection();

 self::extend('frontend/layout.main');
?>

