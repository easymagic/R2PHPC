<?php 
 self::section('headerHeight');

 echo 'height: 17%';

 self::endSection();

 self::section('content');
?>
    <!--about AREA-->
    <section class="blog-area gray-bg padding-top" id="about">
        <div class="service-top-area padding-top" style="padding-top: 25px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                                              <div class="area-title text-center wow fadeIn" style="margin-bottom: 0;">
                            <h2>Student Login</h2>
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 col-md-offset-4 col-lg-4 col-sm-4 col-xs-12">
                        <div class="service-content wow fadeIn">
                          
                          <form method="post">

                            <div class="form-group">
                              <input type="email" name="email" class="form-control" placeholder="E-mail" />
                            </div>


                            <div class="form-group">
                              <input type="password" name="password" class="form-control" placeholder="Password" />
                            </div>

                            <div class="form-group">
                              <input type="submit" class="form-control btn btn-success" value="LOGIN" />
                            </div>


                            
                          </form>

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--about AREA END-->
<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

