<?php 
 self::section('headerHeight');

 echo 'height: 17%';

 self::endSection();

 

 self::section('userContent');
?>

      <div class="form-group">
        <u><b>PROFILE</b></u>
      </div>

      <form method="post" action="<?php echo BASE_URL; ?>student-user-profile/<?php echo $student->id ?>">

        <div class="form-group">
          <input type="" name="" class="form-control" placeholder="Surname" readonly="" value="<?php echo $student->surname; ?>">
        </div>

        <div class="form-group">
          <input type="" name="" class="form-control" placeholder="First Name" readonly="" value="<?php echo $student->first_name; ?>">
        </div>

        <div class="form-group">
          <input type="" name="" class="form-control" placeholder="Other Names" readonly="" value="<?php echo $student->other_names; ?>">
        </div>



        <div class="form-group">
          <input type="email" name="" class="form-control" placeholder="E-mail" readonly="" value="<?php echo $student->email; ?>">
        </div>

         
         <div class="form-group">
           <b>(Guardian E-mail)</b>
         </div>
        <div class="form-group">
          <input type="" name="" class="form-control" placeholder="Guardian E-mail" readonly="" value="<?php echo $student->guardian_email; ?>">
        </div>

        <div class="form-group">
          <input type="test" name="address" class="form-control" placeholder="Address" value="<?php echo $student->address; ?>">
        </div>

        <div class="form-group">
          <input type="test" name="phone" class="form-control" placeholder="Phone" value="<?php echo $student->phone; ?>">
        </div>


        <div class="form-group">
          <input type="submit" class="form-control btn btn-info" value="SAVE">
        </div>


      </form>

<?php

 self::endSection();


 self::section('content');

  self::extend('frontend/layout.student');

 self::endSection();

 self::extend('frontend/layout.main');
?>

