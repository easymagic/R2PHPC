<?php 
 self::section('content');
?>


<!-- content start -->
<div class="content-wrapper">
  <section class="content-header">
      <h1>
        Update Dispatcher Username
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Update Dispatcher Username</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-6">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Dispatcher Username</h3>

              <a href="<?php echo $routeBack; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="<?php echo $route; ?>">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="exampleInputEmail1">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->

                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <label>
                    &nbsp;(<?php echo $user->email; ?>)
                  </label>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter Username" value="<?php echo $user->username; ?>">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Track-Location-Address</label>
                  <input autocomplete="off" type="text" name="current_address" class="form-control" id="pickup" placeholder="Enter Username" value="<?php echo $user->current_address; ?>" >
                </div>

                <div class="form-group">
                  <div id="predictions-list"></div>
                </div>



                <div class="form-group">
                  <label for="exampleInputEmail1">Track-Location-Coordinates</label>
                </div>


                <div class="form-group">
                  <input readonly="" type="text" name="lat" class="form-control" id="lat" placeholder="Latitude" value="<?php echo $user->lat; ?>">
                </div>

                <div class="form-group">
                  <input readonly="" type="text" name="lng" class="form-control" id="lng" placeholder="Longitude" value="<?php echo $user->lng; ?>">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save Dispatcher Settings</button>
              </div>
            </form>
          </div>

          

</div>

<div class="col-md-6">
  <div id="dvMap" style="height: 300px;"></div>
</div>

  <!-- /.col -->
</div>
</section>
<script type="text/javascript">

  
       window.onload = function () {

        EventBus.Notify('InitMap',{
          mapId:"dvMap"
        });

        // EventBus.Notify('AddMarkers',{
        //   markers:markers
        // });

        // EventBus.Notify('DrawPath',{
        //   markers:markers
        // });

        EventBus.Notify('ZoomMap',{
          zoom:10
        });


        // EventBus.Subscribe('MapGetDistance',function(result){
        //   console.log(result);
        // });

        // EventBus.Notify('MapComputeDistance',{
        //   locationA:{
        //     lat:markers[0]['lat'],
        //     lng:markers[0]['lng']
        //   },
        //   locationB:{
        //     lat:markers[1]['lat'],
        //     lng:markers[1]['lng']
        //   }
        // });


        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:markers[1]['lat'],
        //   lng:markers[1]['lng'],
        //   radius:11
        // });


        EventBus.Notify('MapInitInputs',{
          pickup:'#pickup',
          dropoff:'#dropoff'
        });



        EventBus.Subscribe('MapGottenLatLng',function(result){
          $('#lat').val(result.lat);
          $('#lng').val(result.lng);

            console.log(result);
            result.description = result.data.label;

              EventBus.Notify('AddMarkers',{
                markers:[result]
              });

              EventBus.Notify('ZoomToMarker',{
                position:{
                    lat:result.lat,
                    lng:result.lng
                },
                zoom:14
              });




        });

<?php 
 if (!empty($user->lat) && !empty($user->lng)){
?>
        
          setTimeout(function(){

              EventBus.Notify('AddMarkers',{
                markers:[{"lat":"<?php echo $user->lat; ?>","lng":"<?php echo $user->lng; ?>","description":"<?php echo $user->current_address; ?>"}]              });

              EventBus.Notify('ZoomToMarker',{
                position:{
                    lat:<?php echo $user->lat; ?>,
                    lng:<?php echo $user->lng; ?>                },
                zoom:14
              });

              // EventBus.Notify('ZoomArroundMarkers',{
              //   markers:              // })


          },1000);

<?php 
 }
?>
          


function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition,function(){},{maximumAge:60000, timeout:5000, enableHighAccuracy:true});
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  
  console.log(position);
  
  jQuery('[data-lat]').val(position.coords.latitude);
  jQuery('[data-lng]').val(position.coords.longitude);
  // x.innerHTML = "Latitude: " + position.coords.latitude + 
  // "<br>Longitude: " + position.coords.longitude; 


        EventBus.Notify('AddMarkers',{
          markers:[{
            lat:position.coords.latitude,
            lng:position.coords.longitude,
            description:'You'
          }]
        });






        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:position.coords.latitude,
        //   lng:position.coords.longitude,
        //   radius:11
        // });


}

getLocation();


       };
  
</script></div><!-- content stop -->



<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>