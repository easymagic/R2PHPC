<?php 
 self::section('content');
?>
<div class="content-wrapper" style="min-height: 477px;">
	<section class="content-header">
      <h1>
        Dispatchers
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Dispatchers</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Dispatchers</h3>              

              <a href="<?php echo $route; ?>add" class="btn btn-success btn-sm pull-right"> + Add Dispatcher</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">


    <div>
        <?php self::extend('backend/message'); ?>
        <?php 
          // echo $admin->siteSetting->config_value;
        ?>
    </div>  


              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>E-mail</th>
                  <th>Status</th>
                  <th>Operations</th>
                </tr>

                <?php 
                 foreach ($users as $user){
                ?>
                <tr>
                  <td>1</td>
                  <td><?php echo $user->email; ?></td>
                  <td>
                     <?php echo $user->status; ?>
                  </td>
                  <td>

                     <a href="<?php echo $route . $user->id; ?>/edit" class="btn btn-default btn-sm">Edit</a>

                     <a href="<?php echo $route . $user->id; ?>/change-password" class="btn btn-default btn-sm">Change Password</a>


                     <?php 
                       if ($user->status == 1){
                     ?>

                    <a class="btn btn-sm btn-danger confirm" href="<?php echo $route . $user->id; ?>/disable">Disable Account</a>
                                      
                   
                   <?php 
                    }else{
                   ?>

                    <a class="btn btn-sm btn-success confirm" href="<?php echo $route . $user->id; ?>/enable">Enable Account</a>

                    <?php 
                     }
                    ?>
                                      </td>

                </tr>
                <?php 
                 }
                ?>

                

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      </div>
<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
