<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        <?php echo $studentAssignment->student->surname; ?> , <?php echo $studentAssignment->student->first_name; ?>'s Assignment Response (<?php echo $assignment->subject->name; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Student Response</li>
      </ol>
</section>


<section class="content">
<div class="row">

<div class="col-xs-12">
  <label>
  	Question.
  </label>	
</div>
<div class="col-xs-12">
	<?php echo $studentAssignment->assignment->content; ?>
</div>


<div class="col-md-8">
          
<div class="box box-primary">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  



              <h3 class="box-title">
                <?php echo ucfirst($assignment->class); ?>&nbsp;/&nbsp;<?php echo ucfirst($assignment->term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subject-assignment-students/<?php echo $assignment->id; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form enctype="multipart/form-data" role="form" method="post" action="<?php echo BASE_URL; ?>subject-assignment-students/<?php echo $assignment->id; ?>/<?php echo $studentAssignment->id; ?>">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Student Response</label>
                  <div>
                  	<?php echo $studentAssignment->student_response; ?>
                  </div>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Correction</label>
                  <textarea class="form-control" name="correction" placeholder="Student Correction"><?php echo $studentAssignment->correction; ?></textarea>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Passed</label>
                  <input type="text" class="form-control" name="passed" placeholder="Passed." value="<?php echo $studentAssignment->passed; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Failed</label>
                  <input type="text" class="form-control" name="failed" placeholder="Failed." value="<?php echo $studentAssignment->failed; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Remark</label>
                  <input type="text" class="form-control" name="remark" placeholder="Remark." value="<?php echo $studentAssignment->remark; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Attended To</label>
                  <input type="checkbox" name="attended_to" placeholder="Passed." value="1"  <?php echo ($studentAssignment->attended_to == 1)? 'checked':'' ?> required/>
                  <?php //echo $studentTest->attended_to; ?>
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      </div>

<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
