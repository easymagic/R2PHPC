<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Student Assignments (<?php echo $assignment->subject->name; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Student Assignments</li>
      </ol>
</section>


<section class="content">
<div class="row">

<div class="col-xs-12">
  <label>
  	Question.
  </label>	
</div>
<div class="col-xs-12">
	<?php echo $assignment->content; ?>
</div>


<div class="col-md-10">



          <div class="box">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  


              <h3 class="box-title">
                <?php echo ucfirst($assignment->class); ?>&nbsp;/&nbsp;<?php echo ucfirst($assignment->term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subject/<?php echo $assignment->subject->id; ?>/assignments" class="btn btn-success btn-sm pull-right">Back</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Surname</th>
                  <th>First Name</th>
                  <th>Other Names</th>
                  <th>Answerred</th>
                  <th>Date Created</th>
                  <th>Operations</th>
                </tr>

                <?php 
                 foreach ($studentAssignments as $k=>$studentAssignment){
                ?>
                <tr>
                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $studentAssignment->student->surname; ?></td>
                  <td><?php echo $studentAssignment->student->first_name; ?></td>
                  <td><?php echo $studentAssignment->student->other_names; ?></td>
                  <td><?php echo ($studentAssignment->attended_to == 1)? 'yes' : 'no'; ?></td>
                  <td><?php echo $studentAssignment->date_created; ?></td>
                  <td>
                     <a href="<?php echo BASE_URL; ?>subject-assignment-students/<?php echo $assignment->id; ?>/<?php echo $studentAssignment->id; ?>" class="btn btn-primary btn-sm">Submit Your Corrections</a>

                  </td>
                </tr>
                <?php 
                  }
                ?>
                

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      </div>
<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
