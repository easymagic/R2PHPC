<?php 
 self::section('innerContent');
?>

<h3>Change Account Password</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
          

          <form role="form" id="contact-form" name="contact-form" method="post" action="<?php echo BASE_URL; ?>customer-change-password/<?php echo $customer->id; ?>" class="contact-form">
            
    <div>
        <?php self::extend('backend/message'); ?>
    </div>
            

            <div class="form-group">
              <label class="sr-only" for="exampleInputEmail1">Password:</label>
              <input type="password" class="form-control" id="subject" name="password" placeholder="Password" />
            </div>


            <div class="form-group">
              <label class="sr-only" for="exampleInputEmail1">Confirm Password:</label>
              <input type="password" class="form-control" id="subject" name="password_confirm" placeholder="Password" />
            </div>

            
            <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Change Password" style="font-size: 15px;">


          </form>

<?php 
 self::endSection();

 self::extend('frontend/layout.customer');

 self::extend('frontend/layout.main');
?>

