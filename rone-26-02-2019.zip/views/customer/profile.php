<?php 
 self::section('innerContent');
?>

          <h3>Update Profile</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
<form role="form" id="contact-form" name="contact-form" method="post" class="contact-form" action="<?php echo BASE_URL; ?>customer-profile/<?php echo $customer->id; ?>">
  

    <div>
        <?php self::extend('backend/message'); ?>
    </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php echo $customer->first_name; ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="middle_name" placeholder="Middle Name" value="<?php echo $customer->middle_name; ?>" required="">
  </div>


  <div class="form-group">
    
<input type="text" class="form-control" name="surname" placeholder="Surname" value="<?php echo $customer->surname; ?>" required="">
  </div>


  <div class="form-group">
    <select class="form-control" name="gender" required="" data-value="<?php echo $customer->gender; ?>">
      <option value="">--Select Gender--</option>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>
  </div>


  <div class="form-group">
    
    <input type="email" class="form-control" name="email" placeholder="E-mail" value="<?php echo $customer->email; ?>" readonly="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php echo $customer->phone; ?>" required="">
  </div>

  <div class="form-group">
    
    <input type="text" class="form-control" name="address" placeholder="Address" value="<?php echo $customer->address; ?>" required="">
  </div>

  <input type="hidden" name="data[lat]" data-lat="">
  <input type="hidden" name="data[lng]" data-lng="">
  
  <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Save" />
</form>

<script type="text/javascript">
  (function($){
    $(function(){
      $('[data-value]').each(function(){
        var vl = $(this).data('value');
        $(this).val(vl);
      });

    });
  })(jQuery);
</script>


<?php 
 self::endSection();

 self::extend('frontend/layout.customer');

 self::extend('frontend/layout.main');
?>

