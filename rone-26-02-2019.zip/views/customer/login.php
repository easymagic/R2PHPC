<?php 
 self::section('content');
?>

<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Login</font></p>
    </div>
  </div>
  <section class="recent-posts">
    <div class="container">

      <div class="row" style="padding-top: 0;">
        <div class="col-md-8 col-md-offset-2"> 
          <h3>Customer Login</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
          <form role="form" id="contact-form" name="contact-form" method="post" action="<?php echo BASE_URL; ?>customer-login" class="contact-form">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  
            

            <div class="form-group">
              <label class="sr-only" for="email">E-mail:</label>
              <input type="email" class="form-control" name="email" placeholder="E-mail" value="">
            </div>

            <div class="form-group">
              <label class="sr-only" for="password">Password:</label>
              <input type="password" class="form-control" name="password" placeholder="Password" />
            </div>

            
            <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Log In">


            <a href="<?php echo BASE_URL; ?>customer-forgot-password" style="font-size: 15px;">Forgot Password?</a>&nbsp;|&nbsp;
            <a href="<?php echo BASE_URL; ?>customer-register" style="font-size: 15px;">Register</a>
          </form>
          
          
        </div>
      </div>
    </div>
  </section>
</section>


<div id="snackbar"></div>


<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

