<?php 
 self::section('content');
?>

<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
  <section class="recent-posts">
    <div class="container">

      <div class="row" style="padding-top: 0;">
        <div class="col-md-8 col-md-offset-2"> 
          <h3>Customer Registration</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
<form role="form" id="contact-form" name="contact-form" method="post"class="contact-form" action="<?php echo BASE_URL; ?>customer-register">
  
    <div>
        <?php self::extend('backend/message'); ?>
    </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php self::old('first_name'); ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="middle_name" placeholder="Middle Name"value="<?php self::old('middle_name'); ?>" required="">
  </div>


  <div class="form-group">
    
<input type="text" class="form-control" name="surname" placeholder="Surname" value="<?php self::old('surname'); ?>" required="">
  </div>


  <div class="form-group">
    <select class="form-control" name="gender" required="">
      <option value="">--Select Gender--</option>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>
  </div>


  <div class="form-group">
    
    <input type="email" class="form-control" name="email" placeholder="E-mail" value="<?php self::old('email'); ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php self::old('phone'); ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="password" class="form-control" name="password" placeholder="Password" required="">
  </div>


  <div class="form-group">
    
    <input type="password" class="form-control" name="password_confirm" placeholder="Confirm Password" required="">
  </div>

  <div class="form-group">
    
    <input type="text" class="form-control" name="address" placeholder="Address" value="<?php self::old('address'); ?>" required/>
  </div>


  <div class="form-group">

    <label>
      <a target="_blank" href="<?php echo BASE_URL; ?>terms-and-conditions">Check to agree with the terms and conditions.</a>&nbsp;
      <input type="checkbox" name="agree" value="yes" required="">
    </label>
    
  </div>


  <input type="hidden" name="lat" data-lat />
  <input type="hidden" name="lng" data-lng />

  
  <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Submit">
</form>
          
          
        </div>
      </div>
    </div>
  </section>
</section>


<div id="snackbar"></div>
<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

