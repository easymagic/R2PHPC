<?php 
 self::section('content');
?>

<section class="main__middle__container">
  
<!--   <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
 -->

  <section class="recent-posts">
    <div class="container" style="
    width: 100%;
    padding: 0;
">

      <div class="row" style="padding-top: 0;padding: 0;margin: 0;/* width: 100%; */">
        <div class="col-xs-12" style="
    padding: 0;
"> 


   <div id="dvMap" style="height: 500px;">
   </div>

<!-- style="width: 100%; height: 500px;" -->
         
     <!-- [start] -->


<style type="text/css">
  .predictions-list-item:hover{
    background-color: #329832;
    color: #fff;
  }  


  @media(max-width: 768px){

     .handle-mobile{
      width: 100% !important;
      margin: 0 !important;
      padding: 5px !important;
     }

     .pull-right{
      float: right !important;
     }

     .mob-underline{
      text-decoration: underline !important;
     }

     .mob-request-btn{
      background-color: #ddd;
     }



  }


/*     .handle-mobile{
      width: 80% !important;
     }
*/

</style>


<!-- rgba(0,0,0,0.2) -->
<div class="handle-mobile" style="position: absolute;top: 4%;margin-left: 10%;background-color: rgba(255,255,255,0.5);padding: 11px;width: 80%;overflow-y: scroll;height: 466px;">


<h2 style="margin-top: 0;" align="center">
  DISPATCHERS WITHIN YOUR REQUEST COVERAGE
</h2>

   
 <!-- dispatchers list -->
 <div class="col-xs-12">

 <div class="col-xs-12" style="background-color: #111;padding: 4px;color: #fff;">
   <b class="col-xs-12 col-md-5">
     From Pickup : <?php echo $pickup_address; ?>&nbsp;
   </b>

   <b class="pull-right col-xs-12 col-md-5">
     To DropOff : <?php echo $dropoff_address; ?>&nbsp;
   </b>

 </div>


<?php 
 // print_r($dispatchers);
?>
 
      <!-- start -->
<?php 
 foreach ($dispatchers as $k=>$dispatcher){
?>      
    <div class="col-xs-12" style="padding: 11px;background-color: #fff;">
      <div class="col-xs-1 col-md-1" style="margin: 0;padding: 0">
        <img src="<?php echo BASE_URL . $dispatcher->company->company_logo; ?>" style="max-width: 100%;" />
      </div>
      <div class="col-xs-11 col-md-11" style="padding: 0;margin: 0;">
        
        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          
          <span class="col-xs-12 col-md-4 mob-underline" style="color: #332b2b;text-transform: uppercase;letter-spacing: 2px;">Company:
          </span>

          <span class="col-xs-12 col-md-6">
           <?php echo $dispatcher->company->company_name; ?>  
          </span>


          
        </div>


        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          
          <span class="col-xs-12 col-md-4 mob-underline" style="color: #332b2b;text-transform: uppercase;letter-spacing: 2px;">Dispatch Rate:
          </span>
          
          <span class="col-xs-12 col-md-6">
          <?php 
            if ($dispatcher->company->charging_pattern == 'rate-per-km'){

               echo '#' . number_format($dispatcher->company->charged_rate * $dispatch_distance) . ' @ ' . number_format($dispatcher->company->charged_rate) . ' per KM '; 

            }else if ($dispatcher->company->charging_pattern == 'platform'){
      
                echo '#' . number_format($dispatcher->company->siteSetting->config_value);

            }else if ($dispatcher->company->charging_pattern == 'company-defined-rate'){
                 
                echo '#' . number_format($dispatcher->company->charged_rate); 

            }
          ?>
          </span>

        </div>

        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          
          <span class="col-xs-12 col-md-4 mob-underline" style="color: #332b2b;text-transform: uppercase;letter-spacing: 2px;">Dispatcher:</span> 

          <span class="col-xs-12 col-md-6">
            <?php echo $dispatcher->username; ?>
          </span>

        </div>

        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          
          <span class="col-xs-12 col-md-4 mob-underline" style="color: #332b2b;text-transform: uppercase;letter-spacing: 2px;">Distance:</span> 

          <span class="col-xs-12 col-md-6">
          <?php echo $dispatch_distance; ?> KM
          </span>

        </div>

        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          
          <span class="col-xs-12 col-md-4 mob-underline" style="color: #332b2b;text-transform: uppercase;letter-spacing: 2px;">Charging Pattern:</span> 

          <span class="col-md-8 col-xs-12">
           <?php echo $dispatcher->company->charging_pattern; ?>



<span class="pull-right">
<!-- https://www.turboerrands.com/Dispatch/CreateDispatch/20/19   -->


<a href="" class="pull-right btn btn-sm btn-default mob-request-btn" style="color: #000;font-size: 14px;">Request Dispatcher</a>          

          

</span>

          </span>




        </div>

        <div class="col-xs-12" style="border-top: 1px solid #332b2b;padding-top: 9px;margin-top: 9px;">
        </div>



      </div>
    </div>
    <?php 
      }
    ?>
    <!-- stop -->

   </div>  




</div>

<!-- clear fix -->
<div style="clear: both;">&nbsp;</div>
<!-- clear fix -->



        

        <!-- [end]   -->
          
        </div>
      </div>
    </div>
  </section>
</section>


<script type="text/javascript">
  
       window.onload = function () {

        EventBus.Notify('InitMap',{
          mapId:"dvMap"
        });

        // EventBus.Notify('AddMarkers',{
        //   markers:markers
        // });

        // EventBus.Notify('DrawPath',{
        //   markers:markers
        // });

        EventBus.Notify('ZoomMap',{
          zoom:10
        });


        // EventBus.Subscribe('MapGetDistance',function(result){
        //   console.log(result);
        // });

        // EventBus.Notify('MapComputeDistance',{
        //   locationA:{
        //     lat:markers[0]['lat'],
        //     lng:markers[0]['lng']
        //   },
        //   locationB:{
        //     lat:markers[1]['lat'],
        //     lng:markers[1]['lng']
        //   }
        // });


        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:markers[1]['lat'],
        //   lng:markers[1]['lng'],
        //   radius:11
        // });

          var markers_ = [<?php echo json_encode($marker1); ?>,<?php echo json_encode($marker2); ?>];

          EventBus.Notify('AddMarkers',{
            markers:markers_
          });
          EventBus.Notify('DrawPath',{
            markers:markers_
          });
  
          EventBus.Notify('ZoomArroundMarkers',{});    



        // EventBus.Notify('MapInitInputs',{
        //   pickup:'#pickup',
        //   dropoff:'#dropoff'
        // });


       };


</script><div id="snackbar"></div>


<?php 
 self::endSection();

 self::extend('frontend/layout.main');
?>

