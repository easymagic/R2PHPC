<?php 
 // use appx\core\Request;

 self::section('content');
?>
<section class="recent-posts">
    <div class="container">

      <div class="row" style="padding-top: 0;padding-left: 11px;padding-top: 22px;">

        <div class="col-md-12" style="
    padding: 0;
"> 

<div class="col-md-3 col-xs-12" style="
    padding: 0;
">
  <ul class="list-group">
  
    <li class="list-group-item">
       <a href="<?php echo BASE_URL; ?>customer-profile/<?php echo $customer_session->id; ?>">Profile</a>
    </li>

    <li class="list-group-item">
       <a href="<?php echo BASE_URL; ?>request-dispatch" style="font-weight: bold;">Request Dispatch</a>
    </li>

    <li class="list-group-item">
       <a href="<?php echo BASE_URL; ?>customer-transactions/<?php echo $customer_session->id; ?>">Transactions</a>
    </li>

    <li class="list-group-item">
       <a href="<?php echo BASE_URL; ?>customer-change-password/<?php echo $customer_session->id; ?>">Change Password</a>
    </li>

  </ul>
</div>

<div class="col-md-9 col-xs-12">
<?php 
 self::yield('innerContent','Welcome Customer');
?>
</div>

          
          
        </div>
      </div>
    </div>
  </section><div id="snackbar"></div>
  <?php 
   self::endSection();
  ?>