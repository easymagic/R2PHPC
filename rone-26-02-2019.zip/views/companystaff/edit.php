<?php 
 self::section('content');
?>
<div class="content-wrapper" style="min-height: 477px;">
	<section class="content-header">
      <h1>
        Update Company Staff Username
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Update Company Staff Username</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Company Staff Username</h3>

              <a href="<?php echo $routeBack; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="<?php echo $route; ?>">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="exampleInputEmail1">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->

                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <label>
                    &nbsp;(<?php echo $user->email ?>)
                  </label>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter Username" value="<?php echo $user->username ?>">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Change Username</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      </div><?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>
