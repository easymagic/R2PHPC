<?php

namespace controllers;

use models\User;
use models\DispatchRequest;
use models\DispatchLog;
use appx\core\Request;

class TransactionController extends UserTemplateController{

   

   function index(User $admin){
   	 $filters = array();
     return $this->view('transaction/index',[
       'transactions'=>$admin->transactions($filters),
       'user'=>$admin,
       'transactionsCount'=>$admin->transactionsCount($filters),
       'transactionsSum'=>$admin->transactionsSum($filters)
     ]);
   }

   function detail(User $admin,DispatchRequest $transaction){
     return $this->view('transaction/detail',[
       'user'=>$admin,
       'transaction'=>$transaction,
       'routeBack'=>BASE_URL . 'user/' . $admin->id . '/transactions'
     ]);
   }

   function updateDispatchStatus(User $admin,DispatchRequest $transaction,$status){
     $this->setResponse($transaction->updateDispatchStatus($status));
     DispatchLog::createLog([
       'dispatch_id'=>$transaction->id,
       'dispatch_status'=>'dispatch - ' . $status,
       'user_id'=>$transaction->user_id,
       'lat'=>$transaction->user->lat,
       'lng'=>$transaction->user->lng,
       'address'=>$transaction->user->current_address,
       'status'=>'pending',
       'seen_by'=>'pending',
       'created_by'=>$admin->id
     ]);
     redirect('user/' . $admin->id . '/transactions');
   }

   function updatePaymentStatus(User $admin,DispatchRequest $transaction,$status){
     $this->setResponse($transaction->updatePaymentStatus($status));
     DispatchLog::createLog([
       'dispatch_id'=>$transaction->id,
       'dispatch_status'=>'payment - ' . $status,
       'user_id'=>$transaction->user_id,
       'lat'=>$transaction->user->lat,
       'lng'=>$transaction->user->lng,
       'address'=>$transaction->user->current_address,
       'status'=>'pending',
       'seen_by'=>'pending',
       'created_by'=>$admin->id
     ]);
     redirect('user/' . $admin->id . '/transactions');
   }







}