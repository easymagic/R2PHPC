<?php 

namespace controllers;

use models\Customer;
use models\User;
use models\DispatchRequest;

use appx\core\Request;


class CustomerController extends BaseController{


     // function index(){ //default
      
     //  return 'Welcome Home...';
      
     // }

	function customerRegister(){
     return $this->view('customer/register');
	}

	function customerRegisterAction(Customer $customer){
      $data = Request::all();
      $this->setResponse($customer->register([
         'first_name'=>$this->getFormData($data,'first_name'),
         'middle_name'=>$this->getFormData($data,'middle_name'),
         'surname'=>$this->getFormData($data,'surname'),
         'gender'=>$this->getFormData($data,'gender'),
         'email'=>$this->getFormData($data,'email'),
         'phone'=>$this->getFormData($data,'phone'),
         'password'=>$this->getFormData($data,'password'),
         'password_confirm'=>$this->getFormData($data,'password_confirm'),
         'address'=>$this->getFormData($data,'address'),
         'lat'=>$this->getFormData($data,'lat'),
         'lng'=>$this->getFormData($data,'lng'),
         'status'=>0
      ],$cb='sendVerification',$successMessage='Your account has been created successfully, please check your e-mail for the verification link sent.'));

      redirect('customer-login');
        
	}


	function customerForgotPassword(){
     return $this->view('customer/forgot-password');
	}

	function customerForgotPasswordAction(){
		
	}

	// function profile(Customer $customer){

	// }

     function customerLogin(){ //customer-login
       return $this->view('customer/login');
     }

     function customerLoginAction(Customer $customer){ 
       
       $this->entityLoginAction($entity=$customer,
       	                        $sessionName='customer_session',
       	                        $welcomeMessage='Welcome user.(:',
       	                        $cb='redirectToProfile',
       	                        $redir='customer-login');    

     }

     function redirectToProfile(){
     	redirect('customer-profile/' . Request::sessionGet('customer_session')->id);
     }

     function customerLogout(Customer $customer){ //student-user-logout
        Request::sessionUnSet('customer_session');
        $customer->setSuccess('You just logged out.');
        $this->setResponse($customer->getMessage());
        redirect('customer-login');
     }

     function customerProfile(Customer $customer){ //student-user-profile
       return $this->view('customer/profile',[
        'customer'=>$customer
       ]);
     }

     function customerProfileAction(Customer $customer){
          // 'surname'=>$data['surname'],
          // 'first_name'=>$data['first_name'],
          // 'other_names'=>$data['other_names'],
          // 'other_names'=>$data['other_names'],

        $data = Request::all();
        $customer->update([
         'first_name'=>$this->getFormData($data,'first_name'),
         'middle_name'=>$this->getFormData($data,'middle_name'),
         'surname'=>$this->getFormData($data,'surname'),
         'gender'=>$this->getFormData($data,'gender'),
         // 'email'=>$this->getFormData($data,'email'),
         'phone'=>$this->getFormData($data,'phone'),
         // 'password'=>$this->getFormData($data,'password'),
         // 'password_confirm'=>$this->getFormData($data,'password_confirm'),
         'address'=>$this->getFormData($data,'address'),
         'lat'=>$this->getFormData($data,'lat'),
         'lng'=>$this->getFormData($data,'lng'),
        ]);
        $customer->setSuccess('Profile saved');
        $this->setResponse($customer->getMessage());
        redirect('customer-profile/' . $customer->id);
     }

     function customerChangePassword(Customer $customer){ //customer-change-password/(student)
       return $this->view('customer/change-password',[
        'customer'=>$customer
       ]);
     }

     function customerChangePasswordAction(Customer $customer){
        $data = Request::all();
        $this->setResponse($customer->changePassword([
         'password'=>$data['password'],
         'password_confirm'=>$data['password_confirm']
        ]));

        redirect('customer-change-password/' . $customer->id);
     }

     function customerTransactions(Customer $customer){
        $filters = array();  
     	return $this->view('customer/transactions',[
         'transactions'=>$customer->transactions($filters),
         'transactionsCount'=>$customer->transactionsCount($filters),
         'transactionsSum'=>$customer->transactionsSum($filters),
         'customer'=>$customer
     	]);

     }

     function customerTransactionDetail(Customer $customer,DispatchRequest $transaction){
       return $this->view('customer/transaction-detail',[
         'transaction'=>$transaction,
         'customer'=>$customer
       ]);
     }




}