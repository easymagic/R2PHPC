<?php

namespace controllers;

use models\User;
use appx\core\Request;

class StaffController extends UserTemplateController{

   
    protected $routeSingular = 'staff';
    protected $routePlural = 'staffs';

    protected $templatePath = 'staff';

    protected $filters = array('role'=>'staff');
    protected $entity = 'Staff';

    /**
      users,userAdd,userEdit,userEnable,userDisable,changePassword

    **/





}