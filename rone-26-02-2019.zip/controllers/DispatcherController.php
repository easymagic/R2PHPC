<?php

namespace controllers;

use models\User;
use appx\core\Request;

class DispatcherController extends UserTemplateController{

   
    protected $routeSingular = 'dispatcher';
    protected $routePlural = 'dispatchers';

    protected $templatePath = 'dispatcher';

    protected $filters = array('role'=>'dispatcher');
    protected $entity = 'Dispatcher';

    /**
      users,userAdd,userEdit,userEnable,userDisable,changePassword

    **/





}