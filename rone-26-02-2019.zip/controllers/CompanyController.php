<?php

namespace controllers;

use models\User;
use appx\core\Request;

class CompanyController extends UserTemplateController{

   
    protected $routeSingular = 'company';
    protected $routePlural = 'companies';

    protected $templatePath = 'company';

    protected $filters = array('role'=>'company');
    protected $entity = 'Company';

    /**
      users,userAdd,userEdit,userEnable,userDisable,changePassword

    **/





}