<?php 

namespace controllers;


use appx\core\Request;
use models\DispatchRequest;
use models\Testimonial;

class BaseController{

   protected $authUser = null;
  
    protected function getFormData($data,$key){
      if (isset($data[$key])){
        return $data[$key];
      }else{
        return '';
      }
    }

  
   function view($template,$data=[]){
     
     $auth = Request::sessionGet('user_session');
     if (!empty($auth)){
       $authID = Request::sessionGet('user_session')->id;
       $authUserObj = (new \models\User)->find($authID);
       $this->authUser = $authUserObj;
       //staffs
       $data['userCount'] = count($authUserObj->staffs); // (new \models\User)->getCount();
       $data['customerCount'] = (new \models\Customer)->getCount();

       $data['dispatcherCount'] = count($authUserObj->dispatchers);
       $data['dispatchPendingCount'] = $authUserObj->dispatchRequestsCount(['dispatchStatus'=>'pending']);
       $data['dispatchBookedCount'] = $authUserObj->dispatchRequestsCount(['dispatchStatus'=>'booked']);
       $data['dispatchPickedUpCount'] = $authUserObj->dispatchRequestsCount(['dispatchStatus'=>'pickedup']);
       $data['dispatchDroppedOffCount'] = $authUserObj->dispatchRequestsCount(['dispatchStatus'=>'droppedoff']);
       $data['companyCount'] = count($authUserObj->companies);
       $data['dispatchCount'] = $authUserObj->dispatchRequestsCount;

       $data['username'] = $authUserObj->username;
       $data['user_id'] = $authUserObj->id;
       $data['parent_id'] = $authUserObj->autoParentId;
       $data['authUserObj'] = $authUserObj;
       $data['successFullDeliveries'] = DispatchRequest::getSuccessFullDeliveries();

       if (Request::sessionHas('customer_session')){
         $data['customerIsLogged'] = true;
         $data['customer_session'] = Request::sessionGet('customer_session');
       }else{
         $data['customerIsLogged'] = false;
       }

       $data['testimonials'] = (new Testimonial)->get();

     }

     // $data['customerCount'] = (new \models\Customer)->getCount();
     // $data['studentCount'] = (new \models\Student)->getCount();
     // $data['subjectCount'] = (new \models\Subject)->getCount();
     // $data['assignmentCount'] = (new \models\Assignment)->getCount();
     // $data['testCount'] = (new \models\Test)->getCount();
     // $data['classes'] = \models\ClassLoad::getClasses();

     if (!\appx\core\Request::sessionNotSet('_flash')){
       $sessionData = \appx\core\Request::sessionGet('_flash');
       $data['message'] = $sessionData['message'];
       $data['error'] = $sessionData['error'];

       \appx\core\Request::sessionUnset('_flash');
     }

   	 return view($template,$data);

   }
   
   function initResponse(){
   	 if (\appx\core\Request::sessionNotSet('_flash')){
        \appx\core\Request::sessionSet('_flash',array());
   	 }
   }

   function setResponse($response){
     $this->initResponse();
     \appx\core\Request::sessionSet('_flash',$response);
   }





    function entityLoginAction($entity,$sessionName='user_session',$welcomeMessage='Welcome admin.(:',$cb=null,$redir='user-login'){
       $data = Request::all();  
       $check = $entity->login($data['email'],$data['password']);
       if (!empty($check)){
        if (isset($check->status)){
           if ($check->status == 1){

               $r = Request::sessionSet($sessionName,$check);
               $entity->setSuccess('Welcome admin.(:');
               //run automated promotions here.
               if (!is_null($cb)){
                 $this->$cb();
               }
             // \models\AutomatedPromotion::runPromotions();
             // die();
           }else if ($check->status == 0){
             $entity->setError('Please verify your account from the link sent to your e-mail.');
           }  

        }else{

           $r = Request::sessionSet($sessionName,$check);
           $entity->setSuccess('Welcome admin.(:');
           //run automated promotions here.
           if (!is_null($cb)){
             $this->$cb();
           }
         // \models\AutomatedPromotion::runPromotions();
         // die();

        }
       }else{
         $entity->setError('Invalid Login!');   
       }
       $this->setResponse($entity->getMessage());
       redirect($redir);
    }


}