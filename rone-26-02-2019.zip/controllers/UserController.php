<?php

namespace controllers;

use models\User;
use appx\core\Request;

class UserController extends \controllers\BaseController{

   
    function index(){
    	return $this->view('user/index',[
           'users'=>User::all()
    	]);
    }

    function userLogin(){
    	return $this->view('user/login');
    }


    function userLoginAction(User $user){

       $this->entityLoginAction($entity=$user,$sessionName='user_session',$welcomeMessage='Welcome admin.(:',$cb=null,$redir='user-login');
    }

    function userLogOutAction(User $user){
    	Request::sessionUnSet('user_session');
    	$user->setSuccess('You just logged out.):');
    	$this->setResponse($user->getMessage());
    	redirect('user-login');
    }

    function userDashboard($options=array()){
      // print_r($options);
      // print_r( User::allUsersWithinRadius('6.432110900000001','3.5216210999999475','0.0002') );
    	return $this->view('user/dashboard');
    }

    function userChangePassword(User $user){
      return $this->view('user/change-password',['user'=>$user]);
    }

    function userChangePasswordAction(User $user){
       $data = Request::all();	
       $result = $user->changePassword([
        'password'=>$data['password'],
        'password_confirm'=>$data['password_confirm']
       ]);
       $this->setResponse($result);
       redirect('users');
    }





   function users(User $user,$options=array()){
     
     return $this->view('user/users',[
      'users'=>$user->users([
         'role'=>'staff'
      ])
     ]);

   }








    function enableAccountAction(User $user){

    	 $this->setResponse($user->enableAccount());

    	 redirect('users');

    }


    function disableAccountAction(User $user){

    	 $this->setResponse($user->disableAccount());

    	 redirect('users');

    }

    function userCreate(){
      return $this->view('user/create');
    }

    function userCreateAction(User $user){
       $data = Request::all();
       $data = [
         'password'=>$data['password'],
         'password_confirm'=>$data['password_confirm'],
         'email'=>$data['email'],
         'username'=>$data['username'],
         'role'=>'staff'
       ];	
       $this->setResponse($user->register($data,$cb=null,$successMessage='Staff account created successfully.'));
       redirect('users');
    }


    function userEditProfile(User $user){

    	 return $this->view('user/edit',[
          'user'=>$user
    	 ]);

    }

    function userEditProfileAction(User $user){
        $data = Request::all(); 
    	$user->update([
          'username'=>$data['username']
    	]);
    	$user->setSuccess('Profile saved.');
    	$this->setResponse($user->getMessage());
        redirect('users');
    }




}