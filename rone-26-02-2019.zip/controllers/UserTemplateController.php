<?php

namespace controllers;

use models\User;
use appx\core\Request;

class UserTemplateController extends \controllers\BaseController{
    
    protected $routeSingular = 'user';
    protected $routePlural = 'users';

    protected $templatePath = 'user';

    protected $filters = array();
    protected $entity = 'User';
    
    private function customView($view,$data){
      return $this->view($this->templatePath . '/' . $view,$data);
    }
   
    function users(User $admin){
      return $this->customView('index',[
         'admin'=>$admin, 
         'users'=>$admin->users($this->filters),
         'route'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routeSingular . '/',
         'routeBack'=>BASE_URL . 'user/' . $admin->company->id . '/' . $this->routeSingular . '/' . $admin->id . '/edit'         
      ]);
    }

    function userAdd(User $admin){
     return $this->customView('add',[
      'user'=>$admin,
      'route'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routeSingular . '/add',
      'routeBack'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routePlural

     ]);
    }


    function userAddAction(User $admin){
      $data = Request::all();

      $this->setResponse($admin->register([
         'parent_id'=>$admin->id,
         'email'=>$this->getFormData($data,'email'),
         'password'=>$this->getFormData($data,'password'),
         'password_confirm'=>$this->getFormData($data,'password_confirm'),
         'gender'=>$this->getFormData($data,'gender'),
         'company_name'=>$this->getFormData($data,'company_name'),
         'username'=>$this->getFormData($data,'username'),
         'role'=>$this->filters['role'],
         'charging_pattern'=>$this->getFormData($data,'charging_pattern'),
         'charged_rate'=>$this->getFormData($data,'charged_rate'),
         'company_defined_rate'=>$this->getFormData($data,'company_defined_rate'),
         'dispatch_availability'=>'free'
      ],$cb='uploadLogo',$successMessage='Account created successfully.'));
      
      redirect('user/' . $admin->id . '/' . $this->routePlural);

    }


    function userEdit(User $admin,User $user){

     return $this->customView('edit',[
      'user'=>$user,
        'route'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routeSingular . '/' . $user->id . '/edit',
        'routeBack'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routePlural     
     ]);

    }

    function userEditAction(User $admin,User $user){
      $data = Request::all();
      
      $user->update([
         'gender'=>$this->getFormData($data,'gender'),
         'company_name'=>$this->getFormData($data,'company_name'),
         'username'=>$this->getFormData($data,'username'),
         'charging_pattern'=>$this->getFormData($data,'charging_pattern'),
         'charged_rate'=>$this->getFormData($data,'charged_rate'),
         'company_defined_rate'=>$this->getFormData($data,'company_defined_rate'),
         // 'dispatch_availability'=>$this->getFormData($data,'dispatch_availability'),
         'lat'=>$this->getFormData($data,'lat'),
         'lng'=>$this->getFormData($data,'lng'),
         'current_address'=>$this->getFormData($data,'current_address')
      ]);

      $user->uploadLogo();
      $user->setSuccess($this->entity . ' Saved successfully.');
      $this->setResponse($user->getMessage());

      redirect('user/' . $admin->id . '/' . $this->routePlural);
    }

    function userEnable(User $admin,User $user){
       
       $this->setResponse($user->enableAccount());
       
       redirect('user/' . $admin->id . '/' . $this->routePlural);
    }

    function userDisable(User $admin,User $user){

       $this->setResponse($user->disableAccount());

       // user/(user)/staff/(user)/change-password
       
       redirect('user/' . $admin->id . '/' . $this->routePlural);

    }

    function userChangePassword(User $admin,User $user){
       return $this->customView('change-password',[
        'user'=>$user,
        'route'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routeSingular . '/' . $user->id . '/change-password',
        'routeBack'=>BASE_URL . 'user/' . $admin->id . '/' . $this->routePlural     
       ]);
    }

    function userChangePasswordAction(User $admin,User $user){
      $data = Request::all();
      $this->setResponse($user->changePassword([
        'password'=>$data['password'],
        'password_confirm'=>$data['password_confirm']
      ]));
      redirect('user/' . $admin->id . '/' . $this->routePlural);
    }




}