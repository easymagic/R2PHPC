<?php 

namespace controllers;

use models\Student;
use models\StudentTest;
use models\StudentAssignment;
use models\User;

use appx\core\Request;


class HomeController extends BaseController{


     function index(){ //default
      
      return 'Welcome Home...';
      
     }


     function services(){
       return $this->view('home/services');
     }

     function faq(){
       return $this->view('home/faq');
     }

     function contactUs(){
       return $this->view('home/contact-us');
     }

     function contactUsAction(){
      
      redirect('contact-us');
     }

     function termsAndConditions(){
      return $this->view('home/terms-and-conditions');
     }




}