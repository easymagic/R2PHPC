<?php

namespace controllers;

use models\User;
use appx\core\Request;

class CompanyStaffController extends UserTemplateController{

   
    protected $routeSingular = 'companystaff';
    protected $routePlural = 'companystaffs';

    protected $templatePath = 'companystaff';

    protected $filters = array('role'=>'company-staff');
    protected $entity = 'Company Staff';

    /**
      users,userAdd,userEdit,userEnable,userDisable,changePassword

    **/





}