<?php 

namespace controllers;

class PlacesController{

  

     function getPlaces($searchText='ajah'){

   	 $location = $this->getIPLatLng();
   	 $result = null;


		// if (!isset($_GET['searchText'])){
		//   $_GET['searchText'] = 'ajah';
		// }

		$curl = curl_init();


		$searchText = explode(' ', $searchText);
		$searchText = implode('+', $searchText);

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyDgzNrN0i8WNwm3bOiWFeXt_bQFy4Vr5Vs&input=" . $searchText . "&location=" . $location['lat'] . ',' . $location['lng'] . "&radius=50000",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_POSTFIELDS => "",
		  CURLOPT_HTTPHEADER => array(
		    "Postman-Token: 8af565f0-d980-4c00-be48-240f6e3cb92d",
		    "cache-control: no-cache"
		  ),
		));

		$result = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  $json['message'] = "cURL Error #:" . $err;
		  $json['error'] = true;
		} else {
		  $json = json_decode($result,true);
		  $json_decode['error'] = false;
		  // print_r($data);
		}
        
        return $json;

     }



   function getIPLatLng(){
     
     $new_arr[]= unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']));
     // echo "Latitude:".$new_arr[0]['geoplugin_latitude']." and Longitude:".$new_arr[0]['geoplugin_longitude'];   	
     return array(
     	'lat'=>$new_arr[0]['geoplugin_latitude'],
     	'lng'=>$new_arr[0]['geoplugin_longitude']
     );

   }



}