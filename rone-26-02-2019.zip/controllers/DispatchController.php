<?php

namespace controllers;

use models\User;
use models\LatLng;
use models\DispatchRequest;
use models\Customer;
use appx\core\Request;

class DispatchController extends UserTemplateController{

   private $payStackPublicKey = '';
   private $payStackPrivatekey = '';

   function requestDispatch(){
     return $this->view('dispatch/request');
   }

   function saveDispatchSettings(){
     $data = Request::all();
     $prefs = [];
     
     $prefs['pickup_address'] = $data['pickup_address'];
     $prefs['dropoff_address'] = $data['dropoff_address'];
     $prefs['pickup_lat'] = $data['pickup_lat'];
     $prefs['pickup_lng'] = $data['pickup_lng'];
     $prefs['dropoff_lat'] = $data['dropoff_lat'];
     $prefs['dropoff_lng'] = $data['dropoff_lng'];
     $prefs['dispatch_distance'] = $data['dispatch_distance'];

     Request::sessionSet('_dispatch_pref',$prefs);

     $latlng1 = $prefs['pickup_lat'] . ',' . $prefs['pickup_lng'];
     $latlng2 = $prefs['dropoff_lat'] . ',' . $prefs['dropoff_lng'];



     redirect('request-dispatch/get-dispatchers/' . $latlng1 . '/' . $latlng2);      

   }


   function getDispatchers(LatLng $latlng1,LatLng $latlng2){
     $prefs = Request::sessionGet('_dispatch_pref');

     $marker1 = [
      'lat'=>$prefs['pickup_lat'],
      'lng'=>$prefs['pickup_lng'],
      'description'=>$prefs['pickup_address']
     ];

     $marker2 = [
      'lat'=>$prefs['dropoff_lat'],
      'lng'=>$prefs['dropoff_lng'],
      'description'=>$prefs['dropoff_address']
     ];


     return $this->view('dispatch/get-dispatchers',[
       'dispatchers'=>User::allUsersWithinRadius($latlng1->getLat(),$latlng1->getLng(),$radiusKm=15,$bias='19'),
       'dispatch_distance'=>$prefs['dispatch_distance'],
       'pickup_address'=>$prefs['pickup_address'],
       'dropoff_address'=>$prefs['dropoff_address'],
       'pickup_lat'=>$prefs['pickup_lat'],
       'pickup_lng'=>$prefs['pickup_lng'],
       'dropoff_lat'=>$prefs['dropoff_lat'],
       'dropoff_lng'=>$prefs['dropoff_lng'],
       'marker1'=>$marker1,
       'marker2'=>$marker2
     ]);

   }

   function createDispatchRequest(LatLng $latlng1,LatLng $latlng2){

   }

   function additionalInfo(Customer $customer,DispatchRequest $transaction){

   }

   function additionalInfoAction(Customer $customer,DispatchRequest $transaction){

   }

   function cashPaymentPage(Customer $customer,DispatchRequest $transaction){

   }

   function cardPaymentPage(Customer $customer,DispatchRequest $transaction){

   }

   function cardPaymentFeedbackQuery(DispatchRequest $transaction){

   }


   function trackPackage(){
   	
   }   





}