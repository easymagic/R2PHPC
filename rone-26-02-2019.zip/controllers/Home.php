<?php 
namespace controllers;

use models\phonebook\phone_book;

class Home{

   public $newName = 'Old name...';

   
   function index(\models\test\base\Test $test){
   
    // print_r($test);
    // $list = \models\test\base\Test::all();
    // $list = $list[0];
    // $list->update([
    //  'content'=>'new content.123......'
    // ]);

    // print_r(\models\test\base\Test::all());


    // return 'New Default Loaded.';
    return view('hello',['msg'=>'hello']);

   }

   function test(\models\test\base\Test $test2,\models\test\base\Test $test){

     // echo $test;

     print_r($test);

     print_r($test2);

   }






}