<?php 

namespace models;

class SuperAdminUser extends User{



  function adminDispatchRequests($filters=array()){
  	
  	$companies = $this->companies;
  	$list = [];
  	foreach ($companies as $company){

  		$lst = $company->companyDispatchRequests($filters);

  		$list = array_merge($list,$lst);

  	}
   
    return $list;

  }

  


}