<?php 

namespace models;

class DispatchLog extends \models\BaseModel{
  
  protected $table = 'dispatch_log';


  function dispatchRequest(){
  	return $this->belongsTo(DispatchRequst::class,'dispatch_id');
  }

  function user(){
  	return $this->belongsTo(User::class,'user_id');
  }

  function seenBy(){
    return $this->belongsTo(User::class,'seen_by');	
  }

  static function createLog($data){
  	$data['date_created'] = date('Y-m-d h:i:s');
  	DispatchLog::create($data);
  }





}