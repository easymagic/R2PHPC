<?php 

namespace models;

class LatLng extends BaseModel{

     private $lat = null;
     private $lng = null;

	 function customResolveRouteBinding($cords){
       
       $cords = explode(',', $cords);

       // echo 'Called...';
       if (isset($cords[0])){
         $this->lat = $cords[0];
       }

       if (isset($cords[1])){
         $this->lng = $cords[1];
       }

       return $this;

	 }


	 function getLat(){
       return $this->lat;
	 }


	 function getLng(){
	 	return $this->lng;
	 }


}