<?php 

namespace models;

class DispatchRequest extends \models\BaseModel{
  
  protected $table = 'dispatch_request';

  
  function customer(){
  	return $this->belongsTo(Customer::class,'customer_id');
  }

  function user(){
  	return $this->belongsTo(User::class,'user_id');
  }

  function company(){
  	return $this->belongsTo(User::class,'user_parent_id');
  }


  function dispatchLog(){
  	return $this->hasMany(DispatchLog::class,'dispatch_id');
  }

   function applyFilters($filters=array()){
   	if (isset($filters['dispatchStatus'])){
      $this->where('dispatch_status',$filters['dispatchStatus']);
   	}
   	return $this;
   }

   function updateDispatchStatus($status){
      $this->update([
        'dispatch_status'=>$status
      ]);
      // DispatchLog::createLog($this,$user);
      $this->setSuccess('Dispatch status successfully updated to ' . $status);
      return $this->getMessage();
   }

   function updatePaymentStatus($status){
      $this->update([
        'payment_type'=>$status,
        'payment_status'=>'success'
      ]);
      // DispatchLog::createLog($this);
      $this->setSuccess('Payment status successfully updated to ' . $status);
      return $this->getMessage();   
   }


   static function getSuccessFullDeliveries(){
   	$obj = new self;
   	return $obj->where('dispatch_status','droppedoff')->getCount();
   }






}