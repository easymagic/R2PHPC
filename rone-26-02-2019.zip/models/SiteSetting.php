<?php 

namespace models;

class SiteSetting extends \models\BaseModel{
  
  protected $table = 'site_settings';



}