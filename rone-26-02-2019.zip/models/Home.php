<?php 

namespace models;

class Home extends BaseModel{



     function sendFeedback($data){
       
       $this->setSuccess('Your feedback has been sent successfully.');
       return $this->getMessage();
     }



}