<?php 

namespace models;

class Testimonial extends \models\BaseModel{
  
  protected $table = 'testimonial';





}