<?php 

namespace models;

class Customer extends \models\BaseModel{
  
  protected $table = 'customer';


   function customerRegister($data){
    return $this->register($data,null,'Registration completed successfully.');
   }

   function dispatchRequests(){
   	return $this->hasMany(DispatchRequest::class,'customer_id');
   }

   function transactions($filters=array()){
    $cls = DispatchRequest::class;
    $obj = new $cls;
    return $obj->where('customer_id',$this->id)->applyFilters($filters)->get();
   }

   function transactionsCount($filters=array()){
    $cls = DispatchRequest::class;
    $obj = new $cls;
    return $obj->where('customer_id',$this->id)->applyFilters($filters)->getCount();
   }

   //dispatch_amount
   function transactionsSum($filters=array()){
    $cls = DispatchRequest::class;
    $obj = new $cls;
    return $obj->where('customer_id',$this->id)->applyFilters($filters)->getSum('dispatch_amount');
   }


   function sendVerification(){

   }


}