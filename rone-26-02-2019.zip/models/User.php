<?php 

namespace models;

class User extends \models\BaseModel{
  
   protected $table = 'user';


   static function allUsersWithinRadius($lat,$lng,$radiusKm,$bias='1'){
   	$cls = User::class;
   	$obj = new $cls;
    return $obj->cols("*,(
				    6371 * acos (
				      cos ( radians($lat) )
				      * cos( radians( lat ) )
				      * cos( radians( lng ) - radians($lng) )
				      + sin ( radians($lat) )
				      * sin( radians( lat ) )
				    )
				  ) AS distance")->whereRaw("role='dispatcher' and status = 1 and (dispatch_availability = 'free' or parent_id = '$bias')")->having("distance < $radiusKm or parent_id = '$bias'")->get(); //bais the query
   }


   function userRegister($data,$msgSuccess='Staff profile created successfully.'){
    return $this->register($data,null,$msgSuccess);
   }

   function dispatchLogs(){
   	return $this->hasMany(\models\DispatchLog::class,'user_id');
   }

   function transactions($filters=array()){
   	return $this->dispatchRequests($filters);
   }

   function dispatchRequests($filters=array()){

   	$cls = DispatchRequest::class;
   	$obj = new $cls;
   	
   	if ($this->role == 'company'){
   	  return $obj->where('user_parent_id',$this->id)->applyFilters($filters)->get();   	
   	}else if ($this->role == 'staff'){
   	  return $obj->applyFilters($filters)->get();
   	}else if ($this->role == 'admin'){
   	  return $obj->applyFilters($filters)->get();
   	}else if ($this->role == 'company-staff'){
      return $obj->where('user_parent_id',$this->parent_id)->applyFilters($filters)->get();
   	}else if ($this->role == 'dispatcher'){
      return $obj->where('user_id',$this->id)->applyFilters($filters)->get();
   	}

   }


   function dispatchRequestsCount($filters=array()){

   	$cls = DispatchRequest::class;
   	$obj = new $cls;
   	
   	if ($this->role == 'company'){
   	  return $obj->where('user_parent_id',$this->id)->applyFilters($filters)->getCount();
   	}else if ($this->role == 'staff'){
   	  return $obj->applyFilters($filters)->getCount();
   	}else if ($this->role == 'admin'){
   	  return $obj->applyFilters($filters)->getCount();
   	}else if ($this->role == 'company-staff'){
      return $obj->where('user_parent_id',$this->parent_id)->applyFilters($filters)->getCount();
   	}else if ($this->role == 'dispatcher'){
       return $obj->where('user_id',$this->id)->applyFilters($filters)->getCount();
   	}

   }

   function dispatchRequestsSum($filters=array()){ //getSum
   	$cls = DispatchRequest::class;
   	$obj = new $cls;
   	
   	if ($this->role == 'company'){
   	  return $obj->where('user_parent_id',$this->id)->applyFilters($filters)->getSum('dispatch_amount');
   	}else if ($this->role == 'staff'){
   	  return $obj->applyFilters($filters)->getSum('dispatch_amount');
   	}else if ($this->role == 'admin'){
   	  return $obj->applyFilters($filters)->getSum('dispatch_amount');
   	}else if ($this->role == 'company-staff'){
      return $obj->where('user_parent_id',$this->parent_id)->applyFilters($filters)->getSum('dispatch_amount');
   	}else if ($this->role == 'dispatcher'){
       return $obj->where('user_id',$this->id)->applyFilters($filters)->getSum('dispatch_amount');
   	}
   }

   function transactionsCount($filters=array()){
   	return $this->dispatchRequestsCount($filters);
   }

   function transactionsSum($filters=array()){
   	return $this->dispatchRequestsSum($filters);
   }


   function company(){
   	if ($this->role == 'staff' || $this->role == 'company-staff' || $this->role == 'dispatcher'){
      return $this->belongsTo(User::class,'parent_id');  
   	}else if ($this->role == 'company'){
      return $this->belongsTo(User::class,'parent_id');  
   	}else if ($this->role == 'admin'){
     return $this;
   	}
   }

   function companies(){
   	$cls = User::class;
   	$obj = new $cls;
   	if ($this->role == 'staff'){
      return $obj->where('parent_id',$this->parent_id)->where('role','company')->get();
   	}else if ($this->role == 'admin'){
      return $obj->where('parent_id',$this->id)->where('role','company')->get();
   	}else if ($this->role == 'company'){
      return [];
   	}else if ($this->role == 'company-staff'){
      return [];
   	}else if ($this->role == 'dispatcher'){
      return [];
   	}
   }

   function admin(){
   	if ($this->role == 'company-staff' || $this->role == 'dispatcher'){
     return $this->company->admin;
   	}else if ($this->role == 'company'){
     return $this->belongsTo(User::class,'parent_id');
   	}else if ($this->role == 'staff'){
     return $this->company; 
   	}else if ($this->role == 'admin'){
     return $this;
   	}
   }

   function applyUserFilter($config=array()){
   	if (isset($config['role'])){
     $this->where('role',$config['role']);
   	}
   	return $this;
   }

   function users($options=array()){
   	 $cls = User::class;
   	 $obj = new $cls;
   	if ($this->role == 'staff'){        
   		return $obj->where('parent_id',$this->parent_id)->applyUserFilter($options)->get();
   	}else if ($this->role == 'admin'){
   		return $obj->where('parent_id',$this->id)->applyUserFilter($options)->get();   		
   	}else if ($this->role == 'company'){   		
   		return $obj->where('parent_id',$this->id)->applyUserFilter($options)->get();   		
   	}else if ($this->role == 'company-staff'){
      return $obj->where('parent_id',$this->parent_id)->applyUserFilter($options)->get();
   	}else if ($this->role == 'dispatcher'){
      return $obj->where('parent_id',$this->parent_id)->applyUserFilter($options)->get();
   	}   	
   }

   function staffs(){
   	if ($this->role == 'staff'){        
   		$cls = User::class;
   		$obj = new $cls;
   		return $obj->where('parent_id',$this->parent_id)->where('role','staff')->get();
   	}else if ($this->role == 'admin'){
   		$cls = User::class;
   		$obj = new $cls;
   		return $obj->where('parent_id',$this->id)->where('role','staff')->get();   		
   	}else if ($this->role == 'company'){   	
   	  // echo 'called.';	
      return $this->hasMany(User::class,'parent_id');
   	}else if ($this->role == 'company-staff'){
      return $this->hasMany(User::class,'parent_id','parent_id');
   	}else if ($this->role == 'dispatcher'){
      return $this->hasMany(User::class,'parent_id','parent_id');
   	}
   }

   function companyStaff(){
   	
   	$cls = User::class;
    $obj = new $cls;   	

   	if ($this->role == 'staff'){        
   		return [];
   	}else if ($this->role == 'admin'){
   		return [];
   	}else if ($this->role == 'company'){   	
      // return $this->hasMany(User::class,'parent_id');
      return $obj->where('role','company-staff')->where('parent_id',$this->id)->get();
   	}else if ($this->role == 'company-staff'){
      // return $this->hasMany(User::class,'parent_id','parent_id');
   		return $obj->where('role','company-staff')->where('parent_id',$this->parent_id)->get();
   	}else if ($this->role == 'dispatcher'){
      // return $this->hasMany(User::class,'parent_id','parent_id');
      return $obj->where('role','company-staff')->where('parent_id',$this->parent_id)->get();
   	}   	

   }


   function dispatchers(){
   	if ($this->role == 'staff' || $this->role == 'admin'){        
   		$cls = User::class;
   		$obj = new $cls;
   		return $obj->where('role','dispatcher')->get();
   	}else if ($this->role == 'company'){   		
   		$cls = User::class;
   		$obj = new $cls;
   		return $obj->where('role','dispatcher')->where('parent_id',$this->id)->get();
   	}else if ($this->role == 'company-staff' || $this->role == 'dispatcher'){
   		$cls = User::class;
   		$obj = new $cls;
   		return $obj->where('role','dispatcher')->where('parent_id',$this->parent_id)->get();
   	}   	
   }


  function uploadLogo(){
    $obj = \helpers\UploadHelper::factory();
    if ($obj->uploadSucceed('logo','uploads/user/logo')){
        $this->update([
           'company_logo'=>$obj->getUploadedFile()
        ]);
    }
  }


  function autoParentId(){
  	if ($this->role == 'admin'){
     return $this->id;
  	}else if ($this->role == 'staff'){
     return $this->parent_id;
  	}else if ($this->role == 'company'){
     return $this->id;
  	}else if ($this->role == 'company-staff'){
     return $this->parent_id;
  	}
  }

  function siteSetting(){
  	return $this->belongsTo(SiteSetting::class,'flat_rate_id');
  }



}