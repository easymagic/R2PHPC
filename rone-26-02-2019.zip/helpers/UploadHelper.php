<?php 

namespace helpers;

class UploadHelper{

    private $uploadedFile = '';

    static function factory(){
      return new UploadHelper;
    }

    function uploadSucceed($name,$path){
       $r = false;
       $path = $this->escapePath($path); 
    	 
    	 if (isset($_FILES[$name])){

    	 	$tmp = $_FILES[$name]['tmp_name'];
    	 	$fileName = $path . uniqid() . $_FILES[$name]['name'];

        $this->uploadedFile = $fileName;
           
           if ( move_uploaded_file( $tmp , $fileName ) ){
             
             $r = true;

           }

    	 }
      
      return $r;
    }



    private function escapePath($path){ 
      $lst = substr($path, -1);
      if ($lst != '/'){
        $path = $path . '/';
      }
      return $path;
    }

    function getUploadedFile(){
    	return $this->uploadedFile;
    }



}