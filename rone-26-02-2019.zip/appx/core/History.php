<?php 

namespace appx\core;

class History{

    
    private static function init(){
     if (Request::sessionNotSet('_history')){
       Request::sessionSet('_history','');
     }
    }

    static function recordRoute($route){
      self::init();
      Request::sessionSet('_history',$route);
    }

    static function recordRedirectRoute(){
      self::init();
      Request::sessionSet('_history_redirect',self::getLastHistory()); 
    }

    static function fireRedirectRoute(){
      if (Request::sessionHas('_history_redirect')){
         $url = Request::sessionGet('_history_redirect');
         Request::sessionUnSet('_history_redirect');
         redirect($url);
      }
    }

    static function getLastHistory(){
    	return Request::sessionGet('_history');
    }

    static function checkErrorInMessageStream(){
    	//_flash
    	$bundle = Request::sessionGet('_flash');
        // print_r($bundle);
    	// die();
    	if (!is_null($bundle)){
           if (isset($bundle['error'])){
             if ($bundle['error']){
               self::saveOldForm();
               redirectSystem(self::getLastHistory());
             }
           }else{
             self::clearOldForm();
           } 
    	}
    }

    static function saveOldForm(){
      $requests = Request::all();
      $data = array('_old'=>array());
      foreach ($requests as $k=>$v){
       $data['_old'][$k] = $v;
      }
      Request::sessionSet('_old',$data['_old']);
    }

    static function clearOldForm(){
      Request::sessionSet('_old',[]);
    }


}