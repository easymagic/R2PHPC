<?php 
namespace appx\core;

// use Request;

class Template{

 private static $template_store = array();
 private static $current_template_name = '';
 private static $data_store = array();
 // private static $middle_wares = array(); 
 // private static $named_middle_wares = array(); 


   
   static function yield($name,$value=''){
     if (isset(self::$template_store[$name])){
        echo self::$template_store[$name];
     }else{
        echo $value;
     }
   }

   static function section($name){
    ob_start();
    self::$current_template_name = $name;
   }

   static function endSection(){
    self::$template_store[self::$current_template_name] = ob_get_contents();
    ob_end_clean();
   }

   static function extend($__template__,$__data__=array()){
      foreach ($__data__ as $_k_=>$_v_){
        self::$data_store[$_k_] = $_v_;
      }

     $__file__ = 'views/' . $__template__ . '.php'; 
     if (file_exists($__file__)){
      extract(self::$data_store);    
      require($__file__);
     }
   }


   static function view($template,$__data__=array()){
    $__r__ = '';
    ob_start();
    self::extend($template,$__data__);
    $__r__ = ob_get_contents();
    ob_end_clean();
    return $__r__;
   }

   static function old($k){

     if (Request::sessionHas('_old')){
       $old = Request::sessionGet('_old');
       if (isset($old[$k])){
         echo $old[$k];
       } 
     }

   }



}
