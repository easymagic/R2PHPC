<?php 

namespace middlewares;

use appx\core\Request;
use appx\core\History;

class CheckAuth{


  
    function handle($options,$guardOptions=array()){

    	  $sess = Request::session(); 

    	  // print_r($sess);

    	  // print_r($_SESSION);

         if ( isset($guardOptions[0]) && !isset($sess[$guardOptions[0]]) ){
         	
            History::recordRedirectRoute();

            if (isset($guardOptions[1])){
            
              redirect($guardOptions[1]);
         	
            }else{
               //recordRedirectRoute
              redirect('/');

         	}
           
         }else{

             History::fireRedirectRoute();
           
         }

        return $options;
    }


}