<?php
use appx\core\Route;

/*** Url Config***/
// define('DEFAULT_CONTROLLER', 'Admin');
// define('BASE_URL', 'http://timberfieldschoolslagosng.sch.ng/sandbox/');
define('BASE_URL', 'http://localhost/turbo/');
define('CALLBACK_URL', '');
// define('API_URL', '/d2dc/rone/');


/****Database config*****/
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASENAME', 'db_turbo');


/*** Middle-ware declaration ***/
//$__middle_wares__ = array(); 
//$__named_middle_wares__ = array();
// $__named_middle_wares__['auth'] = middlewares\CheckAuth::class;

Route::registerNamedMiddleware('auth',middlewares\CheckAuth::class);
Route::registerNamedMiddleware('guest',middlewares\CheckGuest::class);