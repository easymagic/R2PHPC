<?php
// spl_autoload_extensions('php');
spl_autoload_register(function($file){
 
 $file = "$file.php";
 $file = explode('\\', $file);
 $file = implode('/', $file);
 if (file_exists($file)){
   require_once($file);
 } 
 
});

require_once('config_new.php');
session_start();
error_reporting(E_ALL);


// function __autoload($file){
//  $file = $file . '.php';
//  $file = explode('\\', $file);
//  $file = implode('/', $file);
 
//  if (file_exists($file)){
//    // include_once($file);
//  }
// }

// spl_autoload_extensions('.php');
// spl_autoload();



// require_once('appx/core/core.php');

require_once('routes/web.php');

//create some short-cut helpers here ...
function view($template,$__data__=array()){
	return appx\core\Template::view($template,$__data__);
}

function redirect($url,$absolute=false){
  appx\core\History::checkErrorInMessageStream(); //vcool
	appx\core\Route::redirect($url,$absolute);
}

function redirectSystem($url,$absolute=false){
  appx\core\Route::redirect($url,$absolute);
}


function section($name){
  appx\core\Template::section($name);
}

function extend($__template__,$__data__){
  appx\core\Template::extend($__template__,$__data__);
}

function endSection(){
   appx\core\Template::endSection();
}

function request(){
  return appx\core\Request::all();	
}

 try {
   
   $r = appx\core\Route::runRoute();


   if (is_object($r) || is_array($r)){

       echo json_encode($r);

   }else{

       echo $r;

   }


 } catch (Exception $e) {
   
   $except = $e->getMessage();

   if (is_object($except) || is_array($except)){
    
    echo json_encode($except);

   }else{
    
    echo $except;

   }

   // echo $e->getMessage();
 }

