<?php 
namespace declarations\entities;

class EntityRegister extends \declarations\entities\EntityAll{

   
   function Register($table,$duplicatefield1,$duplicatefield2,$data=array(),$passwordData=array()){
     
     $result = array('data'=>array());

     // LoadClass($this,'@declarations/entities/EntityCheckPassword');
     $obj = new \declarations\entities\EntityCheckPassword;
     
     $this->SetWhere("( $duplicatefield1 = '$data[$duplicatefield1]' OR $duplicatefield2 = '$data[$duplicatefield2]')");

     $check = $this->All($table);
     if (count($check) > 0){
       $result['error'] = true;
       $result['message'] = 'An account with this ' . $duplicatefield1 . ' already exists!';
       $result['data'] = $check[0];
     }else{
     	$passCheck = $obj->CheckPassword($passwordData);
     	if (!$passCheck['error']){

	       $result['error'] = false;
	       $data['password'] = $passCheck['data']['password'];
	       $result['message'] = 'Registration successful.';
	       $this->DbCreate($table,$data);
	       $result['data']['newID'] = $this->newID;

     	}else{
     		// $result['message'] = $passCheck['message'];
     		// $result['error'] = $passCheck['error'];
     		$result = $passCheck;
     	}
     }

     // print_r($result);

     return $result;

   }


}