<?php

namespace rone;

class Model extends \declarations\Db{   

   protected $table = '';

   function __construct(){
    if (empty($this->table)){
	   	$r = get_called_class();
	   	$r = explode('\\', $r);
	   	$this->table = end($r) . 's';
	   	$this->table = strtolower($this->table);
    }
   }

   function getTableName(){
   	return $this->table;
   }

   static function getClassConstructor(){
   	 $cls = get_called_class();
   	 $obj = new $cls;
     return $obj;   	
   }

   
   static function all(){
   	 $obj = self::getClassConstructor();
   	 return $obj->get();
   }

   static function create($data=array()){
     $obj = self::getClassConstructor();
     return $obj->dbCreate($obj->getTableName(),$data);
   }

   function where($k,$v,$eq='='){
   	 if (!is_numeric($v)){
       $v = "'$v'";
   	 }
     $this->setWhere(" ($k $eq $v) ");
     return $this;
   }

   function cols($cols){
    $this->setCols($cols);
    return $this;
   }

   function having($having){
    $this->setHaving($having);
    return $this;
   }

   function sort($sort){
    $this->setSort($sort);
    return $this;
   }

   function limit($limit){
    $this->setLimit($limit);
    return $this;
   }


   function whereRaw($str){
    $this->setWhere($str);
    return $this;
   }

   function get(){
   	return $this->dbGet($this->getTableName());
   }

   function getOne(){
   	$record = $this->get();
   	if (count($record) > 0){
       return $record[0];
   	}else{
   	   return array();
   	}
   }

   function getCount(){
     $this->setCols(' COUNT(*) as recordCount ');
     $data = $this->getOne();
     return $data->recordCount;
   }

   function getSum($col){
     $this->setCols(' SUM(' . $col . ') as recordSum ');
     $data = $this->getOne();
     return $data->recordSum;
   }

   function find($id){
     return $this->where('id',$id)->getOne();
   }

   function findBy($key,$value){
     return $this->where($key,$value);
   }

   private function purifyData($data){
     $filteredData = array();
     foreach ($data as $k=>$v){
      // echo $k;
       if (!is_numeric($k) && isset($this->$k)){
        // echo 'set...';
         $filteredData[$k] = $v;
       }
     }
     // print_r($filteredData);
     // print_r($data);
     // die();
     return $filteredData;
   }

   function update($data=array()){
    $this->where('id',$this->id);
    $this->dbUpdate($this->getTableName(),$this->purifyData($data));
   }

   function delete(){
    $this->where('id',$this->id);
    $this->dbDelete($this->getTableName());
   }

   function resolveRouteBinding($id){ //or customResolveRouteBinding

   	 $this->where('id',$id);
   	 $result = $this->get();

   	 if (isset($result[0])){
       return $result[0];
   	 }else{
       throw new \Exception(view('errors/invalid-selection'));
       return self::getClassConstructor();
   	 }

   }


   //special relations
   function hasMany($class,$key,$id='id'){
   	   // $obj = new $class();
       return (new $class)->findBy($key,$this->$id)->get();
   }

   function belongsTo($class,$key,$id='id'){
    return (new $class)->findBy($id,$this->$key)->getOne();
   }


   function __get($k){

   	 if (method_exists($this, $k)){
       return $this->$k();
   	 }else{
   	   return [];	
   	 }

   }




}
