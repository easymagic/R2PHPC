<?php 

class VendorFacultyCourseMaterialUpdate implements IUseCase{
	
  // use EntityUpdateTrait;

  use EntityUpdateTrait,EntityUploadTrait{
  	EntityUpdateTrait::Exec as DoExec;
  }


 function Exec(){
 	$this->DoUpload();
 	$this->DoExec();
 }  

  function GetTableName(){
    return 'vendor_faculty_course_material';
  }

  function GetUpdateMessage(){
  	return 'Course Material updated.';
  }

  function SetUploadedFile($uploaded_file){
    $this->input['data']['content'] = $uploaded_file;
  }

  function GetUploadName(){
    return 'file';
  }

  function GetUploadPath(){
   return 'uploads/vendor_faculty_course_material/';
  }




}