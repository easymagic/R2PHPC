<?php 

class VendorFacultyCourseTestCreate implements iUseCase{
  
  use EntityCreateTrait;


  function GetTableName(){
    return 'vendor_faculty_course_test';
  }

  function GetCreateMessage(){
    return 'Course Test Added.';
  }



}