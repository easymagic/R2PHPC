<?php 

class VendorFacultyCourseTestUpdate implements IUseCase{
	
  use EntityUpdateTrait;


  function GetTableName(){
    return 'vendor_faculty_course_test';
  }

  function GetUpdateMessage(){
  	return 'Course Test updated.';
  }



}