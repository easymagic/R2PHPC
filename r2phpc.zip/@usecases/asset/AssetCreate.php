<?php 

class AssetCreate implements IUseCase{
	
	use EntityCreateTrait;


  function GetTableName(){
    return 'asset';
  }

  function GetCreateMessage(){
  	return 'Asset created successfully.';
  }



}