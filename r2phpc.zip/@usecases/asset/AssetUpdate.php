<?php 

class AssetUpdate implements IUseCase{
	
	use EntityUpdateTrait;


  function GetTableName(){
    return 'asset';
  }

  function GetUpdateMessage(){
  	return 'Asset updated.';
  }



}