<?php 

class FacultyCourseUpdate implements IUseCase{
	
	use EntityUpdateTrait,EntityUploadTrait{
		EntityUpdateTrait::Exec as DoExec;
	}



  function GetTableName(){
    return 'faculty_course';
  }

  function GetUpdateMessage(){
  	return 'Faculty - Course updated.';
  }

  function PreformatSelection(){
   $r = $this->input['options'];
   $r = implode(',', $r);
   $this->input['data']['units'] = $r;
  }


  function Exec(){
    $this->PreformatSelection();
  	$this->DoUpload();
  	$this->DoExec();
  }

  function SetUploadedFile($uploaded_file){
    $this->input['data']['logo'] = $uploaded_file;
  }

  function GetUploadName(){
    return 'image';
  }

  function GetUploadPath(){
   return 'uploads/faculty_course/';
  }

}