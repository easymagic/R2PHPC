<?php 

class upload_do implements iusecase{
  
  private $path = '';
  private $name = '';
  private $output_name = '';
  private $tmp_name = '';
  private $file_name = '';

  private $input = array();
  private $output = array();

  
  function get_input($input){
     
     //path,name,output_name
  	 $this->input = $input;
  	 
  	 if (!isset($this->input['upload']))
  	 	throw new Exception("upload array-param required!");

  	 $this->path = $input['upload']['path'];
  	 $this->name = $input['upload']['name'];
  	 $this->output_name = $input['upload']['output_name'];

  	 $this->tmp_name = $_FILES[$this->name]['tmp_name'];
  	 
  	 $this->file_name = $_FILES[$this->name]['name'];

  	 $this->rename_file();

  }

  private function rename_file(){
    $r = explode('.', $this->file_name);
    $ext = end($r);
    $this->file_name = uniqid() . '_img_.' . $ext;
  }



  function get_output(){
    return $this->output;
  }

  function get_service($obj){

  }

  function exec(){

  	$destination = $this->path . $this->file_name;

  	if (move_uploaded_file($this->tmp_name, $destination)){
      $this->output['data'] = array(
        'data'=>array($this->output_name=>$this->file_name)
      );
      $this->output['message'] = 'upload successful.';
  	}else{
  	  $this->output['data'] = array();
  	}

  	// print_r($this->output);

  }



}