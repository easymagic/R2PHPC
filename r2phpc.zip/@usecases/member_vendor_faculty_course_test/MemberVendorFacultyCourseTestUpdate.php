<?php 

class MemberVendorFacultyCourseTestUpdate implements IUseCase{
	
	use EntityUpdateTrait;


  function GetTableName(){
    return 'member_vendor_faculty_course_test';
  }

  function GetUpdateMessage(){
  	return 'Test updated.';
  }



}