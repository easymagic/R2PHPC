<?php 

class MemberVendorFacultyCourseTestRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'member_vendor_faculty_course_test';
 }


}