<?php 

class RoleManager{
 

 use EntityRoleActionsTrait,EntityTrait;
   
 function __construct(){
   $this->PreLoadPermissions();
 }

 function Exec(){
   
   if (isset($this->input['role']) && isset($this->input['module'])){
   	 throw new Exception("Role and Module params required!");
   }

   if ($this->HasRoleAction($this->input['role'],$this->input['module'])){
    $this->output['data'] = true;
   }else{
    $this->output['data'] = false;
   }

 }

 function GetService($service_locator){
  
 }


 private function PreLoadPermissions(){

 	$this->AddRoleAction('admin',$module='',$create=false,$read=false,$update=false,$delete=false);



 	$this->AddRoleAction('admin',$module='',$create=false,$read=false,$update=false,$delete=false);




 	$this->AddRoleAction('admin',$module='',$create=false,$read=false,$update=false,$delete=false);



 	$this->AddRoleAction('admin',$module='',$create=false,$read=false,$update=false,$delete=false);


   
 }





}