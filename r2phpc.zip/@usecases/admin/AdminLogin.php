<?php 
/**

 @Inject(Message,Db)

*/

class AdminLogin{
  
  use EntityLoginTrait;




  function GetTableName(){
  	return 'admin';
  }

  function GetSessionName(){
   return 'user.account';
  }

  function GetAuthFields(){
   return array(
    'username'=>'email',
    'password'=>'password'
   );
  }

  function GetLoginSuccessMessage(){
    return 'Access granted, Welcome.';
  }

  function GetLoginFailureMessage(){
    return 'Invalid Login!!!';
  }

  function GetLoginStatusFailureMessage(){
     return 'Your account has been deactivated!!!';
  }

  function GetStatusField(){
  	return 'status';
  } //status (1 or 0)

 

}