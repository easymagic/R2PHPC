<?php 

class artisan_update implements iusecase{
  
  use entity_update_trait;

  
  //abstract implementations

  function get_table_name(){
  	return 'artisan';
  }

  function get_update_message(){
  	return 'artisan updated.';
  }



}