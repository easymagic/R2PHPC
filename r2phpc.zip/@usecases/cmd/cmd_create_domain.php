<?php 

class cmd_create_domain implements iusecase{
  
  use file_io_trait;

  private $output = array();
  private $domain = '';


  function get_input($input){

      if (!isset($input['domain'])){
         throw new Exception("domain-param required!");
      }

      $this->domain = $input['domain'];

  }

  function get_output(){
    return $this->output;
  }

  function get_service($obj){
    
  }

  private function do_creation(){

     $this->output['message'] = '';

     //read_file_raw
     // $r = $this->read_file_raw('create-usecase-template');
     // $r = explode('[domain]', $r);
     // $r = implode($this->domain, $r);

     // echo $r;
     // echo '....';

     $this->commit_file('create-usecase-template','create');

     $this->output['message'].= 'Create domain file added,';


     $this->commit_file('update-usecase-template','update');

     $this->output['message'].= 'Update domain file added,';


     $this->commit_file('read-usecase-template','all');

     $this->output['message'].= 'Read domain file added.';


    
  }

  private function commit_file($id_file,$rename){
     
     $r = $this->read_file_raw($id_file);
     $r = explode('[domain]', $r);
     $r = implode($this->domain, $r);

     $app_file_dir = 'app-x/usecases/' . $this->domain;
     $app_file_name = 'usecases/' . $this->domain . '/' . $this->domain . '_' . $rename;

     if (!file_exists($app_file_dir)){
       mkdir($app_file_dir);
     }

     // if (!file_exists($app_file_name)){
       $this->write_file($app_file_name,$r);
     // }




  }

  function exec(){
     $this->do_creation();
  }

  //create-usecase-template
  //read-usecase-template
  //update-usecase-template

  function get_file_name_in($index){
    return 'code-gen-templates/' . $index . '.php';
  }


  function get_file_name_out($index){
    return 'app-x/' . $index . '.php';
  }




}