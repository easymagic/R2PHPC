<?php 

class user_change_password implements iusecase{
  
  use entity_change_password_trait;


  function get_table_name(){
    return 'user';
  }

  function get_password_map_field(){
    return 'password';
  }

  function get_change_password_success_message(){
  	return 'Password successfully changed.';
  }

  function get_change_password_failure_message(){
  	return 'Passwords do not match!';
  }


}