<?php 

class UserLogOut implements IUseCase{
  
  use EntityLogoutTrait;


  function GetLogoutMessage(){
    return 'You just logged out';
  }

  function GetSessionName(){
    return 'user_account';
  }


}