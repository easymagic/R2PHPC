<?php 

class wig_order_create implements iusecase{
  
  use entity_create_trait;
 
  //abstract implementations
  function get_table_name(){
    return 'wig_order';
  }

  function get_create_message(){
    return 'Order created successfully.';
  }

}