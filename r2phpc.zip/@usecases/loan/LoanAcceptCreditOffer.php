<?php 

class LoanAcceptCreditOffer implements iUseCase{

 
   use EntityTrait;

   private $db = null;
   private $loan_request_id = '';
   private $credit_grant_id = '';
   private $sender_id = '';
   private $credit_grant_data = array();

   function Exec(){ //loan_request_id
      
      $this->credit_grant_id = $this->input['data']['credit_grant_id'];
      $this->sender_id = $this->input['data']['sender_id'];

      $this->CheckDuplicate();
      $this->GetCreditGrantData();
      $this->CreateLoanCorrespondingRequest();
      $this->UpdateCorrespondingCreditRequest(); 
      

      $this->output['message'] = 'Credit Offer Accepted.';
   }

   private function GetCreditGrantData(){
     $this->db->where(array(
       'id'=>$this->credit_grant_id
     ));
     $this->credit_grant_data = $this->db->get('credit_grant');
   }

   private function CreateLoanCorrespondingRequest(){
     
     $this->input['data'] = array();
     $this->input['data']['sender_id'] = $this->sender_id;
     $this->input['data']['interest'] = $this->credit_grant_data[0]['interest'];
     $this->input['data']['amount'] = $this->credit_grant_data[0]['amount'];
     $this->input['data']['credit_grant_id'] = $this->credit_grant_id;
     $this->input['data']['debt_status'] = 'pending';
     $this->input['data']['date_created'] = date('Y-m-d h:i:s');

     $this->db->insert('loan_request',$this->input['data']);

     $this->loan_request_id = $this->db->insert_id();

   }

   private function UpdateCorrespondingCreditRequest(){
     
     $this->input['data'] = array();
     $this->input['data']['credit_status'] = 'pending';
     $this->input['data']['loan_request_id'] = $this->loan_request_id;
     $this->db->where(array(
       'id'=>$this->credit_grant_id
     ));
     $this->db->update('credit_grant',$this->input['data']);

   }

   private function CheckDuplicate(){

     $this->db->where(array(
       'id'=>$this->credit_grant_id
     ));

     $data = $this->db->get('credit_grant');

     // print_r($data);

     if (!empty($data) && !empty($data[0]['loan_request_id'])){
       throw new Exception("Offer already accepted!");
     }

   }

   function GetService($service_locator){
   
     $this->db = $service_locator->get('db');

   }



}