<?php 

class EntityCount implements iUseCase{
  
  use EntityCountTrait{
  	EntityCountTrait::Exec as DoCount;
  }

  private $table_name = '';


  function Exec(){ //table
    
    $args = $this->input['args'];
    $this->table_name = array_shift($args);
    
    $this->DoCount(); 

  }

  function GetTableName(){
    return $this->table_name;
  }


}