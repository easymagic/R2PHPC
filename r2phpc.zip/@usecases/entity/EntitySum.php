<?php 

class EntitySum implements iUseCase{
  
  use EntitySumTrait{
  	EntitySumTrait::Exec as DoSum;
  }

  private $table_name = '';
  private $field_name = '';


  function Exec(){ //table
    
    $args = $this->input['args'];
    $this->table_name = array_shift($args);
    $this->field_name = array_shift($args);
    

    $this->DoSum(); 

  }

  function GetTableName(){
    return $this->table_name;
  }

  function GetFieldName(){
    return $this->field_name;
  }


}