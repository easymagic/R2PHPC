<?php 

class EntityRead implements iUseCase{
  
  use EntityReadTrait{
  	EntityReadTrait::Exec as DoRead;
  }

  private $table_name = '';


  function Exec(){ //table
    
    $args = $this->input['args'];
    $this->table_name = array_shift($args);
    

    $this->DoRead(); 

  }

  function GetTableName(){
    return $this->table_name;
  }


}