<?php 

class EntityCreate implements iUseCase{

 use EntityCreateTrait,EntityUpdateTrait,EntityVerifyTrait,MailTrait{
 	EntityCreateTrait::Exec insteadof EntityUpdateTrait;
 	EntityCreateTrait::GetService insteadof EntityUpdateTrait;
 	EntityCreateTrait::GetInput insteadof EntityUpdateTrait;
 	EntityCreateTrait::GetOutput insteadof EntityUpdateTrait;

 	EntityCreateTrait::Exec insteadof EntityVerifyTrait;
 	EntityCreateTrait::GetService insteadof EntityVerifyTrait;
 	EntityCreateTrait::GetInput insteadof EntityVerifyTrait;
 	EntityCreateTrait::GetOutput insteadof EntityVerifyTrait;


 	EntityCreateTrait::Exec as DoCreate;
 	EntityUpdateTrait::Exec as DoUpdate;
 	EntityVerifyTrait::Exec as DoVerification;
 }

 private $table_name = '';
 private $duplicate_field_policy = '';
 private $verify_field = '';
 private $trigger_table = '';


 function Exec(){
  
  $args = $this->input['args'];

  $this->HandleInputKeyWords();
  
  // print_r($args);

  $this->table_name = array_shift($args);
  $this->duplicate_field_policy = array_shift($args);
  $this->verify_field = array_shift($args);
  $this->trigger_table = array_shift($args);

  $this->GenerateVerificationCode();

  // print_r(array(
  //   $this->duplicate_field_policy=>$this->input['data'][$this->duplicate_field_policy]
  // ));

  if ($this->RecordExists(array(
    $this->duplicate_field_policy=>$this->input['data'][$this->duplicate_field_policy]
  ))){
     throw new Exception("An account with this " . $this->duplicate_field_policy . " already exists!");
  }else{
    
    $this->DoCreate();

    $insert_id = $this->output['data']['id'];


    if (!empty($this->verify_field) && $this->verify_field != 'null'){
      $id = $this->output['data']['id'];
      $this->input['id'] = $id;
      $this->DoVerification();
      $this->SendMail();
      // echo $this->GenerateVerificationCode();
    }

    if (!empty($this->trigger_table)){

       $old_table = $this->table_name;

       $fkey = $old_table . '_id';

       $this->table_name = $this->trigger_table;
       $this->input['data'] = array();
       $this->input['data'][$fkey] = $insert_id;
       $this->DoCreate();

    }


    

    // echo $id;
  }

 }

 function GenerateVerificationCode($id){
  $r = md5($id);
  $r = substr($r, -5);
  return $r;
 }


 function GetTableName(){
 	return $this->table_name;
 }

 function GetCreateMessage(){
 	return 'Account created successfully.';
 }

 function GetUpdateMessage(){
 	return '';
 }


 function GetUpdateAction(){
  $this->DoUpdate();
 }

 function GetVerificationField(){
 	return $this->verify_field;
 }


   function GetMailTo(){
    return $this->output['data']['email'];
   }

   function GetMailFrom(){
    return 'info@r2soft.com.ng';
   }

   function GetMailSubject(){
     return 'Verify Registration';
   }

   function GetMailMessage(){
   	return 'Dear user,<br />
   	Thank You for signing up on this platform, you are a step away from completing your 
   	registration, type in this verification code <b>(' . $this->output['code'] . ')</b> in the box provided from the app.<br />
    <br /> 
   	King Regards';
   }


   function HandleInputKeyWords(){
    $arr = $this->input['data'];
    foreach ($arr as $k=>$v){
       $check = explode('date', $k);
       if (count($check) > 1){ //there is a date-like key in the request data
        if (empty($v)){

            $this->input['data'][$k] = date('Y-m-d h:i:s');

        }
       }
    }
   }



}