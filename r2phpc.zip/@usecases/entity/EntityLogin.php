<?php 

class EntityLogin implements iUseCase{
 

 use EntityLoginTrait{
 	EntityLoginTrait::Exec as DoLogin;
 }

 private $table_name = '';
 private $auth_fields = array();
 private $status_field = '';


 function Exec(){
 	
 	$args = $this->input['args'];

 	// print_r($args);

 	$table = array_shift($args);
 	$this->table_name = $table;

 	$username = array_shift($args);
 	$password = array_shift($args);

 	$this->status_field = array_shift($args);

 	$this->auth_fields['username'] = $username;
 	$this->auth_fields['password'] = $password;

 	// echo 'Called.';

 	$this->DoLogin();

 }






  function GetTableName(){
   return $this->table_name;
  }

  function GetSessionName(){
     return 'auth_user';
  }

  function GetAuthFields(){
    return $this->auth_fields;
  }

  function GetLoginSuccessMessage(){
   return 'Login successful.';
  }

  function GetLoginFailureMessage(){
   return 'Invalid login!!!';
  }

  function GetLoginStatusFailureMessage(){
   return 'Account not activated please activate from the link sent to You.';   
  }

  function GetStatusField(){
  	return $this->status_field;
  }



}