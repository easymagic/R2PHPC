<?php 

class MemberRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'member';
 }


}