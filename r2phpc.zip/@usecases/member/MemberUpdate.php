<?php 

class MemberUpdate implements IUseCase{
	
	use EntityUpdateTrait;


  function GetTableName(){
    return 'member';
  }

  function GetUpdateMessage(){
  	return 'Account updated.';
  }



}