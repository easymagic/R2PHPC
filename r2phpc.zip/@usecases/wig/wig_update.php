<?php 

class wig_update implements iusecase{

  private $uploaded_file = '';	
  
  use entity_update_trait,entity_upload_trait{

  	entity_update_trait::exec as update_entity;

  }

  
  //abstract implementations

  function exec(){

    $this->do_upload();

    if (!empty($this->uploaded_file))
    $this->input['data']['image'] = $this->uploaded_file;

    $this->update_entity();  	

  }

  function get_table_name(){
  	return 'wig';
  }

  function get_update_message(){
  	return 'Wig updated.';
  }


  function set_uploaded_file($uploaded_file){
    $this->uploaded_file = $uploaded_file;
  }

  function get_upload_name(){
   return 'image';
  }

  function get_upload_path(){
   return 'wig_images/';
  }




}