<?php 

class FacultyRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'faculty';
 }


}