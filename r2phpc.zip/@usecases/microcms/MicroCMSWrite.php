<?php 

class MicroCMSWrite implements iUseCase{
  
  use EntityUpdateTrait,EntityCreateTrait,EntityUploadTrait{
  	EntityUpdateTrait::Exec as DoUpdate;
    EntityCreateTrait::Exec as DoCreate;
    EntityCreateTrait::GetService insteadof EntityUpdateTrait;
    EntityCreateTrait::GetInput insteadof EntityUpdateTrait;
    EntityCreateTrait::GetOutput insteadof EntityUpdateTrait;
    EntityCreateTrait::Exec insteadof EntityUpdateTrait;
  }
  
  const PATH = 'uploads/microcmspages/';

  
  function Exec(){
    
    $this->DoUpload();

    if ($this->RecordExists(array('name'=>$this->input['data']['name']))){   
      $this->DoUpdate();       
    }else{
      $this->DoCreate();
    }

  }


  function SetUploadedFile($uploaded_file){
   $this->input['data']['image'] = $uploaded_file;
  }

  function GetUploadName(){
    return 'image';
  }

  function GetUploadPath(){
  	return self::PATH;
  }

  function GetTableName(){
  	return 'microcms';
  }

  function GetUpdateMessage(){
  	return 'Content Saved.';
  }

  function GetCreateMessage(){
    return 'Content Added.';
  }


}