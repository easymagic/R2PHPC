<?php 
 
// namespace core\usecases\foo;

 class foo_test implements iusecase{
   
   private $db = null;
   private $email = null;
   private $out = array();

   
     function get_input($input){

     	//throw new \Exception("Error Processing Request");

     }

     function get_output(){
       return $this->out;
     }

     function exec(){
       // $this->db->where(array('id'=>18));
       // $this->db->order('id','desc');
      // $this->db->limit('3,3');
       $users = $this->db->get('admin'); //_where('user',array('surname'=>'AKL123'));

       // print_r($users);
       
       // echo count($users);
       echo 'Triggered.';

       $this->out['users'] = $users;

       // $this->email->send();

     }

     function get_service($services){
      $this->db = $services->get('db');
      // $this->email = $services->get('email');
     }


 }