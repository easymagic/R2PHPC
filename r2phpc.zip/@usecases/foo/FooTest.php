<?php 

class FooTest implements IUseCase{
 
 use EntityTrait;

 private $http = null;

  
  function Exec(){
    
  	$this->output['data'] = '..data..gotten..' . $this->http->DoGet();

  }

  // function InjectServices($Http,$Email){
  //   $this->email = $Email;
  //   $this->http = $Http;
  // }
  
  function Inject($Http){

  	 $this->http = $Http;

  }


}