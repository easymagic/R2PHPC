<?php 

class foo_update implements iusecase{
  
  use entity_update_trait;

  
  //abstract implementations

  function get_table_name(){
  	return 'foo';
  }

  function get_update_message(){
  	return 'foo updated.';
  }



}