<?php 

class AssetLocationUpdate implements IUseCase{
	
	use EntityUpdateTrait;


  function GetTableName(){
    return 'asset_location';
  }

  function GetUpdateMessage(){
  	return 'Location updated.';
  }



}