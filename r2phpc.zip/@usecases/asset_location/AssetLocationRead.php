<?php 

class AssetLocationRead implements IUseCase{

 use EntityReadTrait;

 function GetTableName(){
 	return 'asset_location';
 }


}