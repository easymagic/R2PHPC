<?php 

class category_create implements iusecase{
  
  use entity_create_trait{
  	entity_create_trait::exec as create_entity;
  }
 
  //abstract implementations
  function get_table_name(){
    return 'category';
  }

  function get_create_message(){
    return 'Category created successfully.';
  }

  function exec(){
     
    if (!isset($this->input['go_ahead1'])){
      throw new Exception("Unauthorized action!");
    } 

  	$this->create_entity();

  }

}