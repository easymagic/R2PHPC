<?php 

class VendorFacultyCourseCreate implements IUseCase{
  
  use EntityCreateTrait{
  	EntityCreateTrait::Exec as DoCreate;
  }

  function Exec(){
  	$vendor_id = $this->input['data']['vendor_id'];
  	$faculty_course_id = $this->input['data']['faculty_course_id'];

  	if ($this->RecordExists(array(
     'vendor_id'=>$vendor_id,
     'faculty_course_id'=>$faculty_course_id
  	))){

  		throw new Exception("You have already applied to offer this course!");

  	}else{
  		$this->DoCreate();
  	}
  }


  function GetTableName(){
    return 'vendor_faculty_course';
  }

  function GetCreateMessage(){
    return 'Course Added.';
  }



}