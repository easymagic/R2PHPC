<?php 

class VendorFacultyCourseUpdate implements IUseCase{
	
	use EntityUpdateTrait;


  function GetTableName(){
    return 'vendor_faculty_course';
  }

  function GetUpdateMessage(){
  	return 'Faculty Course updated.';
  }



}