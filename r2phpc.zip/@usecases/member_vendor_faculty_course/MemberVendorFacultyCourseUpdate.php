<?php 

class MemberVendorFacultyCourseUpdate implements IUseCase{
	
	use EntityUpdateTrait;


  function GetTableName(){
    return 'member_vendor_faculty_course';
  }

  function GetUpdateMessage(){
  	return 'Vendor Faculty Course updated.';
  }



}