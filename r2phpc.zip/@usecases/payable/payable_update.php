<?php 

class payable_update implements iusecase{

 
 use entity_update_trait;

 function get_table_name(){
  return  'payable';
 }

 function get_update_message(){
 	return 'Payable updated.';
 }


}