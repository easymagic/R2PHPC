<?php 

class payable_create implements iusecase{

 
 use entity_create_trait;

 function get_table_name(){
  return  'payable';
 }

 function get_create_message(){
 	return 'Payable created.';
 }


}