<?php 

class payable_delete implements iusecase{

 
 use entity_delete_trait;

 function get_table_name(){
  return  'payable';
 }

 function get_delete_message(){
 	return 'Payable removed.';
 }


}