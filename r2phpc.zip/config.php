<?php 

define('BASE_URL', 'http://r2soft.com.ng/wkf/'); // 'http://bytescloud.ng/demo/');
define('DEFAULT_CONTROLLER', 'home');