<?php 
  

  class Email implements iemail{

   private $message = '';
   private $subject = '';
   private $to = '';
   private $from = ''; 
     
  function send(){

    // echo 'Sending email ... ';
   

     $to = $this->to; 
     $subject = $this->subject; 
     $msg = $this->message; 
     $from = $this->from; 

      if (mail(
        $to, 
        $subject, 
        $msg, 
        "From: " . $from . "\n" . 
        "MIME-Version: 1.0\n" .
        "Content-type: text/html; charset=iso-8859-1"
      )){
        //echo 'Sent ..';
      }else{
        //echo 'Not sent ...';  
      }   


  }

  function set_subject($sub){
    $this->subject = $sub;
  }

  function set_message($msg){
    $this->message = $msg;
  }

  function set_to($to){
    $this->to = $to;
  }

  function set_from($from){
    $this->from = $from;
  }

  function TestMessage(){
    return 'Testing mail message ... ';
  }


  }
 
 

