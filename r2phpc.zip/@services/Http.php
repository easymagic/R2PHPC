<?php 

class Http{

   

   function DoPost(){
   	echo 'Posting Http ... ';
   }

   function DoGet(){
   	return 'Getting ...~~~~###';
   }


}