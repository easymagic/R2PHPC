<?php 

class Message{

    private static $msg = array();


    function Set($k,$v){
      self::$msg[$k] = $v;
      $_SESSION['response'] = self::$msg;
    }

    function Get($k){
     if (isset(self::$msg[$k])){
       return self::$msg[$k];
     }else{
     	return null;
     }
    }

    function GetData(){
      return self::$msg;	
    }




}