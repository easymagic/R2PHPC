<?php
 require_once('config.php');
 require_once('app-x/core/core.php');
 // require_once('index.php');
$PageObject = new FrontControllerV2();
$PageObject->LoadPage();
