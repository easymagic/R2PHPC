<?php 
// namespace core\adapters; 	

interface irepo{
 

 function get($table); //vector
 function get_where($table,$criteria); //vector
 function like($criteria);
 function get_like($table,$criteria);
 function where($criteria); //void
 function insert($table,$data); //void
 function update($table,$data); //void
 function delete($table); //void
 function insert_id(); //scalar
 function limit($limit); //void
 function order($order); //void
 function query($sql); //vector //for lazy programmers.
 // function get_count($table); //scalar
 function count_where($table,$criteria); //scalar


}