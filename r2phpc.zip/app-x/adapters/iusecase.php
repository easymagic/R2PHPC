<?php 

// namespace core\adapters;

interface IUseCase{
  

  // function GetInput($input);
  // function GetOutput();
  // function GetService($obj);
  // function Exec();



}