<?php 

// namespace core\adapters;

interface iemail{
  

  function send();
  function set_subject($sub);
  function set_message($msg);
  function set_to($to);
  function set_from($from);



}