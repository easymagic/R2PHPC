<?php 

class FrontControllerV2{

  private $route = '';
  private $args = array();
  private $controller = '';
  private $controller_obj = null;
  private $method = '';

  private static $trackDIControllers = array();


  function __construct(){
  	$this->HandleRequest();
  }


  function HandleRequest(){
	 if (empty($_REQUEST['__request__'])){
	  $this->route = DEFAULT_CONTROLLER;
	 }else{
	  $this->route =  $_REQUEST['__request__']; 	
	 }

	 $this->args = explode('/', $this->route);

	 $this->GetDefaultController();
	 $this->GetDefaultMethod();
	 // $this->LoadPage();

  }

  private function BuildController($name){
    
    $file = "@framework/controllers/" . $name . '.php';

    // echo $file;
    
    require_once($file);

    $cls = $name;

    if (class_exists($cls)){

      // $obj = new $cls();  
      $obj = InjectClass($cls);
      // $this->CheckForComponentInjection($obj);
      // $this->CheckForUseCaseInjections($obj);

    }else{
      $obj = null;
    }

    return $obj;
    
  }

  private function CheckForComponentInjection($obj){
      
      if (method_exists($obj, 'Inject')){
        
        $reflect = new ReflectionMethod($obj,'Inject');
        $params = $reflect->getParameters();

        $args = DoComponentInjection($params,$argsIn=array());

        call_user_func_array(array($obj,'Inject'), $args);

      }
    
  }

  function GetDefaultController(){
    
    $this->controller = array_shift($this->args);

    $this->controller = ucfirst($this->controller);

    if (!$this->ControllerExists($this->controller)){
      $this->controller = DEFAULT_CONTROLLER;
    }

    $this->controller_obj = $this->BuildController($this->controller);

    // $file = "@framework/controllers/" . $this->controller . '.php';

    // // echo $file;
    
    // require_once($file);

    // $cls = $this->controller;

    // if (class_exists($cls)){

    //   $obj = new $cls();	
    //   $this->controller_obj = $obj;

    // }
    


  }

  private function ControllerExists($ctrl){
    $file = "@framework/controllers/$ctrl.php";
    return file_exists($file);
  }

  function GetDefaultMethod(){
    
    $this->method = array_shift($this->args);
    if (empty($this->method))$this->method = 'index';

  }

  function EvalController(){
  	if ($this->controller_obj != null){

       
  		
       if (method_exists($this->controller_obj, $this->method)){
         // echo 'y';

         // AutoInjectMethod($this->controller_obj,$this->method,$this->args);

         // $reflect = new ReflectionMethod($this->controller_obj,$this->method);
         // $params = $reflect->getParameters();
        
         // $args = DoComponentInjection($params,$this->args);

         call_user_func_array(array($this->controller_obj,$this->method), $this->args);
         
       }else{
       	// echo 'n...' . $this->method;
       }
  	}else{
  		// echo 'n';
  	}
  }



  private function CheckForControllerInjections($obj){
     if (method_exists($obj, 'InjectControllers')){
        
        $reflect = new ReflectionMethod($obj,'InjectControllers');

        $params = $reflect->getParameters();

        $ctrlList = array();

        // print_r($params);
        
        foreach ($params as $k=>$v){

          // echo $v->name . '<br />';

           $ctrlList[] = $this->BuildController($v->name);

        }

        call_user_func_array(array($obj,'InjectControllers'), $ctrlList);

        // print_r($reflect);
        // print_r($reflect->getParameters());

        // print_r($ctrlList);

     }
     
  }

  public function ProxyCallUseCase($package){

    return function($input,&$output) use  ($package){
       echo $package;
       CallUseCase($package,$input,$output);
    };

  }


  private function CheckForUseCaseInjections($obj){
     if (method_exists($obj, 'InjectUseCases')){
        
        $reflect = new ReflectionMethod($obj,'InjectUseCases');

        $params = $reflect->getParameters();

        $ctrlList = array();

        // print_r($params);
        
        foreach ($params as $k=>$v){

          $name = $v->name;
          $name = explode('_', $name);
          $name = implode('/', $name);

          // echo $name;

          // echo $v->name . '<br />';
          $ctrlList[] = $this->ProxyCallUseCase($name);



           // $ctrlList[] = array($this,);  //$this->BuildController($v->name);

        }

        // print_r($ctrlList);

        call_user_func_array(array($obj,'InjectUseCases'), $ctrlList);

        // print_r($reflect);
        // print_r($reflect->getParameters());

        // print_r($ctrlList);

     }
     
  }


  function LoadPage(){
    $this->EvalController();
  }



}