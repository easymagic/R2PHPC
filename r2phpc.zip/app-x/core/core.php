<?php 
session_start();

class InjectViewClass{
  
  private $view = null;
  private $vars = null;

   function __construct($obj,$vars){
     $this->view = $obj;
     $this->vars = $vars;
   }

   function __set($k,$v){
     $this->vars[$k] = $v;
   }

   function UpdateVars($vars){
     $this->vars = $vars;
   }

   function View($content = ''){

    $check = explode('_', $this->view);
    $first = array_shift($check);
    $file = '@components/' . implode('/', $check) . '.php';

      extract($this->vars);
      StartBuffer();
      include($file);
      return GetBuffer();

   }


}


class InjectUseCaseClass{
   
   private $name = null;

   function __construct($name){
     $this->name = $name;
   }

   function Exec($input,&$output){
     
     $r = explode('_', $this->name);
     $package = implode('/', $r);
     
     CallUseCase($package,$input,$output);                 

     return $obj;

   }



}



require_once('FrontControllerV2.php');
// require_once('FrontController.php');




 function InitAdapters(){

//   namespace adapters;  
   
   $dir = scandir('app-x/adapters/');

   $dir = array_diff($dir, array('.','..'));

   foreach ($dir as $k=>$v){
      
      require_once('app-x/adapters/' . $v);

   }

   // init_repo_service();
 }

 function InitTraits(){
  
  //base first
  $dir = scandir('@traits/base/');
  $dir = array_diff($dir, array('.','..'));
  foreach ($dir as $k=>$v){
     require_once('@traits/base/' . $v);
  }
  
  //derived second
  $dir = scandir('@traits/derived/');
  $dir = array_diff($dir, array('.','..'));
  foreach ($dir as $k=>$v){
     require_once('@traits/derived/' . $v);
  }



  //ui traits third
  $dir = scandir('@traits/ui/');
  $dir = array_diff($dir, array('.','..'));
  foreach ($dir as $k=>$v){
     require_once('@traits/ui/' . $v);
  }



 }





  function Redirect($page){
   header("location: " . BASE_URL . $page);
   exit();
  }



 function CallUseCase($uc_file,$input,&$output){

    $f1 = explode('/', $uc_file);
    // $cls  = $package . $endPoint;
    $cls = end($f1);

    // $f2 = implode('\\', $f1);
    // $namespc = $f2; // 'core\\usecases\\' . $f2;
    $file = '@usecases/' . $uc_file . '.php';
    // echo $file;

    if (file_exists($file)){
      
      require_once($file);
      
      $obj = InjectClass($cls);//  new $cls();

    

    try {

      $obj->GetInput($input);
      $out = call_user_func_array(array($obj,'Exec'), array());

      $out = $obj->GetOutput();

      foreach ($out as $k=>$v){
        $output[$k] = $v;
      }

      $output['error'] = false;
      
    } catch (Exception $e) {

      $output['error'] = true;
      $output['message'] = $e->getMessage();

      // echo 'hit...' . $e->getMessage();
      
    }


    }

 }


 function ListenForEvents(){
  if (isset($_REQUEST['ccmd'])){
    $ccmd = $_REQUEST['ccmd'];
    unset($_REQUEST['ccmd']);
    $input = $_REQUEST;
    $output = array();
    if (is_array($ccmd)){
      foreach ($ccmd as $k=>$v){

        CallUseCase($v,$input,$output);     

        if ($output['error']){
          break;
        }    

        if (isset($output['data'])){
          foreach ($output['data'] as $k1=>$v1){
            if ($k1 == 'data' && is_array($v1) && isset($input['data'])){
              foreach ($v1 as $k2=>$v2){
                $input['data'][$k2] = $v2;
              }
            }else{
             $input[$k1] = $v1;  
            }
            
          }
        }
      }

    }else{
      CallUseCase($ccmd,$input,$output);
    }
    
    $_SESSION['response'] = $output;
    // print_r($_SESSION['response']);

  }
 }

 function StartBuffer(){
  ob_start();
 }

 function GetBuffer(){
  $r = ob_get_contents();
  ob_end_clean();
  return $r;
 }

 function GetAllBuffer($fn){
    StartBuffer();
    $fn();
    return GetBuffer();
 }
 

 function Template($k,$v=''){
   
   static $data = array();

   if (!empty($v)){
     $data[$k] = $v;
   }

   if (isset($data[$k])){
     return $data[$k];
   }else{
     return '';
   }

   

 }

 function TemplateStart(){
   StartBuffer();
 }

 function TemplateStop($name){
   Template($name,GetBuffer());
 }

 function LogvMessage(){
  //response
  // print_r($_SESSION);
  if (isset($_SESSION['response']))
  extract($_SESSION['response']);
   if (isset($message)){
    if (isset($error) && $error){
       $cls = 'danger';
    }else{
       $cls = 'success';
    }
    ?>
    <div class="alert alert-<?php echo $cls; ?>"><?php echo $message; ?></div>
    <?php
    unset($_SESSION['response']['message']);
   }  

 }


 function SequenceID($id=0){
   
   static $InternalID = 0;

   if ($id > 0)$InternalID = $id;

   return $InternalID++;

 }






  function IsControllerInjection($name){
    $file = "@framework/controllers/$name.php";
    if (file_exists($file)){
      require_once($file);
      return true;
    }else{
      return false; 
    }
  }


  function IsUseCaseInjection($name){
    
    $check = explode('_', $name);
    
    if (count($check) > 1){

      $file = '@usecases/' . $check[0] . '/' . $check[1] . '.php';

      if (file_exists($file)){
        require_once($file);
        return true;
      }else{
        return false;
      }

    }else{
      return false;
    }

  }

  function IsViewInjection($name){
    $check = explode('_', $name);
    $first = array_shift($check);
    $file = '@components/' . implode('/', $check) . '.php';

    if ($first == 'View' && file_exists($file)){
       return true;
    }else{
       return false;
    }

  }

  function InjectView($name,$argsNames){
    $check = explode('_', $name);
    $first = array_shift($check);
    $file = '@components/' . implode('/', $check) . '.php';

    $fn = function($content='') use ($argsNames,$file){
      extract($argsNames);
      StartBuffer();
      include($file);
      return GetBuffer();
    };

    return $fn;

  }

  function IsServiceInjection($name){
   
    $file = "@services/$name.php";
    if (file_exists($file)){
      require_once($file);
      return true;
    }else{
      return false; 
    }   

  }

  function InjectController($name){
    // $obj = new $name();
    // return $obj;
    return InjectClass($name);
  }

  function InjectUseCase($name){
   
   return new InjectUseCaseClass($name); // $obj;

  }

  function InjectService($name){
    // $obj = new $name();
    // return $obj;
    return InjectClass($name);
  }

  function DoComponentInjection($args,$argsIn,$flag='m'){
    
    $newArgs = array();
    $promiseArgs = array();
    $injectNameInstances = array();

     foreach ($args as $k=>$v){
       
       if (IsControllerInjection($v->name)){
        $injectNameInstances[$v->name] = InjectController($v->name);       
        $newArgs[] = $injectNameInstances[$v->name];       
       }else if (IsServiceInjection($v->name)){
        $injectNameInstances[$v->name] = InjectService($v->name);       
        // $newArgs[] = InjectService($v->name); 
        $newArgs[] = $injectNameInstances[$v->name];
       }else if (IsUseCaseInjection($v->name)){
        $injectNameInstances[$v->name] = InjectUseCase($v->name);       
        // $newArgs[] = InjectUseCase($v->name);
        $newArgs[] = $injectNameInstances[$v->name];
       }else if ($v->name == 'data' && $flag == 'f'){
        $injectNameInstances[$v->name] = $argsIn;
        // $newArgs[] = $argsIn;
        $newArgs[] = $injectNameInstances[$v->name];
       }else if (IsViewInjection($v->name)){
         $promiseArgs[$v->name] = count($newArgs); //store the intended index
         $newArgs[] = null;
       }else{
         $argA = array_shift($argsIn);
         $injectNameInstances[$v->name] = $argA;
         // $newArgs[] = $argA;
         $newArgs[] = $injectNameInstances[$v->name];
       }

     }

     foreach ($promiseArgs as $name=>$index){
        
        $injectNameInstances[$name] = InjectView($name,$injectNameInstances);
        $newArgs[$index] = $injectNameInstances[$name];//InjectView($name,$injectNameInstances);

     }

     return $newArgs;

     
  }

  function AutoInjectMethod($obj,$method,$inArgs=array()){

     if (method_exists($obj, $method)){
       $reflect = new ReflectionMethod($obj,$method);
       $params = $reflect->getParameters();
       $args = DoComponentInjection($params,$inArgs); 
       call_user_func_array(array($obj,$method), $args);
     }

  }

  function InjectionStore($k,$v='',$flag='single'){

    static $data = array();

    if (!empty($v) && $flag == 'single'){
      $data[$k] = $v; 
    }

    if ($flag == 'single'){

      if (isset($data[$k])){
        return $data[$k]; 
      }else{
        return '';
      }

    }else{

      return $data;

    }

  }

  function HasInjection($k){
    return !empty(InjectionStore($k));
  }



  function DoComponentInjectionV2($args,$obj){
    
    $promiseArgs = array();
    $injectNameInstances = array();

    $cls = get_class($obj); // get_called_class($obj);

    if (!HasInjection($cls)){

      InjectionStore($cls,$obj);
      
    }

     foreach ($args as $k=>$name){

      $key = $name;
      $r = explode('=', $name);
      
      if (count($r) > 1){

        $key = trim($r[0]);
        $name = trim($r[1]);

      }

      if (!HasInjection($key)){


         if (IsControllerInjection($name)){
          
          // $injectNameInstances[$key] = InjectController($name);       

          InjectionStore($key,InjectController($name));
             
         }else if (IsServiceInjection($name)){
          
          // $injectNameInstances[$key] = InjectService($name);       
          
          InjectionStore($key,InjectService($name));

         }else if (IsUseCaseInjection($name)){
          
          // $injectNameInstances[$key] = InjectUseCase($name);       

          InjectionStore($key,InjectUseCase($name));

         }else if (IsViewInjection($name)){
           $promiseArgs[$key] = $name; //store the intended key
           // $injectNameInstances[$key] = null;       
         }

        
      }
       

     }

     foreach ($promiseArgs as $key=>$name){

      if (!HasInjection($key)){

        InjectionStore($key,new InjectViewClass($name,$injectNameInstances));  

      }
        
    // $injectNameInstances[$key] = new InjectViewClass($name,$injectNameInstances) ;// InjectView($key,$injectNameInstances);

     }

     foreach ($promiseArgs as $key => $name) {
       # code...
        if (HasInjection($key)){
         InjectionStore($key)->UpdateVars(InjectionStore('null','null','all'));  
        }      
      // $injectNameInstances[$key]->UpdateVars();

     }

     
     foreach ( InjectionStore('null','null','all') as $key => $instance ) {
       # code...
       foreach ( InjectionStore('null','null','all') as $key2 => $instance2){
       
          $instance->$key2 = $instance2;

          InjectionStore($key,$instance);

       }

     }


     // print_r(array_keys($injectNameInstances));
     
     return InjectionStore('null','null','all'); // $injectNameInstances;
     
  }



  function Inject($deps=''){

     static $Dependencies = array();

     if ( count(func_get_args()) > 0 ) {
       
       $data = DoComponentInjectionV2(func_get_args());

       foreach ($data as $key => $value) {
         $Dependencies[$key] = $value;
       }

     }

     return $Dependencies;

  }

  function AutoInjectFunction($fn,$inArgs=array()){

     if (function_exists($fn)){
       $reflect = new ReflectionFunction($fn);
       $params = $reflect->getParameters();
       $args = DoComponentInjection($params,$inArgs,'f'); //f - stands for function here .
       call_user_func_array($fn, $args);
     }

  }


  function GetView($viw){
    $file = "@components/$viw.php";
    // echo $file;
    return $file;
  }

  function InjectClass($cls){
    //getDocComment
    $obj = new $cls();
    $reflect = new ReflectionClass($cls);
    $doc = $reflect->getDocComment();
    if (!empty(trim($doc))){

      $r = explode('@Inject(', $doc);
      $r = explode(')', $r[1]);
      $r = $r[0];
      $r = explode(',', $r);
      $r = array_map('trim', $r);

      $injectors = DoComponentInjectionV2($r,$obj);

      foreach ($injectors as $k=>$v){
       $obj->$k = $v;
      }
      
      return $obj;

    }else{
      // return array(); 
      return $obj;  
    }

    // return $r[0];
  }








 ///boostrap here ...
InitAdapters();
InitTraits();
ListenForEvents();

