  <div class="login-wrapper">
    <div class="text-center">
      <?php LogvMessage(); ?>
      <h2 class="fadeInUp animation-delay8" style="font-weight:bold">
        <span class="text-success">Perfect</span> <span style="color:#ccc; text-shadow:0 1px #fff">Admin</span>
      </h2>
    </div>
    <div class="login-widget animation-delay1"> 
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <div class="pull-left">
            <i class="fa fa-lock fa-lg"></i> Login
          </div>

          <div class="pull-right">
            <span style="font-size:11px;">Don't have any account?</span>
            <a class="btn btn-default btn-xs login-link" href="" style="margin-top:-2px;"><i class="fa fa-plus-circle"></i> Sign up</a>
          </div>
        </div>
        <div class="panel-body">
          <form class="form-login" method="post" action="<?php echo BASE_URL; ?>Admin">
            <div class="form-group">
              <label>Username</label>
              <input name="data[email]" type="text" placeholder="Username" class="form-control input-sm bounceIn animation-delay2" >
            </div>
            <div class="form-group">
              <label>Password</label>
              <input name="data[password]" type="password" placeholder="Password" class="form-control input-sm bounceIn animation-delay4">
            </div>
            <div class="form-group">
              <label class="label-checkbox inline">
                <input type="checkbox" class="regular-checkbox chk-delete" />
                <span class="custom-checkbox info bounceIn animation-delay4"></span>
              </label>
              Remember me   
            </div>
    
            <div class="seperator"></div>
            <div class="form-group">
              Forgot your password?<br/>
              Click <a href="login.html#">here</a> to reset your password
            </div>

            <hr/>
              
            <button type="submit" class="btn btn-success btn-sm bounceIn animation-delay5 login-link pull-right"><i class="fa fa-sign-in"></i> Sign in</button>
            <input type="hidden" name="ccmd" value="admin/AdminLogin" />
          </form>
        </div>
      </div><!-- /panel -->
    </div><!-- /login-widget -->
  </div><!-- /login-wrapper -->
