<?php
  $URL = BASE_URL . 'BackEndUI/';
?>  
<!-- dashboard -->
  <!-- Jquery -->
  <script src="<?php echo $URL; ?>js/jquery-1.10.2.min.js"></script>

  <!-- Bootstrap -->
    <script src="<?php echo $URL; ?>bootstrap/js/bootstrap.js"></script>
   
  <!-- Flot -->
  <script src='<?php echo $URL; ?>js/jquery.flot.min.js'></script>
   
  <!-- Morris -->
  <script src='<?php echo $URL; ?>js/rapheal.min.js'></script> 
  <script src='<?php echo $URL; ?>js/morris.min.js'></script>  
  
  <!-- Colorbox -->
  <script src='<?php echo $URL; ?>js/jquery.colorbox.min.js'></script> 

  <!-- Sparkline -->
  <script src='<?php echo $URL; ?>js/jquery.sparkline.min.js'></script>
  
  <!-- Pace -->
  <script src='<?php echo $URL; ?>js/uncompressed/pace.js'></script>
  
  <!-- Popup Overlay -->
  <script src='<?php echo $URL; ?>js/jquery.popupoverlay.min.js'></script>
  
  <!-- Slimscroll -->
  <script src='<?php echo $URL; ?>js/jquery.slimscroll.min.js'></script>
  
  <!-- Modernizr -->
  <script src='<?php echo $URL; ?>js/modernizr.min.js'></script>
  
  <!-- Cookie -->
  <script src='<?php echo $URL; ?>js/jquery.cookie.min.js'></script>
  
  <!-- Perfect -->
  
  <script src="<?php echo $URL; ?>js/app/app_dashboard.js"></script>

  <script src="<?php echo $URL; ?>js/app/app.js"></script>
