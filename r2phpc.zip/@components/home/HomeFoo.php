<?php 

function HomeFoo($name,$foo_FooTest,$age,$Home,$Http){

  $out = array();

  $foo_FooTest(array(),$out);	

  print_r($out);

  $Http->DoPost();

  $Home->Greet() . '<br />';
  
  echo '<br />' . $name . '<br />';
  echo $age . '<br />';




}