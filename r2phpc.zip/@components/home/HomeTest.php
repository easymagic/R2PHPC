<?php 

function HomeTest($data,$foo_FooTest,$Http){
 
 

 // print_r($dt);

	$Http->DoPost();
 
 $foo_FooTest(array(),$data); 

 print_r($data);

 // echo '...component..Home..Test...';


}