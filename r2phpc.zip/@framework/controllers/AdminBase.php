<?php 

/**

//aliasing View_layout_JsBackendDashboard
@Inject(View_admin_Base,
        View_js_include=View_layout_JsBackendDashboard,
        View_layout_JsBackendDefault) 

*/

class AdminBase{

   

    function Base($content=''){
      
      // Inject('View_admin_Base');
      // extract(Inject());

      // echo Component('admin.Base',$content);
      echo $this->View_admin_Base->View($content);	

    }

    function BaseDefault($content=''){

       $this->View_admin_Base->View_js_include = $this->View_layout_JsBackendDefault;
       echo $this->View_admin_Base->View($content);	
    }




}