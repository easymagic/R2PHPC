<?php 

/**

@Inject(Auth, 
        View_admin_Dashboard,
        View_admin_Panel,
        View_admin_Login,Message,
        admin_AdminFetch,DataAdapter,
        AdminBase)

**/

class Admin{

  
  
  function index(){
     
     if ($this->Auth->IsLogged()){
      $this->Panel();
     }else{
      $this->Login();
     }
     

  }

  function Logout(){
    
    $this->Auth->ClearAuth();
    
    $this->Message->Set('message','Just logged out.');
    $this->Message->Set('error',false);

    $this->Login();

  }

  function Login(){

     $this->AdminBase->Base($content=$this->View_admin_Login->View());
    
  }

  function Panel($content=''){

    // $this->DataAdapter->Resolve();

    $result = $this->DataAdapter->Resolve($this->admin_AdminFetch,array());

    // print_r($result);
    
    // $out = array();
    // $this->admin_AdminFetch->Exec(array(),$out);
    // print_r($out);
    // foreach ($result as $k=>$v){

    //   echo json_encode($v) . '<br />';

    // }
    
    if (empty($content)){
       $content = $this->View_admin_Dashboard->View();
    }

    $this->AdminBase->Base($this->View_admin_Panel->View($content));

  }




}