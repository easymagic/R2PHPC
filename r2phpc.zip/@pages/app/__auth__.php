<?php 

$CAN_ACCESS = true;