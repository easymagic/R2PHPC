<?php 

$this->LoadComponent('asset-location-create',array(
 'back_link'=>BASE_URL . 'asset-location/all'
));