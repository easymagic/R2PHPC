<?php 

$this->LoadComponent('asset-location-edit',array(
 'id'=>$ID,
 'back_link'=>BASE_URL . 'asset-location/all'
));

