<?php 

//silent
echo 'Silent...';