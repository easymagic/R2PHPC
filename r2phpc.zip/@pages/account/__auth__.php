<?php 

 $CAN_ACCESS = (isset($_SESSION['user_account']));
