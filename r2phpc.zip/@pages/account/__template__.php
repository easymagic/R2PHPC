<?php 
 include('@pages/__template__.php');
?>