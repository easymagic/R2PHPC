really nice...
<?php 
 
 $output = array();
 
 CallUseCase('user/UserRead',array(),$output);

 print_r($output);
