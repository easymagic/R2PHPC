<?php 
/**

@Inject(Db,Message)

*/
trait EntityCreateTrait{
  
  use EntityTrait;
  // protected $db = null;

  function Exec(){

  	 if (!isset($this->input['data']))
  	 	throw new Exception("The data parameter is required!");

  	 $this->Db->insert($this->GetTableName(),$this->input['data']);

  	 // $this->output['message'] = $this->GetCreateMessage();
     $this->Message->Set('message',$this->GetCreateMessage());
     $this->Message->Set('data',array(
      'id'=>$this->Db->insert_id()
     ));
     
  	 // $this->output['data'] = array(
    //   'id'=>$this->Db->insert_id()
    //  );

  }

  function RecordExists($criteria){
    $this->Db->where($criteria);
    return (count($this->Db->get($this->GetTableName())) > 0);
  }


  abstract function GetTableName();
  abstract function GetCreateMessage();





}