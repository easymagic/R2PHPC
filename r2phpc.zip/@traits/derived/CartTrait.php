<?php 

trait CartTrait{
  
  use EntityTrait;

  protected $db = null;

   
   private function HandleCartActions(){

     if (!isset($this->input['cartCmd']))
      throw new Exception("cartCmd param expected!");


     // if ($this->input['qty'] > 0){
       

         if ($this->input['cartCmd'] == 'add'){

           if (!isset($this->input['id']))
            throw new Exception("id param expected!");


           if (!isset($this->input['qty']))
            throw new Exception("qty param expected!");


           $this->Add($this->input['id']);

         }else if ($this->input['cartCmd'] == 'remove'){
           
           $this->Remove($this->input['id']);

         }else{ //default to showing contents of the cart.

         }

     // } 

   }

   private function InitCart(){
    
    if (!isset($_SESSION[$this->GetCartName()]))
      $_SESSION[$this->GetCartName()] = array();


   }

   private function GetCartTableSchema($id){

     $record = $this->db->get_where($this->GetTableName(),array(
      $this->GetCartIdName()=>$id
     ));

     if (count($record) > 0){
       return $record[0]; 
     }else{
       return array();
     }

   } 

   private function Add($id){

    if (isset($_SESSION[$this->GetCartName()][$id])){
       
       $_SESSION[$this->GetCartName()][$id]['qty'] = $this->input['qty'];
       //get_cart_price_name
       $_SESSION[$this->GetCartName()][$id]['total_price'] = $_SESSION[$this->GetCartName()][$id][$this->GetCartPriceName()] * $_SESSION[$this->GetCartName()][$id]['qty'];

       $_SESSION[$this->GetCartName()][$id]['date_created'] = date('Y-m-d h:i:s');

    }else{

      $obj = $this->GetCartTableSchema($id);
      $obj['qty'] = $this->input['qty'];
      $obj['total_price'] = $obj[$this->GetCartPriceName()] * $obj['qty'];
      $obj['date_created'] = date('Y-m-d h:i:s');

      $_SESSION[$this->GetCartName()][$id] = $obj;

    }


   }

   private function Remove($id){
     if (isset($_SESSION[$this->GetCartName()][$id])){
       unset($_SESSION[$this->GetCartName()][$id]);
     }
   }

   private function FormatOutput(){
    $r = $_SESSION[$this->GetCartName()];
    $rr = array();
    foreach ($r as $k=>$v){

       $rr[] = $v;

    }

    $this->output['data'] = $rr;

   }
   
   function Exec(){
    
    $this->InitCart();
    $this->HandleCartActions();

    $this->FormatOutput();
      
   } 


  function InjectServices($Db){
     $this->db = $Db;
  }


   abstract function GetCartName();
   abstract function GetTableName();
   abstract function GetCartIdName();
   abstract function GetCartPriceName();



}