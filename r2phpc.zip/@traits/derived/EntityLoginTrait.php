<?php 
/**

 @Inject(Message,Db)


*/

trait EntityLoginTrait{


  
  use EntityTrait;
  // protected $db = null;

  function Exec(){

    // Inject('Message','Db');
    // extract(Inject());

     $auth_fields = $this->GetAuthFields();

     // print_r($this->input);

     if (!isset($this->input['data']))
       throw new Exception("data field required!");

     $username = $this->input['data'][$auth_fields['username']];
     $password = $this->input['data'][$auth_fields['password']];

     $this->Db->where(array(
      $auth_fields['username']=>$username,
      $auth_fields['password']=>$password,
     ));

  	 $data = $this->Db->get($this->GetTableName());
     
     if (count($data) > 0){
      if ($data[0][$this->GetStatusField()] == 1){
        $_SESSION[$this->GetSessionName()] = $data[0];
      }else{
        throw new Exception($this->GetLoginStatusFailureMessage());  
      }
      
     }else{
      throw new Exception($this->GetLoginFailureMessage());
     }

     $this->Message->Set('message',$this->GetLoginSuccessMessage());
     $this->Message->Set('data',$data[0]);

     // return array(
     //  'message'=>$this->GetLoginSuccessMessage(),
     //  'data'=>$data[0]
     // );

  	 // $this->output['message'] = $this->GetLoginSuccessMessage();
  	 // $this->output['data'] = $data[0];

  }

  // function Inject($Db){
  //    $this->db = $Db;
  // }  


  abstract function GetTableName();
  abstract function GetSessionName();
  abstract function GetAuthFields();
  abstract function GetLoginSuccessMessage();
  abstract function GetLoginFailureMessage();
  abstract function GetLoginStatusFailureMessage();
  abstract function GetStatusField(); //status (1 or 0)





}