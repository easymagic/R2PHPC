<?php 

trait EntityRoleActionsTrait{

 


 private $role_map = array();



 function AddRoleAction($role,$module,$create=false,$read=false,$update=false,$delete=false){

 	 $this->role_map[] = array(
      'role'=>$role,
      'module'=>$module,
      'create'=>$create,
      'read'=>$read,
      'update'=>$update,
      'delete'=>$delete
 	 );

 }


 function HasRoleAction($role,$module,$action){
   $found = false;
   foreach ($this->role_map as $k=>$v){

   	 if ($v['role'] == $role && $v['module'] == $module && $v[$action]){
      $found = true;
      break;
   	 }

   }
   return $found;
 }



}

