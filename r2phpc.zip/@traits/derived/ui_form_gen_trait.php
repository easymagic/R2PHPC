<?php 

trait ui_form_gen_trait{
  
  private $form_config = array(); 



  function gen_form(){

    $r = array();
    
    $this->form_config = $this->get_form_config();

    foreach ($this->form_config as $k=>$v){

      if (in_array($v['type'], array('text','password','email','number','date','file'))){
        $r[] = $this->xml_wrap_input($v['label'],  $this->xml_input($v['name'],$v['value'],$v['type'],$v['required']));
      }else if ($v['type'] == 'textarea'){
        $r[] = $this->xml_wrap_input($v['label'], $this->xml_textarea($v['name'],$v['value'],$v['required'])); 
      }else if ($v['type'] == 'select'){
        $r[] = $this->xml_wrap_input($v['label'], $this->xml_select($v['name'],$v['key'],$v['value'],$v['data'],$v['required']));
      }

    }

   return implode('', $r);

  }

  private function xml_inline($tag,$attribs=array()){
   return "<$tag " . implode(' ', $attribs) . " />";
  }

  private function xml_pair($tag,$attribs=array(),$data=''){
    return "<$tag " . implode(' ', $attribs) . ">" . $data . "</$tag>";
  }

  private function xml_wrap_input($label,$input){
    
    $r = array();
    $r[] = $this->xml_pair('div',array('class="col-xs-12"'),
                         $this->xml_pair('label',array(),$label)
                        );
    $r[] = $this->xml_pair('div',array('class="col-xs-12"'),$input);

    return implode('', $r);

  }

  private function xml_collection_pair($tag,$key,$value,$collection=array()){
    $r = array();
    foreach ($collection as $k=>$v){

      if ($key == '$index' && $value == '$index'){
        $ikey = $v;
        $ivalue = $ikey;
      }else{
        $ikey = $v[$key];
        $ivalue = $v[$value];
      }

      $r[] = $this->xml_pair($tag , array('value="' . $ikey . '"'), $ivalue);

    }
    return implode('', $r);
  }

  private function xml_input($name,$value,$type='text',$required=false){

    if ($required){
      $required = 'required = "" ';  
    }else{
      $required = '';
    }

    return $this->xml_inline('input',array('class="form-control"','value="' . $value . '"','type="' . $type . '"','name="' . $name . '"',$required));

  }

  private function xml_select($name,$key,$value,$data=array(),$required=false){

    if ($required){
      $required = 'required = "" ';  
    }else{
      $required = '';
    }

    return $this->xml_pair('select',array('class="form-control"',$required),
                           $this->xml_collection_pair('option',$key,$value,$data)
                          );
  }

  private function xml_textarea($name,$value,$required=false){
    if ($required){
      $required = 'required = "" ';  
    }else{
      $required = '';
    }

   return $this->xml_pair('textarea',array('class="form-control"','name="' . $name . '"',$required),$value);
   
  }



  abstract function get_form_config();  //array of array containing key->value data - items.
  






}


///mathew 25 (Transfer of earthly wealth to spiritual wealth.)

///malachi 3:8-10
//nehemiah 10:38
