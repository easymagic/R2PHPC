<?php 

/**

@Inject(Db,Message)

*/

trait EntityUpdateTrait{
  
  use EntityTrait;
  // protected $db = null;

  function Exec(){

  	 if (!isset($this->input['where']))
  	 	throw new Exception("The where parameter is required!");
  	 if (!isset($this->input['data']))
  	 	throw new Exception("The data parameter is required!");

  	 $this->Db->where($this->input['where']);
  	 $this->Db->update($this->GetTableName(),$this->input['data']);
     $this->Message->Set('message',$this->GetUpdateMessage());
  	 // $this->output['message'] = $this->GetUpdateMessage();
     $this->Message->Set('data',$this->input['data']);
  	 // $this->output['data'] = $this->input['data'];

  }


  abstract function GetTableName();
  abstract function GetUpdateMessage();





}