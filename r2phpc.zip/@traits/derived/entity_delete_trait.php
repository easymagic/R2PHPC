<?php 

trait entity_delete_trait{
  
  use EntityTrait;
  protected $db = null;

  function Exec(){

  	 if (!isset($this->input['where']))
  	 	throw new Exception("The where parameter is required!");

  	 $this->db->where($this->input['where']);
  	 $this->db->delete($this->get_table_name());
  	 $this->output['message'] = $this->get_delete_message();
  	 $this->output['data'] = $this->input['where'];

  }

  function GetService($service_locator){
    $this->db = $service_locator->get('db');
  }

  abstract function get_table_name();
  abstract function get_delete_message();





}