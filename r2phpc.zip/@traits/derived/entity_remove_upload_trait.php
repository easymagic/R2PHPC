<?php 

trait entity_remove_upload_trait{
  
   
  function remove_upload(){

    $file_data = $_FILES[$this->get_upload_name()];

    $file = $this->get_upload_path() .  $this->get_file_name();
    
    if (file_exists($file)){
      @unlink($file);
    }

  } 

  // abstract function set_uploaded_file($uploaded_file);
  // abstract function get_upload_name();
  abstract function get_file_name();
  abstract function get_upload_path();




}