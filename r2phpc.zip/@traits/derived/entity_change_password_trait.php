<?php 

trait entity_change_password_trait{
  
  use EntityTrait;
  protected $db = null;

  function Exec(){

  	 if (!isset($this->input['where']))
  	 	throw new Exception("The where parameter is required!");

     if (!isset($this->input['data']))
      throw new Exception("The data parameter is required!");

     if (!isset($this->input['data']['password1']))
      throw new Exception("The data.password1 parameter is required!");

     if (!isset($this->input['data']['password2']))
      throw new Exception("The data.password2 parameter is required!");
    
    if ($this->input['data']['password1'] != $this->input['data']['password2']
   
     ||  

    (empty($this->input['data']['password1']) || empty($this->input['data']['password2'])) ){
     
     throw new Exception($this->get_change_password_failure_message());

    }else{

     $this->db->where($this->input['where']);
     $this->db->update($this->get_table_name(),array(
      $this->get_password_map_field()=>$this->input['data']['password1']
     ));
     $this->output['message'] = $this->get_change_password_success_message();
     $this->output['data'] = $this->input['data'];

    }


  }

  function GetService($service_locator){
    $this->db = $service_locator->get('db');
  }

  abstract function get_table_name();
  abstract function get_password_map_field();
  abstract function get_change_password_success_message();
  abstract function get_change_password_failure_message();





}