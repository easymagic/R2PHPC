<?php 

trait ControllerCRUDTrait{

  private $entity = ''; 
  private $entityUcFirst = '';

  function __construct(){
    if (!isset($_SESSION['user_account']))Redirect('home/index');
    $this->entity = strtolower($this->GetEntityName());
    $this->entityUcFirst = ucfirst($this->entity);
    $this->entityUcFirst = explode('_', $this->entityUcFirst);
    $this->entityUcFirst = array_map('ucfirst', $this->entityUcFirst);
    $this->entityUcFirst = implode('', $this->entityUcFirst);
  }

  private function GetEntityPartialResolvedPackage(){
   return $this->entity . '.' . $this->entityUcFirst;
  }
  

  function index(){
    //category.Category
    echo Component('layout.main',array(
     'content'=>Component($this->GetEntityPartialResolvedPackage() . 'List',array(
        'title'=>$this->GetEntityTitle(),
        'edit_url'=>BASE_URL . $this->entityUcFirst . '/edit/',
        'add_url'=>BASE_URL . $this->entityUcFirst . '/add'
      ))
    ));
    

  }

  function add(){
    
    echo Component('layout.main',array(
      'content'=>Component($this->GetEntityPartialResolvedPackage() . 'Add',array(
       'back_link'=>BASE_URL . $this->entityUcFirst
     ))
    ));
     

  }

  function edit($id=''){
     
     echo Component('layout.main',array(
       'content'=>Component($this->GetEntityPartialResolvedPackage() . 'Edit',array(
          'back_link'=>BASE_URL . $this->entityUcFirst,
          'id'=>$id
       ))
     ));
    


  }


  abstract function GetEntityName();
  abstract function GetEntityTitle();



}