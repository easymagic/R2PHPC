<?php 

trait admin_login_trait{
 
 

 private $data = array();
 
 function index(){

   $this->check_security();

   $this->load_header();
   // $this->load_vars();
   $this->load_content();
   $this->load_footer();

 }

 private function load_header(){
  $this->data['page_title'] = $this->get_page_title();
  $this->load_view('traits_ui/admin/header_admin',$this->data);
 }

 private function load_content(){
   $this->data['login_usecase'] = $this->get_login_usecase();
   $this->data['login_title'] = $this->get_login_title();
   $this->load_view('traits_ui/admin/login_admin',$this->data);
 }

 private function load_footer(){
  $this->load_view('traits_ui/admin/footer_admin',$this->data);
 }

 private function check_security(){
  if (isset($_SESSION[$this->get_admin_session_name()])){
     redirect($this->get_admin_panel_route());
  }
 }








 //abstract definitions 
 abstract function load_view($view,$data);
 abstract function get_page_title();
 abstract function get_login_title();
 abstract function get_login_usecase();
 abstract function get_admin_panel_route();
 abstract function get_admin_session_name();

}