<?php 

trait admin_panel_trait{
 
 

 private $data = array();
 
 function index(){

   $this->check_security();

   $this->load_header();
   // $this->load_vars();
   $this->load_content();
   $this->load_footer();

 }

 private function load_header(){
  $this->data['page_title'] = $this->get_page_title();
  $this->load_view('traits_ui/admin/header_admin',$this->data);
 }

 private function load_content(){
   // $this->data['login_usecase'] = $this->get_login_usecase();
   $this->data['panel_title'] = $this->get_panel_title();
   $this->data['admin_menu'] = $this->get_admin_menu();
   $this->data['logout_usecase'] = $this->get_logout_usecase();
   $this->data['default_route'] = $this->get_default_route();
   $this->load_view('traits_ui/admin/panel_admin',$this->data);
 }

 private function load_footer(){
  $this->load_view('traits_ui/admin/footer_admin',$this->data);
 }

 private function check_security(){
  if (!isset($_SESSION[$this->get_admin_session_name()])){
     redirect($this->get_admin_login_route());
  }
 }








 //abstract definitions 
 abstract function load_view($view,$data);
 abstract function get_page_title();
 abstract function get_panel_title();
 abstract function get_login_usecase();
 abstract function get_admin_login_route();
 abstract function get_default_route();
 abstract function get_admin_session_name();
 abstract function get_admin_menu();
 abstract function get_logout_usecase();

}