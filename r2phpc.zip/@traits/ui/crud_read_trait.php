<?php 

trait crud_read_trait{
 
 // use ui_form_gen_trait;

 private $data = array();
 
 function index(){

   $this->load_header();
   $this->load_vars();
   $this->load_content();
   $this->load_footer();

 }

 private function load_header(){
  $this->load_view('traits_ui/admin/header_app_admin',$this->data);
 }

 private function load_content(){
   $this->load_view('traits_ui/crud/crud_read',$this->data);
 }

 private function load_footer(){
  $this->load_view('traits_ui/admin/footer_admin',$this->data);
 }


 private function load_vars(){
   $this->data['title'] = $this->get_title();
   $this->data['back_link'] = $this->get_back_link();
   $this->data['table_config'] = $this->get_table_config();

   $input = array();
   
   if (!empty($this->get_where_filter())){
    $input['where'] = $this->get_where_filter();
   }

   if (!empty($this->get_like_filter())){
    $input['like'] = $this->get_like_filter();
   }

   if (!empty($this->get_limit_filter())){
    $input['limit'] = $this->get_limit_filter();
   }

   if (!empty($this->get_order_filter())){
    $input['order'] = $this->get_order_filter();
   }

   $output = array();
   call_usecase($this->get_table_usecase(),$input,$output);
   $this->data['data'] = $output['data'];
   $this->data['row_op'] = array($this,'get_row_operation');
   $this->data['edit_route'] = $this->get_edit_route();
 }






 //abstract definitions 
 abstract function load_view($view,$data);
 abstract function get_title();
 abstract function get_back_link();
 abstract function get_table_config();  //associative array collection.
 abstract function get_table_usecase();
 abstract function get_row_operation($row_data);
 abstract function get_edit_route();

 abstract function get_where_filter();
 abstract function get_like_filter();
 abstract function get_limit_filter();
 abstract function get_order_filter();



}