<?php 

trait crud_create_trait{
 
 use ui_form_gen_trait;

 private $data = array();
 
 function index(){

   $this->load_header();
   $this->load_vars();
   $this->load_content();
   $this->load_footer();

 }

 private function load_header(){
  // $this->data['page_title'] = $this->get_page_title();
  // $this->data['social_links'] = $this->get_social_links();
  // $this->data['nav_menu'] = $this->get_nav_menu();
  $this->load_view('traits_ui/admin/header_app_admin',$this->data);
 }

 private function load_content(){
   $this->load_view('traits_ui/crud/crud_create',$this->data);
 }

 private function load_footer(){
  $this->load_view('traits_ui/admin/footer_admin',$this->data);
 }


 private function load_vars(){
   $this->data['create_usecase'] = $this->get_usecase();
   $this->data['title'] = $this->get_title();
   $this->data['back_link'] = $this->get_back_link();
   $this->data['form'] = $this->gen_form();
   $this->data['button_label'] = $this->get_button_label();
  // $this->data['use_gallery'] = $this->use_gallery();
  // $this->data['galleries'] = $this->get_gallery();
 }






 //abstract definitions 
 abstract function load_view($view,$data);
 abstract function get_usecase();
 abstract function get_title();
 abstract function get_back_link();
 abstract function get_button_label();
 abstract function get_form_config();  //array of array containing key->value data - items.
 



}