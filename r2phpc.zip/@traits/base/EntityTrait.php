<?php 


trait EntityTrait{

  
  protected $input = array();
  protected $output = array();

  function GetInput($in){
    $this->input = $in;
  }

  function GetOutput(){
    // extract(Inject('Message'));
  	return $this->Message->GetData();
  }

  // abstract function Exec();

  // abstract function GetService($service_locator);



}