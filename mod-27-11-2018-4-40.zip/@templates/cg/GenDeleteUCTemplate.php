

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class <?php echo $name; ?>Delete{

 
 function Exec(){
   
   $data1 = $this->DataRequirement->Check('id');
   $id = $data1['id'];

   foreach ($id as $ID){
    $this->Db->Where('id',$ID);
    $this->Db->Delete('<?php echo strtolower($name); ?>');
   }


   $this->RequestResponse->SetResponse('message','<?php echo $name; ?> removed successfully.');

 }


}