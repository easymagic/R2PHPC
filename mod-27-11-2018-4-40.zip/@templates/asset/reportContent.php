<div class="card">

<div style="padding: 17px;">
  <img src="<?php echo BASE_URL; ?>images/logo.jpg" style="height: 60px;" />
</div>


                <div class="card-body">




                  <h4 class="card-title" align="center">Asset Report From <i style="color: #bbb;">(<?php echo $from; ?> - <?php echo $to; ?>)</i>  </h4>
                  <p class="card-description">
                    
                  </p>
                  <div>



                    <table class="table" id="asset-listing">
                      <thead>
                        <tr>
                          <th>S/N</th>
                          <th>Description</th>
                          <th>Category</th>
                          <th>Location</th>                          
                          <th>Purchased</th>     
                          <th>Serial.</th>
                          <th>Vendor</th>
                          <th>Price</th>
                        </tr>
                      </thead>
                      <tbody id="tbody">

                        <?php 
                         $sum = 0;
                         foreach ($list as $k=>$v){

                           $sum+=$v['purchase_price'];

                          ?>

                        <tr>
                          <td><?php echo ($k+1); ?></td> 
                          <td><?php echo $v['description']; ?></td>
                          <td><?php echo $v['asset_category_id']; ?></td>
                          <td><?php echo $v['asset_location_id']; ?></td>                          
                          <td><?php echo $v['date_purchased']; ?></td>     
                          <td><?php echo $v['serial_number']; ?></td>
                          <td><?php echo $v['bought_from']; ?></td>
                          <td><?php echo $v['purchase_price']; ?></td>
                        </tr>

                          <?php 

                         }
                        ?>





                        <tr>
                          <td colspan="7" align="right"><b>Total</b></td> 
                          <td><b><?php echo number_format($sum); ?></b></td> 
                        </tr>




                      </tbody>
                    </table>

                    <?php 
              // print_r($list);
                    ?>



                  </div>

                </div>
</div>                                      	
