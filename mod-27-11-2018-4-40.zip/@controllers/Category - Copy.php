<?php 

/**

@Inject(@services/Input,
        @templates/category/ShowTemplate,
        @templates/category/ListTemplate);

*/


class Category{

  
  function Index(){
    // echo 'Cat.Index.';
    echo $this->ListTemplate->View();
  }

  function Edit($id=''){   
   $this->ShowTemplate->label = 'Save';
   echo $this->ShowTemplate->View();
  }


  function Remove($id=''){   
   $this->ShowTemplate->label = 'Remove';
   echo $this->ShowTemplate->View();
  }

  function Add(){
   $this->ShowTemplate->label = 'Add';
   echo $this->ShowTemplate->View();    
  }

}
 