<?php 

class admin_login implements iusecase{
  
  use entity_login_trait;

  
  //abstract implementations

  function get_table_name(){
    return 'admin';
  }


  function get_session_name(){
   return 'admin_account';
  }

  function get_auth_fields(){
    return array(
     'username'=>'email',
     'password'=>'password'
    );
  }


  function get_login_success_message(){
   return 'Login Successful.';
  }


  function get_login_failure_message(){
   return 'Invalid login!';
  }

  function get_status_field(){
    return 'status';
  }

  function get_login_status_failure_message(){
    return 'Your account has been deactivated!';
  }


}