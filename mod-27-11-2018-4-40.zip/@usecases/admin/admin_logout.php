<?php 

class admin_logout implements iusecase{
  
  use entity_logout_trait;

  
  //abstract implementations

  function get_logout_message(){
    return 'Just logged out!';
  }

  function get_session_name(){
    return 'admin_account';
  }


}