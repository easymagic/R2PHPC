<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class CategoryDelete{

 
 function Exec(){
   
   $data1 = $this->DataRequirement->Check('id');
   $id = $data1['id'];

   foreach ($id as $ID){
    $this->Db->Where('id',$ID);
    $this->Db->Delete('category');
   }


   $this->RequestResponse->SetResponse('message','Category removed successfully.');

 }


} 