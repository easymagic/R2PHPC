<!-- csv operation -->
<?php 

// print_r($_SESSION['response']['csv_data']);

 if (isset($_SESSION['response']['csv_data'])){
?>
<form method="post" enctype="multipart/form-data">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // print_r($_SESSION);
 // LogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Map CSV Fields</h4>
                      <p class="card-description" align="right">
            <a href="<?php echo BASE_URL; ?>Asset" class="btn btn-default">Back</a>
                      </p>
                      <!-- <form class="forms-sample"> -->

                        <?php 
                         foreach ($_SESSION['response']['asset_fields'] as $k=>$v){
                        ?>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Select Field For (<b><?php echo implode(' ', array_map('ucfirst',explode('_', $v)) ); ?></b>)</label>
                          <select class="form-control" name="fields[<?php echo $v; ?>]">
                             <?php 
                               foreach ($_SESSION['response']['csv_data']['header'] as $k1=>$v1){
                             ?>
                            <option value="<?php echo $k1; ?>"><?php echo $v1; ?></option>
                            <?php 
                             }
                            ?>
                          </select>
                        </div>

                        <?php 
                         }
                        ?>


                        <button type="submit" class="btn btn-success mr-2">Bulk Create</button>
                      <!-- </form> -->
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="asset/AssetLoadCSVToDb" />
<input type="hidden" name="data[created_by]" value="<?php echo $created_by; ?>" />

   

</div>

</form>  
<?php 
 }
?>           

<!-- csv operation -->


<!-- asset-create -->
<form method="post" enctype="multipart/form-data">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // print_r($_SESSION);
 // LogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Asset Import CSV</h4>
                      <p class="card-description" align="right">
            <a href="<?php echo BASE_URL; ?>Asset" class="btn btn-default">Back</a>
                      </p>
                      <!-- <form class="forms-sample"> -->

                        <div class="form-group">
                          <label for="exampleInputEmail1">Select CSV File</label>
                          <input type="file" name="csv" />
                        </div>


                        <button type="submit" class="btn btn-success mr-2">Submit</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                      <!-- </form> -->
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="asset/AssetImportCSV" />
<!-- <input type="hidden" name="data[created_by]" value="<?php //echo $created_by; ?>" /> -->

   

</div>

</form>             