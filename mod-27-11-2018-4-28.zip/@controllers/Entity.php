<?php
/**

@Inject(@services/CommandSignal,
        @usecases/entity/EntityRead,
        @declarations/custom/UserDefined,
        @controllers/Base,
        @templates/entity/EntityListTemplate,
        @templates/entity/EntityAddTemplate,
        @templates/entity/EntityEditTemplate,
        @templates/entity/EntityCheckBoxTemplate,
        @templates/entity/EntityToolTemplate);

*/

class Entity{
  
   
   function Index($entity='admin'){
    $this->ListEntity($entity);
   }

   function Init(){
    $this->CommandSignal->HandleEvents($this);
   }

   private function GetTargetTemplate($entity,$suffix){
     return $entity . $suffix . 'Template';
   }

   function ListEntity($entity='admin'){
    $record = $this->EntityRead->Fetch($entity);
    
    $Template = $this->GetTargetTemplate($entity,'TableHeader');
    $this->EntityListTemplate->TableHeaderTemplate = $this->$Template;

    $Template = $this->GetTargetTemplate($entity,'TableRow');
    $this->EntityListTemplate->TableRowTemplate = $this->$Template;

    $Template = $this->GetTargetTemplate($entity,'Post');
    $this->EntityListTemplate->PostTable = $this->$Template;


    $this->EntityListTemplate->data = $record;
    $this->EntityListTemplate->entity = $entity;
    
    $this->Base->Layout($this->EntityListTemplate->View());

   }

   function AddEntity($entity='admin'){

    $this->EntityAddTemplate->message = $this->MessageLogger->GetMessageTemplate();

    $Template = $this->GetTargetTemplate($entity,'Add');
    $this->EntityAddTemplate->AddTemplate = $this->$Template;
    $this->EntityAddTemplate->entity = $entity;

    $this->Base->Layout($this->EntityAddTemplate->View());

   }

   function EditEntity($entity='admin',$id=0){

    $record = $this->EntityRead->Fetch($entity,$id);

    if (count($record) > 0){
      $record = $record[0];
    }


    $Template = $this->GetTargetTemplate($entity,'Edit');
    $this->EntityEditTemplate->$Template = $this->$Template;
    $this->EntityEditTemplate->entity = $entity;

    $this->EntityEditTemplate->data = $record;

    $this->Base->Layout($this->EntityEditTemplate->View());
       
   }

   function EntityCheckBox($value=0){

     $checked = '';
     if ($value == 1){
      $checked = ' checked=checked ';
     }
     $this->EntityCheckBoxTemplate->checked = $checked;
     return $this->EntityCheckBoxTemplate->View();

   } 
  
  
 
}