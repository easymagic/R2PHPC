<!-- CreateTemplate -->
<form method="post" enctype="multipart/form-data">
<div><?php echo $content; ?></div>
<div align="right" style="border-top: 1px solid #aaa;margin-top: 7px;padding-top: 7px;">

  <?php echo $ccmd; ?>
  
  <input type="submit" value="Create" />
  <input type="reset" value="Clear" />

</div>
</form>