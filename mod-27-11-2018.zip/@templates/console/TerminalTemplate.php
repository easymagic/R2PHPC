terminal template ....
<?php 
 // $Test->Foo();
 $Category->Greet();

 $UIComponent->SetKey('gender','m');
 
 echo $UIComponent->GetSelect(array(
   'name'=>'gender',
   'data'=>array(
     'm'=>'Male',
     'f'=>'Female',
   )
 ));


 $UIComponent->SetKey('name','Test Name...123');

 $UIComponent->SetKey('wig','wig/wig.jpg');
 
 $UIComponent->EncloseKeys('data');



 echo $UIComponent->GetEntry(array(
   'label'=>'Select Category',
   'name'=>'data[category]',
   'type'=>'SelectData',
   'entity'=>'category',
   'data-label'=>'name',
   'data-value'=>'id'
 ));


 echo $UIComponent->GetSelectRange(array(
   'name'=>'gender2',
   'min'=>11,
   'max'=>20,
   'step'=>1.5
 ));

 echo $UIComponent->GetInput(array(
  'name'=>'data[name]',
  'type'=>'text'
 ));


 echo $UIComponent->GetEntry(array(
  'name'=>'data[name]',
  'label'=>'<b>E-mail:</b>',
  'type'=>'text'
 ));

 echo $UIComponent->GetEntry(array(
  'name'=>'data[password]',
  'label'=>'<b>Password:</b>',
  'type'=>'password',
  'placeholder'=>''
 ));


 $UIComponent->SetKey('login-button','Login.');

 echo $UIComponent->GetEntry(array(
  'label'=>'',
  'type'=>'SubmitButton',
  'name'=>'login-button'
 ));



 $UIComponent->SetKey('ccmd[]','entity/EntityCreate');

 echo $UIComponent->GetEntry(array(
  'label'=>'',
  'type'=>'CMD'
 ));


 $UIComponent->SetKey('ccmd[]','entity/EntityCreate2');

 echo $UIComponent->GetEntry(array(
  'label'=>'',
  'type'=>'CMD'
 ));





 echo $UIComponent->GetEntry(array(
  'label'=>'Wig Image',
  'name'=>'data[wig]',
  'type'=>'Image'
 ));


 echo $UIComponent->GetEntry(array(
  'label'=>'Wig Image',
  'name'=>'data[wig]',
  'type'=>'File'
 ));

?>