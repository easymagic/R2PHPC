<select class="form-control" name="data[asset_location_id]" data-value="<?php echo $value; ?>">
<option value="">--Select--</option>
<?php 
 foreach ($data as $k=>$v){
 
 ?>
 <option value="<?php echo $v['name']; ?>"><?php echo $v['name']; ?></option>
 <?php 

 }
?>

</select>
