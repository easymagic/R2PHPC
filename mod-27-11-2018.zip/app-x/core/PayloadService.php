<?php 

/**

@Inject(@services/RequestResponse);

*/

class PayloadService{
  
     private $data = array();
    
     function DecodePayload(){
       $requestBody = file_get_contents('php://input');
       $this->data = json_decode($requestBody,true);
       // print_r($this->data);
     }

     function ExportPayload(){
      return $this->data;
     }




  
}