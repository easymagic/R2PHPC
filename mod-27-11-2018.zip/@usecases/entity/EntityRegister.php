<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/EmailQueue);


*/
class EntityRegister{
  
  private $entity = '';

  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     $this->entity = $this->EntityCommit->GetEntity();
     
     if (!isset($request['data']))throw new Exception("data-param required!", 1);
     if (!isset($request['data']['email']))throw new Exception("data-email-param required!", 1);
     
     $this->CheckEmailExistence($request['data']['email']);
     $this->CheckPassword($request);


     $this->EntityCommit->CheckFileUpload($request);
     $this->EntityCommit->CheckDataFileUpload($request);

     $this->EntityCommit->DoAdd($request);
     $newID = $this->Db->InsertID();
     $this->SendVerificationEmail('id',$newID);

     $this->RequestResponse->SetResponse('message','Registration successful, check your email for verification.');

  }

  function GetData($k,$v){

  	 $record = $this->Db->Where($k,$v)->Get($this->entity);
  
  	 if (count($record) > 0){
       throw new Exception("This account does not exist!", 1);
  	 }

  	 $record = $record[0];

  	 return $record;

  }

  private function GetVerifyLink($id){
    return '<a href="' . BASE_URL . $this->entity . '/VerifyAccount/' . base64_encode($id) . '">link</a>';
  }

  function SendVerificationEmail($k,$v){
     
     $data = $this->GetData($k,$v);
     $msg = '<b>Dear user,</b><br /> 
             Your registration at domain.com was successful,<br />
             Click on the ' . $this->GetVerifyLink($data['id']) . ' to verify your account.
             <br /><br />
             <b>Regards.</b>';

     $this->EmailQueue->SetSubject('VERIFICATION FROM SITE.COM');             
     $this->EmailQueue->SetMessage($msg);
     $this->EmailQueue->SetTo($data['email']);
     $this->EmailQueue->SetFrom('info@site.com');
     $this->EmailQueue->Send();

  }

  private function CheckEmailExistence($email){ //required in every registration systems.
    $record = $this->Where('email',$email)->Get($this->entity);
    if (count($record) > 0){
      throw new Exception("An account with this email already exists!", 1);
    }
  }

  function CheckPassword($request){

  	if (!isset($request['data']['password']))throw new Exception("data-password param required", 1);
  	if (!isset($request['password2']))throw new Exception("password2 param required", 1);
  	
    
    $password1 = $request['data']['password'];
    $password2 = $request['password2'];

    if ($password1 != $password2 || empty($password1)){
      throw new Exception("Invalid Password!", 1);
    }

  }




}

