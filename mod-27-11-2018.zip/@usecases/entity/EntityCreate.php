<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);


*/
class EntityCreate{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     $this->EntityCommit->CheckDuplicateRecord($request);
     $this->EntityCommit->CheckFileUpload($request);
     $this->EntityCommit->CheckDataFileUpload($request);
     return $this->EntityCommit->DoAdd($request);

  }


}

