<?php 


class HttpService{

  
   function Dispatch($route){
     // $PageObject = DIContainer::GetInstance()->InjectClass('FrontController'); 
     $dt = $this->FrontController->GetDispatch($route,array('Authorization'=>'secret_key101'));
     return json_decode($dt,true);
   }  





}