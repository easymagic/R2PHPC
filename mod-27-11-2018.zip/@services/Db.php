<?php

/**

@Inject(@services/Message,@services/DataAdapter,
        @services/DataDict);

*/


  class Db{
     //@services/Db,
     private static $connection = null;
     private $whereString = '';
     private $limit_ = '';
     private $orderString = '';
     
     function __construct(){
      $this->InitConnection();
     }

     // private function ReMapFields($recordset=array()){

     //   $record = array();

     //   foreach ($recordset as $rset){

     //     $data = array();

     //      foreach ($rset as $k=>$v){

     //        if ($this->DataDict->HasKey($k)){
     //          $data[$k . 'Transform'] = $this->DataDict->GetField($k,$v);
     //        }
            
     //        $data[$k] = $v; //$this->DataDict->GetField($k,$v);

             

     //      }

     //      $record[] = $data;

     //   }

     //   return $record;

     // }

     private function ResetFilters(){
      $this->whereString = '';
      $this->limit_ = '';
      $this->orderString = '';
     }

     private function InitConnection(){
       if (self::$connection == null){
         self::$connection = mysqli_connect('localhost',
                                            'root',
                                            '',
                                            'db_wig'); // or die('Error in connection.');

         // echo self::$connection;
       }
     }

     private function get_criteria_clause($where,$sep=' = ',$comparator=' and '){
       $r = array();

       foreach ($where as $k=>$v){
         $r[] = " $k $sep '$v' ";
       }

       if (!empty($r)){
          return ' where (' . implode($comparator, $r) . ') ';
       }else{
          return '';
       }
     }

     private function get_insert_query($data){
      
      $keys = array_keys($data);
      $values = array_values($data);

      return "(" . implode(',', $keys) . ") values ('" . implode("','", $values) . "')";

     }

     private function get_update_query($data){
      $r = array();
      foreach ($data as $k=>$v){
        // $v = mysqli_escape_string($v,self::$connection);
        $r[] = " $k = '$v' ";
      }
      return ' set ' . implode(' , ', $r) . ' ';
     }

     private function exec_query($sql){
      // echo "$sql";
      $this->ResetFilters();//this avoids conflict with other queries.   
      return  mysqli_query(self::$connection,$sql);
     }

     private function query_result($query){
      $r = array();
    while ($data = mysqli_fetch_assoc($query)){
          $r[] = $data;
    }

    // $r = $this->ReMapFields($r);

     // print_r($r);
    return $r;
     }
   

 private function record_retrieve_query($sql){
  $sql = $sql . ' ' . $this->orderString . ' ' . $this->limit_;
  return $sql;
 }   

 function Get($table){
   
   $sql = $this->record_retrieve_query("select * from $table " . $this->whereString);

    // echo $sql;


   return $this->query_result($this->exec_query($sql));

 }

 function SetWhereString($whereString){
  $this->whereString = ' where ' . $whereString;
 }
 

 function Where($k,$v,$comparator='=',$open='',$close=''){
   
   if (empty($this->whereString)){

     $this->whereString = " where $open$k$comparator'$v'$close "; 
     return $this;

   }else{

    return $this->And($k,$v,$comparator,$open,$close);

   }

 }

 function And($k,$v,$comparator='=',$open='',$close=''){
  if (empty($this->whereString)){
    return $this->Where($k,$v,$comparator,$open,$close);
  }else{
    $this->whereString = $this->whereString . " and $open$k$comparator'$v'$close "; 
    return $this;
  }
 }

 function Or($k,$v,$comparator='=',$open='',$close=''){
  if (empty($this->whereString)){
    return $this->Where($k,$v,$comparator,$open,$close);
  }else{
    $this->whereString = $this->whereString . " or $open$k$comparator'$v'$close "; 
    return $this;
  }  
 }


 function Insert($table,$data){
   $sql = "insert into $table " . $this->get_insert_query($data);
   return $this->exec_query($sql);   
 }

 function Update($table,$data){
   $sql = "update $table " . $this->get_update_query($data) . $this->whereString;
   return $this->exec_query($sql);   
 }

 function Delete($table){
   $sql = "delete from $table " . $this->whereString;
   return $this->exec_query($sql);   
 }

 function InsertID(){
    return mysqli_insert_id(self::$connection); 
 }

 function Limit($limit){
  $this->limit_ = " limit $limit ";
  return $this;
 }

 function Order($order){
  $this->orderString = " order by $order ";
  return $this;
 }

 function Query($sql){ //for record retrieval only.
   
   $sql = $this->record_retrieve_query($sql);
   return $this->query_result($this->exec_query($sql));

 }

 function DoCount($table,$alias='recordCount'){
   $sql = $this->record_retrieve_query("select count(*) as $alias from $table " . $this->whereString);
   return $this->query_result($this->exec_query($sql));     
 }


 function DoSum($table,$field,$alias='sumTotal'){
   $sql = $this->record_retrieve_query("select sum($field) as $alias from $table " . $this->whereString);
   // echo "$sql";
   return $this->query_result($this->exec_query($sql));     
 }





 function TableExists($table=''){
  $sql = "show tables";
  // echo 'iiii';
  $record = $this->query_result($this->exec_query($sql));
  $r = array();
  foreach ($record as $k=>$v){
     foreach ($v as $k1=>$v1){
       $r[] = $v1;
     }
  }
  
  return in_array($table, $r);
  
 }




  }
 
 

