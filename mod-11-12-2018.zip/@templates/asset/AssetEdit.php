<?php 


 $data = $data[0];

 // $locations = $data;

?>
<!-- asset-create -->
<form method="post">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // LogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Edit Asset</h4>
                      <p class="card-description" align="right">
            <a href="<?php echo BASE_URL; ?>Asset" class="btn btn-default">Back</a>
                      </p>
                      <form class="forms-sample">


<div class="row">


<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Select Category</label>
                          <div class="col-md-9">
                           <?php 
                            echo $Category->CategorySelect($data['asset_category_id']);
                           ?>                              
                         </div>

                        </div>
</div>


<div class="col-md-6">                        


                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Select Location</label>

                          <div class="col-md-9">
                            <?php 
                             echo $Location->LocationSelect($data['asset_location_id']);
                            ?>                            
                         </div>

                        </div>
</div>


<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Description</label>
                          <div class="col-md-9">
                          <textarea class="form-control" name="data[description]"><?php echo $data['description'] ?></textarea>
                          </div>

                        </div>
</div>


<div class="col-md-6">

                        <div class="form-group row">
                          
                          <label class="col-md-3" for="exampleInputEmail1">Serial-Number</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[serial_number]" value="<?php echo $data['serial_number'] ?>" />
                          </div>

                        </div>
</div>

<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Bought From</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[bought_from]"  value="<?php echo $data['bought_from'] ?>" />
                           </div>
                        </div>
</div>


<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Purchase Price</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[purchase_price]" value="<?php echo $data['purchase_price'] ?>" />
                          </div>
                        </div>
</div>


<div class="col-md-6">

                        <div class="form-group row">
                          
                          <label class="col-md-3" for="exampleInputEmail1">Replacement Value</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[replacement_value]" value="<?php echo $data['replacement_value'] ?>" />
                          </div>

                        </div>
</div>


<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Current Value</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[current_value]" value="<?php echo $data['current_value'] ?>" />
                           </div>
                        </div>
</div>

<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Date Purchased</label>


<div class="col-md-9">
<div class="input-group" data-target="#timepicker-example" data-toggle="datetimepicker">

                          <input data-date-format="yyyy-mm-dd" data-trigger="#icon-trigger1" data-datepicker class="form-control" name="data[date_purchased]" value="<?php echo $data['date_purchased'] ?>" />


                          <div id="icon-trigger1" class="input-group-addon input-group-append"><i class="mdi mdi-clock input-group-text"></i></div>
</div>                          
</div>





                        </div>

</div>


<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Notes</label>

                          <div class="col-md-9">
                          <textarea class="form-control" name="data[notes]"><?php echo $data['notes'] ?></textarea>
                          </div>

                        </div>

</div>



<div class="col-md-6">

                        <button type="submit" class="btn btn-success mr-2">Save</button>
                        <!-- <button type="reset" class="btn btn-light">Cancel</button> -->

</div>


</div>

                      </form>
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="asset/AssetUpdate" />
<input type="hidden" name="where[id]" value="<?php echo $id; ?>">
<input type="hidden" name="data[created_by]" value="<?php echo $created_by; ?>" />

   

</div>

</form>             


<script type="text/javascript">
  (function($){
    $(function(){
      $('input').each(function(){
        $(this).attr('required','1');
      });
      $('select').each(function(){
        $(this).attr('required','1');
      });
    });
  })(jQuery);
</script>