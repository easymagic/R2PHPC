<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class CategoryUpdate{

 
 function Exec(){
   
   $data1 = $this->DataRequirement->Check('data','id');
   $data = $data1['data'];
   $id = $data1['id'];
   
   foreach ($id as $ID){
    $this->Db->Where('id',$ID);

    $this->Db->Update('category',$data);
   }

   $this->RequestResponse->SetResponse('message','Category updated successfully.');

 }


} 