<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class WigUpdate{

 
 function Exec(){
   
   $data1 = $this->DataRequirement->Check('data','id');
   $data = $data1['data'];
   $id = $data1['id'];
   
   foreach ($id as $ID){
    $this->Db->Where('id',$ID);

    $this->Db->Update('wig',$data);
   }

   $this->RequestResponse->SetResponse('message','Wig updated successfully.');

 }


} 