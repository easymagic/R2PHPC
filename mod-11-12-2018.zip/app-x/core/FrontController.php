<?php 

/**
@Inject(app-x/core/PluginLoader,
        app-x/core/Router,
        app-x/core/RequestResponse);
*/


class FrontController{
  

  private $obj = null;
  private $name = '';
  private $method = 'Index';
  private $args = array();
  private $plugins = array();
  private $request = array();
  private $parentLookOut = array('dba'=>'DbaV2');
  private $headers = array();




  function __construct(){}

  // private function CheckParentLookOut($name){
  //   if (in_array($name, array_keys($this->parentLookOut))){
  //     // array_unshift($this->args,$this->name);
  //     array_unshift($this->args,$this->method);
  //     $this->name  = $this->parentLookOut[$name];
  //     $this->method = 'Map'; //http://localhost/forde/Dba/category/[ShowList,Add,Edit]
  //     $controllerPath = '@controllers/' . $this->name;
  //     $this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

  //   }
  // }

  function GetDispatch($route,$headers_=array()){
    global $headers;
    foreach ($headers_ as $k=>$v){
      $headers[$k] = $v;
    }
    // global $name;
    // global $action;
    // global $args;

    // $this->headers = $headers;
    $this->request = $route; // $_REQUEST['__request__'];
    // $this->RequestResponse->SetRequest($_REQUEST);
    $r = explode('/', $this->request);

    if (count($r) >= 1){
     $name = array_shift($r);
     $action = array_shift($r);
     $args = $r;
    }else{
     $name = DEFAULT_CONTROLLER;
    }

    if (empty($action) || is_numeric($action)){
     $action = 'Index';
    }

    $controllerPath = '@controllers/' . $name;

    $name = strtolower($name);

    $obj = InjectKey($controllerPath); // DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

    $plugins = $this->DecodePluginUse($obj);
    
    return $this->DispatchRequest_($plugins,$obj,$name,$action,$args);

  }

  // function GetHeaders(){
  //   return $this->headers;
  // }

  function DispatchRequest(){
     return $this->GetDispatch($_REQUEST['__request__']);
  }


  function DecodePluginUse($obj){
      
      $plugins = array();
      
      if (method_exists($obj, 'UsePlugins')){
       $plugins = $obj->UsePlugins();
      }

      return $plugins;

     // print_r($this->plugins);
  }

 
  function DispatchRequest_($plugins,$obj,$name,$method,$args){

   $buffer = ''; 
   
   try {

    if (method_exists($obj, 'GetEntity_Hook')){
       $name = $obj->GetEntity_Hook();
    }
     
     $buffer = $this->Router->Dispatch($plugins,$obj,$name,$method,$args);
     
   } catch (Exception $e) {
     
     $buffer = $e->getMessage();

   }

   return $buffer;


  }






}