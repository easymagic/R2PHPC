<?php 
session_start();


$data = array();
$dataJSON = array();
$dependencyData = array();
$plugins = array();
$args = array();
$name = '';
$action = '';
$headers = array();
$headers = getallheaders();
extract($headers);

/////Decode Payload (As a side Effect)////////
$requestBody = file_get_contents('php://input');
$requestBodyData = array();

if (!empty($requestBody) && is_array(json_decode($requestBody,true))){
 $requestBodyData = json_decode($requestBody,true);	
 foreach ($requestBodyData as $k=>$v){
    $_REQUEST[$k] = $v;
    $_POST[$k] = $v;
 }
}

$request = &$_REQUEST;
$response = array();
$post = &$_POST;
$postData = array();
if (isset($post['data'])){
 $postData = $post['data'];
}
$get = &$_GET;
$session = &$_SESSION;
// $accounts = array('accounts'=>array('admin'));
$accounts = array();
if (isset($session['accounts'])){
  $accounts = $session['accounts'];
}

$actionPermission = true;
$permission = true;
$redirect = '';

//Cron-Jobs
$emailQueue = array();

//Cart - Vars
$cart = array();
$addCart = '';
$removeCart = '';
$cartTotalQty = 0;
$cartTotalPrice = 0;
//Db - Vars
$newID = 0;
$hashID = 0;
$hashedID = '';

//Pagination - Vars
$page = '';
$rpp = '';
if (isset($_GET['rpp']) && is_numeric($_GET['rpp'])){
  $rpp = $_GET['rpp'];
}
if (isset($_GET['page']) && is_numeric($_GET['page'])){
  if (empty($rpp)){
   $rpp = 5;
  }
  $page = ($_GET['page'] - 1) * $rpp;
}

function StartBuffer(){
 ob_start();
}

function GetBuffer(){
 $r = ob_get_contents();
 ob_end_clean();
 return $r;
}

function ActionTrigerred(){
	return (isset($_POST) && !empty($_POST));
}

function EndsWith($str,$ends){
 $end = substr($str, -1 * strlen($ends));
 $end = strtolower($end);
 if ($end == strtolower($ends)){
  return true;
 }else{
  return false;
 }
}



class InjectViewClass{
  
   private $view_ = null;

   function __construct($view){
     $this->view_ = $view;
   }


   function Render(){

   	 global $dependencyData;
   	 global $data;
    
      $file = $this->view_ . '.php';

      if (file_exists($file)){
        $tmp = null;

        if (isset($data['data'])){
          $tmp = $data['data'];
          unset($data['data']);
          $data['data_renamed'] = $tmp;
        }
        extract($data);

        if (isset($dependencyData['data'])){
          $tmp = $dependencyData['data'];
          unset($dependencyData['data']);
          $dependencyData['data_renamed'] = $tmp;
        }
        extract($dependencyData);
        StartBuffer();
        include($file);
        return GetBuffer();
      }else{
      	return '';
      }

   }


}


function InjectClass($cls){
 return DIContainer::GetInstance()->InjectClass($cls);
}


function InjectKey($depStr){
 
  global $dependencyData;	
  
  $file = $depStr . '.php';
  // echo $file;
  $obj  = null;

  if (file_exists($file)){
    

    $r = explode('/', $depStr);

    $package = array_shift($r);

    $cls = end($r);

    if (!isset($dependencyData[$cls])){

        if ($package == '@templates' || substr($cls, -8) == 'Template'){ 

        	$dependencyData[$cls] = new InjectViewClass($depStr);

            $obj =  $dependencyData[$cls]; 
 
        }else{   

          require_once($file);                         

          $dependencyData[$cls] = InjectClass($cls);   

          
          $obj =  $dependencyData[$cls]; 

        }



    }else{

      $obj =  $dependencyData[$cls]; 
      
    }


  }

  return $obj;

}


require_once('FrontController.php');
require_once('DIContainer.php');



