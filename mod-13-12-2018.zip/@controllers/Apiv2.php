<?php
/**

@Inject(@services/HttpService);

*/


class Apiv2{
  
  
  function UsePlugins(){
  	return array('APIPluginv2','APIPermissionPlugin'); //'APIPermissionPlugin'
  }
  
  

 
}