<?php 

/**

@Inject(@usecases/entity/EntityCreate,
        @usecases/entity/EntityRead,
        @usecases/entity/EntityUpdate,
        @usecases/entity/EntityDelete,
        @services/RequestResponse,
        @services/Input,
        @services/FormTrigger,
        @services/entity/EntityCommit,
        @services/View);

*/

class DbaV2{
  

  private $verbs = array('login','ShowList','Add','Edit');
  

  function Map($entity='admin',$method='login'){
    
    $args = func_get_args();
    array_shift($args);
    array_shift($args);
    array_unshift($args,$entity);

    $this->ObjectProxy->CallProxy($this,$method,$args);

  }

  function Map_Action($entity='admin',$method='login'){

    $args = func_get_args();
    array_shift($args);
    array_shift($args);
    array_unshift($args,$entity);

    $this->ObjectProxy->CallProxy($this,$method . '_Action',$args);
    
  }

  //ShowList,Add,Edit

  function ShowList(){
    print_r(func_get_args());
   echo 'Showing List ....';
  }

  function Add($entity){

  }

  function Edit($entity,$id){

  }


  //Actions.
  function ShowList_Action($entity){

  }

  function Add_Action($entity){

  }

  function Edit_Action($entity,$id){

  }




}