<?php
/**

@Inject(@services/PluginAdapter,
        @plugins/HelloWorldPlugin);

*/


class Test{
   
  function Init(){
    $this->PluginAdapter->Install($this->HelloWorldPlugin);
    // $this->PluginAdapter->Install($this->HelloWorldPlugin);
    // $this->PluginAdapter->Install($this->HelloWorldPlugin);
  }    
 
  function Index(){
  	global $buffer;
  	global $contentType;
  	global $json;

  	$json['version'] = 'n.0.0';
  	$json['FrameworkName'] = 'RONE';

  	// $contentType = 'json';

  	StartBuffer();

  	?>
    <form method="post">
    	<input type="text" name="name" placeholder="Name">
    	<button>Post</button>
    </form>
  	<?php 

  	$buffer.=GetBuffer();

  	$buffer.= '<br />Hello world buffer';
  }

  // function Index_Action(){
  // 	global $buffer;

  // 	$buffer.= 'Trigerred from user-defined.';
  // }


 
}