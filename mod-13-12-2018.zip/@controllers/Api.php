<?php
/**

@Inject(@services/HttpService);

*/


class Api{
  
  
  function UsePlugins(){
  	return array('APIPlugin','APIPermissionPlugin');
  }
  
  

 
}