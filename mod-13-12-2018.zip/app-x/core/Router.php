<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/RequestResponse,
        app-x/core/EmailQueue,
        @services/PluginAdapter);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;
   


  function Dispatch($obj){

    // global $data;
    global $json;
    global $actionPermission;
    global $permission;
    // global $accounts;
    global $serverJobs;
    global $contentType;
    global $routeName;
    global $routeAction;
    global $routeArgs;
    global $buffer;
    // global $redirect;

    
    $method = $routeAction;
    $args = $routeArgs;

    // echo $routeAction;
    // echo $routeName;


    $this->CallAction($obj,$method . '_Init',$args);

    if (ActionTrigerred()){

      $this->CallAction($obj,$method . '_ActionPermission',$args);

       if ($actionPermission){
         $this->CallAction($obj,$method . '_Action',$args);        
       }else{
         throw new Exception("You do not have the permission to call this action!");
       }

    }else{

       $this->CallAction($obj,$method . '_NoAction',$args);

    }

    //call server-jobs handlers
    foreach ($serverJobs as $serverJob){
       if (method_exists($serverJob, 'PostJob')){
         $serverJob->PostJob(); //execute each job
       }
    }
    

    $this->CallAction($obj,$method . '_Permission',$args);

    if ($permission){


       $this->CallAction($obj,$method,$args);

    }else{
      
      throw new Exception("You do not have the permission to view this page!");

    }

    //check content-type
    if ($contentType == 'json'){
      $buffer = json_encode($json);
    }

    
    // return $buffer;

  }



  function CallAction($obj,$method,$args){

      if (isset($obj->PluginAdapter)){
        array_unshift($args, $method);
        $this->ObjectProxy->CallProxy($obj->PluginAdapter,'RaiseEvent',$args); 
      }
      $this->ObjectProxy->CallProxy($obj,$method,$args);

      

  }




}