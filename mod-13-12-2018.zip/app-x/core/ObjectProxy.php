<?php 

class ObjectProxy{
  
  function CallProxy($obj,$method='index',$args=array()){
  	if (empty($method)){

  		$method = 'Index';

  	}

  	if (method_exists($obj, $method)){
      return call_user_func_array(array($obj,$method), $args);
  	}else{
  	  return null;	
  	}
    
  }


  
}