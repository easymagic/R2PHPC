<?php 

class HelloWorldPlugin{

  

    function Index(){
      global $buffer;

      $buffer.= 'Modified from HelloWorldPlugin.';
    }

    function Index_Action(){
      global $buffer;

      $buffer.= 'Action Triggerred From Plugin.';

    }


}