<?php 
/**

@Inject(@services/Db);

*/

class AdminFetch{
   
  private $in = array();
  private $out = array(); 
   
  function GetInput($in){
    $this->in = $in;

    if (isset($this->in['filter'])){

    	$filter = $this->in['filter'];

    	$keys = array_keys($filter);
    	$values = array_values($filter);

    	foreach ($keys as $index=>$key){

           if ($index == 0){
             $this->Db->Where($key,$values[$index],'=','(');
           }else{
           	 if ($index == count($keys) - 1){
           	  // echo $index;	
              $this->Db->And($key,$values[$index],'=','',')');	
           	 }else{
           	  $this->Db->And($key,$values[$index]);	
           	 }
             
           }

    	}


    	// $this->Db->Where('id',2)->And('name','foo')->Get('admin');

    	
    	


    }	

  }
  
  //abstract implementations
  function Exec(){
  	$this->out['data'] = $this->Db->Get('admin');
  	// $this->out['data'] = $this->Db->DoCount('admin');
  }

  function GetOutput(){
   return $this->out;
  }



}