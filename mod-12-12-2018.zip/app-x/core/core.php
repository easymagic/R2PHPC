<?php 
session_start();

//Cron-Jobs
//init server jobs here
$serverJobs = array();
$jobDir = scandir('@jobs');
$jobDir = array_diff($jobDir, array('.','..'));

foreach ($jobDir as $currentJob){
  $currentJob = explode('.', $currentJob);
  $currentJob = $currentJob[0];
  require_once('@jobs/' . $currentJob . '.php');
  if (class_exists($currentJob)){
    $$currentJob = InjectClass($currentJob);
    $serverJobs[$currentJob] = $$currentJob;
  }
}



function StartBuffer(){
 ob_start();
}

function GetBuffer(){
 $r = ob_get_contents();
 ob_end_clean();
 return $r;
}

function ActionTrigerred(){
	return (isset($_POST) && !empty($_POST));
}

function EndsWith($str,$ends){
 $end = substr($str, -1 * strlen($ends));
 $end = strtolower($end);
 if ($end == strtolower($ends)){
  return true;
 }else{
  return false;
 }
}



class InjectViewClass{
  
   private $view_ = null;

   function __construct($view){
     $this->view_ = $view;
   }


   function Render(){

   	 global $dependencyData;
   	 global $data;
    
      $file = $this->view_ . '.php';

      if (file_exists($file)){
        $tmp = null;

        if (isset($data['data'])){
          $tmp = $data['data'];
          unset($data['data']);
          $data['data_renamed'] = $tmp;
        }
        extract($data);

        if (isset($dependencyData['data'])){
          $tmp = $dependencyData['data'];
          unset($dependencyData['data']);
          $dependencyData['data_renamed'] = $tmp;
        }
        extract($dependencyData);
        StartBuffer();
        include($file);
        return GetBuffer();
      }else{
      	return '';
      }

   }


}


function InjectClass($cls){
 return DIContainer::GetInstance()->InjectClass($cls);
}


function InjectKey($depStr){
 
  global $dependencyData;	
  
  $file = $depStr . '.php';
  // echo $file;
  $obj  = null;

  if (file_exists($file)){
    

    $r = explode('/', $depStr);

    $package = array_shift($r);

    $cls = end($r);

    if (!isset($dependencyData[$cls])){

        if ($package == '@templates' || substr($cls, -8) == 'Template'){ 

        	$dependencyData[$cls] = new InjectViewClass($depStr);

            $obj =  $dependencyData[$cls]; 
 
        }else{   

          require_once($file);                         

          $dependencyData[$cls] = InjectClass($cls);   

          
          $obj =  $dependencyData[$cls]; 

        }



    }else{

      $obj =  $dependencyData[$cls]; 
      
    }


  }

  return $obj;

}





