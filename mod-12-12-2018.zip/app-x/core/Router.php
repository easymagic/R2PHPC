<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/RequestResponse,
        app-x/core/EmailQueue);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;
   

  // private function HandleRedirects(){
  // }

  // private function HandleEmailQueue(){
  // }

  // private function HandleCartOperations(){
  // }

  // private function HandleHashing(){

  // }

  function Dispatch($plugins,$obj,$name,$method,$args){

    global $data;
    global $dataJSON;
    global $actionPermission;
    global $permission;
    global $accounts;
    global $serverJobs;
    // global $redirect;

    $buffer = '';

    $this->CallAction($obj,$method . '_PageStart',$args);

    if (ActionTrigerred()){

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_ActionPermission',$args);
       if ($actionPermission){
         $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Action',$args);
         $this->CallAction($obj,$method . '_Action',$args);
       }else{
        throw new Exception("You do not have the permission to call this action!");
       }

    }else{

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_NoAction',$args);

    }

    //call server-jobs handlers
    foreach ($serverJobs as $serverJob){
       if (method_exists($serverJob, 'PostJob')){
         $serverJob->PostJob(); //execute each job
       }
    }
    

    //handle $accounts
    // if (isset($accounts['accounts']))
    // foreach ($accounts['accounts'] as $k=>$accountSessionName){
    //   $accountSessionName = ucfirst($accountSessionName);
    //   $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Logged_' . $accountSessionName,$args);
    // }


    

    if ($permission){

       $test = $this->CallAction($obj,$method,$args);
       if (!empty($test)){
        $buffer.=$test;
       }
       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Data',$args);

       foreach ($data as $k=>$v){
         if (!is_object($v)){
           $dataJSON[$k] = $v;
         }
       }

       $buffer.= $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Render',$args);

    }else{
      
      throw new Exception("You do not have the permission to view this page!");

    }

    
    return $buffer;

  }



  function CallAction($obj,$method,$args){

      return $this->ObjectProxy->CallProxy($obj,$method,$args);

  }




}