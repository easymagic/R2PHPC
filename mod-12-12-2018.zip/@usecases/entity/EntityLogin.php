<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);


*/
class EntityLogin{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     // print_r($request);
     $this->EntityCommit->RequireEntity($request);
     $entity = $this->EntityCommit->GetEntity();
     $this->CheckParams($request);

     $email = $request['email'];
     $password = $request['password'];

     $record = $this->Db->Where('email',$email)->And('password',$password)->Get($entity);

     if (count($record) <= 0){
       throw new Exception("Invalid login!", 1);
     }

     $record = $record[0];
     
     if (isset($record['verified'])){
      if ($record['verified'] != '1'){
        throw new Exception("Please verify your account from the mail sent to You.");
      }
     }



     if (!isset($_SESSION['accounts'])){
      $_SESSION['accounts'] = array();
     }

     $_SESSION['accounts'][$entity] = $record;

     $this->RequestResponse->SetResponse('message','Access granted.');

  }

  private function CheckParams($request){
    if (!isset($request['email']) || !isset($request['password'])){
     throw new Exception("email and/or password param required!", 1);
    }
  }



}

