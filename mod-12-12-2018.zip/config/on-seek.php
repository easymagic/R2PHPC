<?php 

// $config['admin1'] = array(
//  array('id',4)
// );

$config['category9'] = array(
 array('id','>= 59 ')
);