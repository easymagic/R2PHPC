<?php

 // Provide('user.UserRead',array(
 //   'where'=>array(

 //   )
 // ));

 // global $data;
 

// print_r($data_sum_purchase_price); 
 

 // print_r($data);

 // if ( count($data) > 0 ){
  // $data = $data['data'];
?>
<div class="card">
                <div class="card-body">
                  <div>
                    <?php LogvMessage(); ?>
                  </div>
                  <h4 class="card-title">User Accounts</h4>
                  <p class="card-description" align="right">
                     <a class="btn btn-default" href="<?php echo BASE_URL; ?>Home/AddAccount">+ Add User</a>
                  </p>
                  <div class="table-responsive">


                    <table class="table">
                      <thead>
                        <tr>
                          <th>E-mail</th>
                          <th>Role</th>
                          <th>Status</th>                          
                        </tr>
                      </thead>
                      <tbody id="tbody">
                       <?php 
                        foreach ($data as $k=>$v){
                          if ($v['id'] != $_SESSION['user_account']['id']){
                       ?>

                       <tr>
                         <td><?php echo $v['email']; ?></td>
                         <td><?php echo $v['role']; ?></td>
                         <td><?php echo ($v['active'] == 1)? 'Active':'Not Active'; ?></td>
                         <td>
                          <?php 
                           if ($_SESSION['user_account']['role'] == 'admin'){
                             
                             if ($v['active'] == 1){

                              ?>
                              <a class="btn btn-danger" href="?ccmd=user/UserDeactivate&id=<?php echo $v['id']; ?>">Deactivate</a>
                              <?php 

                             }else{

                              ?>
                               <a class="btn btn-success" href="?ccmd=user/UserActivate&id=<?php echo $v['id']; ?>">Activate</a>
                              <?php 

                             }
                           ?>
                           
                           
                           <?php 

                           }
                          ?>
                         </td>
                       </tr>

                       <?php 
                         }
                        }
                       ?>                        



                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
<?php 

 // }else{
 //  echo 'No Captured Assets.';
 // }

?>