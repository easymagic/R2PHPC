<!-- asset-create -->
<form method="post">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // LsogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Add Asset</h4>
                      <p class="card-description" align="right">
            <a href="<?php echo BASE_URL; ?>Asset" class="btn btn-default">Back</a>
                      </p>
                      <!-- <form class="forms-sample"> -->

                        <div class="row">


<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Select Category</label>
                          <div class="col-md-9">
                           <?php 
                            echo $Category->CategorySelect('');
                           ?>  
                          </div>

                        </div>
</div>


<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Select Location</label>
                          <div class="col-md-9">
                            <?php 
                             echo $Location->LocationSelect('');
                            ?>
                          </div>
                        </div>
</div>



<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Description</label>
                          <div class="col-md-9">
                          <textarea class="form-control" name="data[description]"></textarea>
                          </div>
                        </div>

</div>


<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Serial-Number</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[serial_number]" />
                          </div>
                        </div>
</div>

<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Bought From</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[bought_from]" />
                          </div> 
                        </div>
</div>


<div class="col-md-6">                        

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Purchase Price</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[purchase_price]" />
                          </div>
                        </div>
</div>


<div class="col-md-6">

                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Replacement Value</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[replacement_value]" />
                          </div>
                        </div>
</div>


<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Current Value</label>
                          <div class="col-md-9">
                          <input type="text" class="form-control" name="data[current_value]" />
                          </div>
                        </div>
</div>


<div class="col-md-6">



                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Date Purchased</label>



<div class="col-md-9">
<div class="input-group" data-target="#timepicker-example" data-toggle="datetimepicker">

                          <input data-date-format="yyyy-mm-dd" autocomplete="off" data-trigger="#icon-trigger1" data-datepicker class="form-control" name="data[date_purchased]" />


                          <div id="icon-trigger1" class="input-group-addon input-group-append"><i class="mdi mdi-clock input-group-text"></i></div>
</div>  
</div>                        

                        </div>

</div>


<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-md-3" for="exampleInputEmail1">Notes</label>
                          <div class="col-md-9">
                          <textarea class="form-control" name="data[notes]"></textarea>
                          </div>
                        </div>
</div>



<div class="col-md-6">

                        <button type="submit" class="btn btn-success mr-2">Submit</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                      <!-- </form> -->

</div>                      
                      </div>

                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="asset/AssetCreate" />
<input type="hidden" name="data[created_by]" value="<?php echo $created_by; ?>" />

   

</div>

</form>             

<script type="text/javascript">
  (function($){
    $(function(){
      $('input').each(function(){
        $(this).attr('required','1');
      });
      $('select').each(function(){
        $(this).attr('required','1');
      });
    });
  })(jQuery);
</script>