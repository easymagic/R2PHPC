<!DOCTYPE html>
<html>
<head>
	
	<title>Admin Back-End.</title>
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>bootstrap/css/bootstrap.min.css" />


</head>
<body>
  
  <?php 
    echo $content;
  ?>

</body>
</html>