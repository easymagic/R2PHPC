<?php 
 echo $Base->Tool($entity);
?>
<div class="col-xs-12">

<form method="post" enctype="multipart/form-data">
   

   <div class="col-xs-12">


    <div class="panel panel-default">
      <div class="panel-heading">
        head
      </div>
      <div class="panel-content">
        content...
      </div>
      <div class="panel-footer clearfix">
        <div class="pull-right">
           <input type="submit" value="Add" class="btn btn-success" />          
        </div>
      </div>
    </div>
     

  <?php 
    echo $AddTemplate->View();
  ?>

   

  



   </div>



</form> 

</div>