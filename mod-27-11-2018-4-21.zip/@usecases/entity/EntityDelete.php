<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);


*/
class EntityDelete{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     return $this->EntityCommit->DoDelete($request);

  }


}

