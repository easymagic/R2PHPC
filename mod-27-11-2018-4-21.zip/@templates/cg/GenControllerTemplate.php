
/**

@Inject(@templates/<?php echo $name; ?>/CreateTemplate,
        @framework/controllers/AdminPanel,
        @templates/<?php echo $name; ?>/ReadTemplate,
        @templates/<?php echo $name; ?>/EditTemplate,
        @templates/<?php echo $name; ?>/<?php echo $name; ?>SelectTemplate,
        @usecases/<?php echo $name; ?>/<?php echo $name; ?>Read,
        @services/DataAdapter,
        @services/CommandSignal,
        @services/MessageLogger,
        @services/Db);

*/

class <?php echo $name; ?>{

  function Init(){
    $this->CommandSignal->HandleEvents($this);
  }

  function Index(){
   $this->Read();
  }

  function API(){
    
    $response = $this->RequestResponse->GetResponse();

    echo json_encode($response);
    
  }

  
  function Create(){
    $this->CreateTemplate->message = $this->MessageLogger->GetMessageTemplate();
    $this->AdminPanel->Panel($this->CreateTemplate->View());
  }

  function Read(){
   $data = $this->DataAdapter->Resolve($this-><?php echo $name; ?>Read); 
   $this->ReadTemplate->data = $data;
   $this->ReadTemplate->message = $this->MessageLogger->GetMessageTemplate();
   $this->AdminPanel->Panel($this->ReadTemplate->View());
  }

  function Edit($id=''){
   $this->Db->Where('id',$id);
   $this->EditTemplate->message = $this->MessageLogger->GetMessageTemplate();
   $data = $this->DataAdapter->Resolve($this-><?php echo $name; ?>Read); 
   if (count($data) > 0){
     $data = $data[0];
     $this->EditTemplate->data = $data;
     $this->AdminPanel->Panel($this->EditTemplate->View());
   }else{
    $this->AdminPanel->InvalidSelection();
   }
  }

  function Select($k,$label,$v){

   $data = $this->DataAdapter->Resolve($this-><?php echo $name; ?>Read); 
   $this-><?php echo $name; ?>SelectTemplate->data = $data;
   $this-><?php echo $name; ?>SelectTemplate->key = $k;
   $this-><?php echo $name; ?>SelectTemplate->label = $label;
   $this-><?php echo $name; ?>SelectTemplate->value = $v;
   return $this-><?php echo $name; ?>SelectTemplate->View();

  }



}
