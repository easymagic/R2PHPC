<div class="card">
                <div class="card-body">
                  <h4 class="card-title">Asset Reports</h4>
                  <p class="card-description">
                    
                  </p>
                  <div>

<label>Date - From
  <input data-datepicker type="text" id="date-from" data-date-format="yyyy-mm-dd" placeholder="Date From" class="form-control" />
</label>

<label>Date - To
  <input data-datepicker type="text" placeholder="Date To" id="date-to" data-date-format="yyyy-mm-dd" class="form-control" />
</label>

<label>
  <button class="btn btn-success" id="gen">Generate</button>
</label>



                  </div>

                </div>
</div>                                      	
<script type="text/javascript">
	(function($){
		$(function(){

			 function HighLightError($el){

			 	 $el.css('border','2px solid red');

			 	 setTimeout(function(){

                   $el.css('border','1px solid #eee');			 	 	 

			 	 },3000);

			 }

             $('#gen').on('click',function(){

             	 var from = $('#date-from').val();
             	 var to = $('#date-to').val();

             	 if (from == ''){

             	 	 HighLightError($('#date-from'));

             	 }else if (to == ''){
                     
                     HighLightError($('#date-to'));

             	 }else{

                 var myWindow = window.open("<?php echo BASE_URL; ?>Report/GenerateReport?from=" + from + "&to=" + to, "", "width=1024,height=800");

             	 }



             });

		});
	})(jQuery);
</script>