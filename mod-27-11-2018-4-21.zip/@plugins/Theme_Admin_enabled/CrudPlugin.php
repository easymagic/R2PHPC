<?php 

/**

@Inject(@usecases/entity/EntityCreate,
        @usecases/entity/EntityRead,
        @usecases/entity/EntityUpdate,
        @usecases/entity/EntityDelete,
        @services/RequestResponse,
        @services/Input,
        @services/FormTrigger,
        @services/entity/EntityCommit,
        @services/View,
        @services/HttpService);

*/


class CrudPlugin{

 private $entity = null;
  
  function SetEntity($entity=''){
    $this->entity = $entity;
  }


  function Index_Action($id=''){
    
    if (empty($id)){
      return $this->Add_Action();
    }else{
     return $this->Remove_Action($id);  
    }
    
  }


  function Index_Inject($id=''){  
    $dt = $this->HttpService->DispatchAPI("Api/Collection/" . $this->entity);
    return $dt;
  }


  function Edit_Action($id=''){
    return $this->HttpService->DispatchAPI("Api/Collection/" . $this->entity . "/$id");
  }


  function Edit_Inject($id=''){
    $record = $this->HttpService->DispatchAPI("Api/Collection/" . $this->entity . "/$id");
    if (count($record) == 1 && !empty($id)){
     $record = $record[0];
    }
    return array($this->entity . '_data'=>$record);
  }


  function Add_Action(){
      return $this->HttpService->DispatchAPI("Api/Collection/" . $this->entity);
  }


  function Remove_Action($id=''){
    return $this->HttpService->DispatchAPI("Api/Collection/" . $this->entity . "/$id/delete");
  }





}


