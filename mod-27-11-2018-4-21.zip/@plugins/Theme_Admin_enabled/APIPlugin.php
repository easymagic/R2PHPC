<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService,
        @services/AuthorizationService);

*/

class APIPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function Collection_Payload($requestData){
    $this->RequestResponse->SetRequest($requestData);
    // print_r($this->RequestResponse->GetRequest());
    // echo 'called.';
    // print_r(getallheaders());
    // print_r(headers_list());

    // print_r(http_get_request_headers());
    // print_r(get_headers());
    // print_r(headers_sent());
  }

  function Collection_Action($entity='',$id='',$verb=''){
    return $this->CrudService->HandleCrudAction($entity,$id,$verb);
  }

  function Collection_Inject($entity='',$id='',$field=''){
    return $this->CrudService->HandleCrud($entity,$id,$field);
    
  }


  function Collection_JSON($json){
    return json_encode($json);
  }




}


