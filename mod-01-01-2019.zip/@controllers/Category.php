<?php 

/**

@Inject(@services/PluginAdapter,
        @plugins/BackEndPlugin,
        @templates/category/indexTemplate,
        @templates/category/EditTemplate,
        @templates/category/AddTemplate);


*/


class Category{
  

  function Init(){
    $this->PluginAdapter->Install($this->BackEndPlugin);
  }

  private function ToolBar($link,$link_name,$label){
    global $buffer;

    $buffer.= '
  <h1>Category </h1>
  <div class="row col-lg-1" style="float:right; margin-bottom:20px; margin-top:10px;">
    <input type="button" class="btn btn-block btn-info" value="Back" onclick="window.history.back()" />
  </div>
  <ol class="breadcrumb">
    <li><a href=""><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="' . $link . '" >' . $link_name . '</a></li>
    <li class="active">' . $label .  '</li>
  </ol>
';    
  }
  
  function Index_AdminToolBar(){
    $this->ToolBar(BASE_URL . 'Category/Add','Add Category','Category List');
  }

  function Index_AdminContent(){
    global $buffer;
    $buffer.=$this->indexTemplate->View();
    // $this->Db->Where('id',41);
  }

  function Edit_AdminToolBar(){
    $this->ToolBar(BASE_URL . 'Category','Category','Category Edit');
  }

  function Edit_AdminContent($id=''){
   global $buffer;
   $buffer.=$this->EditTemplate->View();
  }


  function Add_AdminToolBar(){
    $this->ToolBar(BASE_URL . 'Category','Category','Category Add');
  }

  function Add_AdminContent(){
    global $buffer;
    $buffer.=$this->AddTemplate->View();
  }



  // function Index1(){
  //   return '..hello..';
  // }

  function Test(){
    // $result = $this->FrontController->GetDispatch('Category/Index');
    // $result2 = $this->HttpService->DispatchAPI('Apiv2/Collection/admin/All');
    // print_r($result2);
  ?>
  <form method="post">
    <input type="text" name="data[email]" />
    <button>Send</button>
  </form>
  <?php 
  }

  function Test_Action(){
    global $postData;
    global $session;
    global $emailQueue;
    $session['name'] = 'R2';
    // global $redirect;
    print_r($postData);

    $emailQueue[] = array('subject'=>'test subject','message'=>'test message','to'=>'test to','from'=>'test from.');
    // print_r($_SESSION);
    // $redirect = 'Category/Add';

  }

  function AddCart_Action(){
    global $cart;
    global $addCart;
    global $request;
    global $hashID;

    $hashID = $request['cart']['id'];

    $addCart = $request['cart'];
    // print_r($addCart);
  }

  function RemoveCart_Action($id){
    global $removeCart;
    // echo $id;
    // print_r(func_get_args());
    $removeCart = $id;
  }

  private function ListCart(){
   
   global $cart;
   global $data;
   global $cartTotalQty;
   global $cartTotalPrice;
   global $hashedID;

   if (isset($data['message'])){
     echo '<br />' . $data['message'] . '<br />';
   }
   echo $hashedID;

   foreach ($cart as $k=>$v){

    ?>
    <div>
      <b>(<?php echo $k ?>).</b> <?php echo $v['id'] ?> , <?php echo $v['price'] ?> @ <?php echo $v['qty'] ?>
      <form method="post" action="<?php echo BASE_URL; ?>Category/RemoveCart/<?php echo $k; ?>">
        <input type="submit" name="n" value="Remove Item" />
      </form>
    </div>
    <?php
    
   }

   ?>
   <br />
   <div>
     <b>Total Qty:</b> <?php echo $cartTotalQty; ?>, <b>Total Price:</b> <?php echo $cartTotalPrice; ?>
   </div>
   <hr />
   <form method="post" action="<?php echo BASE_URL; ?>Category/AddCart">
     <input type="text" name="cart[id]" placeholder="Cart - ID" />
     <input type="text" name="cart[price]" placeholder="Price" />
     <button>Add To Cart.</button>
   </form>
 
   <?php 
  }

  function Rdr(){
    return 'Rdr......[][][]...';
  }

  function AddCart_PageStart(){

    global $auth;
    global $authFailRedirect;

    // $auth = 'usr';
    // $authFailRedirect = 'Category/Rdr';


  }

  function AddCart(){

    $this->ListCart();

  }

  function RemoveCart(){
    
    $this->ListCart();

  }

  function Test2_PageStart(){
    global $hashID;
    $hashID = 200;
  }

  function Test2(){
    global $hashedID;
    echo $hashedID;
  }


  // function DropDown($k,$v,$filterKey,$filterValue){
  // }




}
 