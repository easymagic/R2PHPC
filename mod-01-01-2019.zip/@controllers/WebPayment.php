<?php 
/**

@Inject(@plugins/webpayment/WebPaymentPlugin);

*/

class WebPayment{


  function Init(){
  	InstallPlugin($this->WebPaymentPlugin);
  }	

  
  
 function GateWay($uid=''){}
 function Feedback(){}



}