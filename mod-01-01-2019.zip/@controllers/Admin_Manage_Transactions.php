<?php 

/**

@Inject(@plugins/AdminBackEndPlugin,
        @plugins/transaction/TransactionsPlugin,
        @plugins/session/CheckAdminSessionLoggedPlugin);


*/


class Admin_Manage_Transactions{
  
  function Init(){
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->TransactionsPlugin);
    InstallPlugin($this->CheckAdminSessionLoggedPlugin);
  }

  
  function ListTransaction_AdminContent(){}
  function DetailTransaction_AdminContent(){}
  



}
 