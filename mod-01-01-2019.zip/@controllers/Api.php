<?php 

/**

@Inject(@models/transaction/TransactionInitPayment,
        @models/transaction/TransactionQueryStatus);

*/

class Api{

  
  function Init(){
    global $contentType;
    $contentType = 'json';  	
  }
  

  function InitTransaction(){ //post-params: $merchant_secret, post-data-params: amount,email,merchant_feedback_page and memo

    $this->TransactionInitPayment->InitPayment();
    
  }

  function QueryTransaction($reference){
     $this->TransactionQueryStatus->QueryStatus($reference);
  }



}