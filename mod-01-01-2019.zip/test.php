<?php 

echo 'Very cool....';