<?php 

define('DEFAULT_CONTROLLER', 'Accounts');
define('BASE_URL', 'http://interpay.r2soft.com.ng/');
