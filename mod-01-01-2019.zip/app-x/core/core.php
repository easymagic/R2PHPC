<?php 


function PersistData(){
  global $data;
  global $session;

  if (!isset($session)){
    $session['data'] = array();
  }

  foreach ($data as $k=>$v){
    $session['data'][$k] = $v;
  }

}


function RunThemes(){
    //@frameworks
    $dir = scandir('@themes');
    $dir = array_diff($dir, array('.','..'));
    foreach ($dir as $k=>$v){
      require('@themes/' . $v);
    }
}


function InstallPlugin($obj){
  global $plugins;
  $plugins[] = $obj;
}


function StartBuffer(){
 ob_start();
}

function GetBuffer(){
 $r = ob_get_contents();
 ob_end_clean();
 return $r;
}

function ActionTrigerred(){
	return (isset($_POST) && !empty($_POST));
}

function EndsWith($str,$ends){
 $end = substr($str, -1 * strlen($ends));
 $end = strtolower($end);
 if ($end == strtolower($ends)){
  return true;
 }else{
  return false;
 }
}



class InjectViewClass{
  
   private $view_ = null;

   function __construct($view){
     $this->view_ = $view;
   }


   function View(){

   	 global $dependencyData;
   	 global $data;
     global $session;

    
      $file = $this->view_ . '.php';
      // print_r($data);

      if (file_exists($file)){
        $tmp = null;

        if (isset($data['data'])){
          $tmp = $data['data'];
          unset($data['data']);
          $data['data_renamed'] = $tmp;
        }
        
        if (isset($session['data'])){
         extract($session['data']);
        }

        if (isset($dependencyData['data'])){
          $tmp = $dependencyData['data'];
          unset($dependencyData['data']);
          $dependencyData['data_renamed'] = $tmp;
        }
        extract($dependencyData);
        extract($data);
        StartBuffer();
        include($file);
        return GetBuffer();
      }else{
      	return '';
      }

   }


}


function InjectClass($cls){
 return DIContainer::GetInstance()->InjectClass($cls);
}

function CallProxy($obj,$method,$args=array()){

  	if (is_object($obj) && method_exists($obj, $method)){
      call_user_func_array(array($obj,$method), $args);
  	}
    
}


function CallAction($action){
  global $routeObject;
  global $routeArgs;
  global $plugins;
  global $buffer;
  global $routeAction;
  global $routeName;

  foreach ($plugins as $k=>$v){
   CallProxy($v,$action,$routeArgs);
  }
  CallProxy($routeObject,$action,$routeArgs);
  PersistData();
  //call ui template
  $file = '@templates/' . strtolower($routeName) . '/' . $action . 'Template';
  $obj = InjectKey($file);
  // echo $file . '<br />';
  if (!is_null($obj)){
    // echo 'called';
    // print_r($obj);
    $buffer.=$obj->View();
  }

      // $args2 = $args;
      // if (isset($obj->PluginAdapter)){
      //   array_unshift($args2, $method);
      //   CallProxy($obj->PluginAdapter,'RaiseEvent',$args2); 
      // }
      
}


function InjectKey($depStr){
 
  global $dependencyData;	
  
  $file = $depStr . '.php';
  // echo $file;
  $obj  = null;

  if (file_exists($file)){
    

    $r = explode('/', $depStr);

    $package = array_shift($r);

    $cls = end($r);

    if (!isset($dependencyData[$cls])){

        if ($package == '@templates' || substr($cls, -8) == 'Template'){ 

          if (file_exists($depStr . '.php')){
            $dependencyData[$cls] = new InjectViewClass($depStr);
            $obj =  $dependencyData[$cls]; 
          }else{
            $obj = null;
          }

 
        }else{   

          require_once($file);                         

          $dependencyData[$cls] = InjectClass($cls);   

          
          $obj =  $dependencyData[$cls]; 

        }



    }else{

      $obj =  $dependencyData[$cls]; 
      
    }


  }

  return $obj;

}





