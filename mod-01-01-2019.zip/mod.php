<?php
error_reporting(E_ALL);
session_start();



require_once('app-x/core/FrontController.php');
require_once('app-x/core/DIContainer.php');
require_once('config.php');
require_once('app-x/core/core.php');

//Payment variables here
$payStackSecret = 'sk_test_533ac4229f9c0a279ca6fda625b9660ba86bc178';
$payStackPaymentStatus = false;

//Special variables here
$contentType = 'html';
$routeObject = null;
$routeName = '';
$routeAction = '';
$routeArgs = array();
$buffer = '';
$json = array();

//Cron-Jobs
//init server jobs here
$serverJobs = array();
$jobDir = scandir('@jobs');
$jobDir = array_diff($jobDir, array('.','..'));

foreach ($jobDir as $currentJob){
  $currentJob = explode('.', $currentJob);
  $currentJob = $currentJob[0];
  require_once('@jobs/' . $currentJob . '.php');
  if (class_exists($currentJob)){
    $$currentJob = InjectClass($currentJob);
    $serverJobs[$currentJob] = $$currentJob;
  }
}


$PageObject = InjectClass('FrontController'); 
$PageObject->DispatchRequest();



echo $buffer;