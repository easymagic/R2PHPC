<?php 

/**

@Inject(@models/transaction/TransactionGetList,
        @models/transaction/TransactionCallPayStackTransactionCheck,
        @models/transaction/response/TransactionUpdateSuccess,
        @models/transaction/response/TransactionUpdateFailed);

*/


class WebPaymentPlugin{

  
  function GateWay($uid=''){
   // global $db_where;
   // global $data;
   // $db_where = " where (interpay_reference = '$uid')";
   // $this->TransactionGetList->GetList(); 
   // if (count($data['transaction_data']) > 0){
   //   $data['transaction_data'] = $data['transaction_data'][0];
   // }

   $this->GetOneTransaction("interpay_reference = '$uid'");

  }

  private function GetOneTransaction($criteria){
   global $db_where;
   global $data;
   $db_where = " where ($criteria)";
   // echo $db_where;
   $this->TransactionGetList->GetList(); 
   if (count($data['transaction_data']) > 0){
     $data['transaction_data'] = $data['transaction_data'][0];
   }
  }

  function Feedback(){
    global $get;
    global $payStackPaymentStatus;
    global $data;


// print_r($get);

    if (isset($get['reference'])){
       $this->TransactionCallPayStackTransactionCheck->CallPayStackTransactionCheck($get['reference']);
       if ($payStackPaymentStatus){
         $this->TransactionUpdateSuccess->UpdateSuccess($get['reference']);
       }else{
         $this->TransactionUpdateFailed->UpdateFailed($get['reference']);
       }

       $this->GetOneTransaction("paystack_reference = '" . $get['reference'] . "'");

       header('Location: ' . $data['transaction_data']['merchant_feedback_page'] . '?reference=' . $data['transaction_data']['interpay_reference']);
       exit();
       // print_r($data['transaction_data']);
    }

  }


}