<?php 

/**

@Inject(@templates/backend/Admin_HTML_StartTemplate,
        @templates/backend/Admin_HeaderTemplate,
        @templates/backend/merchant/Merchant_SideBarTemplate,
        @templates/backend/Admin_Content_PreStartTemplate,
        @templates/backend/Admin_Content_PreStopTemplate,
        @templates/backend/Admin_FooterTemplate,
        @templates/backend/Admin_HTML_StopTemplate);

*/


class MerchantBackEndPlugin{


 function Admin_HTML_Start(){
  global $buffer;
  $buffer.=$this->Admin_HTML_StartTemplate->View();
 }  

 function Admin_Header(){
  global $buffer;
  $buffer.=$this->Admin_HeaderTemplate->View();
 }

 function Admin_SideBar(){
  global $buffer;
  $buffer.=$this->Merchant_SideBarTemplate->View();
 }

 function Admin_Content_PreStart(){
  global $buffer;
  $buffer.=$this->Admin_Content_PreStartTemplate->View();
 }

 function Admin_Content_PreStop(){
  global $buffer;
  $buffer.=$this->Admin_Content_PreStopTemplate->View();
 }

 function Admin_Footer(){
  global $buffer;
  $buffer.=$this->Admin_FooterTemplate->View();
 }

 function Admin_HTML_Stop(){
  global $buffer;
  $buffer.=$this->Admin_HTML_StopTemplate->View();
 }

 

}