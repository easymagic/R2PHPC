<?php 

class HelloWorldPlugin{

  

    function Index(){
      global $buffer;

      // $buffer.= 'Modified from HelloWorldPlugin.';
    }

    function Index_Action(){
      // global $buffer;
      global $data;

      $data['message'] = 'Action Triggerred From Plugin.';
      // $data['error'] = true;

      // $buffer.= 'Action Triggerred From Plugin.';

    }


}