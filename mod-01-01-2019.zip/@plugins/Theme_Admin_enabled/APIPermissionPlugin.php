<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService,
        @services/AuthorizationService);

*/

class APIPermissionPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function GetScope(){
    return 'private';
  }

  function Authorize(){
    if (!$this->AuthorizationService->IsAuthorized()){
      throw new Exception("Invalid Authorization code!!!", 1);
    }
  }


  function Collection_ActionPermission($entity='',$id='',$verb=''){
    // print_r(func_get_args());
    $this->Authorize();

   if (empty($verb)){

    if ($this->CrudService->IsAddAction($entity,$id)){
      // echo $entity . '_Add'; 
    }else if ($this->CrudService->IsUpdateAction($entity,$id)){
      // echo $entity . '_Update'; 
    }else{
      
    }


   }else if ($this->CrudService->IsDeleteAction($verb)){
      
      // echo $entity . '_Delete';

   }

  }

  function Collection_Permission($entity='',$id=''){
    $this->Authorize();
   // print_r(func_get_args());
    if ($this->CrudService->IsReadAction($entity,$id)){
       // echo $entity . '_Read';
    }else if ($this->CrudService->IsReadOneAction($entity,$id)){
       // echo $entity . '_ReadOne';
    }else{
      
    }

  }



}


