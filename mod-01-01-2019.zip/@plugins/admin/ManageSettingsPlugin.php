<?php 

/**

@Inject(@models/gw_settings/GWSettingsAdd,
        @models/gw_settings/GWSettingsRemove,
        @models/gw_settings/GWSettingsGetList,
        @models/gw_settings/GWSettingsGetOne,
        @models/gw_settings/GWSettingsUpdate);

*/


class ManageSettingsPlugin{

  
  function Init(){
    global $session;
    global $data;
    global $logged;
    global $session_type;
    global $adminID;

    $logged = false;
    $session_type = 'admin';
    
    $data['role'] = '';
    if (isset($session['admin_session'])){
       $data['role'] = $session['admin_session']['role'];
       $logged = true;
       $data['session_type'] = $session_type;
       $adminID = $session['admin_session']['id'];
    }
  }

  
  function ListSetting_AdminContent(){
    $this->GWSettingsGetList->GetList();    
  }

  
  function AddSetting_Action(){
    $this->GWSettingsAdd->Add();
    $this->Redirect();
  }

  function EditSetting_AdminContent($id){
    $this->GWSettingsGetOne->GetOne($id);
  }
  
  function EditSetting_Action($id){
    $this->GWSettingsUpdate->Update($id);
    $this->Redirect();
  }


  function Redirect(){
    global $redirect;
    $redirect = 'ManageSettings/ListSetting';
  }

  function RemoveSetting($id){
    $this->GWSettingsRemove->Remove($id);
    $this->Redirect();
  }

  function Page_Init(){
    // echo 'Called';
    global $logged;
    global $redirect;

    if (!$logged){
      $redirect = 'Accounts';
    }
  }


    function Page_Destroy(){
      global $session;
      global $data;

      unset($session['data']);
      unset($data['message']);
      unset($data['error']);
    }



}