<?php 

$redirect = '';

class RedirectJob{

   
   function PostJob(){
    global $redirect;
    if (!empty($redirect)){
      header("Location: " . BASE_URL . $redirect);
      $redirect = '';
      exit();
    }    
   }

}
