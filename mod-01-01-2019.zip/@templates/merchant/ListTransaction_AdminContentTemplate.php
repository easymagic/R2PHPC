<section class="content-header">
      <h1>
        List Transaction
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Transactions</li>
      </ol>
</section>


<section class="content">
<?php 
 global $get;
?>
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">List Transactions</h3>
              <form method="get" style="display: inline-block;">
                <select data-value="<?php echo @$get['merchant']; ?>" name="merchant" style="padding: 4px;">
                  <option value="">Merchant</option>
                  <?php 
                    foreach ($merchant_data as $k=>$v){
                   ?>
          <option value="<?php echo $v['id']; ?>"><?php echo $v['first_name']; ?></option> 
                   <?php     
                    }
                  ?>                  
                </select>                
                <select data-value="<?php echo @$get['pstatus']; ?>" name="pstatus" style="padding: 4px;">
                  <option value="">Payment Status</option>
                  <option value="pending">Pending</option>
                  <option value="success">Success</option>
                  <option value="failed">Failed</option>
                  <option value="settled">Settled</option>
                </select>
                
                <!-- <input type="text" name="search_text" placeholder="Search" value="<?php //echo @$get['search_text']; ?>"/> -->

                <input type="text" autocomplete="off" data-date name="date1" placeholder="Date From" value="<?php echo @$get['date1']; ?>"/>
                <input type="text" autocomplete="off" data-date name="date2" placeholder="Date To" value="<?php echo @$get['date2']; ?>" />
                <button>Search Transaction</button>
              </form>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Merchant Reference</th>
                  <th>InterPAY Reference</th>
                  <th>PayStack Reference</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Date Created</th>
                </tr>

                <?php 
                  foreach ($transaction_data as $k=>$v){
                ?>

                <tr>
                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $v['merchant_reference']; ?></td>
                  <td><?php echo $v['interpay_reference']; ?></td>
                  <td><?php echo $v['paystack_reference']; ?></td>
                  <td><?php echo $v['amount']; ?></td>
                  <td><?php echo $v['pstatus']; ?></td>
                  <td><?php echo $v['date_created']; ?></td>
                  <td>
                    <a class="btn btn-sm btn-primary" href="<?php echo BASE_URL; ?>Merchant/DetailTransaction/<?php echo $v['id']; ?>">Detail</a>
                  </td>
                </tr>

                <?php 
                 }
                ?>


              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      