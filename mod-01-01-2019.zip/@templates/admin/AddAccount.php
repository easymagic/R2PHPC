<form method="post">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 LogvMessage();
?>

                  <div class="card" style="height: 80vh;">
                    <div class="card-body">
                      <h4 class="card-title">+Add User</h4>
                      <p class="card-description" align="right">
                         <a href="<?php echo BASE_URL; ?>Home/ManageAccounts" class="btn btn-default">Back</a>
                       </p>
                      <!-- <form class="forms-sample"> -->

                        <div class="form-group">
                          <label for="exampleInputEmail1">E-mail</label>
                          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter E-mail" name="data[email]" required="" />
                        </div>

                        
                        <div class="form-group">
                          <label for="exampleInputEmail1">Password</label>
                          <input type="password" class="form-control" id="exampleInputEmail1" placeholder="Enter Password" name="password1" required="" />
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Confirm Password</label>
                          <input type="password" class="form-control" id="exampleInputEmail1" placeholder="Confirm Password" name="password2"  required="" />
                        </div>


                        <button type="submit" class="btn btn-success mr-2">Add</button>
                        <!-- <button type="reset" class="btn btn-light">Cancel</button> -->
                        

                      <!-- </form> -->
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="user/UserCreate" />

   

</div>

</form>             
