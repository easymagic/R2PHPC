<?php 


class PluginAdapter{
  
  private $listeners = array();
  
  function Install($obj){
    $this->listeners[] = $obj;
  }    

  function RaiseEvent(){
    $args = func_get_args();
    $method = array_shift($args);

    foreach ($this->listeners as $k=>$v){
      
      if (is_object($v) && method_exists($v, $method)){
       call_user_func_array(array($v,$method), $args);
      }
      
    }
  }

  

}