<?php 
/**

@Inject(@models/entityv2/EntityReadOne);

*/
class MerchantGetOne{


  function GetOne($id){
  	global $data;

  	$this->EntityReadOne->ReadOne('merchant',$id);

  	return $data['merchant_data'];
  }



}