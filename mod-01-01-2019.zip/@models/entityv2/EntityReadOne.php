<?php 
/**

@Inject(@models/entityv2/EntityRead);

*/

class EntityReadOne{

   

   function ReadOne($entity,$id){     
     
     global $data;
     global $db_where;
     // echo "$entity";
     $db_where = " where (id=$id) ";

     $this->EntityRead->Read($entity);

     if (count($data[$entity . '_data']) > 0){
        $data[$entity . '_data'] = $data[$entity . '_data'][0];
     }
 
   }


}