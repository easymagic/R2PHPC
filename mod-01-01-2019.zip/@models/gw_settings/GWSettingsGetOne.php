<?php 

/**

@Inject(@models/entityv2/EntityReadOne);

*/

class GWSettingsGetOne{

  function GetOne($id){
  	$this->EntityReadOne->ReadOne('gw_settings',$id);
  }

}