<?php 

/**

@Inject(@models/entityv2/EntityUpdate);

*/

class GWSettingsUpdate{


  function Update($id){
    global $postData;
    global $data;

    // $name = $postData['name'];
    $this->EntityUpdate->DoUpdate('gw_settings',$postData,"id=$id");
    
    $data['message'] = 'Option Updated.';
  }

}