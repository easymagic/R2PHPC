<?php 

/**

@Inject(@models/entityv2/EntityDelete);

*/

class GWSettingsRemove{


  function Remove($id){
    // global $postData;
    global $data;

    // $name = $postData['name'];
    $this->EntityDelete->DoDelete('gw_settings',"id=$id");
    // $this->EntityRemoveOption->RemoveOption('gw_settings',$name);
    $data['message'] = 'Option Removed.';
  }

}