<?php 

class TransactionFilterDate{

  


   function FilterDate($date1='',$date2=''){//
   	global $db_where;
   	global $transactionFilters;

   	if (!empty($date1) && !empty($date2)){
   	 $date2.=' 24:59:59 ';	
     $transactionFilters[] = " (date_created >= '$date1' and date_created <= '$date2') ";
     $db_where = " where (" . implode(' and ', $transactionFilters) . ") ";  
     // echo $db_where;
   	}

   }



}