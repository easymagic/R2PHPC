<?php 

class TransactionFilterSearch{

  


   function FilterSearch($search_text){//
   	global $db_where;
   	global $transactionFilters;

   	$transactionFilters[] = " memo like '%$search_text%' or merchant_reference like '%$search_text%' or interpay_reference like '%$search_text%' or paystack_reference like '%$search_text%' or amount like '%$search_text%' ";
     
    $db_where = " where (" . implode(' and ', $transactionFilters) . ") "; 

   }



}