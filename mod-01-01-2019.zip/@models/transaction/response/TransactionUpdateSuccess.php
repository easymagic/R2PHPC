<?php 
/**

@Inject(@models/entityv2/EntityUpdate);

*/


class TransactionUpdateSuccess{
  


  function UpdateSuccess($reference){
  	 global $payStackResponse;

     $this->EntityUpdate->DoUpdate('transaction',array('pstatus'=>'success',
     'paystack_echo_response_data'=>json_encode($payStackResponse)),"paystack_reference = '$reference'");
  }



}