<?php 
/**

@Inject(@models/entityv2/EntityUpdate);

*/


class TransactionUpdateFailed{
  


  function UpdateFailed($reference){
  	global $payStackResponse;

     $this->EntityUpdate->DoUpdate('transaction',array('pstatus'=>'failed',
     'paystack_echo_response_data'=>json_encode($payStackResponse)),"paystack_reference = '$reference'");
  }



}