<?php 

namespace reflect;

class MethodReflect{
  
   
    static function getMethodParams($class,$method){

    	$classObject = new $class;
    	$reflect = new \ReflectionClass($classObject);
        
        $params = $reflect->getMethod($method)->getParameters();  

        $rr = array();

        foreach ($params as $k=>$v){

        	 $rr[] = array(
              'name'=>$v->name,
              'classType'=>$v->getType() . ''
        	 );

        }

    	return array(
          'classObject'=>$classObject,
          'options'=>$rr
    	);

    }


    static function autoInjectParams($class,$method,$inArgsNames=array(),$inArgsValues=array()){
       
        $options = array('args'=>[],'names'=>[]);
        $paramConfig = self::getMethodParams($class,$method);

        foreach ($paramConfig['options'] as $k=>$v){

          $cls = $v['classType'];
          if (!empty($cls)){
            // echo $cls . $inArgsValues[$k];
            $options['args'][$k] = new $cls;
            $options['names'][$k] = $v['name'];
          }else{
            $options['args'][$k] = $inArgsValues[$k];
            $options['names'][$k] = $v['name'];
          }
        	
        	

        }

        // print_r($options);
        // print_r($inArgsNames);

        foreach ($inArgsNames as $k=>$v){
          $track = array_search($v, $options['names']);
          // echo $track . '<br />';

          if (is_numeric($track) && $track >= 0){ // is_numeric($track) && $track >= 0
            $obj = $options['args'][$track];
            
            if (is_object($obj) && method_exists($obj, 'resolveRouteBinding')){
               
               $options['args'][$track] = call_user_func_array(array($options['args'][$track],'resolveRouteBinding'), array($inArgsValues[$k]));
               // echo 'called.';
               if (empty($options['args'][$track])){
                 $options['args'][$track] = null;
               }

            }

          }

        }


        if (method_exists($paramConfig['classObject'], $method)){
           return call_user_func_array(array($paramConfig['classObject'],$method), $options['args']);
        }else{
           return ''; 
        }

    }
 

}