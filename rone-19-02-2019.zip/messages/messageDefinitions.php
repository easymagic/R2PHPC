<?php 

// DefineMessage('00','No message',false);