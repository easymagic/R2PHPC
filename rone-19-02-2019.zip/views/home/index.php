<?php
 
 $themeDir = BASE_URL . 'theme1/';

 TemplateSectionStart('mainContent');
?>    
    <!-- Intro Header -->
	<section >
	  <div class="">
        <div class="masthead" style="background: url(<?php echo $themeDir; ?>img/intro-bg.jpg) no-repeat bottom center scroll">
          <div class="intro-body">
        <div class="container">
             <div class="row">
                <div class="col-lg-5">
			     
			    </div>
			    <div class="col-lg-7" style="padding: 20px;">
			    	<h3>Make Nigeria Working again</h3>
			    	<p>To Advocate for Democratic Dividends from Elected Candidates to the Grassroots.</p>
			      <div class="send-payment-btn" style="float: left;background-color: transparent;">
			        <a href="#regview" id="regview" style="border-radius: 5px;background-color: #000;padding: 7px;margin-right: 11px;">JOIN THE MOVEMENT</a>
			        <a style="border-radius: 5px;background-color: #000;padding: 7px;margin-right: 11px;" href="<?php echo BASE_URL; ?>Home/Login" id="regview">SIGN-IN</a>
			    </div><!--end of send-payment-btn-->
			    </div>
             </div>
			 </div>
			</div>   
         </div>
	   </div>
     </section>
   
    <!-- About Section -->
    <section id="about">
      <div class="container">
	       
	      <div class="hiw-container">
		   
			 
			   <div class="row">
			       <div class="col-lg-7" ">

			       	<?php
			       	 
			       	 if (isset($_SESSION['response']['message'])){
                      $message = $_SESSION['response']['message'];
                      $error = $_SESSION['response']['error'];
                      unset($_SESSION['response']['message']);
			       	 } 

                     if (isset($message)){
                     	if (isset($error) && $error){
                         $cls = 'danger';
                     	}else{
                     	 $cls = 'success';	
                     	}
                       // global $data;
                       // print_r($data);
                     ?>
                      <div class="alert alert-<?php echo $cls; ?>" style="margin-top: 11px;"><?php echo $message; ?></div>  
                     <?php 	
                     }
			       	?>

				      <div class="hiw-lhs">
			       	  <h3 style="text-align: left;">Voice of the grassroot #Doortodoor</h3>
					  <p>To Support and Develop our Youth on Leadership Qualities that Enhances Good Governance
					  </p>

					 <!-- <div class="send-payment-btn" style="float: left;"> -->
			        <!-- <a href="#">MENTION YOUR SELLER</a> -->
			         <!-- </div> -->
			    <!--end of send-payment-btn-->
				      </div><!--end of hiw-lhs-->
					</div>
					
					  <div class="col-lg-5">
				  
					  <div class="hiw-rhs">
				
				<div class="sap-form" id="join">
				 
					  <form method="post" action="<?php echo BASE_URL; ?>apiv1/Acredit">

					  	<input type="hidden" name="cbs" value="#regview" />
					  	<input type="hidden" name="cbe" value="#regview" />
					     
						
<style type="text/css">
	.form-txt input{
		color: #fff !important;
	}
</style>

						 <div class="form-txt">
<select class="form-control2" name="data[state_id]" placeholder="Select State"  data-value="<?php echo __('StateID'); ?>" style="
    /* color: #fff; */
    width: 100%;
    padding: 6px;
    font-weight: bold;
    font-size: 13px;
">
<option value="">--Select State--</option>
<option value="1">ABIA</option>
<option value="2">ADAMAWA</option>
<option value="3">AKWA IBOM</option>
<option value="4">ANAMBRA</option>
<option value="5">BAUCHI</option>
<option value="6">BAYELSA</option>
<option value="7">BENUE</option>
<option value="8">BORNO</option>
<option value="9">CROSS RIVER</option>
<option value="10">DELTA</option>
<option value="11">EBONYI</option>
<option value="12">EDO</option>
<option value="13">EKITI</option>
<option value="14">ENUGU</option>
<option value="37">FCT</option>
<option value="15">GOMBE</option>
<option value="16">IMO</option>
<option value="17">JIGAWA</option>
<option value="18">KADUNA</option>
<option value="19">KANO</option>
<option value="20">KATSINA</option>
<option value="21">KEBBI</option>
<option value="22">KOGI</option>
<option value="23">KWARA</option>
<option value="24">LAGOS</option>
<option value="25">NASARAWA</option>
<option value="26">NIGER</option>
<option value="27">OGUN</option>
<option value="28">ONDO</option>
<option value="29">OSUN</option>
<option value="30">OYO</option>
<option value="31">PLATEAU</option>
<option value="32">RIVERS</option>
<option value="33">SOKOTO</option>
<option value="34">TARABA</option>
<option value="35">YOBE</option>
<option value="36">ZAMFARA</option>
</select>						 	
						 </div>


						 <div class="form-txt">
						 <input name="data[name_on_voter_card]" type="text" class="form-control" id="name" placeholder="SURNAME ON VOTER'S CARD" value="<?php echo __('name_on_voter_card'); ?>" required />
						 </div>
						 
						 <div class="form-txt">
						 <input name="data[email]" type="text" class="form-control" placeholder="EMAIL ADDRESS"  value="<?php echo __('email'); ?>" required />
						 </div>
						 
						
						  <div class="form-txt">
					     <input name="data[phone]" type="text" class="form-control" id="business_name" placeholder="PHONE" value="<?php echo __('phone'); ?>" required />
						 </div>
						  
						  <div class="form-txt">
						 <input name="data[last_8_pvc_pin]" type="text" class="form-control" id="business_name" placeholder="Last 8-digits of PVC PIN" value="<?php echo __('last_8_pvc_pin'); ?>" required />
						 </div>

						  <div class="form-txt">
						 <input name="password1" type="password" class="form-control" id="business_name" placeholder="Password"  value="<?php echo __('password'); ?>" required />
						 </div>

						  <div class="form-txt">
						 <input name="password2" type="password" class="form-control" id="business_name" placeholder="Confirm Password" value="<?php echo __('password2'); ?>" required />
						 </div>


						<button type="submit" border:none; class="submit-btn"  style="background-color: #fff; color: #000; border-radius: 3px;">Submit</button>
						
					  </form>
					</div><!--end of sap-form-->
				</div>
			</div>
				
					
					
				   </div>
			   </div>
			    
		   </div><!--end of hiw-container-->
	   </div><!--end of container-->
    </section>
<?php 
 
 EndTemplateSection();

 TemplateExtend('frontend/layout');

?>