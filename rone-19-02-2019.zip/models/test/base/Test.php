<?php 

namespace models\test\base;

class Test extends \rone\Model{

   
   protected $table = 'test';



   function subject(){

   }

   function students(){
   	
   }



}