<?php
namespace declarations\entities;

class EntitySendMail{


   private $message = '';
   private $subject = '';
   private $to = '';
   private $from = ''; 
     
  function SendMail(){
     // echo 'Mail test sent';
     // return;
   
     $to = $this->to; 
     $subject = $this->subject; 
     $msg = $this->message; 
     $from = $this->from; 

      if (mail(
        $to, 
        $subject, 
        $msg, 
        "From: " . $from . "\n" . 
        "MIME-Version: 1.0\n" .
        "Content-type: text/html; charset=iso-8859-1"
      )){
        // echo 'Sent ..';
      }else{
        // echo 'Not sent ...';  
      }   


  }

  function SetSubject($sub){
    $this->subject = $sub;
  }

  function SetMessage($msg){
    $this->message = $msg;
  }

  function SetTo($to){
    $this->to = $to;
  }

  function SetFrom($from){
    $this->from = $from;
  }


}