<?php
error_reporting(E_ALL);
session_start();

function __autoload($file){
 $file = $file . '.php';
 $file = explode('\\', $file);
 $file = implode('/', $file);
 
 if (file_exists($file)){
   include_once($file);
 }
}


require_once('app-x/core/core.php');
require_once('config.php');
require_once('routes/web.php');


$__method__ = 'get';
if (isset($_POST) && !empty($_POST)){
 $__method__ = 'post';
}

//__request__
if (empty($_REQUEST['__request__'])){
  $_REQUEST['__request__'] = 'default';
}

 try {
   
   $r = matchRoute($__method__,$_REQUEST['__request__']);


   if (is_object($r) || is_array($r)){

       echo json_encode($r);

   }else{

       echo $r;

   }


 } catch (Exception $e) {
   
   echo $e->getMessage();

 }

