<?php 

/**

@Inject(@controllers/Base);

*/

class CrudTemplatePlugin{
  
  function SetEntity($entity=''){}


  function Index_Render($view){
    $this->Base->BackEndLayout($view->View());
  }


  function Edit_Render($view){
    // print_r($view);
    $this->Base->BackEndLayout($view->View());
  }


  function Add_Render($view){
   $this->Base->BackEndLayout($view->View());
  }


  function Remove_Render($view){
    $this->Base->BackEndLayout($view->View());
  }


}


