<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);

*/

class APIPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function Collection_Payload($requestData){
    $this->RequestResponse->SetRequest($requestData);
  }

  function Collection(){
    $args = func_get_args();

    if (count($args) >= 2){
    $package = array_shift($args);
    $packageMethod = array_shift($args);

    $lib = '@usecases/' . $package . '/' . $packageMethod;

    $lib = DIContainer::GetInstance()->DecodeAnnotationKey($lib);

    call_user_func_array(array($this->EntityCommit,'CallUCAction'),array_merge(array($lib),$args));

    }

  }

  function Collection_JSON(){
    echo json_encode($this->RequestResponse->GetResponse());
  }




}


