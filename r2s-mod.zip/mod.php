<?php
require_once('config.php');
require_once('app-x/core/core.php');
$PageObject = DIContainer::GetInstance()->InjectClass('FrontController'); 
$PageObject->DecodeRequest();
$PageObject->DecodePluginUse();
$PageObject->DispatchRequest();