    
      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="">Home</a></li>
           <li class="active"><?php echo $title; ?></li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">




<div class="panel panel-default">
          <div class="panel-heading">
            <?php echo $title; ?>
            
            <span class="pull-right">
              <label class="label-checkbox inline">
                <a href="" data-back="<?php echo $ctrl; ?>">Back</a>
                <!-- <input type="checkbox" id="toggleLine" checked=""> -->
                <span class="custom-checkbox"></span>
                <!-- Toggle Line -->
              </label>
            </span>

          </div>
          <div class="panel-body">
            <div data-message></div>
            <form id="formToggleLine" method="post" class="form-horizontal no-margin form-border" enctype="multipart/form-data">
              
   <?php 
    foreach ($fields as $k=>$v){

 ?>


<div class="form-group">
  <label class="col-lg-2 control-label"><?php echo $Misc->Humanize($v); ?></label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[<?php echo $v; ?>]" type="text" placeholder="<?php echo $Misc->Humanize($v); ?>">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 <?php 

    }
   ?>

            

<div class="form-group">
      <div class="col-lg-offset-2 col-lg-10">
        <input type="submit" value="Create" class="btn btn-success btn-sm" />
      </div><!-- /.col -->
</div>


  <input type="hidden" name="ccmd" value="<?php echo $createUC; ?>" />


            </form>
          </div>
</div>




    
    </div>  









<script type="text/javascript">
  (function($){
    $(function(){


      $('[data-message]').html(message);


    });
  })(jQuery);
</script>
