<?php

 // Provide('asset.AssetMettaRead',array(
 //   'where'=>array(

 //   )
 // ));

 // global $data_count;
 // global $data_sum_purchase_price;

  // print_r($data_sum_purchase_price);


$search_text = '';
if (isset($_REQUEST['search_text'])){
 $search_text = $_REQUEST['search_text'];
}

$_SESSION['asset_page_record'] = array();
 
 

 // print_r($data);

 // if ( count($data) > 0 ){
  // $data = $data['data'];
?>
<div class="card">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $title; ?>(<?php echo $data_count[0]['record_count']; ?>)</h4>
                  <p class="card-description">
                    
                  </p>
                  <div class="table-responsive">


<form method="get">
<div class="col-xs-12" align="right">
  <div class="navbar-menu-wrapper align-items-center" style="display: inline-block;">


          <form class="search-field ml-auto" action="#">
            <div class="form-group mb-0">

              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                </div>
                <input type="text" class="form-control" name="search_text" placeholder="Server Search" />
              </div>
              <?php 
                if (isset($_REQUEST['search_text'])){
              ?>
               <a href="<?php echo BASE_URL; ?>asset">Remove Filter</a>
              <?php 
                }
              ?>
            </div>
          </form>

  </div>
</div>                    
</form>

<div class="col-xs-12">
  <h5 align="left" style="color: #777;">
     Purchase Price Total :  #<?php echo number_format($data_sum_purchase_price[0]['sum_total']); ?>

     <a href="<?php echo BASE_URL; ?>asset/ImportCSV" class="btn btn-success">Import CSV</a>&nbsp;|&nbsp;
     <a href="?ccmd=asset/AssetExportToCSV" class="btn btn-success">Export To CSV</a>
  </h5>
</div>                    



                    <table class="table" id="asset-listing">
                      <thead>
                        <tr>
                          <th>Description</th>
                          <th>Category</th>
                          <th>Location</th>                          
                          <th>Date-Purchased</th>     
                          <th>Serial-No.</th>
                          <th>Bought-From</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody id="tbody">


                      </tbody>
                    </table>

                    <div>
                      <button type="button" class="btn btn-default" id="load-more">
                        + Load More
                      </button>
                      <script type="text/javascript">
                        (function($){


        function InitDataTable(){

            // "aLengthMenu": [
            //   [5, 10, 15, -1],
            //   [5, 10, 15, "All"]
            // ],


          $('#asset-listing').DataTable({
            "iDisplayLength": 10,
            "language": {
              search: "Client Search."
            }
          });

        }

        function UpdateDataTable($rowHtml){

          var jRow = $($rowHtml);
          window.jRow = jRow;
          var dt = $('#asset-listing').dataTable().api();

          var rows = [];

          jRow.each(function(){
             
             var $row = $(this);
             rows.push($row);
             
             // console.log($row);
              dt.row.add($row);          

             // console.log($row);

          });

          // window._rows = rows;

          dt.draw();          
          
        }


        function InitDeleteConfirm(){

          $('.confirm').each(function(){
            $(this).on('click',function(){
              return confirm('Do you want to confirm this action?');
            });
          });

          // $('#asset-listing').on('click','a',function(e){
             
             
          //   if ($(e.target).is('.confirm')){
          //     return confirm('Do you want to confirm this action?');
          //   }else{
          //     //e.preventDefault();
          //   }
            

          // });

        }



                          $(function(){
                            
                            InitDataTable();

                            // InitDeleteConfirm();

                            $('#load-more').AjaxPagination({
                              api:'<?php echo BASE_URL; ?>asset/GetPage/<?php echo $search_text; ?>'
                            }).Append(function(response){

                               // console.log(response);
                               // window.response = response;
                               // $('#tbody').append(response);
                               UpdateDataTable(response);
                               InitDeleteConfirm();
                            });
                          });
                        })(jQuery);
                      </script>
                    </div>
                  </div>
                </div>
              </div>
<?php 

 // }else{
 //  echo 'No Captured Assets.';
 // }

?>