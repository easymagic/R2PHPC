<script> var WigData = <?php echo json_encode($data); ?> </script><script> var message = '<?php echo $message; ?>';</script>
    
      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="">Home</a></li>
           <li class="active">Edit Wig</li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">




<div class="panel panel-default">
          <div class="panel-heading">
            Edit Wig            
            <span class="pull-right">
              <label class="label-checkbox inline">
                <a href="" data-back="Wig">Back</a>
                <!-- <input type="checkbox" id="toggleLine" checked=""> -->
                <span class="custom-checkbox"></span>
                <!-- Toggle Line -->
              </label>
            </span>

          </div>
          <div class="panel-body">
            <div data-message></div>
            <form id="formToggleLine" method="post" class="form-horizontal no-margin form-border" enctype="multipart/form-data">
              
   
<div class="form-group">
  <label class="col-lg-2 control-label">Id</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[id]" type="text" placeholder="Id" data-key="id">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Category Id</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[category_id]" type="text" placeholder="Category Id" data-key="category_id">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Name</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[name]" type="text" placeholder="Name" data-key="name">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Description</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[description]" type="text" placeholder="Description" data-key="description">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Image</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[image]" type="text" placeholder="Image" data-key="image">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Price</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[price]" type="text" placeholder="Price" data-key="price">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Date Created</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[date_created]" type="text" placeholder="Date Created" data-key="date_created">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
<div class="form-group">
  <label class="col-lg-2 control-label">Qty</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[qty]" type="text" placeholder="Qty" data-key="qty">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
      <div class="col-lg-offset-2 col-lg-10">
        <input type="submit" value="Update" class="btn btn-success btn-sm" />
      </div><!-- /.col -->
</div>
            


  
  <input type="hidden" name="id[]" data-key="id" />
  <input type="hidden" name="ccmd" value="wig/WigUpdate" />


            </form>
          </div>
</div>




    
    </div>  









<script type="text/javascript">
  (function($){
    $(function(){

      $('[data-key]').each(function(){

         var key = $(this).data('key');

         if ($(this).is('img')){
          $(this).attr('src',WigData[key]);
         }else{
          $(this).val(WigData[key]); 
         }

      });

      $('[data-message]').html(message);


    });
  })(jQuery);
</script>
