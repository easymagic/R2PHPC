<?php
/**

@Inject(@services/PluginAdapter,
        @plugins/HelloWorldPlugin,
        @plugins/BackEndPlugin);

*/


class Test{
   
  function Init(){
    $this->PluginAdapter->Install($this->HelloWorldPlugin);
    $this->PluginAdapter->Install($this->BackEndPlugin);
  }  

  function foo(){

  } 

  function foo_AdminContent(){
  	
  	global $buffer;
  	
  	$buffer.= '...new content...';

  } 
 
  function Index_AdminContent(){
  	global $buffer;
  	global $contentType;
  	global $json;

  	$json['version'] = 'n.0.0';
  	$json['FrameworkName'] = 'RONE';

  	// $contentType = 'json';

  	StartBuffer();

  	?>
      <!-- left column -->
      <div class="col-md-8"> 

        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Add Movie Form</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body"> 
            <!-- text input -->
            <div class="form-group">
              <label>Title:</label>
              <input type="text" class="form-control" placeholder="Enter Title" id="title" name="title" data-error="Enter title!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Year:</label>
              <input type="text" class="form-control" placeholder="Enter Year" id="year" name="year" data-error="Enter year!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Budget:</label>
              <input type="text" class="form-control" placeholder="Enter Budget" id="budget" name="budget" data-error="Enter budget!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Stage:</label>
              <input type="text" class="form-control" placeholder="Enter Stage" id="stage" name="stage" data-error="Enter stage!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Synopsis:</label>
              <input type="text" class="form-control" placeholder="Enter Synopsis" id="story" name="story" data-error="Enter story!" required />
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <label>Rating:</label>
              <input type="text" class="form-control" placeholder="Enter Rating" id="rating" name="rating" data-error="Enter rating!" required />
              <div class="help-block with-errors"></div>
            </div>

<!--             <div class="form-group">
              <label>Category:</label>
              <select class="form-control" name="moviecategory" id="moviecategory" required >
              </select>
              <div class="help-block with-errors"></div>
            </div>
 -->            
            <div class="form-group">
              <label>Release Date:</label>
              <input type="text" class="form-control" placeholder="Enter Release Date" id="release_date" name="release_date" data-error="Enter release date!" required />
              <div class="help-block with-errors"></div>
            </div>
            </div>
          </div>
          <!-- /.box-body -->
          
          <div class="box-footer">
            <!-- formaction="<?php //base_url(); ?>add" -->
            <button type="submit" class="btn btn-primary">Add Movie</button>
            <button type="reset" class="form-reset btn btn-primary">Reset</button>
          </div>
        </div>
        <!-- /.box --> 
        
  	<?php 

  	$buffer.=GetBuffer();

  	// $buffer.= '<br />Hello world buffer';
  }

  private function ToolBar(){
  	global $buffer;

  	$buffer.= '
  <h1> Add Bank </h1>
  <div class="row col-lg-1" style="float:right; margin-bottom:20px; margin-top:10px;">
    <input type="button" class="btn btn-block btn-info" value="Back" onclick="window.history.back()" />
  </div>
  <ol class="breadcrumb">
    <li><a href="admin/home"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="movie">Banks</a></li>
    <li class="active">Add Bank</li>
  </ol>
';  	
  }

  function Index_AdminToolBar(){
    $this->ToolBar();
  }

  // function Index_Action(){
  // 	global $buffer;

  // 	$buffer.= 'Trigerred from user-defined.';
  // }


 
}