<?php 

/**

@Inject(@services/Db,
        @services/file/FileUpload,
        @services/RequestResponse);


*/

class EntityCommit{

  private $entity = null;

  function GetEntity(){
    return $this->entity;
  }
  

  function RequireEntity(&$request){
    // print_r($request);
   if (!isset($request['entity'])){
     throw new Exception("entity - param required!", 1);
   }else{
     $this->entity = $request['entity'];
   }
   
  }

  function CheckDuplicateRecord(&$request){
    
    if (isset($request['check'])){
      
      $key = $request['check'];
      $value = $request['data'][$key];
      $record = $this->Db->Where($key,$value)->Get($this->entity);
      
      if (count($record) > 0){
        throw new Exception("Duplicate Record!", 1);
      }

    }

  }

  function CheckFileUpload(&$request){
    if (isset($_FILES)){
      foreach ($_FILES as $k=>$hnd){
       if ($this->FileUpload->DoUpload($hnd,$k)){
         $request['data'][$k] = $this->FileUpload->GetUploadedFile();
       }
      }
    }
  }

  function CheckDataFileUpload(&$request){

    if (isset($request['ImageData']) && is_array($request['ImageData'])){
       foreach ($request['ImageData'] as $k=>$v){
          if (!empty($v)){
             $this->FileUpload->DoDataUpload($k,$v);
             $request['data'][$k] = $this->FileUpload->GetUploadedFile();
          }
       }
    }

  }


  function DoAdd(&$request){

    if (!isset($request['data']))throw new Exception("data-param required!", 1);
    $data = $request['data'];
    $this->Db->Insert($this->entity,$data);    
    // $this->RequestResponse->SetResponse('newID',$this->Db->InsertID());
    // $this->RequestResponse->SetResponse('message','New Record Added.');
    return array('message'=>'New Record Added...','id'=>$this->Db->InsertID());

  }


  function DoUpdate($id,&$request){

    if (!isset($request['data']))throw new Exception("data-param required!", 1);
    // if (!isset($request['id']))throw new Exception("id-seek-param required!", 1);
    $data = $request['data'];
    // $id = $request['id'];
    $this->Db->Where('id',$id);
    $this->Db->Update($this->entity,$data);
    return array('message'=>'Record Saved....');
    // $this->RequestResponse->SetResponse('message','Record Saved.');

  }


  function DoDelete(&$request){

    if (!isset($request['id']))throw new Exception("id-seek-param required!", 1);
    $id = $request['id'];
    $this->Db->Where('id',$id);
    $this->Db->Delete($this->entity);
    // $this->RequestResponse->SetResponse('message','Record Removed.');
    return array('message'=>'Record Removed....');

  }


  function DoFilter(&$request){
    
     if (isset($request['filters'])){
       $filters = $request['filters'];
       if (is_array($filters)){
         $c = -1;
         foreach ($filters as $k=>$v){
           
           ++$c;
           if ($c == 0){
             $this->Db->Where($k,$v);
           }else{
             $this->Db->And($k,$v);
           }

         }

       }
     }

  }



 function CallUCAction(){
   
   $args = func_get_args();
   $obj = array_shift($args);
   $result = array();

      try {
        
        // $obj->Exec();
        $response = call_user_func_array(array($obj,'Exec'), $args);

        // $response = $this->RequestResponse->GetResponse();  
        foreach ($response as $k=>$v){
         // InjectViewClass::SetKey($k,$v); 
          $result[$k] = $v;
        }
        // InjectViewClass::SetKey('message',$e->getMessage());
        // InjectViewClass::SetKey('error',false);
        $result['error'] = false;

      } catch (Exception $e) {

        // InjectViewClass::SetKey('message',$e->getMessage());
        $result['message'] = $e->getMessage();
        $result['error'] = true;
        // InjectViewClass::SetKey('error',true);
        
      }



      return $result;

 } 




}