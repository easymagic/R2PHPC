<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class WigCreate{

 
 function Exec(){
   
   $data = $this->DataRequirement->Check('data');
   $data = $data['data'];

   $this->Db->Insert('wig',$data);

   $this->RequestResponse->SetResponse('message','Wig added successfully.');
   $this->RequestResponse->SetResponse('newID',$this->Db->InsertID());

 }


} 