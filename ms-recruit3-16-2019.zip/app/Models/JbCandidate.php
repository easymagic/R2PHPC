<?php

namespace App\Models;

use Illuminate\Http\Request;

use Illuminate\Database\Eloquent\Model;

use App\User;

use Smalot\PdfParser\Parser as SmalotParser;




class JbCandidate extends Model{
    //
    protected $table = 'jb_candidates';

    protected $fillable = ['user_id','name','email','phone_number','address','age','gender','marital_status','cover_letter','cv_string'];
    //cv_upload

                // 'name'=>'required',
                // 'email'=>'required',
                // 'phone_number'=>'required',
                // 'address'=>'required',
                // 'date_of_birth'=>'required',
                // 'gender'=>'required',
                // 'marital_status'=>'required',
                // 'cover_letter'=>'required'


    // const UPDATED_AT = null;
    // const CREATED_AT = null;


    function candidateEducations(){
    	return $this->hasMany(JbCandidateEducation::class,'jb_candidate_id');
    }

    function candidateJobs(){
        return $this->hasMany(JbCandidateJob::class,'jb_candidate_id');
    }

    function candidateCertifications(){
       return $this->hasMany(JbCandidateCertification::class,'jb_candidate_id');
    }


    function candidateSkills(){
       return $this->hasMany(JbCandidateSkill::class,'jb_candidate_id');
    }

    function candidateWorkExperience(){
       return $this->hasMany(JbCandidateWorkExperience::class,'jb_candidate_id'); 
    }


    function user(){
        return $this->belongsTo(User::class,'user_id');
    }

    function competencies(){
    	return $this->hasMany(JbCandidateCompetency::class,'jb_candidate_id');
    }


    static function myCv($userID){
      return JbCandidate::where('user_id',$userID)->first();
    }

   
    function scanText($txt){
      $r = [];
      for ($c = 0;$c < strlen($txt);$c++){
       if ($txt[$c] == "," || $txt[$c] == '.'){
         $r[] = "_SPC_" ;   
       }else{
         $r[] = trim($txt[$c]);
       }
      }
     return implode('', $r);
    }



    function grabCvText(SmalotParser $parser,Request $request){

          $allowed = ['pdf'];

         if ($request->has('cv_upload') || !is_null($request->cv_upload)){
     
            $mime = $request->cv_upload->getClientOriginalextension();
            // dd($mime);
            
            if (!(in_array($mime, $allowed))): throw new \Exception("Invalid File Type"); endif;

            $pdf = $parser->parseFile($request->cv_upload->getRealPath());
                        
            $text = $pdf->getText();

            $text =  $this->scanText($text);

            // dd('pause');

            // $text = $this->mssqlEscape($text);

            // $this->cv_string = addslashes($text);
                
            // dd($this);    

            $this->update([
              'cv_string'=>$text
            ]);

            // echo $text;
            // dd($text);

         }  

    }






    function runFilter($filters=[]){
      
      
      // $query = JbCandidate;

      $query = $this;
      

      //Age Start / Stop .
      if (isset($filters['ageStart'])){

          $query = $query->where('age','>=',$filters['ageStart']);

          if (isset($filters['ageStop'])){
            $query = $query->where('age','<=',$filters['ageStop']);
          }

      }

      
      // Skills
      if (isset($filters['skill'])){
                
          $skill = $filters['skill'];

          foreach ($skill as $skl){

           
           if (is_numeric($skl)){

            // echo '111:' . $skl;

           
               $query = $query->whereHas('candidateSkills',function($innerQuery2) use ($filters,$skl){

                     $innerQuery2->where('jb_skill_id',$skl);
                   
               });
           
           }else{

            // echo 'called...' . $skl;

                $query = $query->where('cv_string','like',"%" . $skl . "%");

           }
            
          }

      }



      // Skills
      if (isset($filters['certification'])){
        
          $certification = $filters['certification'];

          foreach ($certification as $cert){

            
           
           if (is_numeric($cert)){
            
                $query = $query->whereHas('candidateCertifications',function($innerQuery2) use ($filters,$cert){

                       $innerQuery2->where('jb_certification_id',$cert);
                     
                });  
           
           }else{

               $query = $query->where('cv_string','like',"%" . $cert . "%");

           }
            
          }

      }

      //competence
      if (isset($filters['keyword'])){

       // print_r($filters);

          $keyword = $filters['keyword'];

          foreach ($keyword as $kwd){            
           // echo $kwd;
              $query = $query->where('cv_string','like',"%" . $kwd . "%"); 
             
          }


      }


      return $query->paginate(7);        

    }





}
