<?php

namespace App\Http\Controllers\Education;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Http\Controllers\Base\BaseController;
use App\Models\JbEducation;

class EducationController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    private $rootTemplate = 'education'; 
    private $resource = 'education';
    private $storeMessage = 'Education Added';
    private $destroyMessage = 'Education Removed';
    private $updateMessage = 'Education Saved';

    public function index()
    {
        //
        return view($this->rootTemplate . '.index',[
             'educations'=>JbEducation::paginate(7)
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view($this->rootTemplate . '.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = request()->validate([
              'name'=>'required'
        ]);
        $data['created_by'] = \Auth::user()->id;
        try {

            JbEducation::create($data);
            return $this->logSuccess($this->resource . '.index',[],$this->storeMessage);
        } catch (Exception $e) {
            return $this->logError($this->competence . '.create',[],$e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(JbEducation $education)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(JbEducation $education)
    {
        //
        return view($this->rootTemplate . '.edit',[
          'education'=>$education
        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JbEducation $education)
    {
        //
        try {
            $education->update(request()->validate([
              'name'=>'required' 
            ]));
            return $this->logSuccess($this->resource . '.index',[],$this->updateMessage);
        } catch (Exception $e) {
            return $this->logError($this->resource . '.edit',[],$e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(JbEducation $education)
    {
        //
        try {
            $education->delete();
            return $this->logSuccess($this->resource . '.index',[],$this->destroyMessage);
        } catch (Exception $e) {
            return $this->logError($this->resource . '.index',[],$e->getMessage());
        }
    }

}
