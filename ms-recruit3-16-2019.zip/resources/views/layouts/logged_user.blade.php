@section('content')
<div class="col-lg-12">
<span onclick="openNav()" style="cursor: pointer;">
  <img src="/burger.png" style="width: 32px;">
</span>	
</div>
<div class="col-lg-3 sidebar">
  @include('sidebars.admin_sidebar')
</div>
<div class="col-lg-9 post-list" style="@yield('main-center-style','margin-left: 11%;')">
 @yield('inner-content')
</div>
@endsection