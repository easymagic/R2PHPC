@extends('layouts.main')

@extends('layouts.logged_user')

@section('inner-content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="col-md-12">
                <u style="color: #000;font-size: 16px;">Dashboard</u>
            </div>

            @if (Auth::user()->role == 'admin')
            <a href="{{ route('job.index') }}">
            <div class="col-xs-12 col-md-3" style="display: inline-block;margin-bottom: 4px;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($jobCount)}} - Jobs
                    <!-- [end] -->
                    </div>
                </div>                
            </div>
            </a>


            <div class="col-xs-12 col-md-3" style="display: inline-block;margin-bottom: 4px;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($applicantCount)}} - Applicants
                    <!-- [end] -->
                    </div>
                </div>                
            </div>



            <a href="{{ route('skill.index') }}">
            <div class="col-xs-12 col-md-3" style="display: inline-block;margin-bottom: 4px;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($skillCount)}} - Added Skills
                    <!-- [end] -->
                    </div>
                </div>                
            </div>
            </a>

            
            <a href="{{ route('education.index') }}">
            <div class="col-xs-12 col-md-3" style="display: inline-block;margin-bottom: 4px;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($educationCount)}} - Added Institutions
                    <!-- [end] -->
                    </div>
                </div>                
            </div>
            </a>


           <a href="{{ route('user.index') }}">
            <div class="col-xs-12 col-md-3" style="display: inline-block;margin-bottom: 4px;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($userCount)}} - Users
                    <!-- [end] -->
                    </div>
                </div>                
            </div>
            </a>


            @else 

            <div class="col-xs-12 col-md-3" style="display: inline-block;margin-bottom: 4px;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           {{number_format($jobAppliedCount)}} - Applied Jobs
                    <!-- [end] -->
                    </div>
                </div>                
            </div>

            @endif




        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>

@endsection
