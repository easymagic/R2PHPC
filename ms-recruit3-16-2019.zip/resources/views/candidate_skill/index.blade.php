                    <div style="border-bottom: 1px solid #000;" id="candidate-skill">
                        <b style="color: #000;">Your Skills</b>
                    </div>

                    <div class="col-lg-12">
                        
                        <table class="table">
                            <tr>
                                <th>Skill</th>
                            </tr>
                            @foreach ($candidate->candidateSkills as $candidateSkill)
                             <tr>
                                 <td>{{$candidateSkill->skill->name}}</td>
                                 <td>
            <div class="dropdown show">
                <button class="btn btn-success dropdown-toggle btn-sm pull-right" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    Action
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; transform: translate3d(-5px, 38px, 0px); top: 0px; left: 0px; will-change: transform;"> 

                     <form method="post" action="{{ route('candidateskill.destroy',$candidateSkill->id) }}">
                        <!-- /candidate-educations/{candidateEducation}/delete -->
                        
                        @csrf
                        @method('DELETE')

                     <button class="dropdown-item btn btn-danger btn-sm" data-backdrop="false"  data-toggle="modal" data-target="#approveReject" >Remove</button>
                     </form>

                </div>
            </div>                                                  
                                 </td>
                             </tr> 
                            @endforeach
                        </table>



                        <form method="post" action="{{ route('candidateskill.store') }}">
                            <!-- /candidate-educations/add/{candidate}/{user} -->
                            @csrf
                            @method('POST')

                        <table class="table">
                            <tr>
                                
                                <td>
                                <select class="form-control" name="jb_skill_id" style="width: 90%;display: inline-block;">
                                    <option value="">--Select Skill--</option>
                                    @foreach ($skills as $skill)
                                    <option value="{{$skill->id}}">{{$skill->name}}</option>
                                    @endforeach
                                </select>                                    
                                </td>

                                <td align="right">
                                    
                                <button type="submit" class="btn btn-primary btn btn-sm" style="margin-top: 0;">
                                    {{ __(' + ') }}
                                </button>

                                </td>

                            </tr>
                        </table>

                        </form>






</div>
