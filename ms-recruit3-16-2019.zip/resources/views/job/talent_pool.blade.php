@extends('layouts.main')

@extends('layouts.logged_user')

@section('side-bar')

 @include('job.job_filter')
 
@endsection

@section('main-center-style')
 ''
@endsection

@section('inner-content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            
                <!-- <div class="card-header">{{ __('Change Password') }}</div> -->

<div style="
    border-bottom: 3px solid #8c76f7;
    margin-bottom: 17px;
    font-size: 18px;
">
    Applicants
</div>

@include('notifications.message')

 
<!-- <div class="col-md-12">
    <label>
      Keywords Search
    </label>

    <input type="text" name="" placeholder="Keywords" style="padding-left: 7px;" />

</div> 
 -->
<span id="outlet">
  

</span>
                
        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>


<!-- dialog -->
<div class="modal fade modal-3d-slit show" id="profileView" aria-labelledby="exampleModalTitle" role="dialog" style="display: none; padding-right: 17px;">

  <div class="modal-dialog modal-lg">



  <!-- [end] -->
  </div>
</div>
<!-- dialog -->


<script type="text/javascript">
  // /view-applicants/{job}/ajax
  (function($){
    $(function(){
          
          function isEmpty($v){
            return $v == '' || $v == ' ' || $v == null;
          }

          function has($k){
            return !isEmpty(getInput($k));
          }

          function getInput(k){
            return $('#' + k).val(); 
          }
       
          function getFilterConfig(){
           
           var config = {};

            if (has('age-start')){
              config['ageStart'] = getInput('age-start');  
            }

            if (has('age-stop')){
              config['ageStop'] = getInput('age-stop');
            }


            if (has('skill')){
             config['skill'] = getInput('skill');
            } 

            if (has('certification')){
             config['certification'] = getInput('certification');  
            }

            if (has('competence')){
             config['competence'] = getInput('competence');
            }

            if (has('keyword')){ //keyword
              config['keyword'] = getInput('keyword');
            }

           return config;

          }


          $('#filter-btn').on('click',function(){
             
             try{
             // loadAjaxTable();
          loadAjaxTable("{{ route('job.applicants.pool.ajax') }}");

             }catch(e){
               console.log(e);
             }

             return false;

          });

         
          function loadAjaxTable(api){
           // config = config || {};  
           $('#outlet').html('Loading ... ');   
           $.ajax({
            url:api,
            type:'get',
            data:getFilterConfig(),
            success:function(response){
              console.log(response);
               $('#outlet').html(response); 
               initClientAjaxPagination(); 
            }
           });
          }

          function configToGetRequest(){
            var cfg = getFilterConfig();
            return '&' + $.param(cfg);
          }

          function initClientAjaxPagination(){
            $('.page-link').on('click',function(){

                
                var api = $(this).attr('href');
                
                // console.log(api + configToGetRequest());
                // alert(api + configToGetRequest());   
                loadAjaxTable(api + configToGetRequest());

                return false;



            });             
          }

          loadAjaxTable("{{ route('job.applicants.pool.ajax') }}");

    });
  })(jQuery);
</script>

@endsection
