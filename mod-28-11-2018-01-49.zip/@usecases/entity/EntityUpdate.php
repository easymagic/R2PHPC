<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);


*/
class EntityUpdate{


  function Exec($id=''){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     $this->EntityCommit->CheckFileUpload($request);
     $this->EntityCommit->CheckDataFileUpload($request);
     return $this->EntityCommit->DoUpdate($id,$request);

  }


}

