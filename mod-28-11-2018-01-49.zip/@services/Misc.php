<?php 

class Misc{
  
  function Humanize($str){
  	$r = explode('_', $str);
  	$r = array_map('ucfirst', $r);
  	return implode(' ', $r);
  }
  
}