<?php 
 
/**
@Inject(app-x/core/ObjectProxy);
*/ 



 class PluginLoader{

   private $plugins = array();
   private $pluginsObj = array();
   
   function GetPlugins(){
    if (count($this->plugins) <= 0){

      $this->plugins = scandir('@plugins');
      $this->plugins = array_diff($this->plugins, array('.','..'));

      foreach ($this->plugins as $k=>$v){

         $name  = explode('.', $v);
         array_pop($name);
         $name = array_pop($name);
         $pluginDir = '@plugins/' . $name;
         $this->pluginsObj[$name] = DIContainer::GetInstance()->DecodeAnnotationKey($pluginDir);

      }

    }

    return $this->plugins; 
   }
   
   

   //$this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

   function CallPluginHooks($plugins,$obj,$name,$method,$args){

     $this->GetPlugins();

     foreach ($this->pluginsObj as $k=>$v){
       if (in_array($k, $plugins) && method_exists($v, 'SetEntity')){
          $v->SetEntity($name);
          $this->ObjectProxy->CallProxy($v,$method,$args);
       }
     }

   }



 }
