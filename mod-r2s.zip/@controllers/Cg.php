<?php
/**

@Inject(@templates/cg/GenControllerTemplate,
        @services/FileIO,
        @services/DbFields,
        @templates/cg/GenReadTemplate,
        @templates/cg/GenCreateTemplate,

        @templates/cg/GenCreateUCTemplate,
        @templates/cg/GenUpdateUCTemplate,
        @templates/cg/GenDeleteUCTemplate,
        @templates/cg/GenReadUCTemplate,

        @services/Misc,
        @templates/cg/GenEditTemplate,
        @templates/cg/GenSelectTemplate);

*/


class Cg{
  
  

  function Init(){
    
  }

  private function EncodeWithMessageJS($code){
   $code = "<script> var message = '<?php echo " . '$message;' . " ?>';</script>" . $code;
   return $code;
  }

  private function EncodeWithPHP($code){
    // $code = $this->EncodeWithMessageJS($code);
    $code = "<?php $code ";
    return $code;
  }

  private function EncodeWithDataJS($ctrl,$code){
    $code = $this->EncodeWithMessageJS($code);
    $ctrl = $ctrl . 'Data';
    $code = '<script> var ' . $ctrl . ' = <?php echo json_encode($data); ?> </script>' . $code;
    return $code;
  }


  private function GenerateController($ctrl){
    $this->GenControllerTemplate->name = $ctrl;
    $data = $this->GenControllerTemplate->View();
    $data = $this->EncodeWithPHP($data);
    $this->FileIO->Write("@framework/controllers/$ctrl.php",$data);
    echo "<br />Controller $ctrl Generated.<br />";
    $this->GenerateCreateTemplate($ctrl);
  }

  private function GenerateCreateTemplate($ctrl){
    //GetFields
    $fields = $this->DbFields->GetFields($ctrl);
    $this->GenCreateTemplate->fields = $fields;
    $this->GenCreateTemplate->Misc = $this->Misc;
    $this->GenCreateTemplate->createUC = strtolower($ctrl) . '/' . $ctrl . 'Create';
    $this->GenCreateTemplate->title = 'Add ' . $ctrl;
    $this->GenCreateTemplate->ctrl = $ctrl;

    $data = $this->GenCreateTemplate->View();

    $data = $this->EncodeWithMessageJS($data);

    $path = strtolower($ctrl);

    $this->FileIO->CreateDir("@templates/$path");

    $this->FileIO->Write("@templates/$path/CreateTemplate.php",$data);

    echo "Create-Template for $ctrl Generated.<br />";

    $this->GenerateEditTemplate($ctrl);

  }


  private function GenerateEditTemplate($ctrl){
    //GetFields
    $fields = $this->DbFields->GetFields($ctrl);
    $this->GenEditTemplate->fields = $fields;
    $this->GenEditTemplate->Misc = $this->Misc;
    $this->GenEditTemplate->updateUC = strtolower($ctrl) . '/' .  $ctrl . 'Update';
    $this->GenEditTemplate->ctrl = $ctrl;

    $this->GenEditTemplate->title = 'Edit ' . $ctrl;

    $data = $this->GenEditTemplate->View();

    // $data = $this->EncodeWithMessageJS($data);

    $data = $this->EncodeWithDataJS($ctrl,$data);

    $path = strtolower($ctrl);

    $this->FileIO->CreateDir("@templates/$path");

    $this->FileIO->Write("@templates/$path/EditTemplate.php",$data);

    echo "Edit-Template for $ctrl Generated.<br />";

    $this->GenerateCreateUC($ctrl);

  }

  function GenerateCreateUC($ctrl){

    $this->GenCreateUCTemplate->name = $ctrl;

    $data = $this->GenCreateUCTemplate->View();

    $data = $this->EncodeWithPHP($data);

    $path = strtolower($ctrl);
    
    $this->FileIO->CreateDir("@usecases/$path");
    $this->FileIO->Write("@usecases/$path/$ctrl" . 'Create' . ".php",$data);

    echo "Create - usecase for $ctrl Generated.<br />";

    $this->GenerateReadUC($ctrl);
  }

  function GenerateReadUC($ctrl){

    $this->GenReadUCTemplate->name = $ctrl;

    $data = $this->GenReadUCTemplate->View();

    $data = $this->EncodeWithPHP($data);

    $path = strtolower($ctrl);
    
    $this->FileIO->CreateDir("@usecases/$path");
    $this->FileIO->Write("@usecases/$path/$ctrl" . 'Read' . ".php",$data);

    echo "Read - usecase for $ctrl Generated.<br />";
    

    $this->GenerateUpdateUC($ctrl);
  }

  function GenerateUpdateUC($ctrl){


    $this->GenUpdateUCTemplate->name = $ctrl;

    $data = $this->GenUpdateUCTemplate->View();

    $data = $this->EncodeWithPHP($data);

    $path = strtolower($ctrl);
    
    $this->FileIO->CreateDir("@usecases/$path");
    $this->FileIO->Write("@usecases/$path/$ctrl" . 'Update' . ".php",$data);

    echo "Update - usecase for $ctrl Generated.<br />";
    

   

    $this->GenerateDeleteUC($ctrl);
  }

  function GenerateDeleteUC($ctrl){

    $this->GenDeleteUCTemplate->name = $ctrl;

    $data = $this->GenDeleteUCTemplate->View();

    $data = $this->EncodeWithPHP($data);

    $path = strtolower($ctrl);
    
    $this->FileIO->CreateDir("@usecases/$path");
    $this->FileIO->Write("@usecases/$path/$ctrl" . 'Delete' . ".php",$data);

    echo "Delete - usecase for $ctrl Generated.<br />";

    $this->GenerateReadTemplate($ctrl);

  }

  function GenerateReadTemplate($ctrl){
  
    //GetFields
    $fields = $this->DbFields->GetFields($ctrl);
    $this->GenReadTemplate->fields = $fields;
    $this->GenReadTemplate->Misc = $this->Misc;
    $this->GenReadTemplate->name = $ctrl;
    // $this->GenCreateTemplate->createUC = $ctrl . 'Create';
    $this->GenReadTemplate->title = 'Showing List ' . $ctrl;

    $data = $this->GenReadTemplate->View();

    // $data = $this->EncodeWithMessageJS($data);
    $data = $this->EncodeWithDataJS($ctrl,$data);
    

    $path = strtolower($ctrl);

    $this->FileIO->CreateDir("@templates/$path");

    $this->FileIO->Write("@templates/$path/ReadTemplate.php",$data);

    echo "Read-Template for $ctrl Generated.<br />";

    $this->GenerateSelectTemplate($ctrl);

  }

  function GenerateSelectTemplate($ctrl){

    
    $data = $this->FileIO->Read("@templates/cg/GenSelectTemplate.php"); 

    $path = strtolower($ctrl);

    $this->FileIO->CreateDir("@templates/$path");

    $this->FileIO->Write("@templates/$path/" . $ctrl . "SelectTemplate.php",$data);

    // $this->FileIO->Write();

    echo "Select-Template for $ctrl Generated... Successfully.<br />";     

  }

  
  function Index($entity='Wig'){
     echo 'Code - Gen Started ... ';
     $this->GenerateController($entity); //'Wig'
  }


 
}