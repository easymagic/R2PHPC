<?php 

/**

@Inject(@templates/cropit/CropitTemplate);

*/


class Category{

  function UsePlugins(){
    return array('CrudPlugin','CrudPermissionPlugin','CrudTemplatePlugin','APIPlugin');
    //OEM: (Original Equipment Manufacturer).
  }

  
  function Init(){
   // $this->Repository->UseResource('category');  
  }

  function Before_Index(){
    // $this->Db->Where('id','8');
  }

  // function DropDown($k,$v,$filterKey,$filterValue){
  // }




}
 