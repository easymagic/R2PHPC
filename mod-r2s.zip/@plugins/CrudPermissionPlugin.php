<?php 

/**

@Inject(@templates/error/ErrorTemplate);

*/

class CrudPermissionPlugin{
  
  function SetEntity($entity=''){}
  
  private function RaiseError($msg){
    $this->ErrorTemplate->error_message = $msg;
    throw new Exception($this->ErrorTemplate->View(), 1);
  }

  function Index_Permission(){
    // $this->RaiseError('You cant access this index page');
  }

  function Edit_Permission(){
    // $this->RaiseError('You cant access this edit - page'); 
  }

  function Add_Permission(){
    // $this->RaiseError('You cant access this add - page');  
  }

  function Remove_Permission(){
    // $this->RaiseError('You cant access this remove - page'); 
  }

  function Remove_Action_Permission(){
    // $this->RaiseError('You cant access this remove action. - page'); 
  }

  function Edit_Action_Permission(){
    // $this->RaiseError('You cant access this update action.'); 
  }



}


