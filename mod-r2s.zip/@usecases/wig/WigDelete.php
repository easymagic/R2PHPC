<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class WigDelete{

 
 function Exec(){
   
   $data1 = $this->DataRequirement->Check('id');
   $id = $data1['id'];

   foreach ($id as $ID){
    $this->Db->Where('id',$ID);
    $this->Db->Delete('wig');
   }


   $this->RequestResponse->SetResponse('message','Wig removed successfully.');

 }


} 