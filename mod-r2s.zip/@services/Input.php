<?php 

class Input{

  

  function Val($vl,$name='data'){

    $data = InjectViewClass::GetKey($name);
    if (empty($data)){
     return '';
    }else{
     if (isset($data[$vl])){
       return $data[$vl];
     }else{
       return ''; 
     }
    }
    
  }


}