<?php 
 
 // print_r($data);

 if ( count($data) > 0 ){
  // $data = $data['data'];
?>
<div class="card">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $title; ?></h4>
                  <p class="card-description">
                    
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Operations</th>
                        </tr>
                      </thead>
                      <tbody>

 				        <?php 
           	             foreach ($data as $k=>$v){
 				        ?>
                        <tr>
                          
                          <td><?php echo $v['name']; ?></td>
                          <td>
    <?php 
     if ($_SESSION['user_account']['role'] == 'admin'){
    ?>                            
                          	<a class="btn btn-success" href="<?php echo $edit_url . $v['id']; ?>">Edit</a>

    <a href="?ccmd=assetLocation/AssetLocationDelete&where[id]=<?php echo $v['id']; ?>" class="btn btn-danger btn-sm confirm"><i class="remove mdi mdi-close-circle-outline"></i></a>

   <?php 
    }else{
      echo 'N/A';
    }
   ?>                            
                          </td>

                          
                        </tr>
                        <?php 
                         }
                        ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
<?php 
 }else{
  echo 'No Locations.';
 }
?>
<script type="text/javascript">
  (function($){
    $(function(){

        function InitDataTable(){

            // "aLengthMenu": [
            //   [5, 10, 15, -1],
            //   [5, 10, 15, "All"]
            // ],


          $('.table').DataTable({
            "iDisplayLength": 10,
            "language": {
              search: "Client Search."
            }
          });

        }


        InitDataTable();


    });
  })(jQuery);
</script>