<?php 

class admin_change_password implements iusecase{
  
  use entity_change_password_trait;

  
  //abstract implementations
  function get_table_name(){
  	return 'admin';
  }

  function get_password_map_field(){
   return 'password';
  }

  function get_change_password_success_message(){
    return 'Password successfully changed.';
  }

  function get_change_password_failure_message(){
  	return 'Invalid password!';
  }


}