<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class CategoryCreate{

 
 function Exec(){
   
   $data = $this->DataRequirement->Check('data');
   $data = $data['data'];

   $this->Db->Insert('category',$data);

   $this->RequestResponse->SetResponse('message','Category added successfully.');
   $this->RequestResponse->SetResponse('newID',$this->Db->InsertID());

 }


} 