<?php 

/**
@Inject(app-x/core/PluginLoader,
        app-x/core/Router,
        app-x/core/RequestResponse);
*/


class FrontController{
  

  private $obj = null;
  private $name = '';
  private $method = 'Index';
  private $args = array();
  private $plugins = array();
  private $request = array();
  private $parentLookOut = array('dba'=>'DbaV2');


  function __construct(){}

  // private function CheckParentLookOut($name){
  //   if (in_array($name, array_keys($this->parentLookOut))){
  //     // array_unshift($this->args,$this->name);
  //     array_unshift($this->args,$this->method);
  //     $this->name  = $this->parentLookOut[$name];
  //     $this->method = 'Map'; //http://localhost/forde/Dba/category/[ShowList,Add,Edit]
  //     $controllerPath = '@controllers/' . $this->name;
  //     $this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

  //   }
  // }

  function DecodeRequest(){
    $this->request = $_REQUEST['__request__'];
    $this->RequestResponse->SetRequest($_REQUEST);
    $r = explode('/', $this->request);

    if (count($r) >= 1){
     $this->name = array_shift($r);
     $this->method = array_shift($r);
     $this->args = $r;
    }else{
     $this->name = DEFAULT_CONTROLLER;
    }

    if (empty($this->method) || is_numeric($this->method)){
     $this->method = 'Index';
    }

    $controllerPath = '@controllers/' . $this->name;

    $this->name = strtolower($this->name);


    $this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);
    
  }


  function DecodePluginUse(){
   
      if (method_exists($this->obj, 'UsePlugins')){
       $this->plugins = $this->obj->UsePlugins();
      }

     // print_r($this->plugins);
  }

 
  function DispatchRequest(){
   
   try {

    // $this->CheckParentLookOut($this->name);

    // array('plugins'=>$this->plugins,
    //       'sender'=>$this->obj,
    //       'name'=>$this->name,
    //       'method'=>$this->method,
    //       'args'=>$this->args)
    if (method_exists($this->obj, 'GetEntity_Hook')){
       $this->name = $this->obj->GetEntity_Hook();
    }

     $this->Router->SetParams($this->plugins,$this->obj,$this->name,$this->method,$this->args);

     $this->Router->DispatchAction($this->method,$this->args);

     $this->Router->DispatchRoute($this->method,$this->args);
     
   } catch (Exception $e) {
     
     echo $e->getMessage();

   }

   


  }






}