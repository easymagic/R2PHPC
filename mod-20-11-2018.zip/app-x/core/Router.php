<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/View,
        app-x/core/RequestResponse);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;
   

  private function EndsWith($str,$ends){
   $end = substr($str, -1 * strlen($ends));
   $end = strtolower($end);
   if ($end == strtolower($ends)){
    return true;
   }else{
    return false;
   }
  }

  function SetParams($plugins,$obj,$name,$method,$args){
   $this->plugins = $plugins;
   $this->obj = $obj;
   $this->name = $name;
   $this->method = $method;
   $this->args = $args;
  }

  function DispatchAction($method,$args=array()){

     $plugins = $this->plugins;
     $obj = $this->obj;
     $name = $this->name;


     $this->PluginLoader->SetParams($plugins,$obj,$name,$method,$args);

     if (isset($_POST) && !empty($_POST)){
      
      $method = $method . '_Action';
      $this->PluginLoader->CallPluginHooks($method . '_Permission',$args);
      $this->PluginLoader->CallPluginHooks($method,$args);
      $this->CallAction($method,$args);        

     }else{

       $this->PluginLoader->CallPluginHooks('No_Action',$args);

     }    
     

  }

  function DispatchRoute($method,$args=array()){

     $plugins = $this->plugins;
     $obj = $this->obj;
     $name = $this->name;

     $this->PluginLoader->SetParams($plugins,$obj,$name,$method,$args);
      
      /////////////////////////////////////
      if ($this->EndsWith($method,'_Action')){
        throw new Exception("<h1>Not Allowed!!!</h1>");
      }
      //////Options - hook /////////////////
      $arg2 = array('sender'=>$obj,'plugins'=>$plugins,'obj'=>$obj,'name'=>$name,'method'=>$method,'args'=>$args,'loader'=>$this->ObjectProxy,'pluginLoader'=>$this->PluginLoader);      
      $this->PluginLoader->CallPluginHooks('Options_Hook',array($arg2) );
      ////universal-hook//////////
      $this->PluginLoader->CallPluginHooks('Universal_Hook',$args);
      /////////////////////////////////////
      $this->PayloadService->DecodePayload();
      $payloadData = $this->PayloadService->ExportPayload();
      $args2 = array($payloadData);
      $this->PluginLoader->CallPluginHooks($method . '_Payload',$args2);
      /////////////////////////////////////
      $this->PluginLoader->CallPluginHooks($method . '_Permission',$args);
      /////////////////////////////////////
      $this->CallAction('Before_' . $method,$args);        
      /////////////////////////////////////
      // $args2 = array_merge($args,array($this->View));
      $this->PluginLoader->CallPluginHooks($method . '_Inject',$args);
      /////////////////////////////////////
      $templateString = "@templates/$name/$method" . 'Template';
      $templateObject = DIContainer::GetInstance()->DecodeAnnotationKey($templateString);
      $args2 = array($templateObject);
      if (!method_exists($obj, $method)){
       $this->PluginLoader->CallPluginHooks($method . '_Render',$args2);
      }
      /////////////////////////////////////      
      $this->PluginLoader->CallPluginHooks($method,$args);
      /////////////////////////////////////
      $this->CallAction($method,$args);        
      /////////////////////////////////////
      $args = array_merge($args,array($this->RequestResponse));
      $this->PluginLoader->CallPluginHooks($method . '_JSON',$args);


  }


  function CallAction($method,$args){

      $this->ObjectProxy->CallProxy($this->obj,$method,$args);

  }




}