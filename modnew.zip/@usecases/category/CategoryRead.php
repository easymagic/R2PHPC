<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class CategoryRead{

 
 function Exec(){
   
   $record = $this->Db->Get('category');

   $this->RequestResponse->SetResponse('data',$record);

 }


} 