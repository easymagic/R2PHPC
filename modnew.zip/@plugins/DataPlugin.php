<?php 

/**

@Inject(@services/Db);

*/

class DataPlugin{

  private $entity;
  private $Obj;
  private $name;
  private $method;
  private $loader;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function Options_Hook($options){
    // print_r(func_get_args());
    $this->Obj = $options['sender'];
    $this->plugins = $options['plugins'];
    $this->name = $options['name'];
    $this->method = $options['method'];
    $this->loader = $options['loader'];
  }

  function Universal_Hook(){

    $args = func_get_args();

    if (method_exists($this->Obj,'GetEntities')){
     $entities = $this->Obj->GetEntities();
     foreach ($entities as $k=>$v){
       

       $this->loader->CallProxy($this->Obj,'BeforeDataSeek_' . $k,$args);
       $dataName = $k . '_data';
       $this->View->$dataName = $this->Db->Get($v);

     }
    }

    if (method_exists($this->Obj, 'GetCountEntities')){
     $entities = $this->Obj->GetCountEntities();
     foreach ($entities as $k=>$v){
       

       $this->loader->CallProxy($this->Obj,'BeforeDataCount_' . $k,$args);
       $dataName = $k . '_count';
       $record = $this->Db->DoCount($v);
       $this->View->$dataName = $record[0]['recordCount'];

     }      
    }


    if (method_exists($this->Obj, 'GetSumEntities')){
     $entities = $this->Obj->GetSumEntities();
     foreach ($entities as $k=>$v){
       

       $this->loader->CallProxy($this->Obj,'BeforeDataSum_' . $k,$args);
       $dataName = $k . '_sum';
       $record = $this->Db->DoSum($v[0],$v[1]);
       
       $this->View->$dataName = $record[0]['sumTotal'];

     }      
    }
    
    

  }




}


