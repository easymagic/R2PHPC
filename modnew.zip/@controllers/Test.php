<?php
/**

@Inject(@services/FolderMigrate,
        @controllers/Category,
        @services/UIComponent,
        @templates/console/TerminalTemplate,
        @services/DbFields,
        @services/CommandSignal);

*/

//HMT

class Test{
  
  


  
  function Index(){
     echo 'Testing ...';
  }


 
}