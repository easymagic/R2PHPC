<?php 
 
 // global $user_count;
 // Provide('user.UserMettaRead',array(
 //   'where'=>array(
     
 //   )
 // ));


 // Provide('asset.AssetMettaRead',array(
 //   'where'=>array(

 //   )
 // ));

 // global $data_count;
 // global $data_sum_purchase_price;

 // LogvMessage();

?>
          <div class="row">
            <div class="col-12 grid-margin">
              
              <div class="card0 card-statistics">


<!-- dshb -->

<div class="row">
            <div class="col-md-6 grid-margin">
              <div class="card">
                <div class="card-body" style="min-height: 20vh !important;">
                  <h4 class="card-title mb-0">Assets</h4>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="d-inline-block pt-3">
                      <div class="d-flex">
                        <h2 class="mb-0">
<?php 
 // print_r($data_count);
 // echo $data_count;
?>
                          <?php echo number_format($data_count[0]['record_count']); ?></h2>
                        <div class="d-flex align-items-center ml-2">
                          <i class="mdi mdi-clock text-muted"></i>
                          <!-- <small class=" ml-1 mb-0">Updated: 9:10am</small> -->
                        </div>
                      </div>
                      <small class="text-gray">Assets</small>
                    </div>
                    <div class="d-inline-block">
                      <div class="bg-success px-4 py-2 rounded">
                        <i class="mdi mdi-buffer text-white icon-lg"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 grid-margin">
              <div class="card">
                <div class="card-body" style="min-height: 20vh !important;">
                  <h4 class="card-title mb-0">Accounts</h4>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="d-inline-block pt-3">
                      <div class="d-flex">
                        <h2 class="mb-0"><?php echo number_format($user_count[0]['record_count']); ?></h2>
                        <div class="d-flex align-items-center ml-2">
                          <i class="mdi mdi-clock text-muted"></i>
                          <!-- <small class=" ml-1 mb-0">Updated: 05:42pm</small> -->
                        </div>
                      </div>
                      <small class="text-gray">Users</small>
                    </div>
                    <div class="d-inline-block">
                      <div class="bg-warning px-4 py-2 rounded">
                        <i class="mdi mdi-wallet text-white icon-lg"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<!-- dshb -->


<!--                 <div class="row">

                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          <i class="mdi mdi-account-multiple-outline text-primary mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
                            <p class="card-text mb-0">Staffs</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo number_format($user_count[0]['record_count']); ?></h3>
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          <i class="mdi mdi-checkbox-marked-circle-outline text-primary mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
                            <p class="card-text mb-0">Asset Total Value</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo number_format($data_sum_purchase_price[0]['sum_total']); ?></h3>
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>



                </div>
 -->



              </div>
            </div>
          </div>
          
          <div class="row">
            
            <div class="col-12 grid-margin">


<?php 

 echo $Asset->AssetList('Assets.');

 // echo Component('asset.AssetList',array(
 //        'title'=>'Assets'
 //      ));

?>

              
            </div>
          </div>
          
          
          


<script type="text/javascript">
  (function($){
    $(function(){
      $('[data-value]').each(function(){
        $(this).val($(this).data('value'));
        console.log($(this).data('value'));
      });
    });
  })(jQuery);
</script>
