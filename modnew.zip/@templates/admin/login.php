<?php 
 if (isset($message)){
   echo $message;
 }
 // print_r($_SESSION);
?>
<div>
  <form method="post">
    <input type="text" name="email" placeholder="E-mail" />
    <input type="password" name="password" placeholder="Password" />
    <button>Login</button>
  </form>
</div>