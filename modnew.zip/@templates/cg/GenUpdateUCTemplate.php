

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @services/DataRequirement);

*/

class <?php echo $name; ?>Update{

 
 function Exec(){
   
   $data1 = $this->DataRequirement->Check('data','id');
   $data = $data1['data'];
   $id = $data1['id'];
   
   foreach ($id as $ID){
    $this->Db->Where('id',$ID);

    $this->Db->Update('<?php echo strtolower($name); ?>',$data);
   }

   $this->RequestResponse->SetResponse('message','<?php echo $name; ?> updated successfully.');

 }


}