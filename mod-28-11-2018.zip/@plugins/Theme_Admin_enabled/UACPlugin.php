<?php 

/**

@Inject(@services/Db,
        @services/RequestResponse,
        @usecases/entity/EntityLogin,
        @usecases/entity/EntityRegister,
        @usecases/entity/EntityVerify,
        @usecases/entity/EntitySendVerification,
        @usecases/entity/EntityChangePassword,
        @usecases/entity/EntityPasswordRecover,
        @usecases/entity/EntityPasswordRecoverChange,
        @usecases/entity/EntityAccountUpdate,
        @services/entity/EntityCommit);

*/


class UACPlugin{

  private $entity;

/***

  LoginAction,RegisterAction,Account,AccountAction,RecoverPasswordAction,RecoverPasswordChangeAction

*/


  function Validate($entity=''){
    $this->entity = $entity;
    // return $this->Db->TableExists($entity);
    return $this->SideEffect->IsEntity();
  }


  function Login_Action(){
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->EntityCommit->CallUCAction($this->EntityLogin); 
  }

  function Register_Action(){
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->EntityCommit->CallUCAction($this->EntityRegister); 
  }

  function Account(){
    
    $id = $_SESSION['accounts'][$this->entity]['id'];

    $record = $this->Db->Where('id',$id)->Get($this->entity);

    InjectViewClass::SetKey('data',$record[0]);

  }

  function Account_Action(){
   $this->RequestResponse->AddRequest('entity',$this->entity);  
   $this->EntityCommit->CallUCAction($this->EntityAccountUpdate);  
  }

  function RecoverPassword_Action(){ ///*****once online.
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->EntityCommit->CallUCAction($this->EntityPasswordRecover);  
  }

  function RecoverPasswordChange_Action($id=''){
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->RequestResponse->AddRequest('id',$id);
   $this->EntityCommit->CallUCAction($this->EntityPasswordRecoverChange);  
  }

  function VerifyAccount($id=''){
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->RequestResponse->AddRequest('id',$id);
   $this->EntityCommit->CallUCAction($this->EntityVerify);  
  }

  function ChangePassword_Action(){
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->EntityCommit->CallUCAction($this->EntityChangePassword);  
  }

  function SendVerification_Action(){
   $this->RequestResponse->AddRequest('entity',$this->entity);
   $this->EntityCommit->CallUCAction($this->EntitySendVerification);  
  }



}


