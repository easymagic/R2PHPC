<?php 

/**

@Inject(@controllers/Base);

*/

class CrudTemplatePlugin{
  
  function SetEntity($entity=''){}

  function GetScope(){
    // echo "string...scp.";
    return 'private';
  }


  function Index_Render($view){
    // echo "string...";
     return $this->Base->BackEndLayout($view->View());
  }


  function Edit_Render($view){
    // print_r($view);
    return $this->Base->BackEndLayout($view->View());
  }


  function Add_Render($view){
   return $this->Base->BackEndLayout($view->View());
  }


  function Remove_Render($view){
    return $this->Base->BackEndLayout($view->View());
  }


}


