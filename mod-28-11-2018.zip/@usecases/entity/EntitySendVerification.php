<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @usecases/entity/EntityRegister);


*/
class EntitySendVerification{

  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $this->EntityCommit->RequireEntity($request);
     // $entity = $this->EntityCommit->GetEntity();

     if (!isset($request['email']))throw new Exception("email-param required!", 1);

     $email = $request['email'];

     $this->EntityRegister->SendVerificationEmail('email',$email);

     $this->RequestResponse->SetResponse('message','Account verification sent to your E-mail.');


  }


}

