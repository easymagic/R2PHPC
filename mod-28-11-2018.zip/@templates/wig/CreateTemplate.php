<script> var message = '<?php echo $message; ?>';</script>    
      <div id="breadcrumb">
        <ul class="breadcrumb">
           <li><i class="fa fa-home"></i><a href="">Home</a></li>
           <li class="active">Add Wig</li>   
        </ul>
      </div><!-- /breadcrumb-->      
     




     <div class="col-md-10 padding-md">




<div class="panel panel-default">
          <div class="panel-heading">
            Add Wig            
            <span class="pull-right">
              <label class="label-checkbox inline">
                <a href="" data-back="Wig">Back</a>
                <!-- <input type="checkbox" id="toggleLine" checked=""> -->
                <span class="custom-checkbox"></span>
                <!-- Toggle Line -->
              </label>
            </span>

          </div>
          <div class="panel-body">
            <div data-message></div>
            <form id="formToggleLine" method="post" class="form-horizontal no-margin form-border" enctype="multipart/form-data">
              
   

<div class="form-group">
  <label class="col-lg-2 control-label">Id</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[id]" type="text" placeholder="Id">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Category Id</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[category_id]" type="text" placeholder="Category Id">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Name</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[name]" type="text" placeholder="Name">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Description</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[description]" type="text" placeholder="Description">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Image</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[image]" type="text" placeholder="Image">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Price</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[price]" type="text" placeholder="Price">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Date Created</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[date_created]" type="text" placeholder="Date Created">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 

<div class="form-group">
  <label class="col-lg-2 control-label">Qty</label>
  <div class="col-lg-10">
    <input class="form-control"  name="data[qty]" type="text" placeholder="Qty">

<!--     <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
 -->    
  </div><!-- /.col -->
</div><!-- /form-group -->


 
            

<div class="form-group">
      <div class="col-lg-offset-2 col-lg-10">
        <input type="submit" value="Create" class="btn btn-success btn-sm" />
      </div><!-- /.col -->
</div>


  <input type="hidden" name="ccmd" value="wig/WigCreate" />


            </form>
          </div>
</div>




    
    </div>  









<script type="text/javascript">
  (function($){
    $(function(){


      $('[data-message]').html(message);


    });
  })(jQuery);
</script>
