<select class="input-sm form-control inline" name="data[<?php echo $key; ?>]" data-select-value="<?php echo $value; ?>">
	<option value="">--Select--</option>
	<?php 
       foreach ($data as $k=>$v){
     ?>

     <option value="<?php echo $v[$key]; ?>"><?php echo $v[$label]; ?></option>

     <?php 
       }
	?>
</select>



