<?php 
session_start();



require_once('FrontController.php');
require_once('DIContainer.php');


 function StartBuffer(){
  ob_start();
 }

 function GetBuffer(){
  $r = ob_get_contents();
  ob_end_clean();
  return $r;
 }

