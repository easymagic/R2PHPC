<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/RequestResponse,
        app-x/core/EmailQueue);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;
   

  private function HandleRedirects(){
    global $redirect;
    if (!empty($redirect)){
      header("Location: " . BASE_URL . $redirect);
      $redirect = '';
      exit();
    }    
  }

  private function HandleEmailQueue(){
    global $emailQueue;
    //subject,message,to,from
    foreach ($emailQueue as $k=>$v){
       if (isset($v['subject']) && isset($v['message']) && isset($v['to']) && isset($v['from'])){
         $this->EmailQueue->SetSubject($v['subject']); 
         $this->EmailQueue->SetMessage($v['message']);
         $this->EmailQueue->SetTo($v['to']);
         $this->EmailQueue->SetFrom($v['from']);
         $this->EmailQueue->Send();
       }
    }
    $emailQueue = array(); //clear the queue.
  }

  function Dispatch($plugins,$obj,$name,$method,$args){

    global $data;
    global $dataJSON;
    global $actionPermission;
    global $permission;
    global $accounts;
    // global $redirect;

    $buffer = '';

    if (ActionTrigerred()){

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_ActionPermission',$args);
       if ($actionPermission){
         $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Action',$args);
         $this->CallAction($obj,$method . '_Action',$args);
       }else{
        throw new Exception("You do not have the permission to call this action!");
       }

    }else{

       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_NoAction',$args);

    }
    
    //handle email queue
    $this->HandleEmailQueue();
    
    //handle $redirects
    $this->HandleRedirects();

    //handle $accounts
    if (isset($accounts['accounts']))
    foreach ($accounts['accounts'] as $k=>$accountSessionName){
      $accountSessionName = ucfirst($accountSessionName);
      $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,'Logged_' . $accountSessionName,$args);
    }

    $this->HandleRedirects();


    

    if ($permission){

       $test = $this->CallAction($obj,$method,$args);
       if (!empty($test)){
        $buffer.=$test;
       }
       $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Data',$args);

       $this->HandleRedirects();

       foreach ($data as $k=>$v){
         if (!is_object($v)){
           $dataJSON[$k] = $v;
         }
       }

       $buffer.= $this->PluginLoader->CallPluginHooks($plugins,$obj,$name,$method . '_Render',$args);

    }else{
      
      throw new Exception("You do not have the permission to view this page!");

    }

    
    return $buffer;

  }



  function CallAction($obj,$method,$args){

      return $this->ObjectProxy->CallProxy($obj,$method,$args);

  }




}