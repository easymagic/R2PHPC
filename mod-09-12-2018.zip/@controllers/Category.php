<?php 

/**

@Inject(@services/Db,@templates/cropit/CropitTemplate,
        @services/HttpService);


*/


class Category{

  function UsePlugins(){
    return array('CrudPlugin','CrudTemplatePlugin');
    //OEM: (Original Equipment Manufacturer).
  }

  function Index(){
    // $this->Db->Where('id',41);
  }

  function Greet(){
    return 'Good Evening.';
  }

  function GetEntities(){
    return array('admin1'=>'admin','member'=>'member');
  }

  function GetCountEntities(){
    return array('category'=>'category');
  }

  function GetSumEntities(){
    return array('category1'=>array('category','id'));
  }

  function BeforeDataCount_category(){
    // $this->Db->Where('id','8');
  }

  function BeforeDataSum_category(){
   $this->Db->Where('id','8'); 
  }

  function BeforeDataSeek_admin1(){
    $this->Db->Where('email','admin1');
    // echo 'called before seek admin';
  }

  function BeforeDataSeek_member(){
    // echo 'called before seek member<br />.';
  }

  
  function Init(){
   // $this->Repository->UseResource('category');  
  }

  function Before_Index(){
    // $this->Db->Where('id','8');
  }

  function Before_DropDown(){
   // $this->Db->Where('id','8'); 
  }

  // function Index1(){
  //   return '..hello..';
  // }

  function Test(){
    // $result = $this->FrontController->GetDispatch('Category/Index');
    // $result2 = $this->HttpService->DispatchAPI('Apiv2/Collection/admin/All');
    // print_r($result2);
  ?>
  <form method="post">
    <input type="text" name="data[email]" />
    <button>Send</button>
  </form>
  <?php 
  }

  function Test_Action(){
    global $postData;
    global $session;
    global $emailQueue;
    $session['name'] = 'R2';
    // global $redirect;
    print_r($postData);

    $emailQueue[] = array('subject'=>'test subject','message'=>'test message','to'=>'test to','from'=>'test from.');
    // print_r($_SESSION);
    // $redirect = 'Category/Add';

  }


  // function DropDown($k,$v,$filterKey,$filterValue){
  // }




}
 