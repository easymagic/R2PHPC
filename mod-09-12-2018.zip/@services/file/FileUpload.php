<?php 

class FileUpload{
  
  private $uploaded_file = null;
  
  function DoUpload($hnd,$key){
    $tmp = $hnd['tmp_name'];
    $name = $this->GetUniqueName($hnd['name']);
    // echo $name;
    $target_path = 'uploads/' . $key . '-uploads/';
    $target = "$target_path$name";
    // echo $target;
    
    if (move_uploaded_file($tmp, $target)){
       $this->uploaded_file = $target;
       return true;
    }else{
       return false;
    }
    
  }

  private function GetUniqueName($name){
    return uniqid() . $name;
  }

  private function GetDataUniqueName(){
    return uniqid() . '.png';
  }

  function GetUploadedFile(){
    return $this->uploaded_file;
  }

  function DoDataUpload($k,$base64string){
  
    $target_path = 'uploads/' . $k . '-uploads/';
    $dataName = $target_path . $this->GetDataUniqueName();
    //data:image/png;base64,
    $base64string = explode('data:image/png;base64,', $base64string);
    $base64string = $base64string[1];
    
    $hnd = fopen($dataName, 'wb');
    fwrite($hnd, base64_decode($base64string));
    fclose($hnd);

    // echo $base64string;
    // file_put_contents($dataName, base64_decode($base64string));
    $this->uploaded_file = $dataName;

  }


}