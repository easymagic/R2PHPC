<?php
error_reporting(E_ALL);
require_once('config.php');
require_once('app-x/core/core.php');
$PageObject = InjectClass('FrontController'); 
echo $PageObject->DispatchRequest();
// echo $PageObject->DispatchRequest();
// $PageObject->DecodePluginUse();
// $PageObject->DispatchRequest();