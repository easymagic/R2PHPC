<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit);


*/


class EntityVerify{


  function Exec(){

     $request = $this->RequestResponse->GetRequest();
     $id = $request['id'];
     $id = base64_decode($id);
     $this->EntityCommit->RequireEntity($request);
     $entity = $this->EntityCommit->GetEntity();

     $this->Db->Where('id',$id);
     $this->Db->Update($this->entity,array('verified'=>'1'));

     $this->RequestResponse->SetResponse('message','Account succesfully verified.');

  }


}

