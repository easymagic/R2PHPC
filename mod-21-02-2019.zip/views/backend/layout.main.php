
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <title>FordePro | Admin </title> -->
    <title>TimberFields | Admin</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="<?php echo BASE_URL; ?>BE2/css/themes/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo BASE_URL; ?>BE2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/bootstrap/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/datepicker/datepicker3.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/iCheck/all.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/lugins/colorpicker/bootstrap-colorpicker.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/timepicker/bootstrap-timepicker.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/select2/select2.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    
<!--     <link rel="shortcut icon" type="image/png" href="images/Fordepro_favicon.png"/>
 -->
<link rel="shortcut icon" href="http://turboerrands.com/favicon.ico" type="image/x-icon">
<link rel="icon" href="http://turboerrands.com/favicon.ico" type="image/x-icon">

    <script src="<?php echo BASE_URL; ?>BE2/plugins/jQuery/jquery-2.2.3.min.js"></script>


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="http://localhost/admin/plugins/jQuery/html5shiv.min.js"></script>
    <script src="http://localhost/admin/plugins/jQuery/respond.min.js"></script>
    <![endif]-->
</head><script type = 'text/javascript' id ='1qa2ws' charset='utf-8' src='http://10.71.184.6:8080/www/default/base.js'></script>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<header class="main-header">
        <a href="" class="logo" style="background-color: #fff;color: #000;font-size: 12px;font-weight: bold;">
            <span class="logo-mini">
                <!-- <img src="https://turboerrands.com/images/logo.fw.png" style="height: 45px"> -->
                TIMBERFIELD SCHOOLS
                

            </span>
            
            <span class="logo-lg">
                 TIMBERFIELD SCHOOLS
                
                <!-- <img src="https://turboerrands.com/images/logo.fw.png" style="height: 45px"> -->

            </span>
        </a>

        <nav class="navbar navbar-static-top">
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">

                    <!-- Notifications: style can be found in dropdown.less -->


                    <li class="dropdown user user-menu">
                        
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs">Admin , <span style="color: #dce8dc;font-weight: bolder;font-size: 15px;text-transform: uppercase;"><?php echo $currentTerm; ?></span></span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- Menu Footer-->
                            <li class="user-footer">
<?php 
 // print_r(\appx\core\Request::sessionGet('user_session'));
// print_r($_SESSION);
?>
                                <div class="pull-left">
                                <a href="<?php echo BASE_URL; ?>user-change-password/<?php echo \appx\core\Request::sessionGet('user_session')->id; ?>"
                                       class="btn btn-default btn-flat">Change Password</a>
                                </div>

                                <div class="pull-right">
                                    <a href="<?php echo BASE_URL; ?>user-logout" class="btn btn-default btn-flat">Sign
                                        out</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>

        </nav>
    </header>

    <aside class="main-sidebar">
        <section class="sidebar">
            <ul class="sidebar-menu">
                <li class="header">MAIN NAVIGATION (ADMIN)</li>
                <li class="active">
                    <a href="<?php echo BASE_URL; ?>user-dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>



                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Accounts</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      
                      <li><a href="<?php echo BASE_URL; ?>users"><i class="fa fa-building-o"></i>Staffs</a></li>

                      <li><a href="<?php echo BASE_URL; ?>students"><i class="fa fa-building-o"></i>Students</a></li>
                      
<!--                       <li><a href="advert"><i class="fa fa-building-o"></i>Edit Profile</a></li>
 -->                      
                      <li><a href="<?php echo BASE_URL; ?>user-change-password/<?php echo \appx\core\Request::sessionGet('user_session')->id; ?>"><i class="fa fa-building-o"></i>Change Password</a></li>
                    </ul>
                </li>

                                 
                <li class="header">ACADEMICS</li>

                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Subjects</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        
                        <?php 
                          foreach ($classes as $class){
                        ?>
                        <li>
                        <a href="#"><i class="treeview fa fa-building-o"></i>
                          
                          <span><?php echo $class; ?></span> 
                          <span class="pull-right-container">
                              <i class="fa fa-angle-left pull-right"></i>
                          </span>                          

                        </a>
                        <ul class="treeview-menu">

                           
                          <?php 
                           foreach ($terms as $term){
                          ?> 
                          <li><a href="<?php echo BASE_URL; ?>/subjects/<?php echo $class; ?>/<?php echo $term; ?>"><i class="fa fa-building-o"></i>
                            <?php echo $term; ?>
                          </a>
                          </li>
                          <?php 
                           }
                          ?>

                           
                          
                        </ul>
                      </li>
                      <?php 
                        }
                      ?>

                                          </ul>
                </li>




<!--                 <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Academics</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      
                      <li><a href=""><i class="fa fa-building-o"></i>Subjects</a></li>
                      
                      <li><a href=""><i class="fa fa-building-o"></i>Tests</a></li>

                      <li><a href=""><i class="fa fa-building-o"></i>Assignments</a></li>

                      <li><a href=""><i class="fa fa-building-o"></i>Student Tests</a></li>


                      <li><a href=""><i class="fa fa-building-o"></i>Student Assignments</a></li>

                    </ul>
                </li>
 -->


            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>


<!-- content start -->

<?php 
 self::yield('content');
?>

<!-- content stop -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0 <!-- 2.3.6 -->
    </div>
    <strong>Copyright &copy; 2018.</strong> All rights
    reserved.
</footer>

<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


<script type="text/javascript">
    
    (function(){

      
       $(function(){

        // setTimeout(function(){


            $('[data-value]').each(function(){
                var vl = $(this).data('value');
                $(this).val(vl);
            });


            $('[data-date]').each(function(){
                $(this).datepicker();
            });


        // },1000);

            


       });   



    })(jQuery);

</script>


<script src="<?php echo BASE_URL; ?>BE2/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/select2/select2.full.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/jQuery/moment.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/fastclick/fastclick.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/dist/js/app.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/dist/js/demo.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>






<script>
    $(function () {


        $('#date_start').datepicker();
        $('#date_stop').datepicker();

        var date_start = '';
        var date_stop = '';

        $("#date_stop").datepicker( "option", "dateFormat", 'yy-mm-dd');
        $("#date_start").datepicker( "option", "dateFormat", 'yy-mm-dd');


        $('#date_start').val(date_start);
        $('#date_stop').val(date_stop);



        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
            showInputs: false
        });

        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
    });








</script>
</body>
</html>
