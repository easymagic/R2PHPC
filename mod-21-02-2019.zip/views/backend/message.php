<?php 
 if (isset($message)){
 	$cls = 'success';
 	if (isset($error)){
       if ($error){
         $cls = 'danger';
       }
 	}else{
 	  $cls  = 'success';	
 	}
?>
<div class="col-xs-12">
	<div class="alert alert-<?php echo $cls; ?>"><?php echo $message; ?></div>
</div>
<?php 
 }
?>