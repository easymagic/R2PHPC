<!DOCTYPE html>
<html>
<head>
	<title>Backend</title>
</head>
<body>

<h1>Title</h1>


<div>
	<?php 
       self::yield('content','default');  
	?>
</div>
</body>
</html>