<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Edit Subject
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Subject</li>
      </ol>
</section>


<section class="content">
<div class="row">

<div class="col-md-8">
          
<div class="box box-primary">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  



              <h3 class="box-title">
                <?php echo ucfirst($subject->class); ?>&nbsp;/&nbsp;<?php echo ucfirst($subject->term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subjects/<?php echo $subject->class; ?>/<?php echo $subject->term; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form enctype="multipart/form-data" role="form" method="post" action="<?php echo BASE_URL; ?>subject-edit/<?php echo $subject->id; ?>">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Name</label>
                  <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Subject Name" value="<?php echo $subject->name; ?>">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      </div>

<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


