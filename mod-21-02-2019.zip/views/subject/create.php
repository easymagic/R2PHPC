<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Add Subject
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Subject</li>
      </ol>
</section>


<section class="content">
<div class="row">

<div class="col-md-8">
          
<div class="box box-primary">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  



              <h3 class="box-title">
                <?php echo ucfirst($class); ?>&nbsp;/&nbsp;<?php echo ucfirst($term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subjects/<?php echo $class; ?>/<?php echo $term; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form enctype="multipart/form-data" role="form" method="post" action="<?php echo BASE_URL; ?>subject-create/<?php echo $class; ?>/<?php echo $term; ?>">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Name</label>
                  <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Subject Name">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      </div>

<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


