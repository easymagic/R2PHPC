<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Subjects
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Subjects</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-10">
          <div class="box">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  


              <h3 class="box-title">
                <?php echo ucfirst($class); ?>&nbsp;/&nbsp;<?php echo ucfirst($term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subject-create/<?php echo $class; ?>/<?php echo $term; ?>" class="btn btn-success btn-sm pull-right"> + Add Subject</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Name</th>
                  <th>Tests</th>
                  <th>Assignments</th>
                  <th>Date Created</th>
                  <th>Last Updated</th>
                  <th>Operations</th>
                </tr>

                <?php 
                 foreach ($subjects as $k=>$subject){
                ?>
                <tr>
                  <td><?php echo $k+1; ?></td>
                  <td><?php echo $subject->name; ?></td>
                  <td><?php echo count($subject->tests); ?></td>
                  <td><?php echo count($subject->assignments); ?></td>
                  <td><?php echo $subject->date_created; ?></td>
                  <td><?php echo $subject->last_updated; ?></td>
                  <td>
                     <a href="<?php echo BASE_URL; ?>subject-edit/<?php echo $subject->id; ?>" class="btn btn-primary btn-sm">Edit</a>

                    <?php 
                     if ($currentTerm == $term){
                    ?>

                  <a href="<?php echo BASE_URL; ?>subject/<?php echo $subject->id; ?>/tests" class="btn btn-primary btn-sm">Tests</a>
                  <a href="<?php echo BASE_URL; ?>subject/<?php echo $subject->id; ?>/assignments" class="btn btn-success btn-sm">Assignment</a>

                    <?php 
                     }
                    ?> 

                  </td>
                </tr>
                <?php 
                  }
                ?>
                

              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      </div>
<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


