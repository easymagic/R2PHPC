<?php 
self::section('content');
?>

<div class="content-wrapper" style="min-height: 476px;">
  <section class="content-header">
      <h1>
        Add Assignment (<?php echo $subject->name; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Assignment</li>
      </ol>
</section>


<section class="content">
<div class="row">

<div class="col-md-8">
          
<div class="box box-primary">
            <div class="box-header with-border">

    <div>
        <?php self::extend('backend/message'); ?>
    </div>  



              <h3 class="box-title">
                <?php echo ucfirst($subject->class); ?>&nbsp;/&nbsp;<?php echo ucfirst($subject->term); ?>
              </h3>

              <a href="<?php echo BASE_URL; ?>subject/<?php echo $subject->id ?>/assignments" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form enctype="multipart/form-data" role="form" method="post" action="<?php echo BASE_URL; ?>subject/<?php echo $subject->id ?>/assignment/create">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Content</label>
                  <textarea class="form-control" name="content" placeholder="Assignment Content"></textarea>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Corrections</label>
                  <textarea class="form-control" name="correction" placeholder="Assignment Correction"></textarea>
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      </div>

<?php 
 
 self::endSection();

 self::extend('backend/layout.main');

?>


