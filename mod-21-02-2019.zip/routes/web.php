<?php 
use appx\core\Route;

$guest = ['guest:user_session,user-dashboard'];
$auth = ['auth:user_session,user-login'];

Route::get('/default','controllers\UserController@userLogin',$guest);

// Route::get('/test/(test)','controllers\Home@test',['auth:user,admin']);
Route::get('/test/(test)','controllers\Home@test');

// registerRoute('get','/default','controllers\Home:index');

Route::get('/user-login','controllers\UserController@userLogin',$guest);

Route::get('/user-logout','controllers\UserController@userLogOutAction',$auth);


Route::get('/user-dashboard','controllers\UserController@userDashboard',$auth);


Route::post('/user-login','controllers\UserController@userLoginAction',$guest);

Route::get('/user-create','controllers\UserController@userCreate',$auth);

Route::post('/user-create','controllers\UserController@userCreateAction',$auth);

Route::get('/user-change-password/(user)','controllers\UserController@userChangePassword',$auth);

Route::post('/user-change-password/(user)','controllers\UserController@userChangePasswordAction',$auth);

Route::get('/user-edit-profile/(user)','controllers\UserController@userEditProfile',$auth);

Route::post('/user-edit-profile/(user)','controllers\UserController@userEditProfileAction',$auth);

Route::get('/user-change-password-other/(user)','controllers\UserController@userChangePasswordOther');

Route::post('/user-change-password-other/(user)','controllers\UserController@userChangePasswordOtherAction');

Route::get('/user-enable-account/(user)','controllers\UserController@enableAccountAction');
Route::get('/user-disable-account/(user)','controllers\UserController@disableAccountAction');


//enableAccountAction
Route::get('/users','controllers\UserController@index');

//oui
Route::get('/students','controllers\StudentController@index',$auth);
Route::get('/student-create','controllers\StudentController@studentCreate',$auth);
Route::post('/student-create','controllers\StudentController@studentCreateAction',$auth);
Route::get('/student-edit/(student)','controllers\StudentController@studentEdit',$auth);
Route::post('/student-edit/(student)','controllers\StudentController@studentEditAction',$auth);

Route::get('/student-change-password/(student)','controllers\StudentController@studentChangePassword',$auth);

Route::post('/student-change-password/(student)','controllers\StudentController@studentChangePasswordAction',$auth);



Route::get('/subjects/(class)/(term)','controllers\SubjectController@index');
Route::get('/subject-create/(class)/(term)','controllers\SubjectController@subjectCreate');
Route::post('/subject-create/(class)/(term)','controllers\SubjectController@subjectCreateAction');
Route::get('/subject-edit/(subject)','controllers\SubjectController@subjectEdit');
Route::post('/subject-edit/(subject)','controllers\SubjectController@subjectEditAction');


///subject test.
Route::get('/subject/(subject)/tests','controllers\TestController@index');
Route::get('/subject/(subject)/test/create','controllers\TestController@create');
Route::post('/subject/(subject)/test/create','controllers\TestController@createAction');
Route::get('/subject-test/(test)','controllers\TestController@detail');
Route::post('/subject-test/(test)','controllers\TestController@editAction');

Route::get('/subject-test-students/(test)','controllers\StudentTestController@index');
Route::post('/subject-test-students/(test)/(studentTest)','controllers\StudentTestController@edit');


///subject assignment.
Route::get('/subject/(subject)/assignments','controllers\AssignmentController@index');
Route::get('/subject/(subject)/assignment/create','controllers\AssignmentController@create');
Route::post('/subject/(subject)/assignment/create','controllers\AssignmentController@createAction');
Route::get('/subject-assignment/(assignment)','controllers\AssignmentController@detail');
Route::post('/subject-assignment/(assignment)','controllers\AssignmentController@editAction');

Route::get('/subject-assignment-students/(assignment)','controllers\StudentAssignmentController@index');
Route::post('/subject-assignment-students/(assignment)/(studentTest)','controllers\StudentAssignmentController@edit');


// Route::post('/student-profile/(student)','controllers\Home@studentLoginAction');

//User
// registerRoute('post','/user/login/action','controllers\UserController:loginAction');
// registerRoute('post','/user/logout/action','controllers\UserController:logoutAction');

// registerRoute('get','/user/login','controllers\UserController:login');
// registerRoute('get','/user','controllers\UserController:index');
// registerRoute('get','/user/(user)/edit','controllers\UserController:edit');
// registerRoute('get','/user/add','controllers\UserController:add');
// registerRoute('get','/user/change/password/(user)','controllers\UserController:changePassword');


// registerRoute('post','/user/change/password/(user)/action','controllers\UserController:changePasswordAction');



// //Subjects
// registerRoute('get','/subject','controllers\SubjectController:index');
// registerRoute('get','/subject/(subject)/edit','controllers\SubjectController:edit');
// registerRoute('get','/subject/add','controllers\SubjectController:add');
// registerRoute('post','/subject','controllers\SubjectController:create');
// registerRoute('post','/subject/(subject)','controllers\SubjectController:update');
// registerRoute('post','/subject/(subject)/delete','controllers\SubjectController:delete');


// //Test
// registerRoute('get','/test','controllers\TestController:index');
// registerRoute('get','/test/add','controllers\TestController:add');
// registerRoute('post','/test','controllers\TestController:create');

// //Assignment
// registerRoute('get','/assignment','controllers\AssignmentController:index');
// registerRoute('get','/assignment/add','controllers\AssignmentController:add');
// registerRoute('post','/assignment','controllers\AssignmentController:create');



// //Student
// registerRoute('get','/student','controllers\StudentController:index');
// registerRoute('get','/student/(student)/edit','controllers\StudentController:edit');
// registerRoute('get','/student/add','controllers\StudentController:add');

// registerRoute('post','/student','controllers\StudentController:store');
// registerRoute('post','/student/(student)','controllers\StudentController:update');
// registerRoute('post','/student/(student)/delete','controllers\StudentController:delete');
// registerRoute('post','/student/change/password/(student)',
// 	          'controllers\StudentController:changePassword');


// //StudentTest
// // registerRoute('post','/create-student-test','controllers\StudentTestController:store');
// registerRoute('get','/student/test','controllers\StudentTestController:index');
// // registerRoute('get','/student/test/(studentTest)/edit',
// // 	          'controllers\AssignmentController:edit');
// // registerRoute('get','/assignment/add','controllers\AssignmentController:add');

// // registerRoute('post','/update-student-test/(studentTest)','controllers\StudentTestController:update');
// registerRoute('post','/student/test/(studentTest)/delete',
// 	          'controllers\StudentController:delete');


// //StudentAssignment
// registerRoute('get','/student/assignment','controllers\StudentAssignmentController:index');
// // registerRoute('get','/assignment/(test)/edit','controllers\AssignmentController:edit');
// // registerRoute('get','/assignment/add','controllers\AssignmentController:add');

// // registerRoute('post','/create-student-test','controllers\StudentTestController:store');
// // registerRoute('post','/update-student-assignment/(studentAssignment)','controllers\StudentAssignmentController:update');
// // registerRoute('post','/delete-student-assignment/(studentAssignment)','controllers\StudentAssignmentController:delete');


// ///student-profile
// registerRoute('get','/student/login',
// 	          'controllers\HomeController:login');
// registerRoute('get','/student/profile/(student)',
// 	          'controllers\HomeController:profile');
// registerRoute('get','/student/test/',
// 	          'controllers\HomeController:test');
// registerRoute('get','/student/assignment/',
// 	          'controllers\HomeController:assignment');
// registerRoute('get','/student/test/(studentTest)/show',
// 	          'controllers\HomeController:testShow');
// registerRoute('get','/student/assignment/(studentAssignment)/show',
// 	          'controllers\HomeController:assignmentSubmit');
// registerRoute('get','/student/change/password/(student)/show',
// 	          'controllers\HomeController:changeStudentPasswordProfile');


// registerRoute('post','/student/login',
// 	          'controllers\HomeController:loginAction');

// registerRoute('post','/student/logout',
// 	         'controllers\HomeController:logout');

// registerRoute('post','/student/update/profile/(student)',
// 	          'controllers\HomeController:profileAction');

// registerRoute('post','/student/change/password/profile/(student)',
// 	          'controllers\HomeController:changeStudentPasswordProfileAction');


// registerRoute('post','/student/submit/test/(studentTest)',
// 	          'controllers\HomeController:submitStudentTest');
// registerRoute('post','/student/submit/assignment/(studentAssignment)',
// 	          'controllers\HomeController:submitStudentAssignment');

// // registerRoute('post','/student-submit-test/(test)','controllers\HomeController:submitStudentTest');

// registerRoute('get','/test2/(test)','controllers\Home:test');

