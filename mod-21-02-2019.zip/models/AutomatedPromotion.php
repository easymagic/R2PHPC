<?php 

namespace models;

class AutomatedPromotion{


  

   static function runPromotions(){

   	  $students = Student::all();

   	  foreach ($students as $student){
        
   	  	$student->determinePromotion();

   	  }

   }



}