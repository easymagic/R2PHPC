<?php 

namespace models;

class Assignment extends \models\BaseModel{
  
  protected $table = 'assignment';

  
  function subject(){
    return $this->belongsTo(\models\Subject::class,'subject_id');
  }

  function studentAssignments(){
  	return $this->hasMany(\models\StudentAssignment::class,'assignment_id');
  }

  



}