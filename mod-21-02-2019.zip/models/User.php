<?php 

namespace models;

class User extends \models\BaseModel{
  
  protected $table = 'user';


   function userRegister($data){
    return $this->register($data,null,'Staff profile created successfully.');
   }



}