<?php 

namespace models;

class StudentAssignment extends \models\BaseModel{
  
  protected $table = 'student_assignment';

  
  function assignment(){
   return $this->belongsTo(\models\Assignment::class,'assignment_id');	
  }

  function student(){
   return $this->belongsTo(\models\Student::class,'student_id');		
  }

  



}