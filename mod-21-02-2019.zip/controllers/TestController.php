<?php 

namespace controllers;

use models\Subject;
use models\Test;
use models\Student;
use models\StudentTest;
use appx\core\Request;

class TestController extends \controllers\BaseController{

   

    function index(Subject $subject){
      return $this->view('test/index',[
          'tests'=>$subject->tests,
          'subject'=>$subject
      ]);
    }

    function create(Subject $subject){
      return $this->view('test/create',[
          'subject'=>$subject
      ]);      
    }

    function detail(Test $test){
       return $this->view('test/detail',[
         'test'=>$test
       ]); 
    }

    function createAction(Subject $subject){

      $data = Request::all();
      $user = Request::sessionGet('user_session');
      $user_id = $user->id;

      $testID = Test::create([
        'class'=>$subject->class,
        'term'=>$subject->term,
        'content'=>$data['content'],
        'correction'=>$data['correction'],
        'date_created'=>date('Y-m-d h:i:s'),
        'subject_id'=>$subject->id,
        'user_id'=>$user_id
      ]);
      
      $students = Student::allByClass($subject->class);

      foreach ($students as $student){

         StudentTest::create([
           'term'=>$subject->term,
           'class'=>$subject->class,
           'student_id'=>$student->id,
           'student_response'=>'',
           'date_created'=>date('Y-m-d h:i:s'),
           'date_submitted'=>'',
           'passed'=>'',
           'failed'=>'',
           'correction'=>$data['correction'],
           'result'=>'',
           'remark'=>'',
           'test_id'=>$testID
         ]);

      }

      $subject->setSuccess('Test created successfully.');
      $this->setResponse($subject->getMessage());

      //subject/8/tests
      redirect('subject/' . $subject->id . '/tests');

    }

    // function edit(Test $test){
      
    // }

    // function editAction(Test $test){

    // }
  




}	
