<?php 

namespace controllers;

class BaseController{

  
   function view($template,$data=[]){
     
     $data['currentTerm'] = \models\TermAutoSelect::getCurrentTerm();
     $data['terms'] = \models\TermAutoSelect::getTerms();
     $data['staffCount'] = (new \models\User)->getCount();
     $data['studentCount'] = (new \models\Student)->getCount();
     $data['subjectCount'] = (new \models\Subject)->getCount();
     $data['assignmentCount'] = (new \models\Assignment)->getCount();
     $data['testCount'] = (new \models\Test)->getCount();
     $data['classes'] = \models\ClassLoad::getClasses();

     if (!\appx\core\Request::sessionNotSet('_flash')){
       $sessionData = \appx\core\Request::sessionGet('_flash');
       $data['message'] = $sessionData['message'];
       $data['error'] = $sessionData['error'];

       \appx\core\Request::sessionUnset('_flash');
     }

   	 return view($template,$data);

   }
   
   function initResponse(){
   	 if (\appx\core\Request::sessionNotSet('_flash')){
        \appx\core\Request::sessionSet('_flash',array());
   	 }
   }

   function setResponse($response){
     $this->initResponse();
     \appx\core\Request::sessionSet('_flash',$response);
   }


}