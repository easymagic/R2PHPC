<?php 

namespace appx\core;

class Request{

     static function all(){
     	return $_REQUEST;
     }

     static function session(){
     	return $_SESSION;
     }

     static function sessionSet($k,$v){
        $_SESSION[$k] = $v;
     }

     static function sessionGet($k){
        if (!self::sessionNotSet($k)){
          return $_SESSION[$k];
        }else{
          return null;  
        }       
     }

     static function sessionUnSet($k){
        if (!self::sessionNotSet($k)){
          unset($_SESSION[$k]);
        }  
     }

     static function sessionNotSet($k){
       return !isset($_SESSION[$k]);  
     }


     static function &post(){
     	return $_POST;
     }

     static function &get(){
     	return $_GET;
     }

}